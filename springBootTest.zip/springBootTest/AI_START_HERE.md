# AI_START_HERE —— 下次开机先读这个（给 AI 自己看的）

> 本文件是给 AI 的工作备忘。**读完就不需要再探索项目结构、不用再试错环境。**
> 用户机器每次开机都会重置：`node_modules`、`target` 会被删除，但项目源码和其他目录保留。

---

## 1. 项目是什么

Hello Kitty 主题登录/注册系统，前后端分离：

| 角色 | 路径 | 技术栈 | 端口 |
|------|------|--------|------|
| 前端 | `C:\Users\彭彭\Desktop\hellokitty-login-vue` | Vue 3 + Vite 6 | 5173 |
| 后端 | `D:\workSpace\springBootTest` | Spring Boot 3.4.5 + MyBatis-Plus 3.5.7 + **H2 内存库** | 8080 |

演示账号：`kitty` / `1234`

---

## 2. 启动方式（直接用脚本，别自己拼命令）

```bat
D:\workSpace\springBootTest\scripts\一键启动前后端.bat     ← 首选
D:\workSpace\springBootTest\scripts\一键停止全部.bat
```

单独控制：

```bat
D:\workSpace\springBootTest\scripts\启动后端.bat
D:\workSpace\springBootTest\scripts\停止后端.bat
C:\Users\彭彭\Desktop\hellokitty-login-vue\scripts\启动前端.bat
C:\Users\彭彭\Desktop\hellokitty-login-vue\scripts\停止前端.bat
```

脚本已内置：找 Java → 找 Maven → 编译 → 启动；前端检查/还原依赖 → 启动。
**全部是 GBK(cp936) + CRLF 编码**，用 UTF-8 保存会乱码甚至语法报错。改完要转回 GBK：

```powershell
$t = [IO.File]::ReadAllText($f, [Text.Encoding]::UTF8)
$t = $t.Replace("`r`n","`n").Replace("`n","`r`n")
[IO.File]::WriteAllText($f, $t, [Text.Encoding]::GetEncoding(936))
```

> PowerShell 5.1 在**无 BOM** 时按 ANSI(GBK) 解析 `.ps1`，所以 `deps-cache.ps1` 必须是 GBK，写 UTF-8 会让中文注释把语法搞崩（踩过）。

---

## 3. 实测耗时（2026-10-28 验证）

| 环节 | 耗时 | 说明 |
|------|------|------|
| 后端启动（**命中 jar 缓存**） | **6 秒** | 跳过 Maven，直接 `java -jar .build-cache\app.jar` |
| 后端启动（源码有改动，走编译） | 13-14 秒 | `mvn package` + 启动 |
| 后端启动（首次/无缓存，冷启动） | 约 30 秒 | 编译 + 打包 + 启动 |
| 前端启动（命中依赖缓存） | **3-6 秒** | 解压 13 MB 缓存 zip |
| 前端启动（无缓存，npm ci） | 约 90 秒 | 首次或缓存过期时 |

**后端 jar 缓存**（`scripts\启动后端.bat` + `scripts\src-hash.ps1`）：

- 位置：`springBootTest\.build-cache\app.jar`（29 MB）+ `src.hash`
- 指纹 = `pom.xml` + `src/**` 所有文件的 路径|大小|修改时间 的 SHA-256
- 指纹相同 → 直接用缓存 jar，**不跑 Maven**；指纹不同 → 正常编译并刷新缓存
- `target` 被删不影响，缓存不在 `target` 里
- 想强制重编：删掉 `.build-cache` 文件夹即可

**离线缓存机制**（`前台 scripts\deps-cache.ps1`）：

- 位置：`hellokitty-login-vue\.deps-cache\node_modules.zip`（幂等，可随时删）
- `save`：把 `node_modules` 打包（**必须带 base directory**，否则还原时会污染项目根目录——踩过）
- `restore`：解压到项目根，退出码 3=无缓存 / 4=已存在 / 5=缓存过期
- 过期判断：`package-lock.json` 比 zip 新 → 退出 5 → bat 删缓存走 `npm ci`，装完重新打包

---

## 4. 环境事实（已验证，别重复探测）

| 工具 | 位置 | 备注 |
|------|------|------|
| Java 17 | `C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot` | 在 PATH 里 |
| Node | `C:\Program Files\nodejs\node.exe` | 系统安装；另有 WorkBuddy 内置 `C:\Users\彭彭\.workbuddy\binaries\node\versions\22.22.2-6` |
| Maven | **不在 PATH**！用 IDEA 自带：`D:\IDEA\IntelliJ IDEA 2026.2.3\plugins\maven-plugin\lib\maven3\bin\mvn.cmd` | 3.9.16；脚本会自动按 `D:\IDEA\*` 搜索 |
| Maven 本地仓库 | `C:\Users\彭彭\.m2\repository` | 依赖已缓存 |
| MySQL | **已损坏，禁止使用** | 服务拒绝访问、`bin\mysqld.exe` 不存在 |

PowerShell 跑 Maven 的完整写法：

```powershell
$env:JAVA_HOME = "C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot"
Set-Location "D:\workSpace\springBootTest"
& "D:\IDEA\IntelliJ IDEA 2026.2.3\plugins\maven-plugin\lib\maven3\bin\mvn.cmd" -B -DskipTests package
```

> 沙箱环境变量 `SERVER__PORT=52735` 会覆盖 `server.port`，命令行启动必须 `--server.port=8080`（脚本里已 `set "SERVER__PORT="` 清掉）。

---

## 5. 数据库（H2 内存库，无需外部服务）

- URL：`jdbc:h2:mem:hello_kitty;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE;NON_KEYWORDS=USER`
- 账号 `sa` / 空密码；控制台 `http://localhost:8080/h2-console`
- 启动自动执行 `db/schema.sql` + `db/data.sql`（建表 + 演示账号 + 分级分类 + 12 条首页内容）
- **一重启数据就清空**，只剩 `kitty` —— 正常，不是 bug
- `user` 是 H2 关键字，`NON_KEYWORDS=USER` 不能删

三张表：

| 表 | 说明 |
|----|------|
| `user` | 用户 |
| `admin` | **后台管理员**：`username` 唯一，密码 `SHA-256(密码 + "hello_kitty_salt")`；演示账号 `admin` / `admin123` |
| `category` | 分级分类：`parent_id=0` 是一级，否则指向一级；`level` 1/2；`code` 唯一 |
| `home_item` | 首页内容。简介列叫 **`summary`**（`desc` 是 SQL 关键字）；`cover_bg` 存渐变背景字符串 |

演示数据：管理员 `admin` / `admin123`；4 个一级分类（甜点/穿搭/好物/心情）× 3 个二级分类（各 1 条内容）+ 12 条内容。

---

## 6. 接口 & 验证命令

**账号**

| 方法 | 路径 | 请求体 |
|------|------|--------|
| POST | `/api/auth/register` | `{"username","nickname","password"}` |
| POST | `/api/auth/login` | `{"username","password"}` |
| GET | `/api/auth/check?username=xx` | - |

**首页**

| 方法 | 路径 | 参数 |
|------|------|------|
| GET | `/api/home/categories` | - （一级 + children，每节点带 count） |
| GET | `/api/home/items` | `keyword` `categoryId` `includeChildren` `sort` `page` `size` |
| GET | `/api/home/hot` | `limit` |
| GET | `/api/home/items/{id}` | - （浏览量 +1） |
| GET | `/api/home/stats` | - |

搜索规则（`HomeServiceImpl.applyKeyword`）：多词之间是 AND；单个词在 标题/简介/标签 命中任一即可；
**若该词本身是分类名，则连同它所有子分类下的内容一起命中**（搜「甜点」得 3 条）。
`categoryId` 传一级分类默认含子分类，`includeChildren=false` 可关；`size` 上限 50。

**后台管理**（所有 `/api/admin/**` 都要请求头 `X-Admin-Token`，否则 401）

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/admin/auth/login` | `{"username","password"}` → 返回 `data.token` |
| POST | `/api/admin/auth/logout` | 作废当前 token |
| GET | `/api/admin/stats` | 概览：内容总数/在架下架/分类数/累计点赞/浏览/热门数 |
| GET | `/api/admin/items` | 内容分页：`page` `size` `keyword` `status`(0下架/1上架) `categoryId` |
| GET | `/api/admin/items/{id}` | 单条详情 |
| POST | `/api/admin/items` | 新增：必填 `title` `categoryId`，其余可选 |
| PUT | `/api/admin/items/{id}` | 编辑（全字段） |
| DELETE | `/api/admin/items/{id}` | 删除 |
| GET | `/api/admin/categories` | 分类平铺列表（带 `parentName`/`level`） |
| POST | `/api/admin/categories` | 新增分类：一级 `parentId=0`，二级 `parentId=一级id` |
| PUT | `/api/admin/categories/{id}` | 编辑（同名同级唯一、不能把二级的父级设成二级） |
| DELETE | `/api/admin/categories/{id}` | 删除：**有子分类 / 有内容的分类不能删** |

鉴权实现：`AdminTokenStore`（内存 `Map<token, adminId>`，重启清空），`AdminAuthInterceptor` 拦 `/api/admin/**`（登录/登出除外）。
前端：导航栏「后台管理」按钮（`HomeNav.vue`）→ `router.push('/admin/login')`；已登录管理员访问登录页会自动跳后台（`AdminLogin.vue` 的 `onMounted`）。

统一返回 `{code, message, data}`，`code===200` 成功。

```bash
unset HTTP_PROXY HTTPS_PROXY http_proxy https_proxy   # 本机请求走代理会 502
curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" -d '{"username":"kitty","password":"1234"}'
curl -s http://localhost:8080/api/home/categories
curl -s "http://localhost:8080/api/home/items?keyword=%E8%8D%89%E8%8E%93"   # 草莓 -> 2 条
curl -s http://localhost:5173/api/home/stats                              # 验证 Vite 代理
```

---

## 7. 常踩的坑

1. **Maven 不在 PATH** → 用 IDEA 自带那份，或直接跑脚本。
2. **`SERVER__PORT` 环境变量** → 覆盖端口，清掉或显式指定。
3. **`node_modules` / `target` 每次开机被删** → 不能假设存在。
4. **`user` 是 H2 保留字** → URL 必须带 `NON_KEYWORDS=USER`。
5. **H2 数据不持久** → 重启后用户没了是正常现象。
6. **`.bat` / `.ps1` 都要 GBK + CRLF** → 否则中文乱码或语法错误。
7. **本机 curl 走代理 502** → 先 `unset *_proxy`。
8. **`ZipFile.CreateFromDirectory` 第四个参数要 `$true`** → 否则压缩包缺 `node_modules/` 这层，还原会污染项目根目录。
9. **`cmd /c 停止脚本` 会卡在 `pause`** → 非交互调用要加 `/quiet`。
10. **`start` 拉起的窗口在沙箱/非交互会话里会随父进程被回收** → 这是 AI 侧限制，用户双击不受影响；AI 验证要用无窗口方式直接跑 `启动后端.bat`。
11. **改完 `src` 或 `pom.xml` 才会触发重编** → 只改 `scripts`/文档不会，别以为缓存坏了。
12. **`desc` 是 SQL 关键字** → 首页内容表的简介列叫 `summary`，只在 VO 里映射成 `desc` 给前端。
13. **MyBatis-Plus 嵌套 wrapper 开头不能是 `AND`** → 一个词一组 `wrapper.and(w -> w.like(a).or().like(b))`，
    不要写成 `outer.and(...)` 多层套；多词循环多次 and 天然就是 AND 关系。
14. **首页数据改了要改 `db/data.sql`**，前端已经没有硬编码假数据了。

---

## 8. 缺什么（用户没要求就别动）

- 后端：无单元测试、无 JWT 鉴权（token 只是 UUID，存内存 `Map`）、无用户列表/改密接口
- 后端：无 Maven Wrapper（`mvnw`），强依赖本机 Maven
- 前端：无 Pinia、无 ESLint；首页详情点开只弹提示（详情页没做）
- 全局：无 CI、无 Docker
- 后台：管理员表只有单条演示账号，没有「管理员增删改 / 改密码 / 角色权限」；token 重启即失效
