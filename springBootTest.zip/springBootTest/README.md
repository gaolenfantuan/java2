# springBootTest —— Hello Kitty 后端（登录注册 + 首页搜索展示，H2 内存数据库版）

Spring Boot 3.4.5 + MyBatis-Plus 3.5.7 + **H2 内存数据库**，配合前端 `hellokitty-login-vue` 使用。

包含两块功能：
- **账号**：注册 / 登录 / 用户名查重
- **首页**：分级分类树、关键词搜索（支持多词 + 分类名命中）、排序、分页、详情（浏览量自增）、统计

> ✅ 不需要安装 / 启动任何数据库，也不需要建库建表。
> 启动项目时 H2 自动建表并插入演示账号，开箱即用。

## 一、启动（就两步）

**方式一：IDEA（推荐）**
打开 `D:\workSpace\springBootTest` → 等 Maven 依赖加载完 → 运行 `SpringBootTestApplication`。

**方式二：命令行**

```bash
cd D:\workSpace\springBootTest
mvn spring-boot:run
```

启动成功控制台会打印 `🎀 Hello Kitty 后端启动成功！`，端口 **8080**。

然后启动前端：

```bash
cd C:\Users\彭彭\Desktop\hellokitty-login-vue
npm run dev
```

打开 http://localhost:5173 ，注册或登录即可。

## 二、演示账号

| 用户名 | 密码 | 昵称 |
|--------|------|------|
| `kitty` | `1234` | 小猫咪 |

也可以自己注册新账号，注册成功会直接跳回登录页。

## 三、H2 内存库说明（重要）

| 项目 | 值 |
|------|-----|
| JDBC URL | `jdbc:h2:mem:hello_kitty;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE;NON_KEYWORDS=USER` |
| 用户名 | `sa` |
| 密码 | 空 |
| 控制台 | http://localhost:8080/h2-console |

**看数据**：浏览器打开 http://localhost:8080/h2-console ，JDBC URL 填 `jdbc:h2:mem:hello_kitty`，
用户 `sa`、密码留空，点 Connect 就能看到 `USER` 表里注册的用户。

**数据会丢**：`mem:` 表示数据只在内存里，**后端一重启数据就清空**，回到只有 `kitty` 一个演示账号的状态。
（因为每次启动都会执行 `db/schema.sql` + `db/data.sql` 重建，所以不会出错。）

**想改成持久化**：把 URL 里的 `mem:hello_kitty` 换成文件路径即可，例如
`jdbc:h2:file:./data/hello_kitty;MODE=MySQL;NON_KEYWORDS=USER`（数据存到项目下 `data/` 目录）。
注意首次切换要把 `spring.sql.init.mode` 改成 `never`，否则每次启动都会清表重建。

## 四、接口说明

统一返回格式：

```json
{ "code": 200, "message": "操作成功", "data": {} }
```

`code === 200` 成功，其他失败（`message` 是给用户看的中文提示）。

| 方法 | 路径 | 请求体 / 参数 | 说明 |
|------|------|--------------|------|
| POST | `/api/auth/register` | `{"username":"xx","nickname":"xx","password":"xxxx"}` | 注册，返回新用户 id |
| POST | `/api/auth/login` | `{"username":"xx","password":"xxxx"}` | 登录，返回 `{id, username, nickname, token}` |
| GET | `/api/auth/check?username=xx` | - | 用户名是否已占用，`true` 表示已存在 |

### 首页接口

| 方法 | 路径 | 参数 | 说明 |
|------|------|------|------|
| GET | `/api/home/categories` | - | 分类树（一级 + children 二级），每个节点带 `count` 内容数 |
| GET | `/api/home/items` | `keyword`、`categoryId`、`includeChildren`、`sort`、`page`、`size` | 搜索 / 列表，返回分页对象 |
| GET | `/api/home/hot` | `limit`（默认 6，最大 20） | 按点赞数取热门 |
| GET | `/api/home/items/{id}` | - | 详情，**每次访问浏览量 +1** |
| GET | `/api/home/stats` | - | `{itemTotal, categoryTotal, likeTotal, hotTotal}` |

`/api/home/items` 参数细节：

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `keyword` | 空 | 关键词。可空格分隔多个词，多个词之间是「且」；单个词在 **标题 / 简介 / 标签** 任一命中即可；**如果这个词本身是分类名（如「甜点」「蛋糕」），会把这个分类及其所有子分类下的内容一起搜出来** |
| `categoryId` | 无 | 分类 ID。传一级分类时自动包含它下面所有二级分类 |
| `includeChildren` | `true` | 传 `false` 时只看该分类本身，不含子分类 |
| `sort` | `default` | `default` 按排序号 / `hot` 按点赞降序 / `new` 按创建时间倒序 |
| `page` | `1` | 页码，从 1 开始 |
| `size` | `12` | 每页条数，**上限 50**（传 999 也只返回 50） |

响应里的 `list` 元素字段刻意和前端卡片对齐：
`{id, title, desc, emoji, tag, bg, categoryId, category, subCategory, likes, views, hot}`

PowerShell 快速测试：

```powershell
curl.exe -X POST http://localhost:8080/api/auth/login `
  -H "Content-Type: application/json" `
  -d '{\"username\":\"kitty\",\"password\":\"1234\"}'

curl.exe "http://localhost:8080/api/home/categories"
curl.exe "http://localhost:8080/api/home/items?keyword=%E8%8D%89%E8%8E%93"      # 搜「草莓」
curl.exe "http://localhost:8080/api/home/items?categoryId=1&sort=hot"           # 甜点（含子分类）按热度
curl.exe "http://localhost:8080/api/home/items/1"                               # 详情
```

## 五、建表 SQL

| 文件 | 用途 |
|------|------|
| `src/main/resources/db/schema.sql` | 建表语句，**启动时自动执行** |
| `src/main/resources/db/data.sql` | 演示账号数据，启动时自动执行 |
| `sql/h2_schema.sql` | 上面的合并版，供你在 H2 控制台里手动执行时用 |
| `sql/hello_kitty.sql` | MySQL 版脚本（以后 MySQL 修好了迁移过去用） |

表结构（三张表）：

```sql
CREATE TABLE user (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(50)  NOT NULL,           -- 用户名（唯一）
    nickname    VARCHAR(50),                     -- 昵称
    password    VARCHAR(128) NOT NULL,           -- SHA-256 加盐密文
    avatar      VARCHAR(255),                    -- 头像（预留）
    status      TINYINT      NOT NULL DEFAULT 1, -- 1 正常 0 禁用
    deleted     TINYINT      NOT NULL DEFAULT 0, -- 逻辑删除
    create_time TIMESTAMP,
    update_time TIMESTAMP
);
CREATE UNIQUE INDEX uk_username ON user (username);

-- 分级分类：parent_id = 0 是一级分类，否则指向某个一级分类
CREATE TABLE category (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(50) NOT NULL,            -- 甜点 / 蛋糕
    code        VARCHAR(50) NOT NULL,            -- dessert / cake（唯一）
    parent_id   BIGINT      NOT NULL DEFAULT 0,  -- 0 = 一级分类
    level       TINYINT     NOT NULL DEFAULT 1,  -- 1 一级 2 二级
    icon        VARCHAR(16),                     -- emoji
    sort        INT         NOT NULL DEFAULT 0,
    status      TINYINT     NOT NULL DEFAULT 1,
    deleted     TINYINT     NOT NULL DEFAULT 0,
    create_time TIMESTAMP,
    update_time TIMESTAMP
);
CREATE UNIQUE INDEX uk_category_code ON category (code);
CREATE INDEX idx_category_parent ON category (parent_id);

CREATE TABLE home_item (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(100) NOT NULL,
    summary     VARCHAR(255),                    -- 简介（desc 是 SQL 关键字，所以叫 summary）
    emoji       VARCHAR(16),
    tag         VARCHAR(50),                     -- #今日推荐
    cover_bg    VARCHAR(160),                    -- 封面渐变背景
    category_id BIGINT       NOT NULL,           -- 所属分类（一般是二级分类）
    likes       INT          NOT NULL DEFAULT 0,
    views       INT          NOT NULL DEFAULT 0,
    is_hot      TINYINT      NOT NULL DEFAULT 0,
    sort        INT          NOT NULL DEFAULT 0,
    status      TINYINT      NOT NULL DEFAULT 1,
    deleted     TINYINT      NOT NULL DEFAULT 0,
    create_time TIMESTAMP,
    update_time TIMESTAMP
);
CREATE INDEX idx_item_category ON home_item (category_id);
CREATE INDEX idx_item_likes ON home_item (likes);
```

初始化数据：4 个一级分类 × 3 个二级分类 + 12 条首页内容（`db/data.sql`）。

## 六、代码结构

```
src/main/java/com/example/springboottest/
├── SpringBootTestApplication.java     # 启动类
├── common/
│   ├── Result.java                    # 统一返回结果
│   └── GlobalExceptionHandler.java    # 全局异常处理（校验失败/业务异常/兜底）
├── config/
│   ├── MybatisPlusConfig.java         # 分页插件 + 时间自动填充 + Mapper 扫描
│   └── CorsConfig.java                # 跨域配置
├── controller/
│   ├── AuthController.java            # 登录/注册/查重
│   └── HomeController.java            # 首页：分类树/搜索/热门/详情/统计
├── dto/                               # 请求参数（@NotBlank、@Size 校验）
├── entity/
│   ├── User.java
│   ├── Category.java                  # 分级分类（parentId）
│   └── HomeItem.java                  # 首页内容
├── mapper/                            # 三个 Mapper，继承 BaseMapper
├── service/
│   ├── UserService(.Impl)             # 注册/登录
│   └── HomeService(.Impl)             # 分类树组装、分级搜索、详情、统计
├── util/PasswordUtil.java             # SHA-256 加盐加密
└── vo/                                # LoginVO / CategoryVO / HomeItemVO / PageVO / HomeStatsVO
```

## 七、几点说明

- **密码加密**：`SHA-256 + 固定盐`（`PasswordUtil`），避免明文存库；真实项目建议换 BCrypt。
- **token**：随机 UUID，仅演示，没有做鉴权拦截；要做真登录态可上 JWT + 拦截器。
- **逻辑删除**：`deleted` 字段，MyBatis-Plus 查询自动过滤已删数据。
- **时间字段**：`create_time` / `update_time` 由 `MetaObjectHandler` 自动填充。
- **为什么表名叫 user 却能用**：H2 里 `USER` 是关键字，JDBC URL 里加了 `NON_KEYWORDS=USER` 才允许这么用。
- **端口被占用**：改 `application.yml` 里的 `server.port`，同时记得改前端 `vite.config.js` 的代理 target。
