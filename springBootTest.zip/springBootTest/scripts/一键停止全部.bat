@echo off
chcp 936 >nul
echo ==========================================================
echo    һ��ֹͣ�����(8080) + ǰ��(5173)
echo ==========================================================
echo.
call "%~dp0ֹͣ���.bat" /quiet
set "FES=%USERPROFILE%\Desktop\hellokitty-login-vue\scripts\ֹͣǰ��.bat"
if not exist "%FES%" goto :done
call "%FES%" /quiet

:done
echo.
echo ȫ����ֹͣ��
ping -n 4 127.0.0.1 >nul
exit /b 0
