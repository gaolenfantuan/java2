﻿param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$pom = Join-Path $root 'pom.xml'
$src = Join-Path $root 'src\main'
$paths = @()
if (Test-Path $pom) { $paths += $pom }
if (Test-Path $src) {
  $paths += @(Get-ChildItem -Path $src -Recurse -File -Include *.java,*.yml,*.xml,*.sql | ForEach-Object { $_.FullName })
}
$sb = New-Object System.Text.StringBuilder
foreach ($p in ($paths | Sort-Object)) {
  $rel = $p.Substring($root.Length)
  $h = (Get-FileHash -Algorithm SHA256 -Path $p).Hash
  [void]$sb.Append($rel).Append('=').Append($h).Append(';')
}
$sha = [System.Security.Cryptography.SHA256]::Create()
$bytes = [System.Text.Encoding]::UTF8.GetBytes($sb.ToString())
$hash = [System.BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-', '').Substring(0, 16)
Write-Output $hash
