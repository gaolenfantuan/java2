package com.example.springboottest.service.impl;

import com.example.springboottest.dto.AdminCategoryRequest;
import com.example.springboottest.dto.AdminItemRequest;
import com.example.springboottest.entity.Admin;
import com.example.springboottest.entity.Category;
import com.example.springboottest.entity.HomeItem;
import com.example.springboottest.security.AdminTokenStore;
import com.example.springboottest.service.AdminService;
import com.example.springboottest.store.MemoryDataStore;
import com.example.springboottest.util.PasswordUtil;
import com.example.springboottest.vo.AdminCategoryVO;
import com.example.springboottest.vo.AdminItemVO;
import com.example.springboottest.vo.AdminLoginVO;
import com.example.springboottest.vo.AdminStatsVO;
import com.example.springboottest.vo.PageVO;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 后台管理业务实现（内存版）
 *
 * 内容 / 分类的新增、编辑、删除、查询全部读写 MemoryDataStore。
 * Controller 路径与返回 JSON 结构保持不变。
 */
@Service
public class AdminServiceImpl implements AdminService {

    private static final int MAX_SIZE = 100;
    private static final String DEFAULT_COVER_BG = "linear-gradient(135deg,#ffe3ef,#ffc9de)";
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final MemoryDataStore store;
    private final AdminTokenStore tokenStore;

    public AdminServiceImpl(MemoryDataStore store, AdminTokenStore tokenStore) {
        this.store = store;
        this.tokenStore = tokenStore;
    }

    // ==================================================================
    //  登录
    // ==================================================================

    @Override
    public AdminLoginVO login(String username, String password) {
        Admin admin = store.findAdminByUsername(username == null ? "" : username.trim());
        if (admin == null || !PasswordUtil.matches(password, admin.getPassword())) {
            throw new IllegalArgumentException("账号或密码不对哦，再检查一下~");
        }
        if (admin.getStatus() != null && admin.getStatus() == 0) {
            throw new IllegalArgumentException("这个管理员账号已被禁用啦，请联系超级管理员~");
        }

        AdminTokenStore.Session session = tokenStore.issue(admin.getId(), admin.getUsername(), admin.getNickname());
        return new AdminLoginVO(session.getToken(), admin.getId(), admin.getUsername(),
                admin.getNickname(), session.getExpiresIn());
    }

    @Override
    public AdminLoginVO current(String token) {
        AdminTokenStore.Session session = tokenStore.get(token);
        if (session == null) {
            throw new IllegalArgumentException("登录已过期，请重新登录后台~");
        }
        return new AdminLoginVO(session.getToken(), session.getAdminId(), session.getUsername(),
                session.getNickname(), session.getExpiresIn());
    }

    @Override
    public void logout(String token) {
        tokenStore.revoke(token);
    }

    // ==================================================================
    //  内容管理
    // ==================================================================

    @Override
    public PageVO<AdminItemVO> searchItems(String keyword, Long categoryId, Integer status,
                                           Integer page, Integer size) {
        long current = (page == null || page < 1) ? 1 : page;
        long pageSize = (size == null || size < 1) ? 10 : Math.min(size, MAX_SIZE);

        List<Category> allCategories = store.listCategories(false);
        Map<Long, Category> byId = allCategories.stream()
                .collect(Collectors.toMap(Category::getId, Function.identity()));

        List<HomeItem> candidates = new ArrayList<>(store.listItems(false));

        if (status != null) {
            candidates.removeIf(item -> !statusEquals(item.getStatus(), status));
        }
        if (categoryId != null && categoryId > 0) {
            Set<Long> ids = collectSelfAndDescendants(categoryId, groupByParent(allCategories));
            candidates.removeIf(item -> !ids.contains(item.getCategoryId()));
        }

        String kw = keyword == null ? "" : keyword.trim();
        if (!kw.isEmpty()) {
            candidates.removeIf(item -> !contains(item.getTitle(), kw)
                    && !contains(item.getSummary(), kw)
                    && !contains(item.getTag(), kw));
        }

        candidates.sort(Comparator
                .comparing(HomeItem::getSort, Comparator.nullsLast(Comparator.naturalOrder()))
                .thenComparing(HomeItem::getId));

        long total = candidates.size();
        int from = (int) Math.min((current - 1) * pageSize, total);
        int to = (int) Math.min(from + pageSize, total);
        List<AdminItemVO> list = candidates.subList(from, to).stream()
                .map(item -> toItemVO(item, byId))
                .toList();

        return new PageVO<>(list, total, current, pageSize);
    }

    @Override
    public AdminItemVO getItem(Long id) {
        HomeItem item = store.findItem(id);
        if (item == null) {
            throw new IllegalArgumentException("这条内容不存在或已被删除~");
        }
        Map<Long, Category> byId = store.listCategories(false).stream()
                .collect(Collectors.toMap(Category::getId, Function.identity()));
        return toItemVO(item, byId);
    }

    @Override
    public Long createItem(AdminItemRequest request) {
        requireExistingCategory(request.getCategoryId());

        HomeItem item = new HomeItem();
        item.setTitle(request.getTitle().trim());
        item.setSummary(trimToNull(request.getSummary()));
        item.setEmoji(blankToDefault(request.getEmoji(), "🎀"));
        item.setTag(trimToNull(request.getTag()));
        item.setCoverBg(blankToDefault(request.getCoverBg(), DEFAULT_COVER_BG));
        item.setCategoryId(request.getCategoryId());
        item.setLikes(nullToZero(request.getLikes()));
        item.setViews(nullToZero(request.getViews()));
        item.setIsHot(request.getIsHot() == null ? 0 : request.getIsHot());
        item.setSort(request.getSort() == null ? store.nextItemSort() : request.getSort());
        item.setStatus(request.getStatus() == null ? 1 : request.getStatus());
        item.setDeleted(0);
        item.setCreateTime(LocalDateTime.now());
        item.setUpdateTime(LocalDateTime.now());

        return store.addItem(item);
    }

    @Override
    public void updateItem(Long id, AdminItemRequest request) {
        HomeItem exist = store.findItem(id);
        if (exist == null) {
            throw new IllegalArgumentException("这条内容不存在或已被删除~");
        }
        requireExistingCategory(request.getCategoryId());

        HomeItem updated = new HomeItem();
        updated.setId(id);
        updated.setTitle(request.getTitle().trim());
        updated.setSummary(trimToNull(request.getSummary()));
        updated.setEmoji(blankToDefault(request.getEmoji(), "🎀"));
        updated.setTag(trimToNull(request.getTag()));
        updated.setCoverBg(blankToDefault(request.getCoverBg(), DEFAULT_COVER_BG));
        updated.setCategoryId(request.getCategoryId());
        updated.setLikes(nullToZero(request.getLikes()));
        updated.setViews(nullToZero(request.getViews()));
        updated.setIsHot(request.getIsHot() == null ? 0 : request.getIsHot());
        updated.setSort(request.getSort() == null ? 0 : request.getSort());
        updated.setStatus(request.getStatus() == null ? 1 : request.getStatus());
        updated.setDeleted(0);
        updated.setCreateTime(exist.getCreateTime());
        updated.setUpdateTime(LocalDateTime.now());

        store.saveItem(updated);
    }

    @Override
    public void deleteItem(Long id) {
        if (store.findItem(id) == null) {
            throw new IllegalArgumentException("这条内容不存在或已被删除~");
        }
        store.deleteItem(id);
    }

    // ==================================================================
    //  分类管理
    // ==================================================================

    @Override
    public List<AdminCategoryVO> listCategories() {
        List<Category> all = store.listCategories(false);
        Map<Long, Category> byId = all.stream()
                .collect(Collectors.toMap(Category::getId, Function.identity()));
        Map<Long, Long> counts = countItemsByCategory();

        Map<Long, List<Category>> byParent = groupByParent(all);
        List<Category> ordered = new ArrayList<>();
        Set<Long> added = new LinkedHashSet<>();
        for (Category root : byParent.getOrDefault(0L, List.of())) {
            if (added.add(root.getId())) ordered.add(root);
            for (Category child : byParent.getOrDefault(root.getId(), List.of())) {
                if (added.add(child.getId())) ordered.add(child);
            }
        }
        for (Category category : all) {
            if (added.add(category.getId())) ordered.add(category);
        }

        List<AdminCategoryVO> list = new ArrayList<>(ordered.size());
        for (Category category : ordered) {
            AdminCategoryVO vo = new AdminCategoryVO();
            vo.setId(category.getId());
            vo.setName(category.getName());
            vo.setCode(category.getCode());
            vo.setParentId(category.getParentId());
            vo.setLevel(category.getLevel());
            vo.setIcon(category.getIcon());
            vo.setSort(category.getSort());
            vo.setStatus(category.getStatus());
            vo.setItemCount(counts.getOrDefault(category.getId(), 0L));
            vo.setCreateTime(formatTime(category.getCreateTime()));
            Long parentId = category.getParentId();
            if (parentId != null && parentId > 0) {
                Category parent = byId.get(parentId);
                vo.setParentName(parent == null ? "已删除的分类" : parent.getName());
            }
            list.add(vo);
        }
        return list;
    }

    @Override
    public Long createCategory(AdminCategoryRequest request) {
        String name = request.getName().trim();
        long parentId = request.getParentId() == null ? 0L : request.getParentId();

        Category parent = null;
        if (parentId > 0) {
            parent = store.findCategory(parentId);
            if (parent == null) {
                throw new IllegalArgumentException("上级分类不存在，刷新一下页面试试~");
            }
            if (parent.getLevel() != null && parent.getLevel() >= 2) {
                throw new IllegalArgumentException("目前最多只支持两级分类，二级分类下面不能再加子分类啦~");
            }
        }

        boolean duplicated = store.listCategories(false).stream()
                .anyMatch(c -> name.equals(c.getName()) && parentId == nvlLong(c.getParentId()));
        if (duplicated) {
            throw new IllegalArgumentException("同一级下已经有叫「" + name + "」的分类啦~");
        }

        String code = trimToNull(request.getCode());
        if (code == null) {
            code = "c" + System.currentTimeMillis();
        } else {
            requireValidCode(code);
            String finalCode = code;
            boolean codeUsed = store.listCategories(false).stream().anyMatch(c -> finalCode.equals(c.getCode()));
            if (codeUsed) {
                throw new IllegalArgumentException("英文标识「" + code + "」已经被别的分类用掉啦，换一个吧~");
            }
        }

        Category category = new Category();
        category.setName(name);
        category.setCode(code);
        category.setParentId(parentId);
        category.setLevel(parentId > 0 ? 2 : 1);
        category.setIcon(trimToNull(request.getIcon()));
        category.setSort(request.getSort() == null ? store.nextCategorySort(parentId) : request.getSort());
        category.setStatus(request.getStatus() == null ? 1 : request.getStatus());
        category.setDeleted(0);
        category.setCreateTime(LocalDateTime.now());
        category.setUpdateTime(LocalDateTime.now());

        return store.addCategory(category);
    }

    @Override
    public void updateCategory(Long id, AdminCategoryRequest request) {
        Category exist = store.findCategory(id);
        if (exist == null) {
            throw new IllegalArgumentException("这个分类不存在或已被删除~");
        }

        String name = request.getName().trim();
        long parentId = request.getParentId() == null ? 0L : request.getParentId();
        if (parentId == id) {
            throw new IllegalArgumentException("上级分类不能选自己哦~");
        }

        long childCount = store.listCategories(false).stream()
                .filter(c -> id.equals(c.getParentId())).count();
        if (childCount > 0 && parentId > 0) {
            throw new IllegalArgumentException("「" + exist.getName() + "」下面还有 "
                    + childCount + " 个子分类，不能把它改成二级分类，请先处理子分类~");
        }

        if (parentId > 0) {
            Category parent = store.findCategory(parentId);
            if (parent == null) {
                throw new IllegalArgumentException("上级分类不存在，刷新一下页面试试~");
            }
            if (parent.getLevel() != null && parent.getLevel() >= 2) {
                throw new IllegalArgumentException("目前最多只支持两级分类，二级分类下面不能再加子分类啦~");
            }
        }

        boolean duplicated = store.listCategories(false).stream()
                .anyMatch(c -> !id.equals(c.getId())
                        && name.equals(c.getName())
                        && parentId == nvlLong(c.getParentId()));
        if (duplicated) {
            throw new IllegalArgumentException("同一级下已经有叫「" + name + "」的分类啦~");
        }

        String code = trimToNull(request.getCode());
        if (code == null) {
            code = exist.getCode();
        } else {
            requireValidCode(code);
            String finalCode = code;
            boolean codeUsed = store.listCategories(false).stream()
                    .anyMatch(c -> !id.equals(c.getId()) && finalCode.equals(c.getCode()));
            if (codeUsed) {
                throw new IllegalArgumentException("英文标识「" + code + "」已经被别的分类用掉啦，换一个吧~");
            }
        }

        exist.setName(name);
        exist.setCode(code);
        exist.setParentId(parentId);
        exist.setLevel(parentId > 0 ? 2 : 1);
        exist.setIcon(trimToNull(request.getIcon()));
        exist.setSort(request.getSort() == null ? 0 : request.getSort());
        exist.setStatus(request.getStatus() == null ? 1 : request.getStatus());
        store.saveCategory(exist);
    }

    @Override
    public void deleteCategory(Long id) {
        Category exist = store.findCategory(id);
        if (exist == null) {
            throw new IllegalArgumentException("这个分类不存在或已被删除~");
        }

        long childCount = store.listCategories(false).stream()
                .filter(c -> id.equals(c.getParentId())).count();
        if (childCount > 0) {
            throw new IllegalArgumentException("「" + exist.getName() + "」下面还有 " + childCount
                    + " 个子分类，先把子分类删掉再试~");
        }

        long itemCount = store.listItems(false).stream()
                .filter(i -> id.equals(i.getCategoryId())).count();
        if (itemCount > 0) {
            throw new IllegalArgumentException("「" + exist.getName() + "」下面还有 " + itemCount
                    + " 条内容，先把它们改到别的分类或删掉再试~");
        }

        store.deleteCategory(id);
    }

    // ==================================================================
    //  概览
    // ==================================================================

    @Override
    public AdminStatsVO stats() {
        List<HomeItem> items = store.listItems(false);
        long online = 0, offline = 0, likeTotal = 0, viewTotal = 0, hotTotal = 0;
        for (HomeItem item : items) {
            if (item.getStatus() != null && item.getStatus() == 1) online++;
            else offline++;
            likeTotal += item.getLikes() == null ? 0 : item.getLikes();
            viewTotal += item.getViews() == null ? 0 : item.getViews();
            if (item.getIsHot() != null && item.getIsHot() == 1) hotTotal++;
        }
        long categoryTotal = store.listCategories(false).size();
        return new AdminStatsVO((long) items.size(), online, offline, categoryTotal,
                likeTotal, viewTotal, hotTotal);
    }

    // ==================================================================
    //  内部工具
    // ==================================================================

    private Map<Long, List<Category>> groupByParent(List<Category> all) {
        Map<Long, List<Category>> byParent = new LinkedHashMap<>();
        for (Category category : all) {
            Long parentId = category.getParentId() == null ? 0L : category.getParentId();
            byParent.computeIfAbsent(parentId, k -> new ArrayList<>()).add(category);
        }
        return byParent;
    }

    private Set<Long> collectSelfAndDescendants(Long rootId, Map<Long, List<Category>> byParent) {
        Set<Long> ids = new LinkedHashSet<>();
        Deque<Long> queue = new ArrayDeque<>();
        queue.add(rootId);
        while (!queue.isEmpty()) {
            Long id = queue.poll();
            if (!ids.add(id)) continue;
            for (Category child : byParent.getOrDefault(id, List.of())) {
                queue.add(child.getId());
            }
        }
        return ids;
    }

    private Map<Long, Long> countItemsByCategory() {
        Map<Long, Long> counts = new HashMap<>();
        for (HomeItem item : store.listItems(false)) {
            if (item.getCategoryId() != null) {
                counts.merge(item.getCategoryId(), 1L, Long::sum);
            }
        }
        return counts;
    }

    private void requireExistingCategory(Long categoryId) {
        if (categoryId == null) {
            throw new IllegalArgumentException("请选择所属分类~");
        }
        if (store.findCategory(categoryId) == null) {
            throw new IllegalArgumentException("选择的分类不存在，刷新页面重新选一下~");
        }
    }

    private void requireValidCode(String code) {
        if (!code.matches("^[a-zA-Z][a-zA-Z0-9_]*$")) {
            throw new IllegalArgumentException("英文标识要以字母开头，只能用字母、数字、下划线~");
        }
    }

    private AdminItemVO toItemVO(HomeItem item, Map<Long, Category> byId) {
        AdminItemVO vo = new AdminItemVO();
        vo.setId(item.getId());
        vo.setTitle(item.getTitle());
        vo.setSummary(item.getSummary());
        vo.setEmoji(item.getEmoji());
        vo.setTag(item.getTag());
        vo.setCoverBg(item.getCoverBg());
        vo.setCategoryId(item.getCategoryId());
        vo.setLikes(item.getLikes());
        vo.setViews(item.getViews());
        vo.setIsHot(item.getIsHot());
        vo.setSort(item.getSort());
        vo.setStatus(item.getStatus());
        vo.setCreateTime(formatTime(item.getCreateTime()));
        vo.setUpdateTime(formatTime(item.getUpdateTime()));

        Category sub = byId.get(item.getCategoryId());
        if (sub != null) {
            vo.setSubCategoryName(sub.getName());
            Category parent = (sub.getParentId() != null && sub.getParentId() > 0)
                    ? byId.get(sub.getParentId())
                    : sub;
            vo.setCategoryName(parent == null ? sub.getName() : parent.getName());
        }
        return vo;
    }

    private String formatTime(LocalDateTime time) {
        return time == null ? "" : time.format(TIME_FMT);
    }

    private static String trimToNull(String value) {
        if (value == null) return null;
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private static String blankToDefault(String value, String defaultValue) {
        String trimmed = trimToNull(value);
        return trimmed == null ? defaultValue : trimmed;
    }

    private static int nullToZero(Integer value) {
        return value == null ? 0 : Math.max(0, value);
    }

    private static long nvlLong(Long value) {
        return value == null ? 0L : value;
    }

    private static boolean statusEquals(Integer actual, Integer expected) {
        return actual != null && actual.equals(expected);
    }

    private static boolean contains(String source, String term) {
        return source != null && source.contains(term);
    }
}
