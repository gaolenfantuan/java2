package com.example.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboottest.entity.VisitPet;
import org.apache.ibatis.annotations.Mapper;

/**
 * 毛孩子快照 Mapper（串门模块）
 */
@Mapper
public interface VisitPetMapper extends BaseMapper<VisitPet> {
}
