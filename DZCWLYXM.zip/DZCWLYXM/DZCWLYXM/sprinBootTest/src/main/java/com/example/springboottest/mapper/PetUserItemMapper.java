package com.example.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboottest.entity.PetUserItem;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户零食背包 Mapper
 */
@Mapper
public interface PetUserItemMapper extends BaseMapper<PetUserItem> {
}
