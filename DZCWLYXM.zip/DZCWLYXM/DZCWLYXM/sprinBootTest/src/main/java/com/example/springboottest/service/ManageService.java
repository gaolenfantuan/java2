package com.example.springboottest.service;

import com.example.springboottest.dto.PetSaveRequest;
import com.example.springboottest.entity.Pet;
import com.example.springboottest.entity.PetCategory;
import com.example.springboottest.entity.User;
import com.example.springboottest.vo.ManageStatsVO;
import com.example.springboottest.vo.PageVO;
import com.example.springboottest.vo.PetCategoryVO;
import com.example.springboottest.vo.PetVO;

import java.util.List;

/**
 * 领养站管理后台业务接口
 */
public interface ManageService {

    /** 概览统计 */
    ManageStatsVO stats();

    /** 宠物管理列表（含所有状态，支持关键词/分类/状态筛选 + 分页） */
    PageVO<PetVO> petList(String keyword, Long categoryId, Integer status, Long page, Long size);

    /** 新增宠物，返回ID */
    Long createPet(PetSaveRequest request);

    /** 编辑宠物 */
    void updatePet(Long id, PetSaveRequest request);

    /** 删除宠物（逻辑删除） */
    void deletePet(Long id);

    /** 修改宠物状态（上架/下架/已领养） */
    void changeStatus(Long id, Integer status);

    /** 分类列表（平铺，含 id/name/parent/icon/状态/宠物数量） */
    List<PetCategoryVO> categoryList();

    /** 新增分类 */
    Long createCategory(String name, Long parentId, String icon);

    /** 删除分类（有宠物或子分类时拒绝） */
    void deleteCategory(Long id);

    /** 用户列表（分页） */
    PageVO<User> userList(String keyword, Long page, Long size);
}
