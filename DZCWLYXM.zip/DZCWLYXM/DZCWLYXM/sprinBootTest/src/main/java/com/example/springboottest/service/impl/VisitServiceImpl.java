package com.example.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.example.springboottest.common.BizException;
import com.example.springboottest.dto.VisitLikeRequest;
import com.example.springboottest.dto.VisitSyncRequest;
import com.example.springboottest.dto.VisitTreatRequest;
import com.example.springboottest.entity.PetUserItem;
import com.example.springboottest.entity.User;
import com.example.springboottest.entity.VisitLike;
import com.example.springboottest.entity.VisitPet;
import com.example.springboottest.entity.VisitRecord;
import com.example.springboottest.entity.VisitTreat;
import com.example.springboottest.mapper.PetUserItemMapper;
import com.example.springboottest.mapper.UserMapper;
import com.example.springboottest.mapper.VisitLikeMapper;
import com.example.springboottest.mapper.VisitPetMapper;
import com.example.springboottest.mapper.VisitRecordMapper;
import com.example.springboottest.mapper.VisitTreatMapper;
import com.example.springboottest.security.UserContext;
import com.example.springboottest.service.VisitService;
import com.example.springboottest.vo.VisitHomeVO;
import com.example.springboottest.vo.VisitItemVO;
import com.example.springboottest.vo.VisitPetVO;
import com.example.springboottest.vo.VisitTargetVO;
import com.example.springboottest.vo.VisitorVO;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 串门轻社交实现
 *
 * 数据来源：
 *   sys_user       主人 / 访客的昵称
 *   visit_pet      主人的毛孩子快照（前端同步上来）
 *   visit_record   来访足迹（同一访客只保留最新一条）
 *   visit_like     点赞（host + visitor + 日期 唯一索引，每人每天 1 次）
 *   visit_treat    送零食流水
 *   pet_user_item  访客的零食背包（真实扣库存）
 *
 * 安全约定：
 *   - 「我是谁」一律取 UserContext（由 token 解析），绝不使用请求体里的 visitorId；
 *   - 修改某只宠物的状态前，必须校验当前登录用户 == 该宠物 user_id，否则 403。
 */
@Service
public class VisitServiceImpl implements VisitService {

    /** 访客小头像，按 ID 稳定取一个，保证同一个人每次显示一致 */
    private static final String[] AVATARS = {"🐱", "🐶", "🐰", "🐼", "🦊", "🐹", "🐨", "🐯"};

    /** 零食定义：编码、名称、emoji、饱腹加成、心情加成 */
    private record TreatItem(String code, String name, String emoji, int fullness, int mood) {
    }

    private static final Map<String, TreatItem> TREATS;

    static {
        Map<String, TreatItem> map = new LinkedHashMap<>();
        map.put("dried_fish", new TreatItem("dried_fish", "小鱼干", "🐟", 8, 6));
        map.put("chicken_jerky", new TreatItem("chicken_jerky", "鸡肉干", "🍖", 12, 4));
        map.put("cheese_cube", new TreatItem("cheese_cube", "奶酪块", "🧀", 6, 10));
        map.put("carrot_stick", new TreatItem("carrot_stick", "胡萝卜条", "🥕", 10, 3));
        map.put("cookie_bone", new TreatItem("cookie_bone", "骨头饼干", "🦴", 9, 5));
        TREATS = Collections.unmodifiableMap(map);
    }

    /** 默认推荐零食 */
    private static final String DEFAULT_ITEM_CODE = "dried_fish";

    /** 领取毛孩子时的新手零食包：每种 3 个 */
    private static final int STARTER_PACK_SIZE = 3;

    private final UserMapper userMapper;
    private final VisitPetMapper visitPetMapper;
    private final VisitRecordMapper visitRecordMapper;
    private final VisitLikeMapper visitLikeMapper;
    private final VisitTreatMapper visitTreatMapper;
    private final PetUserItemMapper petUserItemMapper;

    public VisitServiceImpl(UserMapper userMapper,
                            VisitPetMapper visitPetMapper,
                            VisitRecordMapper visitRecordMapper,
                            VisitLikeMapper visitLikeMapper,
                            VisitTreatMapper visitTreatMapper,
                            PetUserItemMapper petUserItemMapper) {
        this.userMapper = userMapper;
        this.visitPetMapper = visitPetMapper;
        this.visitRecordMapper = visitRecordMapper;
        this.visitLikeMapper = visitLikeMapper;
        this.visitTreatMapper = visitTreatMapper;
        this.petUserItemMapper = petUserItemMapper;
    }

    /* ==================== 1. 解析串门目标 ==================== */
    @Override
    public VisitTargetVO resolve(String keyword) {
        String key = keyword == null ? "" : keyword.trim();
        if (key.isEmpty()) {
            throw BizException.badRequest("输入对方的 ID 或昵称，才能去串门哦～");
        }

        User user = null;
        // 纯数字优先当 ID 找，找不到再当昵称 / 手机号找
        if (key.matches("\\d+")) {
            try {
                user = userMapper.selectById(Long.parseLong(key));
            } catch (NumberFormatException ignored) {
                user = null;
            }
        }
        if (user == null) {
            user = userMapper.selectOne(new LambdaQueryWrapper<User>()
                    .eq(User::getNickname, key)
                    .last("LIMIT 1"));
        }
        if (user == null) {
            user = userMapper.selectOne(new LambdaQueryWrapper<User>()
                    .eq(User::getUsername, key)
                    .last("LIMIT 1"));
        }
        if (user == null) {
            throw BizException.notFound("没有找到这位铲屎官，再核对一下 ID 或昵称吧～");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw BizException.forbidden("这位铲屎官的小院暂时关门啦，改天再来吧～");
        }

        VisitPet pet = visitPetMapper.selectById(user.getId());
        VisitTargetVO vo = new VisitTargetVO();
        vo.setUserId(user.getId());
        vo.setNickname(user.getNickname());
        vo.setHasPet(pet != null);
        vo.setPetName(pet == null ? null : pet.getPetName());
        vo.setPetType(pet == null ? null : pet.getPetType());
        return vo;
    }

    /* ==================== 2. 对方宠物公开信息（只读 + 记足迹） ==================== */
    @Override
    @Transactional
    public VisitHomeVO home(Long hostUserId) {
        User host = requireUser(hostUserId);

        Long viewerId = UserContext.get();
        boolean isSelf = viewerId != null && viewerId.equals(hostUserId);

        // 别人来访时记一条足迹（同一个人只留最新一条）；只动 visit_record，不动宠物状态
        if (!isSelf && viewerId != null) {
            recordVisit(hostUserId, viewerId, resolveName(viewerId));
        }

        VisitHomeVO vo = new VisitHomeVO();
        vo.setUserId(host.getId());
        vo.setNickname(host.getNickname());
        vo.setIsSelf(isSelf);

        VisitPet pet = visitPetMapper.selectById(hostUserId);
        vo.setPet(pet == null ? null : toPetVO(pet));

        boolean canInteract = viewerId != null && !isSelf;
        vo.setCanInteract(canInteract);

        if (canInteract) {
            Long liked = visitLikeMapper.selectCount(new LambdaQueryWrapper<VisitLike>()
                    .eq(VisitLike::getHostUserId, hostUserId)
                    .eq(VisitLike::getVisitorId, viewerId)
                    .eq(VisitLike::getLikeDate, LocalDate.now()));
            Long treated = visitTreatMapper.selectCount(new LambdaQueryWrapper<VisitTreat>()
                    .eq(VisitTreat::getHostUserId, hostUserId)
                    .eq(VisitTreat::getVisitorId, viewerId)
                    .eq(VisitTreat::getTreatDate, LocalDate.now()));
            vo.setLiked(liked != null && liked > 0);
            vo.setTreatedToday(treated != null && treated > 0);
            vo.setMyItems(bagItems(viewerId));
            vo.setDefaultItemCode(pickDefaultItemCode(viewerId));
        } else {
            vo.setLiked(false);
            vo.setTreatedToday(false);
            vo.setMyItems(Collections.emptyList());
            vo.setDefaultItemCode(DEFAULT_ITEM_CODE);
        }

        List<VisitorVO> visitors = listVisitors(hostUserId, 5);
        vo.setVisitors(visitors);
        Long total = visitRecordMapper.selectCount(new LambdaQueryWrapper<VisitRecord>()
                .eq(VisitRecord::getHostUserId, hostUserId));
        vo.setVisitorCount(total == null ? 0 : total.intValue());
        return vo;
    }

    /* ==================== 3. 点赞 ==================== */
    @Override
    @Transactional
    public Map<String, Object> like(VisitLikeRequest request) {
        // 点赞人只能是 token 对应的登录用户
        Long visitorId = UserContext.require();
        Long hostId = request.getHostUserId();

        if (visitorId.equals(hostId)) {
            // 需求：校验不能给自己点赞
            throw BizException.forbidden("不能给自己点赞啦，摸摸自己的头～");
        }
        requireUser(hostId);
        VisitPet pet = requirePet(hostId);

        LocalDate today = LocalDate.now();
        Long todayCount = visitLikeMapper.selectCount(new LambdaQueryWrapper<VisitLike>()
                .eq(VisitLike::getHostUserId, hostId)
                .eq(VisitLike::getVisitorId, visitorId)
                .eq(VisitLike::getLikeDate, today));

        Map<String, Object> data = new LinkedHashMap<>();
        if (todayCount != null && todayCount > 0) {
            // 同一天重复点赞：不改数据、不加心情，直接告诉前端今天已经点过了
            data.put("liked", true);
            data.put("already", true);
            data.put("likeCount", nvl(pet.getLikeCount()));
            data.put("mood", clamp(pet.getMood(), 80));
            data.put("moodGain", 0);
            data.put("likeDate", today.toString());
            return data;
        }

        VisitLike like = new VisitLike();
        like.setHostUserId(hostId);
        like.setVisitorId(visitorId);
        like.setLikeDate(today);
        like.setCreateTime(LocalDateTime.now());
        try {
            visitLikeMapper.insert(like);
        } catch (DuplicateKeyException e) {
            // 并发双击：唯一索引兜底，整个事务回滚，不会重复加心情
            throw BizException.badRequest("今天已经给它点过赞啦，明天再来比心吧～");
        }

        // 点赞成功：点赞数 +1，对方心情 +5（上限 100）
        int mood = Math.min(100, clamp(pet.getMood(), 80) + 5);
        pet.setLikeCount(nvl(pet.getLikeCount()) + 1);
        pet.setMood(mood);
        pet.setUpdateTime(LocalDateTime.now());
        visitPetMapper.updateById(pet);

        data.put("liked", true);
        data.put("already", false);
        data.put("likeCount", nvl(pet.getLikeCount()));
        data.put("mood", mood);
        data.put("moodGain", 5);
        data.put("likeDate", today.toString());
        return data;
    }

    /* ==================== 4. 送零食 ==================== */
    @Override
    @Transactional
    public Map<String, Object> treat(VisitTreatRequest request) {
        Long visitorId = UserContext.require();
        Long hostId = request.getHostUserId();

        if (visitorId.equals(hostId)) {
            throw BizException.forbidden("零食自己喂就好啦，把小鱼干留给别人送吧～");
        }
        requireUser(hostId);
        VisitPet pet = requirePet(hostId);

        // 没指定就挑一个背包里还有货的（优先小鱼干）
        String code = resolveItemCode(visitorId, request.getItemCode());
        TreatItem item = TREATS.get(code);
        if (item == null) {
            throw BizException.badRequest("没有这种零食哦，换个口味试试～");
        }

        PetUserItem bag = findBagItem(visitorId, code);
        if (bag == null || nvl(bag.getQuantity()) <= 0) {
            throw BizException.badRequest("你的背包里没有" + item.name() + "啦，去领养专区逛逛补充一下～");
        }

        // 扣库存用 quantity >= 1 做条件，避免并发送出负数
        int rows = petUserItemMapper.update(null, new LambdaUpdateWrapper<PetUserItem>()
                .eq(PetUserItem::getId, bag.getId())
                .ge(PetUserItem::getQuantity, 1)
                .setSql("quantity = quantity - 1")
                .set(PetUserItem::getUpdateTime, LocalDateTime.now()));
        if (rows == 0) {
            throw BizException.badRequest(item.name() + "刚刚被用掉啦，换一个试试～");
        }

        VisitTreat treat = new VisitTreat();
        treat.setHostUserId(hostId);
        treat.setVisitorId(visitorId);
        treat.setItemCode(code);
        treat.setTreatDate(LocalDate.now());
        treat.setCreateTime(LocalDateTime.now());
        visitTreatMapper.insert(treat);

        int fullness = Math.min(100, clamp(pet.getFullness(), 80) + item.fullness());
        int mood = Math.min(100, clamp(pet.getMood(), 80) + item.mood());
        pet.setTreatCount(nvl(pet.getTreatCount()) + 1);
        pet.setFullness(fullness);
        pet.setMood(mood);
        pet.setUpdateTime(LocalDateTime.now());
        visitPetMapper.updateById(pet);

        PetUserItem after = petUserItemMapper.selectById(bag.getId());

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("treatedToday", true);
        data.put("itemCode", item.code());
        data.put("itemName", item.name());
        data.put("itemEmoji", item.emoji());
        data.put("fullnessGain", item.fullness());
        data.put("moodGain", item.mood());
        data.put("fullness", fullness);
        data.put("mood", mood);
        data.put("treatCount", nvl(pet.getTreatCount()));
        data.put("leftQuantity", after == null ? 0 : nvl(after.getQuantity()));
        return data;
    }

    /* ==================== 5. 同步毛孩子快照（只能操作自己） ==================== */
    @Override
    @Transactional
    public void sync(VisitSyncRequest request) {
        Long current = UserContext.require();

        // 需求：所有修改宠物状态的接口，强制校验登录用户与宠物 user_id 一致
        if (request.getUserId() != null && !request.getUserId().equals(current)) {
            throw BizException.forbidden("只能同步自己的毛孩子哦，别人家的要主人自己来～");
        }
        request.setUserId(current);
        requireUser(current);

        VisitPet pet = visitPetMapper.selectById(current);
        if (pet != null && !Objects.equals(pet.getUserId(), current)) {
            // 双保险：即使主键被脏数据串了也不允许改别人的宠物
            throw BizException.forbidden("这只毛孩子不属于你，不能修改它的状态～");
        }

        boolean isNew = pet == null;
        if (isNew) {
            pet = new VisitPet();
            pet.setUserId(current);
            pet.setLikeCount(0);
            pet.setTreatCount(0);
        }

        pet.setPetName(blankTo(request.getPetName(), "小可爱"));
        pet.setPetType(normalizeType(request.getPetType()));
        pet.setPetColor(blankTo(request.getPetColor(), "#ffd84d"));
        pet.setPetEmoji(blankTo(request.getPetEmoji(), "🐾"));
        pet.setPetBreed(blankTo(request.getPetBreed(), ""));
        pet.setMood(clamp(request.getMood(), 80));
        pet.setFullness(clamp(request.getFullness(), 80));
        pet.setExp(Math.max(0, request.getExp() == null ? 0 : request.getExp()));
        pet.setUpdateTime(LocalDateTime.now());

        if (isNew) {
            visitPetMapper.insert(pet);
            // 第一次领取毛孩子，送一份新手零食包
            grantStarterPack(current);
        } else {
            visitPetMapper.updateById(pet);
        }
    }

    /* ==================== 6. 我的访客记录 ==================== */
    @Override
    public List<VisitorVO> visitors(Long userId, Integer limit) {
        Long current = UserContext.require();
        Long target = (userId == null) ? current : userId;
        // 需求：只能查自己的访客，查别人一律无权限
        if (!target.equals(current)) {
            throw BizException.forbidden("只能查看自己的访客记录哦～");
        }
        return listVisitors(target, limit);
    }

    /* ==================== 7. 我的零食背包 ==================== */
    @Override
    public List<VisitItemVO> myItems() {
        return bagItems(UserContext.require());
    }

    /* ==================== 内部工具 ==================== */

    /** 最近访客（内部使用，不做权限校验；home 里用于展示主人家公开的访客列表） */
    private List<VisitorVO> listVisitors(Long hostUserId, Integer limit) {
        int size = (limit == null || limit <= 0) ? 5 : Math.min(limit, 20);
        List<VisitRecord> records = visitRecordMapper.selectList(new LambdaQueryWrapper<VisitRecord>()
                .eq(VisitRecord::getHostUserId, hostUserId)
                .orderByDesc(VisitRecord::getVisitTime)
                .last("LIMIT " + size));

        List<VisitorVO> list = new ArrayList<>();
        for (VisitRecord record : records) {
            VisitorVO vo = new VisitorVO();
            vo.setVisitorId(record.getVisitorId());
            vo.setNickname(blankTo(record.getVisitorName(), "神秘铲屎官"));
            vo.setEmoji(avatarOf(record.getVisitorId()));
            vo.setVisitTime(record.getVisitTime());
            vo.setTimeText(timeText(record.getVisitTime()));
            list.add(vo);
        }
        return list;
    }

    /** 记录来访：同一访客只保留最新一条，反复刷新不会刷出一堆重复记录 */
    private void recordVisit(Long hostId, Long visitorId, String visitorName) {
        VisitRecord latest = visitRecordMapper.selectOne(new LambdaQueryWrapper<VisitRecord>()
                .eq(VisitRecord::getHostUserId, hostId)
                .eq(VisitRecord::getVisitorId, visitorId)
                .orderByDesc(VisitRecord::getVisitTime)
                .last("LIMIT 1"));

        if (latest != null) {
            latest.setVisitorName(visitorName);
            latest.setVisitTime(LocalDateTime.now());
            visitRecordMapper.updateById(latest);
            return;
        }

        VisitRecord record = new VisitRecord();
        record.setHostUserId(hostId);
        record.setVisitorId(visitorId);
        record.setVisitorName(visitorName);
        record.setVisitTime(LocalDateTime.now());
        visitRecordMapper.insert(record);
    }

    private String resolveName(Long visitorId) {
        User user = userMapper.selectById(visitorId);
        if (user != null && user.getNickname() != null && !user.getNickname().isBlank()) {
            return user.getNickname();
        }
        return "神秘铲屎官";
    }

    /** 用户必须存在且没被禁用 */
    private User requireUser(Long userId) {
        if (userId == null || userId <= 0) {
            throw BizException.badRequest("用户 ID 不正确哦～");
        }
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw BizException.notFound("这位铲屎官好像搬走了，换个 ID 试试吧～");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw BizException.forbidden("这位铲屎官的小院暂时关门啦，改天再来吧～");
        }
        return user;
    }

    private VisitPet requirePet(Long userId) {
        VisitPet pet = visitPetMapper.selectById(userId);
        if (pet == null) {
            throw BizException.notFound("TA 还没有领取电子宠物，先去提醒一下？");
        }
        return pet;
    }

    /** 目标用户背包全部零食（没有库存的也返回，前端好显示 0） */
    private List<VisitItemVO> bagItems(Long userId) {
        List<PetUserItem> owned = petUserItemMapper.selectList(new LambdaQueryWrapper<PetUserItem>()
                .eq(PetUserItem::getUserId, userId));
        Map<String, Integer> stock = new LinkedHashMap<>();
        for (PetUserItem item : owned) {
            stock.merge(item.getItemCode(), nvl(item.getQuantity()), Integer::sum);
        }

        List<VisitItemVO> list = new ArrayList<>();
        for (TreatItem treat : TREATS.values()) {
            VisitItemVO vo = new VisitItemVO();
            vo.setCode(treat.code());
            vo.setName(treat.name());
            vo.setEmoji(treat.emoji());
            vo.setQuantity(stock.getOrDefault(treat.code(), 0));
            vo.setFullnessGain(treat.fullness());
            vo.setMoodGain(treat.mood());
            list.add(vo);
        }
        return list;
    }

    private PetUserItem findBagItem(Long userId, String code) {
        return petUserItemMapper.selectOne(new LambdaQueryWrapper<PetUserItem>()
                .eq(PetUserItem::getUserId, userId)
                .eq(PetUserItem::getItemCode, code)
                .last("LIMIT 1"));
    }

    /** 优先用前端指定的，其次默认小鱼干，再其次背包里第一个有货的 */
    private String resolveItemCode(Long userId, String requested) {
        if (requested != null && !requested.isBlank()) {
            return requested.trim().toLowerCase();
        }
        PetUserItem fish = findBagItem(userId, DEFAULT_ITEM_CODE);
        if (fish != null && nvl(fish.getQuantity()) > 0) {
            return DEFAULT_ITEM_CODE;
        }
        for (TreatItem treat : TREATS.values()) {
            PetUserItem item = findBagItem(userId, treat.code());
            if (item != null && nvl(item.getQuantity()) > 0) {
                return treat.code();
            }
        }
        return DEFAULT_ITEM_CODE;
    }

    private String pickDefaultItemCode(Long userId) {
        return resolveItemCode(userId, null);
    }

    /** 新用户新手零食包 */
    private void grantStarterPack(Long userId) {
        for (TreatItem treat : TREATS.values()) {
            Long exists = petUserItemMapper.selectCount(new LambdaQueryWrapper<PetUserItem>()
                    .eq(PetUserItem::getUserId, userId)
                    .eq(PetUserItem::getItemCode, treat.code()));
            if (exists != null && exists > 0) {
                continue;
            }
            PetUserItem item = new PetUserItem();
            item.setUserId(userId);
            item.setItemCode(treat.code());
            item.setItemName(treat.name());
            item.setQuantity(STARTER_PACK_SIZE);
            item.setUpdateTime(LocalDateTime.now());
            petUserItemMapper.insert(item);
        }
    }

    private VisitPetVO toPetVO(VisitPet pet) {
        VisitPetVO vo = new VisitPetVO();
        vo.setUserId(pet.getUserId());
        vo.setName(blankTo(pet.getPetName(), "小可爱"));
        vo.setType(normalizeType(pet.getPetType()));
        vo.setColor(blankTo(pet.getPetColor(), "#ffd84d"));
        vo.setEmoji(blankTo(pet.getPetEmoji(), "🐾"));
        vo.setBreed(blankTo(pet.getPetBreed(), ""));
        vo.setMood(clamp(pet.getMood(), 80));
        vo.setFullness(clamp(pet.getFullness(), 80));
        int exp = pet.getExp() == null ? 0 : Math.max(0, pet.getExp());
        vo.setExp(exp);
        vo.setLevel(Math.min(30, exp / 100 + 1));
        vo.setLikeCount(nvl(pet.getLikeCount()));
        vo.setTreatCount(nvl(pet.getTreatCount()));
        vo.setUpdateTime(pet.getUpdateTime());
        vo.setUpdateText(timeText(pet.getUpdateTime()));
        return vo;
    }

    private String normalizeType(String type) {
        String t = type == null ? "" : type.trim().toLowerCase();
        if ("dog".equals(t) || "bunny".equals(t) || "cat".equals(t)) {
            return t;
        }
        return "cat";
    }

    private String avatarOf(Long visitorId) {
        if (visitorId == null) {
            return AVATARS[0];
        }
        return AVATARS[(int) Math.abs(visitorId % AVATARS.length)];
    }

    private String timeText(LocalDateTime time) {
        if (time == null) {
            return "很久以前";
        }
        long minutes = Duration.between(time, LocalDateTime.now()).toMinutes();
        if (minutes < 1) {
            return "刚刚";
        }
        if (minutes < 60) {
            return minutes + " 分钟前";
        }
        long hours = minutes / 60;
        if (hours < 24) {
            return hours + " 小时前";
        }
        long days = hours / 24;
        if (days == 1) {
            return "昨天";
        }
        if (days < 7) {
            return days + " 天前";
        }
        return time.toLocalDate().toString();
    }

    private int nvl(Integer value) {
        return value == null ? 0 : value;
    }

    private int clamp(Integer value, int fallback) {
        int v = value == null ? fallback : value;
        return Math.max(0, Math.min(100, v));
    }

    private String blankTo(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value.trim();
    }
}
