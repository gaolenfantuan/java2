package com.example.springboottest.vo;

import java.time.LocalDateTime;

/**
 * 访客条目：「谁来看过我」列表用
 */
public class VisitorVO {

    private Long visitorId;
    private String nickname;
    /** 小头像 emoji，按 id 稳定派生 */
    private String emoji;
    private String timeText;
    private LocalDateTime visitTime;

    public Long getVisitorId() {
        return visitorId;
    }

    public void setVisitorId(Long visitorId) {
        this.visitorId = visitorId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getEmoji() {
        return emoji;
    }

    public void setEmoji(String emoji) {
        this.emoji = emoji;
    }

    public String getTimeText() {
        return timeText;
    }

    public void setTimeText(String timeText) {
        this.timeText = timeText;
    }

    public LocalDateTime getVisitTime() {
        return visitTime;
    }

    public void setVisitTime(LocalDateTime visitTime) {
        this.visitTime = visitTime;
    }
}
