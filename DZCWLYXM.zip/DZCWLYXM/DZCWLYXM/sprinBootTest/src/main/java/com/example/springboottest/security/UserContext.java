package com.example.springboottest.security;

import com.example.springboottest.common.BizException;

/**
 * 当前登录用户上下文（一次请求一份）
 *
 * 由 UserAuthInterceptor 在请求进入时写入、请求结束时清除。
 * 业务层统一用 UserContext.require() 取当前用户 ID，
 * 绝不信任前端在请求体里传来的 userId —— 那是可以随便伪造的。
 */
public final class UserContext {

    private static final ThreadLocal<Long> HOLDER = new ThreadLocal<>();

    private UserContext() {
    }

    public static void set(Long userId) {
        if (userId == null || userId <= 0) {
            HOLDER.remove();
            return;
        }
        HOLDER.set(userId);
    }

    /** 可能为 null：用于允许游客访问的只读接口 */
    public static Long get() {
        return HOLDER.get();
    }

    /** 必须已登录，否则 401 */
    public static Long require() {
        Long userId = HOLDER.get();
        if (userId == null) {
            throw BizException.unauthorized("先登录一下才能操作哦，小院的门要刷铲屎官卡～");
        }
        return userId;
    }

    public static void clear() {
        HOLDER.remove();
    }
}
