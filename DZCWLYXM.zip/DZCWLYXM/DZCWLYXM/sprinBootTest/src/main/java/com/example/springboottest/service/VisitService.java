package com.example.springboottest.service;

import com.example.springboottest.dto.VisitLikeRequest;
import com.example.springboottest.dto.VisitSyncRequest;
import com.example.springboottest.dto.VisitTreatRequest;
import com.example.springboottest.vo.VisitHomeVO;
import com.example.springboottest.vo.VisitItemVO;
import com.example.springboottest.vo.VisitTargetVO;
import com.example.springboottest.vo.VisitorVO;

import java.util.List;
import java.util.Map;

/**
 * 串门轻社交业务
 *
 * 约定：所有「当前用户」都从登录 token 解析（UserContext），接口参数里只允许传目标用户 ID。
 */
public interface VisitService {

    /** 按用户 ID / 昵称 / 手机号解析串门目标 */
    VisitTargetVO resolve(String keyword);

    /**
     * 查询对方宠物公开信息（只读，不改宠物状态）
     * 已登录访客访问时会自动写一条来访足迹。
     */
    VisitHomeVO home(Long hostUserId);

    /** 点赞：不能给自己点，每人每天限 1 次，成功后对方心情 +5 */
    Map<String, Object> like(VisitLikeRequest request);

    /** 送零食：扣减访客背包库存，给对方加饱腹值和心情值 */
    Map<String, Object> treat(VisitTreatRequest request);

    /** 把自己的毛孩子快照同步到服务端（只能同步自己的） */
    void sync(VisitSyncRequest request);

    /** 查询我的访客记录；传别人的 userId 会 403 */
    List<VisitorVO> visitors(Long userId, Integer limit);

    /** 我的零食背包 */
    List<VisitItemVO> myItems();
}
