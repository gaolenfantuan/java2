package com.example.springboottest.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 拦截器注册
 *
 * 1. /api/admin/**、/api/manage/** 走管理员鉴权（AdminAuthInterceptor）；
 * 2. /api/visit/** 走前台用户身份解析（UserAuthInterceptor），把 token 换成 UserContext 里的 userId。
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final AdminAuthInterceptor adminAuthInterceptor;
    private final UserAuthInterceptor userAuthInterceptor;

    public WebConfig(AdminAuthInterceptor adminAuthInterceptor,
                     UserAuthInterceptor userAuthInterceptor) {
        this.adminAuthInterceptor = adminAuthInterceptor;
        this.userAuthInterceptor = userAuthInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(adminAuthInterceptor)
                .addPathPatterns("/api/admin/**", "/api/manage/**")
                .excludePathPatterns("/api/admin/auth/login");

        registry.addInterceptor(userAuthInterceptor)
                .addPathPatterns("/api/visit/**")
                .order(1);
    }
}
