package com.example.springboottest.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * 管理后台「新增 / 编辑宠物」请求体
 */
public class PetSaveRequest {

    @NotBlank(message = "宠物名字不能为空")
    @Size(max = 30, message = "名字最多 30 个字")
    private String name;

    @Size(max = 10, message = "emoji 最多 10 个字符")
    private String emoji;

    @NotBlank(message = "品种不能为空")
    @Size(max = 30, message = "品种最多 30 个字")
    private String breed;

    @NotNull(message = "请选择一级分类")
    private Long categoryId;

    private Long breedId;

    @Size(max = 20, message = "年龄最多 20 个字")
    private String age;

    @Size(max = 10, message = "性别最多 10 个字")
    private String sex;

    @Size(max = 30, message = "城市最多 30 个字")
    private String city;

    @Size(max = 20, message = "颜色值太长啦")
    private String color;

    @Size(max = 255, message = "标签太长啦")
    private String tags;

    /** 状态：1可领养 0已领养 */
    private Integer status;

    /** 是否首页推荐：1是 0否 */
    private Integer featured;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmoji() { return emoji; }
    public void setEmoji(String emoji) { this.emoji = emoji; }
    public String getBreed() { return breed; }
    public void setBreed(String breed) { this.breed = breed; }
    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }
    public Long getBreedId() { return breedId; }
    public void setBreedId(Long breedId) { this.breedId = breedId; }
    public String getAge() { return age; }
    public void setAge(String age) { this.age = age; }
    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    public Integer getFeatured() { return featured; }
    public void setFeatured(Integer featured) { this.featured = featured; }
}
