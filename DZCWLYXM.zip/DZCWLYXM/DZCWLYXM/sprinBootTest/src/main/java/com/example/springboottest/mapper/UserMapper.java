package com.example.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboottest.entity.User;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户表 Mapper
 * 继承 BaseMapper 后自带 insert / selectOne / updateById 等 CRUD 方法
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {
}
