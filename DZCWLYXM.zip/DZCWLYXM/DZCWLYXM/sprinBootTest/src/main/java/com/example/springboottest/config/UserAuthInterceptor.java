package com.example.springboottest.config;

import com.example.springboottest.security.LoginSessionStore;
import com.example.springboottest.security.UserContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * 前台用户身份解析拦截器
 *
 * 只做「认人」，不做「拦人」：
 *   - 带了合法 token 就把 userId 放进 UserContext；
 *   - 没带 / 过期就当作游客，由具体接口自行决定是否要求登录
 *     （串门页允许游客看，但写操作和「我的访客」必须登录）。
 *
 * 支持三种携带方式，方便前端 / Postman 调试：
 *   Authorization: Bearer xxx
 *   X-Token: xxx
 *   ?token=xxx
 */
@Component
public class UserAuthInterceptor implements HandlerInterceptor {

    private static final String BEARER = "Bearer ";

    private final LoginSessionStore loginSessionStore;

    public UserAuthInterceptor(LoginSessionStore loginSessionStore) {
        this.loginSessionStore = loginSessionStore;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        UserContext.clear();
        String token = extractToken(request);
        Long userId = loginSessionStore.resolve(token);
        if (userId != null) {
            UserContext.set(userId);
        }
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception ex) {
        // Tomcat 线程复用，不清理会串号
        UserContext.clear();
    }

    private String extractToken(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith(BEARER)) {
            return header.substring(BEARER.length()).trim();
        }
        if (header != null && !header.isBlank()) {
            return header.trim();
        }
        String xToken = request.getHeader("X-Token");
        if (xToken != null && !xToken.isBlank()) {
            return xToken.trim();
        }
        return request.getParameter("token");
    }
}
