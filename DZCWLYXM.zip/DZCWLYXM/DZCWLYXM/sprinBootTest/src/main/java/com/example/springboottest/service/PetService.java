package com.example.springboottest.service;

import com.example.springboottest.vo.PageVO;
import com.example.springboottest.vo.PetCategoryVO;
import com.example.springboottest.vo.PetVO;

import java.util.List;

/**
 * 宠物业务接口：首页展示 + 搜索 + 分级分类
 */
public interface PetService {

    /**
     * 分页查询宠物列表
     * @param keyword    关键词（名字/品种/城市/标签模糊匹配），可空
     * @param categoryId 一级分类ID，可空（0或null表示全部）
     * @param breedId    二级分类ID（品种），可空
     * @param featured   只查首页推荐（1），可空
     * @param page       页码，从1开始
     * @param size       每页条数
     */
    PageVO<PetVO> list(String keyword, Long categoryId, Long breedId, Integer featured, Long page, Long size);

    /** 搜索宠物（list 的语义化别名，前端 /pets/search 用） */
    PageVO<PetVO> search(String keyword, Long categoryId, Long breedId, Long page, Long size);

    /** 分级分类树（一级 + 二级品种） */
    List<PetCategoryVO> categoryTree();

    /** 根据ID查详情 */
    PetVO detail(Long id);
}
