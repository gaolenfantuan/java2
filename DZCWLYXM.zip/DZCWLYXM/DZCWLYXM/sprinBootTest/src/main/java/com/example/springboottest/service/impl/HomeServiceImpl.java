package com.example.springboottest.service.impl;

import com.example.springboottest.entity.Category;
import com.example.springboottest.entity.HomeItem;
import com.example.springboottest.service.HomeService;
import com.example.springboottest.store.MemoryDataStore;
import com.example.springboottest.vo.CategoryVO;
import com.example.springboottest.vo.HomeItemVO;
import com.example.springboottest.vo.HomeStatsVO;
import com.example.springboottest.vo.PageVO;
import org.springframework.stereotype.Service;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 首页业务实现（内存版）
 *
 * 分类树、搜索筛选、详情、统计全部读取 MemoryDataStore，不再访问任何数据库。
 */
@Service
public class HomeServiceImpl implements HomeService {

    private static final int DEFAULT_SIZE = 12;
    private static final int MAX_SIZE = 50;

    private final MemoryDataStore store;

    public HomeServiceImpl(MemoryDataStore store) {
        this.store = store;
    }

    @Override
    public List<CategoryVO> getCategoryTree() {
        List<Category> all = store.listCategories(true);
        Map<Long, List<Category>> byParent = groupByParent(all);
        Map<Long, Long> directCount = countDirectly();

        List<CategoryVO> roots = new ArrayList<>();
        for (Category root : byParent.getOrDefault(0L, List.of())) {
            roots.add(buildNode(root, byParent, directCount));
        }
        return roots;
    }

    private CategoryVO buildNode(Category category, Map<Long, List<Category>> byParent, Map<Long, Long> directCount) {
        CategoryVO vo = new CategoryVO();
        vo.setId(category.getId());
        vo.setName(category.getName());
        vo.setCode(category.getCode());
        vo.setIcon(category.getIcon());
        vo.setParentId(category.getParentId());
        vo.setLevel(category.getLevel());

        long total = directCount.getOrDefault(category.getId(), 0L);
        for (Category child : byParent.getOrDefault(category.getId(), List.of())) {
            CategoryVO childVO = buildNode(child, byParent, directCount);
            vo.getChildren().add(childVO);
            total += childVO.getCount();
        }
        vo.setCount(total);
        return vo;
    }

    @Override
    public PageVO<HomeItemVO> search(String keyword, Long categoryId, Boolean includeChildren,
                                     String sort, Integer page, Integer size) {
        long current = (page == null || page < 1) ? 1 : page;
        long pageSize = (size == null || size < 1) ? DEFAULT_SIZE : Math.min(size, MAX_SIZE);

        List<Category> all = store.listCategories(true);
        Map<Long, List<Category>> byParent = groupByParent(all);
        Map<Long, Category> byId = all.stream().collect(Collectors.toMap(Category::getId, Function.identity()));

        List<HomeItem> candidates = new ArrayList<>(store.listItems(true));

        if (categoryId != null && categoryId > 0) {
            Set<Long> categoryIds = Boolean.FALSE.equals(includeChildren)
                    ? Set.of(categoryId)
                    : collectSelfAndDescendants(categoryId, byParent);
            candidates.removeIf(item -> !categoryIds.contains(item.getCategoryId()));
        }

        String kw = keyword == null ? "" : keyword.trim();
        if (!kw.isEmpty()) {
            List<String> terms = Arrays.stream(kw.split("\\s+"))
                    .filter(term -> !term.isBlank())
                    .toList();
            for (String term : terms) {
                Set<Long> matchedCategoryIds = new LinkedHashSet<>();
                for (Category category : all) {
                    if (category.getName().contains(term)) {
                        matchedCategoryIds.addAll(collectSelfAndDescendants(category.getId(), byParent));
                    }
                }
                candidates.removeIf(item -> !matchesTerm(item, term, matchedCategoryIds));
            }
        }

        String sortType = sort == null ? "default" : sort.toLowerCase();
        switch (sortType) {
            case "hot" -> candidates.sort(Comparator
                    .comparing(HomeItem::getLikes, Comparator.nullsLast(Comparator.reverseOrder()))
                    .thenComparing(HomeItem::getViews, Comparator.nullsLast(Comparator.reverseOrder()))
                    .thenComparing(HomeItem::getId));
            case "new" -> candidates.sort(Comparator
                    .comparing(HomeItem::getCreateTime, Comparator.nullsLast(Comparator.reverseOrder()))
                    .thenComparing(HomeItem::getId, Comparator.nullsLast(Comparator.reverseOrder())));
            default -> candidates.sort(Comparator
                    .comparing(HomeItem::getSort, Comparator.nullsLast(Comparator.naturalOrder()))
                    .thenComparing(HomeItem::getId));
        }

        long total = candidates.size();
        int from = (int) Math.min((current - 1) * pageSize, total);
        int to = (int) Math.min(from + pageSize, total);
        List<HomeItemVO> list = candidates.subList(from, to).stream()
                .map(item -> toVO(item, byId))
                .toList();

        return new PageVO<>(list, total, current, pageSize);
    }

    private boolean matchesTerm(HomeItem item, String term, Set<Long> matchedCategoryIds) {
        return contains(item.getTitle(), term)
                || contains(item.getSummary(), term)
                || contains(item.getTag(), term)
                || matchedCategoryIds.contains(item.getCategoryId());
    }

    private boolean contains(String source, String term) {
        return source != null && source.contains(term);
    }

    @Override
    public HomeItemVO getDetail(Long id) {
        HomeItem item = store.findItem(id);
        if (item == null || item.getStatus() == null || item.getStatus() != 1) {
            throw new IllegalArgumentException("这条内容已经不见啦，看看别的吧~");
        }

        store.incrementViews(id);
        item = store.findItem(id);

        List<Category> all = store.listCategories(true);
        Map<Long, Category> byId = all.stream().collect(Collectors.toMap(Category::getId, Function.identity()));
        return toVO(item, byId);
    }

    @Override
    public HomeStatsVO getStats() {
        List<HomeItem> items = store.listItems(true);
        long likeTotal = 0;
        long hotTotal = 0;
        for (HomeItem item : items) {
            likeTotal += item.getLikes() == null ? 0 : item.getLikes();
            if (item.getIsHot() != null && item.getIsHot() == 1) hotTotal++;
        }
        long categoryTotal = store.listCategories(true).size();
        return new HomeStatsVO((long) items.size(), categoryTotal, likeTotal, hotTotal);
    }

    private Map<Long, List<Category>> groupByParent(List<Category> all) {
        Map<Long, List<Category>> byParent = new LinkedHashMap<>();
        for (Category category : all) {
            Long parentId = category.getParentId() == null ? 0L : category.getParentId();
            byParent.computeIfAbsent(parentId, k -> new ArrayList<>()).add(category);
        }
        return byParent;
    }

    private Set<Long> collectSelfAndDescendants(Long rootId, Map<Long, List<Category>> byParent) {
        Set<Long> ids = new LinkedHashSet<>();
        Deque<Long> queue = new ArrayDeque<>();
        queue.add(rootId);
        while (!queue.isEmpty()) {
            Long id = queue.poll();
            if (!ids.add(id)) continue;
            for (Category child : byParent.getOrDefault(id, List.of())) {
                queue.add(child.getId());
            }
        }
        return ids;
    }

    private Map<Long, Long> countDirectly() {
        Map<Long, Long> counts = new HashMap<>();
        for (HomeItem item : store.listItems(true)) {
            if (item.getCategoryId() != null) {
                counts.merge(item.getCategoryId(), 1L, Long::sum);
            }
        }
        return counts;
    }

    private HomeItemVO toVO(HomeItem item, Map<Long, Category> byId) {
        HomeItemVO vo = new HomeItemVO();
        vo.setId(item.getId());
        vo.setTitle(item.getTitle());
        vo.setDesc(item.getSummary());
        vo.setEmoji(item.getEmoji());
        vo.setTag(item.getTag());
        vo.setBg(item.getCoverBg());
        vo.setCategoryId(item.getCategoryId());
        vo.setLikes(item.getLikes());
        vo.setViews(item.getViews());
        vo.setHot(item.getIsHot() != null && item.getIsHot() == 1);

        Category sub = byId.get(item.getCategoryId());
        if (sub != null) {
            vo.setSubCategory(sub.getName());
            Category parent = (sub.getParentId() != null && sub.getParentId() > 0)
                    ? byId.get(sub.getParentId())
                    : null;
            vo.setCategory(parent != null ? parent.getName() : sub.getName());
        }
        return vo;
    }
}
