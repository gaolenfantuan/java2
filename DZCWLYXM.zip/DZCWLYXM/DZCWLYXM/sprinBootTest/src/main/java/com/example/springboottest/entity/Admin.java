package com.example.springboottest.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.time.LocalDateTime;

/**
 * 后台管理员，对应数据库表 admin
 *
 * 为什么不复用 user 表：
 *   普通用户是「前台用户」，管理员是「后台运营」，
 *   两者登录入口、权限、字段都不一样，拆开更清楚，也不会让普通用户误登后台。
 */
public class Admin {

    private Long id;

    /** 登录用户名（唯一） */
    private String username;

    /** 昵称，后台右上角展示 */
    private String nickname;

    /** 密码密文（SHA-256 加盐），不返回给前端 */
    @JsonIgnore
    private String password;

    /** 状态：1 正常，0 禁用 */
    private Integer status;

    /** 逻辑删除：0 未删除，1 已删除 */
    @JsonIgnore
    private Integer deleted;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}
