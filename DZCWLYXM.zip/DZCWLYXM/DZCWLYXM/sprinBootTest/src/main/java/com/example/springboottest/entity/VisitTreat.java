package com.example.springboottest.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 送零食记录，对应数据库表 visit_treat
 *
 * 每成功投喂一次记一条，真正的限制是「访客背包里还有没有这个零食」（pet_user_item）。
 * 礼物本身是有限资源，所以不再额外限制每天次数，送完就没了。
 */
@TableName("visit_treat")
public class VisitTreat {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long hostUserId;

    private Long visitorId;

    /** 送的哪种零食 */
    private String itemCode;

    /** 送礼日期，便于统计「今天有没有被投喂」 */
    private LocalDate treatDate;

    private LocalDateTime createTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getHostUserId() {
        return hostUserId;
    }

    public void setHostUserId(Long hostUserId) {
        this.hostUserId = hostUserId;
    }

    public Long getVisitorId() {
        return visitorId;
    }

    public void setVisitorId(Long visitorId) {
        this.visitorId = visitorId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public LocalDate getTreatDate() {
        return treatDate;
    }

    public void setTreatDate(LocalDate treatDate) {
        this.treatDate = treatDate;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }
}
