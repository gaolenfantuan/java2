package com.example.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboottest.entity.VisitRecord;
import org.apache.ibatis.annotations.Mapper;

/**
 * 串门足迹 Mapper
 */
@Mapper
public interface VisitRecordMapper extends BaseMapper<VisitRecord> {
}
