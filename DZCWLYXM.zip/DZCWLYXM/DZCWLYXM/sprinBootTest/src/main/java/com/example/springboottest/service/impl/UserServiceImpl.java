package com.example.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.springboottest.dto.LoginRequest;
import com.example.springboottest.dto.RegisterRequest;
import com.example.springboottest.entity.User;
import com.example.springboottest.mapper.UserMapper;
import com.example.springboottest.security.LoginSessionStore;
import com.example.springboottest.service.UserService;
import com.example.springboottest.util.PasswordUtil;
import com.example.springboottest.vo.LoginVO;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * 用户业务实现（MySQL + MyBatis-Plus）
 *
 * 用户数据来自 pet_adoption.sys_user，注册写入数据库，服务重启后数据仍在。
 */
@Service
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;
    private final LoginSessionStore loginSessionStore;

    public UserServiceImpl(UserMapper userMapper, LoginSessionStore loginSessionStore) {
        this.userMapper = userMapper;
        this.loginSessionStore = loginSessionStore;
    }

    @Override
    public Long register(RegisterRequest request) {
        String username = request.getUsername().trim();

        if (isUsernameTaken(username)) {
            throw new IllegalArgumentException("这个手机号已经注册啦，直接登录吧~");
        }

        User user = new User();
        user.setUsername(username);
        String nickname = request.getNickname();
        user.setNickname(nickname == null || nickname.isBlank() ? username : nickname.trim());
        user.setPassword(PasswordUtil.encode(request.getPassword()));
        user.setStatus(1);
        user.setDeleted(0);
        user.setCreateTime(LocalDateTime.now());
        user.setUpdateTime(LocalDateTime.now());

        userMapper.insert(user);
        return user.getId();
    }

    @Override
    public LoginVO login(LoginRequest request) {
        String account = request.getUsername().trim();

        // 兼容管理后台演示账号
        if ("admin".equals(account) && PasswordUtil.matches(request.getPassword(), PasswordUtil.encode("admin888"))) {
            // admin 是演示用的虚拟账号（id=0），没有对应的 sys_user，不发前台会话
            String adminToken = UUID.randomUUID().toString().replace("-", "");
            return new LoginVO(0L, "admin", "超级管理员", adminToken);
        }

        // 支持用手机号或昵称登录
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getUsername, account).or().eq(User::getNickname, account);
        User user = userMapper.selectOne(wrapper);

        if (user == null || !PasswordUtil.matches(request.getPassword(), user.getPassword())) {
            throw new IllegalArgumentException("账号或密码不对哦，再检查一下~");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new IllegalArgumentException("这个账号已被禁用啦，请联系管理员~");
        }

        // 签发服务端会话：之后所有写接口的「当前用户」都从 token 解析，不再相信前端传的 userId
        String token = loginSessionStore.create(user.getId());
        if (token == null) {
            throw new IllegalArgumentException("账号状态异常，暂时无法登录，请联系管理员~");
        }
        return new LoginVO(user.getId(), user.getUsername(), user.getNickname(), token);
    }

    @Override
    public boolean isUsernameTaken(String username) {
        return userMapper.selectOne(
                new LambdaQueryWrapper<User>().eq(User::getUsername, username)
        ) != null;
    }
}
