package com.example.springboottest.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDateTime;

/**
 * 用户背包里的零食道具，对应数据库表 pet_user_item
 *
 * 串门送零食时会真实扣减这里的库存，扣到 0 就送不出去了。
 * 领取电子宠物时由后端发放新手零食包。
 */
@TableName("pet_user_item")
public class PetUserItem {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    /** 道具编码，例如 dried_fish */
    private String itemCode;

    /** 道具名称快照，例如 小鱼干 */
    private String itemName;

    /** 数量 */
    private Integer quantity;

    private LocalDateTime updateTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}
