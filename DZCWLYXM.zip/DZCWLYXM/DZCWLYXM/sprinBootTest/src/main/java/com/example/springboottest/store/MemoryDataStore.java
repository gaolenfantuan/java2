package com.example.springboottest.store;

import com.example.springboottest.entity.*;
import com.example.springboottest.util.PasswordUtil;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 全局内存数据源
 *
 * 本次改造后，后端不再依赖 DataSource / MyBatis-Plus / 任何数据库。
 * 用户、管理员、分类、首页内容以及小游戏数据全部在启动时初始化到 List/Map 中，
 * 所有 Service 只与本类交互；服务重启后数据恢复为初始种子数据。
 */
@Component
public class MemoryDataStore {

    private final Map<Long, User> users = new ConcurrentHashMap<>();
    private final AtomicLong userIdSeq = new AtomicLong(2);

    private final Map<Long, Admin> admins = new ConcurrentHashMap<>();

    private final List<Category> categories = new CopyOnWriteArrayList<>();
    private final AtomicLong categoryIdSeq = new AtomicLong(44);

    private final List<HomeItem> items = new CopyOnWriteArrayList<>();
    private final AtomicLong itemIdSeq = new AtomicLong(13);

    private final List<GameCard> gameCards = new CopyOnWriteArrayList<>();
    private final AtomicLong gameCardIdSeq = new AtomicLong(13);

    private final List<GameQuizQuestion> quizQuestions = new CopyOnWriteArrayList<>();
    private final AtomicLong quizQuestionIdSeq = new AtomicLong(13);

    private final Map<Long, GameUserPoint> points = new ConcurrentHashMap<>();
    private final List<GameUserCard> userCards = new CopyOnWriteArrayList<>();
    private final List<GameCheckin> checkins = new CopyOnWriteArrayList<>();
    private final List<GameQuizRecord> quizRecords = new CopyOnWriteArrayList<>();
    private final List<GameDrawRecord> drawRecords = new CopyOnWriteArrayList<>();
    private final List<GameUserAchievement> achievements = new CopyOnWriteArrayList<>();
    private final AtomicLong gameRowIdSeq = new AtomicLong(1);

    public MemoryDataStore() {
        initUsers();
        initAdmins();
        initCategories();
        initItems();
        initGameCards();
        initQuizQuestions();
    }

    // ==================================================================
    //  初始化种子数据
    // ==================================================================

    private void initUsers() {
        User user = new User();
        user.setId(1L);
        user.setUsername("kitty");
        user.setNickname("小猫咪");
        user.setPassword(PasswordUtil.encode("1234"));
        user.setStatus(1);
        user.setDeleted(0);
        user.setCreateTime(LocalDateTime.now());
        user.setUpdateTime(LocalDateTime.now());
        users.put(user.getId(), user);
    }

    private void initAdmins() {
        Admin admin = new Admin();
        admin.setId(1L);
        admin.setUsername("admin");
        admin.setNickname("超级管理员");
        // 本次要求：后台管理员账号 admin / admin888
        admin.setPassword(PasswordUtil.encode("admin888"));
        admin.setStatus(1);
        admin.setDeleted(0);
        admin.setCreateTime(LocalDateTime.now());
        admin.setUpdateTime(LocalDateTime.now());
        admins.put(admin.getId(), admin);
    }

    private void initCategories() {
        categories.add(category(1L, "甜点", "dessert", 0L, 1, "🍰", 1));
        categories.add(category(2L, "穿搭", "outfit", 0L, 1, "🎀", 2));
        categories.add(category(3L, "好物", "goods", 0L, 1, "🧸", 3));
        categories.add(category(4L, "心情", "mood", 0L, 1, "🌸", 4));

        categories.add(category(11L, "蛋糕", "cake", 1L, 2, "🍰", 1));
        categories.add(category(12L, "布丁", "pudding", 1L, 2, "🍮", 2));
        categories.add(category(13L, "甜甜圈", "donut", 1L, 2, "🍩", 3));
        categories.add(category(21L, "发饰", "hairpin", 2L, 2, "🎀", 1));
        categories.add(category(22L, "服装", "clothing", 2L, 2, "👗", 2));
        categories.add(category(23L, "袜子", "socks", 2L, 2, "🧦", 3));
        categories.add(category(31L, "咖啡", "coffee", 3L, 2, "☕", 1));
        categories.add(category(32L, "玩偶", "doll", 3L, 2, "🧸", 2));
        categories.add(category(33L, "数码", "digital", 3L, 2, "🎧", 3));
        categories.add(category(41L, "季节", "season", 4L, 2, "🌸", 1));
        categories.add(category(42L, "日常", "daily", 4L, 2, "🌷", 2));
        categories.add(category(43L, "习惯", "habit", 4L, 2, "📖", 3));
    }

    private void initItems() {
        items.add(item(1L, "草莓奶油蛋糕", "三层软绵戚风，夹着新鲜草莓和轻奶油。", "🍰", "#今日推荐", "linear-gradient(135deg,#ffe3ef,#ffc9de)", 11L, 128, 1024, 1, 1));
        items.add(item(2L, "焦糖布丁", "微微发苦的焦糖配滑嫩蛋奶，一口就化。", "🍮", "#下午茶", "linear-gradient(135deg,#fff2d8,#ffe0b3)", 12L, 96, 760, 0, 2));
        items.add(item(3L, "丝绒蝴蝶结发夹", "正红色丝绒，戴上去就是甜甜的小猫。", "🎀", "#点睛单品", "linear-gradient(135deg,#ffdbe6,#ffb6cc)", 21L, 215, 1680, 1, 3));
        items.add(item(4L, "粉色百褶裙", "轻盈有垂感，转起来像一朵开花的花瓣。", "👗", "#春日出街", "linear-gradient(135deg,#ffe8f4,#ffcfe6)", 22L, 174, 1310, 0, 4));
        items.add(item(5L, "猫咪拉花拿铁", "奶泡上画一只小猫，拍照超好看。", "☕", "#咖啡时间", "linear-gradient(135deg,#f3e7dd,#e6d2c3)", 31L, 88, 690, 0, 5));
        items.add(item(6L, "毛绒小熊抱枕", "软乎乎一大只，抱着睡觉特别安心。", "🧸", "#治愈系", "linear-gradient(135deg,#ffeede,#ffd9bd)", 32L, 302, 2140, 1, 6));
        items.add(item(7L, "樱花季限定", "一年只开两周，错过就要再等一年。", "🌸", "#季节限定", "linear-gradient(135deg,#ffe6f2,#ffd0e6)", 41L, 456, 3205, 1, 7));
        items.add(item(8L, "今日份好心情", "天气很好，适合出门走走，买一束花。", "🌷", "#记录生活", "linear-gradient(135deg,#fff0f5,#ffdcea)", 42L, 67, 540, 0, 8));
        items.add(item(9L, "草莓甜甜圈", "粉粉的糖霜加上彩针，看着就很开心。", "🍩", "#甜食控", "linear-gradient(135deg,#ffe4ee,#ffc7dc)", 13L, 143, 1150, 0, 9));
        items.add(item(10L, "粉色头戴耳机", "降噪不错，通勤路上安静听歌。", "🎧", "#数码好物", "linear-gradient(135deg,#ffe1ec,#ffc4db)", 33L, 121, 980, 0, 10));
        items.add(item(11L, "猫咪中筒袜", "袜口绣了小耳朵，露出来才发现很可爱。", "🧦", "#小心机", "linear-gradient(135deg,#fff0f7,#ffd9ea)", 23L, 59, 470, 0, 11));
        items.add(item(12L, "睡前读十页书", "把手机放远一点，读几页就困了。", "📖", "#好习惯", "linear-gradient(135deg,#f6efff,#e8dcff)", 43L, 41, 380, 0, 12));
    }

    private void initGameCards() {
        gameCards.add(card(1L, "strawberry_cake", "草莓奶油蛋糕", "🍰", "甜点", "RARE", "linear-gradient(135deg,#ffe3ef,#ffb6cf)", "三层戚风夹着草莓和轻奶油，是店里的招牌。", 10, 1));
        gameCards.add(card(2L, "bow_hairpin", "丝绒蝴蝶结", "🎀", "穿搭", "COMMON", "linear-gradient(135deg,#ffdbe6,#ffb0c8)", "正红色丝绒，戴上立刻甜甜的。", 20, 2));
        gameCards.add(card(3L, "caramel_pudding", "焦糖布丁", "🍮", "甜点", "COMMON", "linear-gradient(135deg,#fff2d8,#ffdfae)", "微微发苦的焦糖配滑嫩蛋奶，一勺就化。", 20, 3));
        gameCards.add(card(4L, "strawberry_donut", "草莓甜甜圈", "🍩", "甜点", "COMMON", "linear-gradient(135deg,#ffe4ee,#ffc2da)", "粉色糖霜撒彩针，看着就开心。", 20, 4));
        gameCards.add(card(5L, "milk_bottle", "限定牛奶瓶", "🥛", "甜点", "COMMON", "linear-gradient(135deg,#f4f7ff,#dfe9ff)", "玻璃瓶装的草莓牛奶，一天只出十瓶。", 20, 5));
        gameCards.add(card(6L, "teddy_doll", "毛绒小熊", "🧸", "好物", "RARE", "linear-gradient(135deg,#ffeede,#ffd6b5)", "软乎乎一大只，抱着睡觉特别安心。", 10, 6));
        gameCards.add(card(7L, "sakura_petal", "樱花瓣", "🌸", "心情", "COMMON", "linear-gradient(135deg,#ffe6f2,#ffcbdf)", "一年只开两周，落在手心里就化了。", 20, 7));
        gameCards.add(card(8L, "rainbow_candy", "彩虹糖", "🌈", "心情", "EPIC", "linear-gradient(135deg,#e8f4ff,#ffd9ec)", "七种颜色一把抓，心情也跟着变甜。", 4, 8));
        gameCards.add(card(9L, "star_hairtie", "星星发绳", "⭐", "穿搭", "COMMON", "linear-gradient(135deg,#fffbe0,#ffe9a8)", "随手一扎就有元气，星星朝上更可爱。", 20, 9));
        gameCards.add(card(10L, "heart_bag", "爱心小包", "👜", "穿搭", "RARE", "linear-gradient(135deg,#ffe1ef,#ffbdd8)", "能装下口红和零钱，出门刚刚好。", 10, 10));
        gameCards.add(card(11L, "angel_kitty", "天使小猫", "👼", "心情", "LEGENDARY", "linear-gradient(135deg,#fff8e7,#ffd9a8)", "据说看到它的人，这一周都会很幸运。", 1, 11));
        gameCards.add(card(12L, "golden_crown", "黄金皇冠", "👑", "好物", "LEGENDARY", "linear-gradient(135deg,#fff6cc,#ffd166)", "图鉴最高荣誉，只有最执着的人才集得到。", 1, 12));
    }

    private void initQuizQuestions() {
        quizQuestions.add(question(1L, "提拉米苏（Tiramisu）在意大利语里的原意是什么？", "带我走", "甜心", "早安", "云朵", "A", "甜点", "简单", 5, "Tiramisu 有「带我走」的意思，是它最浪漫的标签。", 1));
        quizQuestions.add(question(2L, "马卡龙最经典的层次口感是？", "外脆内软", "硬如石头", "咸香酥脆", "冰凉弹牙", "A", "甜点", "简单", 5, "好的马卡龙外壳薄脆、内里湿润，中间还有一层夹馅。", 2));
        quizQuestions.add(question(3L, "戚风蛋糕能烤得蓬松，关键靠什么打发？", "蛋白霜", "奶油", "黄油", "牛奶", "A", "甜点", "简单", 5, "蛋白霜撑起结构；翻拌时消泡就会塌，所以手法要轻。", 3));
        quizQuestions.add(question(4L, "慕斯之所以能凝固成形，通常靠的是？", "吉利丁", "面粉", "酵母", "小苏打", "A", "甜点", "中等", 5, "吉利丁（明胶）是慕斯凝固的主力，冷藏后才能定型。", 4));
        quizQuestions.add(question(5L, "舒芙蕾出炉后为什么会塌陷？", "温度下降导致气泡回缩", "糖放少了", "模具太大", "没放黄油", "A", "甜点", "中等", 5, "舒芙蕾靠热空气撑起来，一旦离炉降温就会自然回缩，最好立刻吃。", 5));
        quizQuestions.add(question(6L, "蛋糕上捏花朵造型用的「翻糖」，英文是？", "Fondant", "Cream", "Custard", "Meringue", "A", "甜点", "中等", 5, "Fondant 可塑性极强，翻糖花是蛋糕装饰的常见技法。", 6));
        quizQuestions.add(question(7L, "Hello Kitty 标志性的蝴蝶结一般戴在哪一侧？", "左耳", "右耳", "头顶", "脖子上", "A", "穿搭", "简单", 5, "她常年长在左耳上，是最好认的辨识点。", 7));
        quizQuestions.add(question(8L, "日系水手服最标志性的部件是？", "水手领", "西装领", "高领", "一字领", "A", "穿搭", "简单", 5, "水手领就是背后那块方方正正的方巾式领子。", 8));
        quizQuestions.add(question(9L, "洛丽塔（Lolita）风格最常见的裙型是？", "A 字蓬蓬裙", "紧身包臀裙", "直筒长裙", "工装短裤", "A", "穿搭", "简单", 5, "钟形裙撑撑出的蓬蓬裙是 Lolita 最典型的轮廓。", 9));
        quizQuestions.add(question(10L, "粉色系穿搭里，最安全的配色搭档是？", "白色与奶油色", "大红色与黑色", "荧光绿", "深棕与橄榄绿", "A", "穿搭", "中等", 5, "白色和奶油色能压住粉色的甜腻，整体更干净。", 10));
        quizQuestions.add(question(11L, "把「JK 制服」的 JK 展开，指的是？", "女子高中生", "老师", "大学生", "上班族", "A", "穿搭", "简单", 5, "JK 是日语「女子高校生」的罗马音缩写。", 11));
        quizQuestions.add(question(12L, "真丝、羊毛这类面料在清洗时最需要注意的是？", "冷水轻柔手洗", "开水烫洗", "强力甩干", "长时间暴晒", "A", "穿搭", "中等", 5, "蛋白质纤维怕高温怕拧，冷水轻揉、平铺阴干最安全。", 12));
    }

    // ==================================================================
    //  用户 / 管理员
    // ==================================================================

    public synchronized User findUserByUsername(String username) {
        return users.values().stream()
                .filter(u -> u.getDeleted() == null || u.getDeleted() == 0)
                .filter(u -> username != null && username.equals(u.getUsername()))
                .findFirst().orElse(null);
    }

    public synchronized User findUserById(Long id) {
        User user = users.get(id);
        return user != null && (user.getDeleted() == null || user.getDeleted() == 0) ? user : null;
    }

    public synchronized Long addUser(User user) {
        user.setId(userIdSeq.getAndIncrement());
        if (user.getCreateTime() == null) user.setCreateTime(LocalDateTime.now());
        if (user.getUpdateTime() == null) user.setUpdateTime(LocalDateTime.now());
        if (user.getDeleted() == null) user.setDeleted(0);
        users.put(user.getId(), user);
        return user.getId();
    }

    public synchronized Admin findAdminByUsername(String username) {
        return admins.values().stream()
                .filter(a -> a.getDeleted() == null || a.getDeleted() == 0)
                .filter(a -> username != null && username.equals(a.getUsername()))
                .findFirst().orElse(null);
    }

    // ==================================================================
    //  分类
    // ==================================================================

    public synchronized List<Category> listCategories(boolean enabledOnly) {
        return new ArrayList<>(categories.stream()
                .filter(c -> c.getDeleted() == null || c.getDeleted() == 0)
                .filter(c -> !enabledOnly || c.getStatus() != null && c.getStatus() == 1)
                .sorted((a, b) -> {
                    int bySort = Integer.compare(nvl(a.getSort()), nvl(b.getSort()));
                    return bySort != 0 ? bySort : Long.compare(a.getId(), b.getId());
                })
                .toList());
    }

    public synchronized Category findCategory(Long id) {
        return categories.stream()
                .filter(c -> c.getDeleted() == null || c.getDeleted() == 0)
                .filter(c -> c.getId().equals(id))
                .findFirst().orElse(null);
    }

    public synchronized Long addCategory(Category category) {
        category.setId(categoryIdSeq.getAndIncrement());
        if (category.getCreateTime() == null) category.setCreateTime(LocalDateTime.now());
        if (category.getUpdateTime() == null) category.setUpdateTime(LocalDateTime.now());
        if (category.getDeleted() == null) category.setDeleted(0);
        categories.add(category);
        return category.getId();
    }

    public synchronized void saveCategory(Category category) {
        category.setUpdateTime(LocalDateTime.now());
        categories.removeIf(c -> c.getId().equals(category.getId()));
        categories.add(category);
    }

    public synchronized void deleteCategory(Long id) {
        categories.removeIf(c -> c.getId().equals(id));
    }

    public synchronized int nextCategorySort(long parentId) {
        return categories.stream()
                .filter(c -> c.getDeleted() == null || c.getDeleted() == 0)
                .filter(c -> parentId == nvlLong(c.getParentId()))
                .mapToInt(c -> nvl(c.getSort()))
                .max().orElse(0) + 1;
    }

    // ==================================================================
    //  首页内容（业务上等价于后台的「宠物/内容」数据）
    // ==================================================================

    public synchronized List<HomeItem> listItems(boolean onlineOnly) {
        return new ArrayList<>(items.stream()
                .filter(i -> i.getDeleted() == null || i.getDeleted() == 0)
                .filter(i -> !onlineOnly || i.getStatus() != null && i.getStatus() == 1)
                .toList());
    }

    public synchronized HomeItem findItem(Long id) {
        return items.stream()
                .filter(i -> i.getDeleted() == null || i.getDeleted() == 0)
                .filter(i -> i.getId().equals(id))
                .findFirst().orElse(null);
    }

    public synchronized Long addItem(HomeItem item) {
        item.setId(itemIdSeq.getAndIncrement());
        if (item.getCreateTime() == null) item.setCreateTime(LocalDateTime.now());
        if (item.getUpdateTime() == null) item.setUpdateTime(LocalDateTime.now());
        if (item.getDeleted() == null) item.setDeleted(0);
        items.add(item);
        return item.getId();
    }

    public synchronized void saveItem(HomeItem item) {
        item.setUpdateTime(LocalDateTime.now());
        items.removeIf(i -> i.getId().equals(item.getId()));
        items.add(item);
    }

    public synchronized void deleteItem(Long id) {
        items.removeIf(i -> i.getId().equals(id));
    }

    public synchronized void incrementViews(Long id) {
        HomeItem item = findItem(id);
        if (item != null) item.setViews(nvl(item.getViews()) + 1);
    }

    public synchronized int nextItemSort() {
        return items.stream()
                .filter(i -> i.getDeleted() == null || i.getDeleted() == 0)
                .mapToInt(i -> nvl(i.getSort()))
                .max().orElse(0) + 1;
    }

    // ==================================================================
    //  小游戏数据
    // ==================================================================

    public synchronized List<GameCard> listGameCards() {
        return new ArrayList<>(gameCards);
    }

    public synchronized GameCard findGameCard(Long id) {
        return gameCards.stream().filter(c -> c.getId().equals(id)).findFirst().orElse(null);
    }

    public synchronized List<GameQuizQuestion> listQuizQuestions() {
        return new ArrayList<>(quizQuestions);
    }

    public synchronized GameQuizQuestion findQuizQuestion(Long id) {
        return quizQuestions.stream().filter(q -> q.getId().equals(id)).findFirst().orElse(null);
    }

    public synchronized GameUserPoint findPoint(Long userId) {
        return points.get(userId);
    }

    public synchronized GameUserPoint savePoint(GameUserPoint point) {
        if (point.getId() == null) point.setId(gameRowIdSeq.getAndIncrement());
        if (point.getUpdateTime() == null) point.setUpdateTime(LocalDateTime.now());
        point.setUpdateTime(LocalDateTime.now());
        points.put(point.getUserId(), point);
        return point;
    }

    public synchronized GameUserCard findUserCard(Long userId, Long cardId) {
        return userCards.stream()
                .filter(r -> r.getUserId().equals(userId) && r.getCardId().equals(cardId))
                .findFirst().orElse(null);
    }

    public synchronized List<GameUserCard> listUserCards(Long userId) {
        return new ArrayList<>(userCards.stream().filter(r -> r.getUserId().equals(userId)).toList());
    }

    public synchronized GameUserCard saveUserCard(GameUserCard row) {
        if (row.getId() == null) row.setId(gameRowIdSeq.getAndIncrement());
        userCards.removeIf(r -> r.getUserId().equals(row.getUserId()) && r.getCardId().equals(row.getCardId()));
        userCards.add(row);
        return row;
    }

    public synchronized List<GameCheckin> listCheckins(Long userId) {
        return new ArrayList<>(checkins.stream().filter(r -> r.getUserId().equals(userId)).toList());
    }

    public synchronized GameCheckin addCheckin(GameCheckin row) {
        row.setId(gameRowIdSeq.getAndIncrement());
        checkins.add(row);
        return row;
    }

    public synchronized List<GameQuizRecord> listQuizRecords(Long userId) {
        return new ArrayList<>(quizRecords.stream().filter(r -> r.getUserId().equals(userId)).toList());
    }

    public synchronized GameQuizRecord addQuizRecord(GameQuizRecord row) {
        row.setId(gameRowIdSeq.getAndIncrement());
        quizRecords.add(row);
        return row;
    }

    public synchronized List<GameDrawRecord> listDrawRecords(Long userId) {
        return new ArrayList<>(drawRecords.stream().filter(r -> r.getUserId().equals(userId)).toList());
    }

    public synchronized GameDrawRecord addDrawRecord(GameDrawRecord row) {
        row.setId(gameRowIdSeq.getAndIncrement());
        drawRecords.add(row);
        return row;
    }

    public synchronized List<GameUserAchievement> listAchievements(Long userId) {
        return new ArrayList<>(achievements.stream().filter(r -> r.getUserId().equals(userId)).toList());
    }

    public synchronized GameUserAchievement addAchievement(GameUserAchievement row) {
        row.setId(gameRowIdSeq.getAndIncrement());
        achievements.add(row);
        return row;
    }

    // ==================================================================
    //  种子数据构造工具
    // ==================================================================

    private Category category(long id, String name, String code, long parentId, int level, String icon, int sort) {
        Category c = new Category();
        c.setId(id);
        c.setName(name);
        c.setCode(code);
        c.setParentId(parentId);
        c.setLevel(level);
        c.setIcon(icon);
        c.setSort(sort);
        c.setStatus(1);
        c.setDeleted(0);
        c.setCreateTime(LocalDateTime.now());
        c.setUpdateTime(LocalDateTime.now());
        return c;
    }

    private HomeItem item(long id, String title, String summary, String emoji, String tag, String coverBg,
                          long categoryId, int likes, int views, int hot, int sort) {
        HomeItem i = new HomeItem();
        i.setId(id);
        i.setTitle(title);
        i.setSummary(summary);
        i.setEmoji(emoji);
        i.setTag(tag);
        i.setCoverBg(coverBg);
        i.setCategoryId(categoryId);
        i.setLikes(likes);
        i.setViews(views);
        i.setIsHot(hot);
        i.setSort(sort);
        i.setStatus(1);
        i.setDeleted(0);
        i.setCreateTime(LocalDateTime.now());
        i.setUpdateTime(LocalDateTime.now());
        return i;
    }

    private GameCard card(long id, String code, String name, String emoji, String series, String rarity,
                          String bg, String intro, int weight, int sort) {
        GameCard c = new GameCard();
        c.setId(id);
        c.setCode(code);
        c.setName(name);
        c.setEmoji(emoji);
        c.setSeries(series);
        c.setRarity(rarity);
        c.setBg(bg);
        c.setIntro(intro);
        c.setDropWeight(weight);
        c.setSort(sort);
        return c;
    }

    private GameQuizQuestion question(long id, String content, String a, String b, String c, String d,
                                      String answer, String category, String difficulty, int points,
                                      String explanation, int sort) {
        GameQuizQuestion q = new GameQuizQuestion();
        q.setId(id);
        q.setContent(content);
        q.setOptionA(a);
        q.setOptionB(b);
        q.setOptionC(c);
        q.setOptionD(d);
        q.setAnswerKey(answer);
        q.setCategory(category);
        q.setDifficulty(difficulty);
        q.setPoints(points);
        q.setExplanation(explanation);
        q.setSort(sort);
        return q;
    }

    private static int nvl(Integer value) {
        return value == null ? 0 : value;
    }

    private static long nvlLong(Long value) {
        return value == null ? 0L : value;
    }
}
