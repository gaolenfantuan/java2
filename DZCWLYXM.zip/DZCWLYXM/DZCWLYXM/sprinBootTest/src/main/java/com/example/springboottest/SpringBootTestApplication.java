package com.example.springboottest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.mybatis.spring.annotation.MapperScan;

/**
 * 启动类
 * 运行这个类的 main 方法即可启动服务（默认端口 8080）
 */
@SpringBootApplication
@MapperScan("com.example.springboottest.mapper")
public class SpringBootTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootTestApplication.class, args);
        System.out.println("""
                
                ==========================================
                  Hello Kitty 后端启动成功（内存数据模式）！
                  登录接口  POST http://localhost:8080/api/auth/login
                  注册接口  POST http://localhost:8080/api/auth/register
                  后台登录 POST http://localhost:8080/api/admin/auth/login
                  数据说明  不依赖 MySQL / H2，重启后恢复初始数据
                ==========================================
                """);
    }
}
