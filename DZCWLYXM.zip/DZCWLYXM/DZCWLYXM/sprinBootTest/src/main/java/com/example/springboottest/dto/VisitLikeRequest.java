package com.example.springboottest.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

/**
 * 点赞请求体
 *
 * 注意：这里只有「被点赞的主人」。点赞人是谁由服务端从 token 解析，
 * 前端即使偷偷塞 visitorId 也不会被采纳 —— 防止冒充别人刷赞。
 */
public class VisitLikeRequest {

    @NotNull(message = "缺少要点赞的主人 ID")
    @Positive(message = "主人 ID 不正确")
    private Long hostUserId;

    public Long getHostUserId() {
        return hostUserId;
    }

    public void setHostUserId(Long hostUserId) {
        this.hostUserId = hostUserId;
    }
}
