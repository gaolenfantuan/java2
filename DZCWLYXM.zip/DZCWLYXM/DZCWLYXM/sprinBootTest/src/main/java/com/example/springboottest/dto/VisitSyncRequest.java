package com.example.springboottest.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * 「我的毛孩子」把本地养成状态同步到服务端的请求体
 *
 * 前端养成的权威数据仍在 localStorage，这里只是存一份快照给串门页面看。
 * userId 字段仅为兼容旧版前端保留：服务端一律以 token 里的用户为准，
 * 传了别的 userId 会直接 403（见 VisitServiceImpl#sync）。
 */
public class VisitSyncRequest {

    private Long userId;

    @Size(max = 32, message = "宠物名字最多 32 个字")
    private String petName;

    /** cat / dog / bunny */
    @Pattern(regexp = "(?i)cat|dog|bunny", message = "宠物造型只能是 cat / dog / bunny")
    private String petType;

    @Size(max = 16, message = "颜色值不合法")
    private String petColor;

    @Size(max = 16, message = "表情不合法")
    private String petEmoji;

    @Size(max = 64, message = "品种最多 64 个字")
    private String petBreed;

    /** 心情值 */
    @Min(value = 0, message = "心情值不能小于 0")
    @Max(value = 100, message = "心情值不能大于 100")
    private Integer mood;

    /** 饱腹值（前端字段叫 satiety） */
    @Min(value = 0, message = "饱腹值不能小于 0")
    @Max(value = 100, message = "饱腹值不能大于 100")
    private Integer fullness;

    @Min(value = 0, message = "经验值不能小于 0")
    @Max(value = 999999, message = "经验值超出范围")
    private Integer exp;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public String getPetColor() {
        return petColor;
    }

    public void setPetColor(String petColor) {
        this.petColor = petColor;
    }

    public String getPetEmoji() {
        return petEmoji;
    }

    public void setPetEmoji(String petEmoji) {
        this.petEmoji = petEmoji;
    }

    public String getPetBreed() {
        return petBreed;
    }

    public void setPetBreed(String petBreed) {
        this.petBreed = petBreed;
    }

    public Integer getMood() {
        return mood;
    }

    public void setMood(Integer mood) {
        this.mood = mood;
    }

    public Integer getFullness() {
        return fullness;
    }

    public void setFullness(Integer fullness) {
        this.fullness = fullness;
    }

    public Integer getExp() {
        return exp;
    }

    public void setExp(Integer exp) {
        this.exp = exp;
    }
}
