package com.example.springboottest.vo;

/**
 * 领养站管理后台 - 概览统计
 */
public class ManageStatsVO {

    /** 宠物总数（未删除） */
    private Long petTotal;
    /** 可领养数量 */
    private Long adoptableTotal;
    /** 已领养数量 */
    private Long adoptedTotal;
    /** 首页推荐数量 */
    private Long featuredTotal;
    /** 分类总数 */
    private Long categoryTotal;
    /** 注册用户总数 */
    private Long userTotal;

    public Long getPetTotal() { return petTotal; }
    public void setPetTotal(Long petTotal) { this.petTotal = petTotal; }
    public Long getAdoptableTotal() { return adoptableTotal; }
    public void setAdoptableTotal(Long adoptableTotal) { this.adoptableTotal = adoptableTotal; }
    public Long getAdoptedTotal() { return adoptedTotal; }
    public void setAdoptedTotal(Long adoptedTotal) { this.adoptedTotal = adoptedTotal; }
    public Long getFeaturedTotal() { return featuredTotal; }
    public void setFeaturedTotal(Long featuredTotal) { this.featuredTotal = featuredTotal; }
    public Long getCategoryTotal() { return categoryTotal; }
    public void setCategoryTotal(Long categoryTotal) { this.categoryTotal = categoryTotal; }
    public Long getUserTotal() { return userTotal; }
    public void setUserTotal(Long userTotal) { this.userTotal = userTotal; }
}
