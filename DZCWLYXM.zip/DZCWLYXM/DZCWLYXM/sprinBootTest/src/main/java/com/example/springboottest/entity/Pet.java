package com.example.springboottest.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDateTime;

/**
 * 宠物实体，对应 pet_adoption.sys_pet
 */
@TableName("sys_pet")
public class Pet {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 宠物名字 */
    private String name;

    /** Q版头像 emoji */
    private String emoji;

    /** 品种名称 */
    private String breed;

    /** 一级分类ID：1猫咪 2狗狗 3小宠物 */
    @TableField("category_id")
    private Long categoryId;

    /** 二级分类ID（品种） */
    @TableField("breed_id")
    private Long breedId;

    /** 年龄 */
    private String age;

    /** 性别：弟弟/妹妹 */
    private String sex;

    /** 所在城市 */
    private String city;

    /** 卡片背景色 */
    private String color;

    /** 标签，英文逗号分隔 */
    private String tags;

    /** 状态：1可领养 0已领养 */
    private Integer status;

    /** 是否首页推荐：1是 0否 */
    private Integer featured;

    /** 逻辑删除：0否 1是 */
    private Integer deleted;

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("update_time")
    private LocalDateTime updateTime;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmoji() { return emoji; }
    public void setEmoji(String emoji) { this.emoji = emoji; }
    public String getBreed() { return breed; }
    public void setBreed(String breed) { this.breed = breed; }
    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }
    public Long getBreedId() { return breedId; }
    public void setBreedId(Long breedId) { this.breedId = breedId; }
    public String getAge() { return age; }
    public void setAge(String age) { this.age = age; }
    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    public Integer getFeatured() { return featured; }
    public void setFeatured(Integer featured) { this.featured = featured; }
    public Integer getDeleted() { return deleted; }
    public void setDeleted(Integer deleted) { this.deleted = deleted; }
    public LocalDateTime getCreateTime() { return createTime; }
    public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }
    public LocalDateTime getUpdateTime() { return updateTime; }
    public void setUpdateTime(LocalDateTime updateTime) { this.updateTime = updateTime; }
}
