package com.example.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboottest.entity.PetCategory;
import org.apache.ibatis.annotations.Mapper;

/**
 * 宠物分类表 Mapper
 */
@Mapper
public interface PetCategoryMapper extends BaseMapper<PetCategory> {
}
