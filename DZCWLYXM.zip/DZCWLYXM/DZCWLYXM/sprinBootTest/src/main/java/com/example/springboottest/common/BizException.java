package com.example.springboottest.common;

/**
 * 业务异常（带状态码）
 *
 * 与 IllegalArgumentException 的区别：
 *   IllegalArgumentException 一律按 400 返回；
 *   BizException 可以携带 401（未登录）/ 403（无权限）/ 404（不存在）等语义码，
 *   由 GlobalExceptionHandler 统一转成 Result{code, message, data}。
 *
 * 前端只需判断 Result.code：
 *   200 成功 / 400 参数或业务提示 / 401 未登录 / 403 无权限 / 404 资源不存在 / 500 服务器异常
 */
public class BizException extends RuntimeException {

    private final int code;

    public BizException(int code, String message) {
        super(message);
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    /** 参数不合法 / 业务规则不满足 */
    public static BizException badRequest(String message) {
        return new BizException(400, message);
    }

    /** 没登录，或者 token 过期 */
    public static BizException unauthorized(String message) {
        return new BizException(401, message);
    }

    /** 登录了，但操作的不是自己家的东西 */
    public static BizException forbidden(String message) {
        return new BizException(403, message);
    }

    /** 用户 / 宠物不存在 */
    public static BizException notFound(String message) {
        return new BizException(404, message);
    }
}
