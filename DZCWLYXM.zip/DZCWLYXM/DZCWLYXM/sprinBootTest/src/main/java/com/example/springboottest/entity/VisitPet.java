package com.example.springboottest.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDateTime;

/**
 * 串门用的「毛孩子快照」，对应数据库表 visit_pet
 *
 * 一个用户一条记录（user_id 就是主键）。前端在「我的毛孩子」里领取 / 喂食 / 逗玩后
 * 会把当前状态同步上来，别人来串门时看到的就是这份快照。
 */
@TableName("visit_pet")
public class VisitPet {

    /** 主人用户 ID，既是主键也是外键（逻辑上指向 sys_user.id） */
    @TableId(value = "user_id", type = IdType.INPUT)
    private Long userId;

    /** 宠物名字 */
    private String petName;

    /** 造型：cat / dog / bunny */
    private String petType;

    /** 主色，前端 3D 组件用 */
    private String petColor;

    /** 表情 emoji，列表兜底展示用 */
    private String petEmoji;

    /** 品种描述 */
    private String petBreed;

    /** 心情值 0-100 */
    private Integer mood;

    /** 饱腹值 0-100（对应前端 pet.satiety） */
    private Integer fullness;

    /** 经验值，等级由经验换算 */
    private Integer exp;

    /** 收到的赞 */
    private Integer likeCount;

    /** 收到的小鱼干 */
    private Integer treatCount;

    /** 最后同步时间 */
    private LocalDateTime updateTime;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public String getPetColor() {
        return petColor;
    }

    public void setPetColor(String petColor) {
        this.petColor = petColor;
    }

    public String getPetEmoji() {
        return petEmoji;
    }

    public void setPetEmoji(String petEmoji) {
        this.petEmoji = petEmoji;
    }

    public String getPetBreed() {
        return petBreed;
    }

    public void setPetBreed(String petBreed) {
        this.petBreed = petBreed;
    }

    public Integer getMood() {
        return mood;
    }

    public void setMood(Integer mood) {
        this.mood = mood;
    }

    public Integer getFullness() {
        return fullness;
    }

    public void setFullness(Integer fullness) {
        this.fullness = fullness;
    }

    public Integer getExp() {
        return exp;
    }

    public void setExp(Integer exp) {
        this.exp = exp;
    }

    public Integer getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(Integer likeCount) {
        this.likeCount = likeCount;
    }

    public Integer getTreatCount() {
        return treatCount;
    }

    public void setTreatCount(Integer treatCount) {
        this.treatCount = treatCount;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}
