package com.example.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboottest.entity.Pet;
import org.apache.ibatis.annotations.Mapper;

/**
 * 宠物表 Mapper
 */
@Mapper
public interface PetMapper extends BaseMapper<Pet> {
}
