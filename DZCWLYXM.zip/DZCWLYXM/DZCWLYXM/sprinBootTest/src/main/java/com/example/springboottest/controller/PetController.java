package com.example.springboottest.controller;

import com.example.springboottest.common.Result;
import com.example.springboottest.service.PetService;
import com.example.springboottest.vo.PageVO;
import com.example.springboottest.vo.PetCategoryVO;
import com.example.springboottest.vo.PetVO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 宠物首页 / 搜索接口
 *
 * 前端通过 Vite 代理（/api -> localhost:8080）调用：
 *   GET /api/pets/list?keyword=&categoryId=&breedId=&featured=&page=1&size=12
 *   GET /api/pets/search?keyword=&categoryId=&breedId=&page=1&size=12
 *   GET /api/pets/categories       分级分类树
 *   GET /api/pets/{id}             宠物详情
 */
@RestController
@RequestMapping("/api/pets")
public class PetController {

    private final PetService petService;

    public PetController(PetService petService) {
        this.petService = petService;
    }

    /** 首页宠物列表（支持关键词、分类、品种、推荐筛选 + 分页） */
    @GetMapping("/list")
    public Result<PageVO<PetVO>> list(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) Long breedId,
            @RequestParam(required = false) Integer featured,
            @RequestParam(defaultValue = "1") Long page,
            @RequestParam(defaultValue = "12") Long size) {
        return Result.success(petService.list(keyword, categoryId, breedId, featured, page, size));
    }

    /** 搜索宠物（语义化路径，参数同 list） */
    @GetMapping("/search")
    public Result<PageVO<PetVO>> search(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) Long breedId,
            @RequestParam(defaultValue = "1") Long page,
            @RequestParam(defaultValue = "12") Long size) {
        return Result.success(petService.search(keyword, categoryId, breedId, page, size));
    }

    /** 分级分类树（一级分类 + 二级品种） */
    @GetMapping("/categories")
    public Result<List<PetCategoryVO>> categories() {
        return Result.success(petService.categoryTree());
    }

    /** 宠物详情 */
    @GetMapping("/{id}")
    public Result<PetVO> detail(@PathVariable Long id) {
        PetVO vo = petService.detail(id);
        if (vo == null) return Result.error("没有找到这只小可爱~");
        return Result.success(vo);
    }
}
