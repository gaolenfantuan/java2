package com.example.springboottest.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 点赞记录，对应数据库表 visit_like
 *
 * 唯一索引 (host_user_id, visitor_id, like_date) 保证同一个人对同一只毛孩子
 * 「每天最多点赞 1 次」；第二天可以再来比心。
 */
@TableName("visit_like")
public class VisitLike {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 被点赞的毛孩子主人 */
    private Long hostUserId;

    /** 点赞的人 */
    private Long visitorId;

    /** 点赞日期，用于按天限次 */
    private LocalDate likeDate;

    private LocalDateTime createTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getHostUserId() {
        return hostUserId;
    }

    public void setHostUserId(Long hostUserId) {
        this.hostUserId = hostUserId;
    }

    public Long getVisitorId() {
        return visitorId;
    }

    public void setVisitorId(Long visitorId) {
        this.visitorId = visitorId;
    }

    public LocalDate getLikeDate() {
        return likeDate;
    }

    public void setLikeDate(LocalDate likeDate) {
        this.likeDate = likeDate;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }
}
