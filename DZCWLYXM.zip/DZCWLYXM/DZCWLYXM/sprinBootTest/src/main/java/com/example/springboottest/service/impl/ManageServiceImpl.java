package com.example.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.springboottest.dto.PetSaveRequest;
import com.example.springboottest.entity.Pet;
import com.example.springboottest.entity.PetCategory;
import com.example.springboottest.entity.User;
import com.example.springboottest.mapper.PetCategoryMapper;
import com.example.springboottest.mapper.PetMapper;
import com.example.springboottest.mapper.UserMapper;
import com.example.springboottest.service.ManageService;
import com.example.springboottest.vo.ManageStatsVO;
import com.example.springboottest.vo.PageVO;
import com.example.springboottest.vo.PetCategoryVO;
import com.example.springboottest.vo.PetVO;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 领养站管理后台业务实现（MySQL + MyBatis-Plus）
 */
@Service
public class ManageServiceImpl implements ManageService {

    private final PetMapper petMapper;
    private final PetCategoryMapper categoryMapper;
    private final UserMapper userMapper;

    public ManageServiceImpl(PetMapper petMapper, PetCategoryMapper categoryMapper, UserMapper userMapper) {
        this.petMapper = petMapper;
        this.categoryMapper = categoryMapper;
        this.userMapper = userMapper;
    }

    @Override
    public ManageStatsVO stats() {
        List<Pet> pets = petMapper.selectList(new LambdaQueryWrapper<Pet>().eq(Pet::getDeleted, 0));
        ManageStatsVO vo = new ManageStatsVO();
        vo.setPetTotal((long) pets.size());
        vo.setAdoptableTotal(pets.stream().filter(p -> Integer.valueOf(1).equals(p.getStatus())).count());
        vo.setAdoptedTotal(pets.stream().filter(p -> Integer.valueOf(0).equals(p.getStatus())).count());
        vo.setFeaturedTotal(pets.stream().filter(p -> Integer.valueOf(1).equals(p.getFeatured())).count());
        vo.setCategoryTotal((long) categoryMapper.selectCount(new LambdaQueryWrapper<PetCategory>().eq(PetCategory::getStatus, 1)));
        vo.setUserTotal((long) userMapper.selectCount(new LambdaQueryWrapper<User>().eq(User::getDeleted, 0)));
        return vo;
    }

    @Override
    public PageVO<PetVO> petList(String keyword, Long categoryId, Integer status, Long page, Long size) {
        if (page == null || page < 1) page = 1L;
        if (size == null || size < 1) size = 10L;
        if (size > 100) size = 100L;

        LambdaQueryWrapper<Pet> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Pet::getDeleted, 0);
        if (categoryId != null && categoryId > 0) wrapper.eq(Pet::getCategoryId, categoryId);
        if (status != null && (status == 0 || status == 1)) wrapper.eq(Pet::getStatus, status);
        String kw = keyword == null ? "" : keyword.trim();
        if (!kw.isEmpty()) {
            wrapper.and(w -> w.like(Pet::getName, kw).or().like(Pet::getBreed, kw)
                    .or().like(Pet::getCity, kw).or().like(Pet::getTags, kw));
        }
        wrapper.orderByDesc(Pet::getId);

        List<Pet> all = petMapper.selectList(wrapper);
        long total = all.size();
        int from = (int) Math.min((page - 1) * size, total);
        int to = (int) Math.min(from + size, total);
        List<Pet> rows = from >= to ? Collections.emptyList() : all.subList(from, to);

        Map<Long, String> catNames = categoryMapper.selectList(null).stream()
                .collect(Collectors.toMap(PetCategory::getId, PetCategory::getName, (a, b) -> a));
        List<PetVO> vos = rows.stream().map(p -> toVO(p, catNames)).collect(Collectors.toList());
        return new PageVO<>(vos, total, page, size);
    }

    @Override
    public Long createPet(PetSaveRequest request) {
        Pet pet = new Pet();
        applyRequest(pet, request);
        pet.setStatus(request.getStatus() == null ? 1 : request.getStatus());
        pet.setFeatured(request.getFeatured() == null ? 0 : request.getFeatured());
        pet.setDeleted(0);
        pet.setCreateTime(LocalDateTime.now());
        pet.setUpdateTime(LocalDateTime.now());
        petMapper.insert(pet);
        return pet.getId();
    }

    @Override
    public void updatePet(Long id, PetSaveRequest request) {
        Pet pet = petMapper.selectById(id);
        if (pet == null || Integer.valueOf(1).equals(pet.getDeleted())) {
            throw new IllegalArgumentException("这只宠物不存在或已被删除~");
        }
        applyRequest(pet, request);
        if (request.getStatus() != null) pet.setStatus(request.getStatus());
        if (request.getFeatured() != null) pet.setFeatured(request.getFeatured());
        pet.setUpdateTime(LocalDateTime.now());
        petMapper.updateById(pet);
    }

    @Override
    public void deletePet(Long id) {
        Pet pet = petMapper.selectById(id);
        if (pet == null) throw new IllegalArgumentException("这只宠物不存在~");
        pet.setDeleted(1);
        pet.setUpdateTime(LocalDateTime.now());
        petMapper.updateById(pet);
    }

    @Override
    public void changeStatus(Long id, Integer status) {
        Pet pet = petMapper.selectById(id);
        if (pet == null) throw new IllegalArgumentException("这只宠物不存在~");
        if (status == null || (status != 0 && status != 1)) throw new IllegalArgumentException("状态值不合法~");
        pet.setStatus(status);
        pet.setUpdateTime(LocalDateTime.now());
        petMapper.updateById(pet);
    }

    @Override
    public List<PetCategoryVO> categoryList() {
        List<PetCategory> all = categoryMapper.selectList(
                new LambdaQueryWrapper<PetCategory>().orderByAsc(PetCategory::getParentId, PetCategory::getSortOrder));
        List<Pet> allPets = petMapper.selectList(new LambdaQueryWrapper<Pet>().eq(Pet::getDeleted, 0));
        Map<Long, Long> counts = new java.util.HashMap<>();
        for (Pet pet : allPets) {
            if (pet.getCategoryId() != null) counts.merge(pet.getCategoryId(), 1L, Long::sum);
            if (pet.getBreedId() != null) counts.merge(pet.getBreedId(), 1L, Long::sum);
        }
        List<PetCategoryVO> list = new ArrayList<>();
        for (PetCategory c : all) {
            PetCategoryVO vo = new PetCategoryVO();
            vo.setId(c.getId());
            vo.setName(c.getName());
            vo.setIcon(c.getIcon());
            vo.setParentId(c.getParentId() == null ? 0L : c.getParentId());
            vo.setPetCount(counts.getOrDefault(c.getId(), 0L));
            list.add(vo);
        }
        return list;
    }

    @Override
    public Long createCategory(String name, Long parentId, String icon) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("分类名不能为空~");
        long pid = parentId == null ? 0L : parentId;
        boolean dup = categoryMapper.selectList(new LambdaQueryWrapper<PetCategory>()
                        .eq(PetCategory::getName, name.trim()).eq(PetCategory::getParentId, pid))
                .stream().anyMatch(c -> Integer.valueOf(1).equals(c.getStatus()));
        if (dup) throw new IllegalArgumentException("同一级下已经有叫「" + name + "」的分类啦~");
        PetCategory c = new PetCategory();
        c.setName(name.trim());
        c.setParentId(pid);
        c.setIcon(icon == null || icon.isBlank() ? "🐾" : icon.trim());
        c.setSortOrder(0);
        c.setStatus(1);
        categoryMapper.insert(c);
        return c.getId();
    }

    @Override
    public void deleteCategory(Long id) {
        long childCount = categoryMapper.selectCount(new LambdaQueryWrapper<PetCategory>().eq(PetCategory::getParentId, id));
        if (childCount > 0) throw new IllegalArgumentException("这个分类还有子分类，请先删除子分类~");
        long petCount = petMapper.selectCount(new LambdaQueryWrapper<Pet>().eq(Pet::getCategoryId, id).eq(Pet::getDeleted, 0));
        if (petCount > 0) throw new IllegalArgumentException("这个分类下还有 " + petCount + " 只宠物，不能删除~");
        categoryMapper.deleteById(id);
    }

    @Override
    public PageVO<User> userList(String keyword, Long page, Long size) {
        if (page == null || page < 1) page = 1L;
        if (size == null || size < 1) size = 10L;
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getDeleted, 0);
        String kw = keyword == null ? "" : keyword.trim();
        if (!kw.isEmpty()) {
            wrapper.and(w -> w.like(User::getUsername, kw).or().like(User::getNickname, kw));
        }
        wrapper.orderByDesc(User::getId);
        List<User> all = userMapper.selectList(wrapper);
        // 不把密码返回给前端
        all.forEach(u -> u.setPassword(""));
        long total = all.size();
        int from = (int) Math.min((page - 1) * size, total);
        int to = (int) Math.min(from + size, total);
        List<User> rows = from >= to ? Collections.emptyList() : all.subList(from, to);
        return new PageVO<>(rows, total, page, size);
    }

    private void applyRequest(Pet pet, PetSaveRequest r) {
        pet.setName(r.getName().trim());
        pet.setEmoji(r.getEmoji() == null || r.getEmoji().isBlank() ? "🐾" : r.getEmoji().trim());
        pet.setBreed(r.getBreed().trim());
        pet.setCategoryId(r.getCategoryId());
        pet.setBreedId(r.getBreedId());
        pet.setAge(r.getAge());
        pet.setSex(r.getSex());
        pet.setCity(r.getCity());
        pet.setColor(r.getColor() == null || r.getColor().isBlank() ? "#ffd84d" : r.getColor().trim());
        pet.setTags(r.getTags());
    }

    private PetVO toVO(Pet p, Map<Long, String> catNames) {
        PetVO vo = new PetVO();
        vo.setId(p.getId());
        vo.setEmoji(p.getEmoji());
        vo.setName(p.getName());
        vo.setBreed(p.getBreed());
        vo.setCategoryName(catNames.get(p.getCategoryId()));
        vo.setBreedId(p.getBreedId());
        vo.setAge(p.getAge());
        vo.setSex(p.getSex());
        vo.setCity(p.getCity());
        vo.setColor(p.getColor());
        String tags = p.getTags();
        vo.setTags(tags == null || tags.isBlank() ? Collections.emptyList()
                : Arrays.stream(tags.split(",")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList()));
        vo.setStatus(p.getStatus());
        vo.setFeatured(p.getFeatured());
        return vo;
    }
}
