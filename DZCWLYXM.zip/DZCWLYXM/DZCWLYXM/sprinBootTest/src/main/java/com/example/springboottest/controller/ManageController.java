package com.example.springboottest.controller;

import com.example.springboottest.common.Result;
import com.example.springboottest.dto.PetSaveRequest;
import com.example.springboottest.entity.User;
import com.example.springboottest.service.ManageService;
import com.example.springboottest.vo.ManageStatsVO;
import com.example.springboottest.vo.PageVO;
import com.example.springboottest.vo.PetCategoryVO;
import com.example.springboottest.vo.PetVO;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 领养站管理后台接口（操作 MySQL 真实数据，需带 X-Admin-Token）
 *
 * 登录仍用现有的 POST /api/admin/auth/login（admin / admin888）
 */
@RestController
@RequestMapping("/api/manage")
public class ManageController {

    private final ManageService manageService;

    public ManageController(ManageService manageService) {
        this.manageService = manageService;
    }

    /** 概览统计 */
    @GetMapping("/stats")
    public Result<ManageStatsVO> stats() {
        return Result.success(manageService.stats());
    }

    /** 宠物管理列表（含所有状态） */
    @GetMapping("/pets")
    public Result<PageVO<PetVO>> pets(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) Integer status,
            @RequestParam(defaultValue = "1") Long page,
            @RequestParam(defaultValue = "10") Long size) {
        return Result.success(manageService.petList(keyword, categoryId, status, page, size));
    }

    /** 新增宠物 */
    @PostMapping("/pets")
    public Result<Long> createPet(@Valid @RequestBody PetSaveRequest request) {
        return Result.success("新增成功", manageService.createPet(request));
    }

    /** 编辑宠物 */
    @PutMapping("/pets/{id}")
    public Result<Void> updatePet(@PathVariable Long id, @Valid @RequestBody PetSaveRequest request) {
        manageService.updatePet(id, request);
        return Result.success("保存成功", null);
    }

    /** 删除宠物（逻辑删除） */
    @DeleteMapping("/pets/{id}")
    public Result<Void> deletePet(@PathVariable Long id) {
        manageService.deletePet(id);
        return Result.success("删除成功", null);
    }

    /** 改状态：1可领养 0已领养 */
    @PatchMapping("/pets/{id}/status")
    public Result<Void> changeStatus(@PathVariable Long id, @RequestParam Integer status) {
        manageService.changeStatus(id, status);
        return Result.success("状态已更新", null);
    }

    /** 分类列表 */
    @GetMapping("/categories")
    public Result<List<PetCategoryVO>> categories() {
        return Result.success(manageService.categoryList());
    }

    /** 新增分类 */
    @PostMapping("/categories")
    public Result<Long> createCategory(@RequestParam String name,
                                       @RequestParam(required = false) Long parentId,
                                       @RequestParam(required = false) String icon) {
        return Result.success("新增成功", manageService.createCategory(name, parentId, icon));
    }

    /** 删除分类 */
    @DeleteMapping("/categories/{id}")
    public Result<Void> deleteCategory(@PathVariable Long id) {
        manageService.deleteCategory(id);
        return Result.success("删除成功", null);
    }

    /** 用户列表 */
    @GetMapping("/users")
    public Result<PageVO<User>> users(
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "1") Long page,
            @RequestParam(defaultValue = "10") Long size) {
        return Result.success(manageService.userList(keyword, page, size));
    }
}
