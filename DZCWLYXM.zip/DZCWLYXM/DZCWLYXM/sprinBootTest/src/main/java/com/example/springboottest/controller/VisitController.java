package com.example.springboottest.controller;

import com.example.springboottest.common.Result;
import com.example.springboottest.dto.VisitLikeRequest;
import com.example.springboottest.dto.VisitSyncRequest;
import com.example.springboottest.dto.VisitTreatRequest;
import com.example.springboottest.service.VisitService;
import com.example.springboottest.vo.VisitHomeVO;
import com.example.springboottest.vo.VisitItemVO;
import com.example.springboottest.vo.VisitTargetVO;
import com.example.springboottest.vo.VisitorVO;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * 串门轻社交接口（/api/visit/**）
 *
 * 身份获取：前端在请求头带 Authorization: Bearer ＜token＞（也兼容 X-Token / ?token=），
 * 由 UserAuthInterceptor 解析成当前用户，写在 UserContext 里。
 * 因此所有写接口的参数里都【没有】visitorId —— 前端传了也不会被采纳。
 *
 * 接口清单：
 *   GET  /api/visit/resolve?keyword=          按用户 ID / 昵称 / 手机号解析串门目标
 *   GET  /api/visit/pet/{userId}              查询对方宠物公开信息（只读，自动记来访足迹）
 *   GET  /api/visit/home?userId=              同上，兼容旧前端的路径
 *   POST /api/visit/like                      点赞（不能自赞，每天 1 次，对方心情 +5）
 *   POST /api/visit/treat                     送零食（扣访客背包库存，加饱腹 / 心情）
 *   GET  /api/visit/items                     我的零食背包
 *   GET  /api/visit/visitors?limit=5          谁来看过我（只能查自己）
 *   POST /api/visit/sync                      同步「我的毛孩子」快照（只能改自己的宠物）
 *
 * 返回结构沿用项目统一的 Result{ code, message, data }：
 *   200 成功 / 400 参数或业务提示 / 401 未登录 / 403 无权限 / 404 不存在 / 500 服务器异常
 */
@RestController
@RequestMapping("/api/visit")
@Validated
public class VisitController {

    private final VisitService visitService;

    public VisitController(VisitService visitService) {
        this.visitService = visitService;
    }

    /** 输入框校验：把 ID / 昵称换成真实用户 */
    @GetMapping("/resolve")
    public Result<VisitTargetVO> resolve(
            @RequestParam @NotBlank(message = "先输入对方的 ID 或昵称吧～") String keyword) {
        return Result.success(visitService.resolve(keyword));
    }

    /** 查询对方宠物公开信息：只读接口，已登录访客会顺手记一条来访足迹 */
    @GetMapping("/pet/{userId}")
    public Result<VisitHomeVO> pet(@PathVariable @Positive(message = "用户 ID 不正确") Long userId) {
        return Result.success(visitService.home(userId));
    }

    /** 与 /pet/{userId} 等价，保留给已有前端 */
    @GetMapping("/home")
    public Result<VisitHomeVO> home(@RequestParam @Positive(message = "用户 ID 不正确") Long userId) {
        return Result.success(visitService.home(userId));
    }

    /** 点赞 */
    @PostMapping("/like")
    public Result<Map<String, Object>> like(@Valid @RequestBody VisitLikeRequest request) {
        return Result.success(visitService.like(request));
    }

    /** 送零食 */
    @PostMapping("/treat")
    public Result<Map<String, Object>> treat(@Valid @RequestBody VisitTreatRequest request) {
        return Result.success(visitService.treat(request));
    }

    /** 我的零食背包 */
    @GetMapping("/items")
    public Result<List<VisitItemVO>> myItems() {
        return Result.success(visitService.myItems());
    }

    /** 谁来看过我（默认 5 条，最多 20 条） */
    @GetMapping("/visitors")
    public Result<List<VisitorVO>> visitors(
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) @Min(value = 1, message = "至少查 1 条") @Max(value = 20, message = "最多查 20 条") Integer limit) {
        return Result.success(visitService.visitors(userId, limit));
    }

    /** 「我的毛孩子」把本地状态同步上来（只能同步自己的） */
    @PostMapping("/sync")
    public Result<Void> sync(@Valid @RequestBody VisitSyncRequest request) {
        visitService.sync(request);
        return Result.success("同步成功", null);
    }
}
