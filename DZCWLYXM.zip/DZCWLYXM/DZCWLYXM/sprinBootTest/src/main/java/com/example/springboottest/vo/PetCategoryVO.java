package com.example.springboottest.vo;

import java.util.ArrayList;
import java.util.List;

/**
 * 分级分类 VO：一个一级分类下挂多个二级品种
 */
public class PetCategoryVO {

    private Long id;
    private String name;
    private String icon;
    /** 父分类ID，0表示一级分类 */
    private Long parentId;
    /** 该分类下的宠物数量 */
    private Long petCount;
    /** 一级分类的二级品种列表 */
    private List<PetCategoryVO> children = new ArrayList<>();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }
    public Long getParentId() { return parentId; }
    public void setParentId(Long parentId) { this.parentId = parentId; }
    public Long getPetCount() { return petCount; }
    public void setPetCount(Long petCount) { this.petCount = petCount; }
    public List<PetCategoryVO> getChildren() { return children; }
    public void setChildren(List<PetCategoryVO> children) { this.children = children; }
}
