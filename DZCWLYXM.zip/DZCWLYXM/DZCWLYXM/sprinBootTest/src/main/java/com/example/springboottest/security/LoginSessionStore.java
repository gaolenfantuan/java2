package com.example.springboottest.security;

import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 登录会话存储（token ＞ 用户ID）
 *
 * 项目原来登录只返回一个随机 UUID，token 没有落库也没在服务端保存，
 * 任何人都能随便编一个 visitorId 冒充别人。这里补上服务端会话：
 *   - 登录成功时 create(userId) 生成 token 并记住归属；
 *   - 后续请求带 Authorization: Bearer ＜token＞，由 UserAuthInterceptor 解析出 userId。
 *
 * 单机内存实现，服务重启后需要重新登录（和原来体验一致）。
 * 以后要换成 Sa-Token / Redis，只需替换本类与拦截器里的取值逻辑，
 * 业务代码统一从 UserContext 拿当前用户，不需要改动。
 */
@Component
public class LoginSessionStore {

    /** token 有效期：7 天 */
    private static final long TTL_MILLIS = Duration.ofDays(7).toMillis();

    /** 简单的会话对象 */
    private static final class Session {
        private final Long userId;
        private final long expireAt;

        private Session(Long userId, long expireAt) {
            this.userId = userId;
            this.expireAt = expireAt;
        }
    }

    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    /** 登录成功后签发 token */
    public String create(Long userId) {
        if (userId == null || userId <= 0) {
            return null;
        }
        purgeExpired();
        String token = UUID.randomUUID().toString().replace("-", "");
        sessions.put(token, new Session(userId, System.currentTimeMillis() + TTL_MILLIS));
        return token;
    }

    /** 解析 token，找不到或已过期返回 null（不抛异常，由业务决定是否必须登录） */
    public Long resolve(String token) {
        if (token == null || token.isBlank()) {
            return null;
        }
        Session session = sessions.get(token.trim());
        if (session == null) {
            return null;
        }
        if (session.expireAt < System.currentTimeMillis()) {
            sessions.remove(token.trim());
            return null;
        }
        return session.userId;
    }

    /** 退出登录 */
    public void remove(String token) {
        if (token != null && !token.isBlank()) {
            sessions.remove(token.trim());
        }
    }

    /** 顺手清理过期会话，避免内存无限增长 */
    private void purgeExpired() {
        long now = System.currentTimeMillis();
        sessions.entrySet().removeIf(entry -> entry.getValue().expireAt < now);
    }
}
