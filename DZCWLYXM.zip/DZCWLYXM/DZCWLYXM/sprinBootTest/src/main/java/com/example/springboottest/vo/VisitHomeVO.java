package com.example.springboottest.vo;

import java.util.List;

/**
 * 串门页面主数据：一次请求拿齐主人信息、毛孩子状态、我的点赞/送礼状态、最近访客
 */
public class VisitHomeVO {

    private Long userId;
    private String nickname;
    /** 访客是不是主人自己 */
    private Boolean isSelf;
    /** 我有没有点过赞 */
    private Boolean liked;
    /** 我今天有没有送过小鱼干 */
    private Boolean treatedToday;
    /** 毛孩子快照，没领养时为 null */
    private VisitPetVO pet;
    /** 最近访客（默认 5 条） */
    private List<VisitorVO> visitors;
    /** 访客总数 */
    private Integer visitorCount;
    /** 访客自己的零食背包（未登录时为空列表） */
    private List<VisitItemVO> myItems;
    /** 默认推荐投喂的零食编码 */
    private String defaultItemCode;
    /** 当前访客能不能互动（已登录且不是主人自己） */
    private Boolean canInteract;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public Boolean getIsSelf() {
        return isSelf;
    }

    public void setIsSelf(Boolean isSelf) {
        this.isSelf = isSelf;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public Boolean getTreatedToday() {
        return treatedToday;
    }

    public void setTreatedToday(Boolean treatedToday) {
        this.treatedToday = treatedToday;
    }

    public VisitPetVO getPet() {
        return pet;
    }

    public void setPet(VisitPetVO pet) {
        this.pet = pet;
    }

    public List<VisitorVO> getVisitors() {
        return visitors;
    }

    public void setVisitors(List<VisitorVO> visitors) {
        this.visitors = visitors;
    }

    public Integer getVisitorCount() {
        return visitorCount;
    }

    public void setVisitorCount(Integer visitorCount) {
        this.visitorCount = visitorCount;
    }

    public List<VisitItemVO> getMyItems() {
        return myItems;
    }

    public void setMyItems(List<VisitItemVO> myItems) {
        this.myItems = myItems;
    }

    public String getDefaultItemCode() {
        return defaultItemCode;
    }

    public void setDefaultItemCode(String defaultItemCode) {
        this.defaultItemCode = defaultItemCode;
    }

    public Boolean getCanInteract() {
        return canInteract;
    }

    public void setCanInteract(Boolean canInteract) {
        this.canInteract = canInteract;
    }
}
