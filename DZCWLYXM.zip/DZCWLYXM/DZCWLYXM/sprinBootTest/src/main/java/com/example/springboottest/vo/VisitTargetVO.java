package com.example.springboottest.vo;

/**
 * 输入 ID / 昵称后解析出来的串门目标
 */
public class VisitTargetVO {

    private Long userId;
    private String nickname;
    /** 对方有没有领养毛孩子 */
    private Boolean hasPet;
    /** 对方毛孩子的造型，用于输入成功后的提示 */
    private String petName;
    private String petType;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public Boolean getHasPet() {
        return hasPet;
    }

    public void setHasPet(Boolean hasPet) {
        this.hasPet = hasPet;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }
}
