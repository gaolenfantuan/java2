package com.example.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.springboottest.entity.Pet;
import com.example.springboottest.entity.PetCategory;
import com.example.springboottest.mapper.PetCategoryMapper;
import com.example.springboottest.mapper.PetMapper;
import com.example.springboottest.service.PetService;
import com.example.springboottest.vo.PageVO;
import com.example.springboottest.vo.PetCategoryVO;
import com.example.springboottest.vo.PetVO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 宠物业务实现（MySQL + MyBatis-Plus）
 *
 * 支持：关键词搜索（名字/品种/城市/标签）、一级分类、二级品种分类、首页推荐筛选、分页。
 */
@Service
public class PetServiceImpl implements PetService {

    private final PetMapper petMapper;
    private final PetCategoryMapper categoryMapper;

    public PetServiceImpl(PetMapper petMapper, PetCategoryMapper categoryMapper) {
        this.petMapper = petMapper;
        this.categoryMapper = categoryMapper;
    }

    @Override
    public PageVO<PetVO> list(String keyword, Long categoryId, Long breedId,
                              Integer featured, Long page, Long size) {
        if (page == null || page < 1) page = 1L;
        if (size == null || size < 1) size = 12L;
        if (size > 50) size = 50L;

        LambdaQueryWrapper<Pet> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Pet::getStatus, 1);          // 只看可领养的
        wrapper.eq(Pet::getDeleted, 0);         // 排除逻辑删除

        // 分级分类筛选
        if (categoryId != null && categoryId > 0) {
            wrapper.eq(Pet::getCategoryId, categoryId);
        }
        if (breedId != null && breedId > 0) {
            wrapper.eq(Pet::getBreedId, breedId);
        }
        if (featured != null && featured == 1) {
            wrapper.eq(Pet::getFeatured, 1);
        }

        // 关键词搜索：名字 / 品种 / 城市 / 标签（标签是逗号分隔字符串，用 like 匹配）
        String kw = keyword == null ? "" : keyword.trim();
        if (!kw.isEmpty()) {
            wrapper.and(w -> w.like(Pet::getName, kw)
                    .or().like(Pet::getBreed, kw)
                    .or().like(Pet::getCity, kw)
                    .or().like(Pet::getTags, kw));
        }
        wrapper.orderByDesc(Pet::getFeatured).orderByAsc(Pet::getId);

        List<Pet> all = petMapper.selectList(wrapper);
        long total = all.size();

        // 内存分页（数据量小，简单可靠）
        int from = (int) Math.min((page - 1) * size, total);
        int to = (int) Math.min(from + size, total);
        List<Pet> pageRows = from >= to ? Collections.emptyList() : all.subList(from, to);

        // 分类ID -> 一级分类名
        Map<Long, String> categoryNames = categoryMapper.selectList(null).stream()
                .collect(Collectors.toMap(PetCategory::getId, PetCategory::getName, (a, b) -> a));

        List<PetVO> vos = pageRows.stream().map(p -> toVO(p, categoryNames)).collect(Collectors.toList());
        return new PageVO<>(vos, total, page, size);
    }

    @Override
    public PageVO<PetVO> search(String keyword, Long categoryId, Long breedId, Long page, Long size) {
        return list(keyword, categoryId, breedId, null, page, size);
    }

    @Override
    public List<PetCategoryVO> categoryTree() {
        List<PetCategory> all = categoryMapper.selectList(
                new LambdaQueryWrapper<PetCategory>()
                        .eq(PetCategory::getStatus, 1)
                        .orderByAsc(PetCategory::getSortOrder));

        Map<Long, PetCategoryVO> voMap = all.stream().collect(Collectors.toMap(
                PetCategory::getId,
                c -> {
                    PetCategoryVO vo = new PetCategoryVO();
                    vo.setId(c.getId());
                    vo.setName(c.getName());
                    vo.setIcon(c.getIcon());
                    return vo;
                },
                (a, b) -> a));

        List<PetCategoryVO> roots = new ArrayList<>();
        for (PetCategory c : all) {
            PetCategoryVO vo = voMap.get(c.getId());
            if (c.getParentId() == null || c.getParentId() == 0) {
                roots.add(vo);
            } else {
                PetCategoryVO parent = voMap.get(c.getParentId());
                if (parent != null) parent.getChildren().add(vo);
            }
        }
        return roots;
    }

    @Override
    public PetVO detail(Long id) {
        Pet pet = petMapper.selectById(id);
        if (pet == null) return null;
        Map<Long, String> categoryNames = categoryMapper.selectList(null).stream()
                .collect(Collectors.toMap(PetCategory::getId, PetCategory::getName, (a, b) -> a));
        return toVO(pet, categoryNames);
    }

    private PetVO toVO(Pet p, Map<Long, String> categoryNames) {
        PetVO vo = new PetVO();
        vo.setId(p.getId());
        vo.setEmoji(p.getEmoji());
        vo.setName(p.getName());
        vo.setBreed(p.getBreed());
        vo.setCategoryName(categoryNames.get(p.getCategoryId()));
        vo.setBreedId(p.getBreedId());
        vo.setAge(p.getAge());
        vo.setSex(p.getSex());
        vo.setCity(p.getCity());
        vo.setColor(p.getColor());
        String tags = p.getTags();
        vo.setTags(tags == null || tags.isBlank()
                ? Collections.emptyList()
                : Arrays.stream(tags.split(","))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList()));
        vo.setStatus(p.getStatus());
        vo.setFeatured(p.getFeatured());
        return vo;
    }
}
