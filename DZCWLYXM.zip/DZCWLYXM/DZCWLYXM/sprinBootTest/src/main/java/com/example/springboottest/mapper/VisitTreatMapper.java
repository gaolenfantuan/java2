package com.example.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboottest.entity.VisitTreat;
import org.apache.ibatis.annotations.Mapper;

/**
 * 送小鱼干 Mapper
 */
@Mapper
public interface VisitTreatMapper extends BaseMapper<VisitTreat> {
}
