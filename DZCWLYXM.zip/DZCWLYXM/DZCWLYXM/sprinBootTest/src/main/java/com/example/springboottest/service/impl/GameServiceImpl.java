package com.example.springboottest.service.impl;

import com.example.springboottest.entity.GameCard;
import com.example.springboottest.entity.GameCheckin;
import com.example.springboottest.entity.GameDrawRecord;
import com.example.springboottest.entity.GameQuizQuestion;
import com.example.springboottest.entity.GameQuizRecord;
import com.example.springboottest.entity.GameUserAchievement;
import com.example.springboottest.entity.GameUserCard;
import com.example.springboottest.entity.GameUserPoint;
import com.example.springboottest.service.GameService;
import com.example.springboottest.store.MemoryDataStore;
import com.example.springboottest.vo.CheckinResultVO;
import com.example.springboottest.vo.CollectResultVO;
import com.example.springboottest.vo.DrawResultVO;
import com.example.springboottest.vo.GameAchievementVO;
import com.example.springboottest.vo.GameCardVO;
import com.example.springboottest.vo.GameProfileVO;
import com.example.springboottest.vo.QuizQuestionVO;
import com.example.springboottest.vo.QuizResultVO;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 四个小游戏的业务实现（内存版）
 *
 * 原有 /api/game/** 路径和返回结构完全不变，底层数据从 MyBatis Mapper 换成 MemoryDataStore。
 */
@Service
public class GameServiceImpl implements GameService {

    private static final int WELCOME_POINTS = 60;
    private static final int CHECKIN_BASE_POINTS = 10;
    private static final int CHECKIN_WEEK_BONUS = 20;
    private static final int DRAW_COST = 20;
    private static final int DUPLICATE_REFUND = 5;
    private static final int QUIZ_DAILY_LIMIT = 10;
    private static final int QUIZ_DEFAULT_SIZE = 5;

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private static final Map<String, String> RARITY_NAME = new LinkedHashMap<>();

    static {
        RARITY_NAME.put("COMMON", "普通");
        RARITY_NAME.put("RARE", "稀有");
        RARITY_NAME.put("EPIC", "史诗");
        RARITY_NAME.put("LEGENDARY", "传说");
    }

    private enum AchType { COLLECT, CHECKIN, QUIZ }

    private static class AchDef {
        final String code;
        final String title;
        final String desc;
        final String emoji;
        final int target;
        final AchType type;

        AchDef(String code, String title, String desc, String emoji, int target, AchType type) {
            this.code = code;
            this.title = title;
            this.desc = desc;
            this.emoji = emoji;
            this.target = target;
            this.type = type;
        }
    }

    private static final List<AchDef> ACH_DEFS = List.of(
            new AchDef("collect_3", "初遇甜心", "收集 3 张卡片", "🍬", 3, AchType.COLLECT),
            new AchDef("collect_6", "甜点小达人", "收集 6 张卡片", "🍰", 6, AchType.COLLECT),
            new AchDef("collect_9", "图鉴收藏家", "收集 9 张卡片", "📚", 9, AchType.COLLECT),
            new AchDef("collect_12", "全图鉴达成", "收集全部 12 张卡片", "👑", 12, AchType.COLLECT),
            new AchDef("checkin_3", "三日不断", "连续打卡 3 天", "☀️", 3, AchType.CHECKIN),
            new AchDef("checkin_7", "一周甜心", "连续打卡 7 天", "📅", 7, AchType.CHECKIN),
            new AchDef("checkin_14", "半月坚持", "连续打卡 14 天", "🏅", 14, AchType.CHECKIN),
            new AchDef("quiz_5", "甜点学徒", "累计答对 5 题", "🎓", 5, AchType.QUIZ),
            new AchDef("quiz_10", "甜点博士", "累计答对 10 题", "🧁", 10, AchType.QUIZ)
    );

    private final MemoryDataStore store;

    public GameServiceImpl(MemoryDataStore store) {
        this.store = store;
    }

    // ==================================================================
    //  总览
    // ==================================================================

    @Override
    public GameProfileVO getProfile(Long userId) {
        checkUser(userId);
        GameUserPoint account = ensureAccount(userId);

        List<GameCard> cards = allCards();
        Map<Long, GameUserCard> stateMap = userCardMap(userId);

        int collected = (int) stateMap.values().stream().filter(this::isCollected).count();
        int favoriteCards = (int) stateMap.values().stream()
                .filter(row -> row.getFavorite() != null && row.getFavorite() == 1)
                .filter(this::isCollected)
                .count();

        int totalCards = cards.size();
        int percent = totalCards == 0 ? 0 : collected * 100 / totalCards;

        List<GameCheckin> checkins = checkins(userId);
        LocalDate today = LocalDate.now();
        boolean todayChecked = checkins.stream().anyMatch(c -> today.equals(c.getCheckinDate()));

        int correctCount = countQuizRecords(userId, true);
        int totalQuizCount = countQuizRecords(userId, null);
        int todayQuizCount = countQuizToday(userId);
        int drawCount = store.listDrawRecords(userId).size();

        List<GameAchievementVO> achievements = buildAchievements(userId, collected, maxStreak(userId), correctCount);

        GameProfileVO vo = new GameProfileVO();
        vo.setUserId(userId);
        vo.setPoints(nvl(account.getPoints()));
        vo.setTotalEarned(nvl(account.getTotalEarned()));
        vo.setTotalSpent(nvl(account.getTotalSpent()));
        vo.setCollectedCount(collected);
        vo.setTotalCards(totalCards);
        vo.setCollectPercent(percent);
        vo.setFavoriteCardCount(favoriteCards);
        vo.setStreakDays(currentStreak(userId));
        vo.setTodayChecked(todayChecked);
        vo.setTotalCheckinDays(checkins.size());
        vo.setCorrectCount(correctCount);
        vo.setTotalQuizCount(totalQuizCount);
        vo.setTodayQuizCount(todayQuizCount);
        vo.setDrawCount(drawCount);
        vo.setAchievements(achievements);
        vo.setNextAchievement(achievements.stream()
                .filter(a -> Boolean.FALSE.equals(a.getUnlocked()))
                .findFirst().orElse(null));
        return vo;
    }

    @Override
    public Map<String, Object> getMeta() {
        Map<String, Object> meta = new LinkedHashMap<>();
        meta.put("drawCost", DRAW_COST);
        meta.put("welcomePoints", WELCOME_POINTS);
        meta.put("checkinBasePoints", CHECKIN_BASE_POINTS);
        meta.put("checkinWeekBonus", CHECKIN_WEEK_BONUS);
        meta.put("duplicateRefund", DUPLICATE_REFUND);
        meta.put("quizDailyLimit", QUIZ_DAILY_LIMIT);

        List<GameCard> cards = allCards();
        List<Map<String, Object>> rarities = new ArrayList<>();
        RARITY_NAME.forEach((code, name) -> {
            int weight = cards.stream()
                    .filter(c -> code.equals(c.getRarity()))
                    .mapToInt(c -> nvl(c.getDropWeight()))
                    .sum();
            long count = cards.stream().filter(c -> code.equals(c.getRarity())).count();
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("code", code);
            item.put("name", name);
            item.put("weight", weight);
            item.put("count", count);
            rarities.add(item);
        });
        meta.put("rarities", rarities);
        meta.put("totalCards", cards.size());
        return meta;
    }

    // ==================================================================
    //  玩法一：卡片收集 / 收藏
    // ==================================================================

    @Override
    public List<GameCardVO> getCards(Long userId) {
        checkUser(userId);
        ensureAccount(userId);
        Map<Long, GameUserCard> stateMap = userCardMap(userId);
        return allCards().stream()
                .map(card -> toCardVO(card, stateMap.get(card.getId())))
                .collect(Collectors.toList());
    }

    @Override
    public CollectResultVO collect(Long userId, Long cardId) {
        checkUser(userId);
        ensureAccount(userId);
        GameCard card = requireCard(cardId);

        GameUserCard row = findUserCard(userId, cardId);
        boolean firstTime;
        if (row == null) {
            row = new GameUserCard();
            row.setUserId(userId);
            row.setCardId(cardId);
            row.setCollectCount(1);
            row.setFavorite(0);
            row.setFirstCollectTime(LocalDateTime.now());
            row.setUpdateTime(LocalDateTime.now());
            store.saveUserCard(row);
            firstTime = true;
        } else if (!isCollected(row)) {
            row.setCollectCount(1);
            row.setFirstCollectTime(LocalDateTime.now());
            row.setUpdateTime(LocalDateTime.now());
            store.saveUserCard(row);
            firstTime = true;
        } else {
            row.setCollectCount(nvl(row.getCollectCount()) + 1);
            row.setUpdateTime(LocalDateTime.now());
            store.saveUserCard(row);
            firstTime = false;
        }

        List<GameAchievementVO> newly = evaluateAchievements(userId);
        int collected = countCollected(userId);
        int total = allCards().size();

        CollectResultVO vo = new CollectResultVO();
        vo.setCard(toCardVO(card, row));
        vo.setFirstTime(firstTime);
        vo.setCollectedCount(collected);
        vo.setTotalCards(total);
        vo.setCollectPercent(total == 0 ? 0 : collected * 100 / total);
        vo.setNewAchievements(newly);
        vo.setMessage(firstTime
                ? "🎀 收到「" + card.getName() + "」啦！"
                : "这张已经收集过啦，又摸了一下~");
        return vo;
    }

    @Override
    public GameCardVO toggleFavorite(Long userId, Long cardId, Boolean favorite) {
        checkUser(userId);
        GameCard card = requireCard(cardId);
        GameUserCard row = findUserCard(userId, cardId);
        if (row == null || !isCollected(row)) {
            throw new IllegalArgumentException("先把这张卡片收集起来，才能收藏哦~");
        }
        int target;
        if (favorite == null) {
            target = (row.getFavorite() != null && row.getFavorite() == 1) ? 0 : 1;
        } else {
            target = favorite ? 1 : 0;
        }
        row.setFavorite(target);
        row.setUpdateTime(LocalDateTime.now());
        store.saveUserCard(row);
        return toCardVO(card, row);
    }

    // ==================================================================
    //  玩法二：每日打卡
    // ==================================================================

    @Override
    public CheckinResultVO checkin(Long userId) {
        checkUser(userId);
        ensureAccount(userId);
        LocalDate today = LocalDate.now();

        List<GameCheckin> checkins = checkins(userId);
        boolean todayChecked = checkins.stream().anyMatch(c -> today.equals(c.getCheckinDate()));

        CheckinResultVO vo = new CheckinResultVO();
        if (todayChecked) {
            GameUserPoint account = ensureAccount(userId);
            vo.setAlreadyChecked(true);
            vo.setStreakDays(currentStreak(userId));
            vo.setPointsAwarded(0);
            vo.setTotalCheckinDays(checkins.size());
            vo.setPoints(nvl(account.getPoints()));
            vo.setNewAchievements(List.of());
            vo.setMessage("今天已经打过卡啦，明天记得再来哦~");
            return vo;
        }

        GameCheckin latest = checkins.isEmpty() ? null : checkins.get(0);
        int streak = (latest != null && today.minusDays(1).equals(latest.getCheckinDate()))
                ? nvl(latest.getStreakDays()) + 1
                : 1;
        int award = CHECKIN_BASE_POINTS + (streak % 7 == 0 ? CHECKIN_WEEK_BONUS : 0);

        GameCheckin row = new GameCheckin();
        row.setUserId(userId);
        row.setCheckinDate(today);
        row.setStreakDays(streak);
        row.setPointsAwarded(award);
        row.setCreateTime(LocalDateTime.now());
        store.addCheckin(row);

        GameUserPoint account = addPoints(userId, award, true);
        List<GameAchievementVO> newly = evaluateAchievements(userId);

        vo.setAlreadyChecked(false);
        vo.setStreakDays(streak);
        vo.setPointsAwarded(award);
        vo.setTotalCheckinDays(checkins.size() + 1);
        vo.setPoints(nvl(account.getPoints()));
        vo.setNewAchievements(newly);
        vo.setMessage(streak % 7 == 0 && streak > 0
                ? "🎉 连续打卡 " + streak + " 天，额外奖励 " + CHECKIN_WEEK_BONUS + " 积分！"
                : "打卡成功，积分 +" + award + " ~");
        return vo;
    }

    // ==================================================================
    //  玩法三：甜点趣味答题
    // ==================================================================

    @Override
    public List<QuizQuestionVO> getQuizQuestions(Long userId, Integer limit) {
        checkUser(userId);
        ensureAccount(userId);
        int size = (limit == null || limit < 1) ? QUIZ_DEFAULT_SIZE : Math.min(limit, QUIZ_DAILY_LIMIT);

        List<GameQuizQuestion> all = store.listQuizQuestions().stream()
                .sorted(Comparator.comparing(q -> nvl(q.getSort())))
                .collect(Collectors.toList());
        if (all.isEmpty()) return List.of();
        Collections.shuffle(all, new Random());
        return all.stream().limit(size).map(this::toQuestionVO).collect(Collectors.toList());
    }

    @Override
    public QuizResultVO answerQuiz(Long userId, Long questionId, String choice) {
        checkUser(userId);
        ensureAccount(userId);
        if (questionId == null) throw new IllegalArgumentException("缺少题目信息哦~");
        if (choice == null || choice.trim().isEmpty()) throw new IllegalArgumentException("先选一个答案再提交吧~");

        GameQuizQuestion question = store.findQuizQuestion(questionId);
        if (question == null) throw new IllegalArgumentException("这道题不见啦，换一题试试~");
        if (countQuizToday(userId) >= QUIZ_DAILY_LIMIT) {
            throw new IllegalArgumentException("今天的答题奖励已经领满 " + QUIZ_DAILY_LIMIT + " 题啦，明天再来~");
        }

        String picked = choice.trim().toUpperCase();
        boolean correct = question.getAnswerKey() != null && question.getAnswerKey().equalsIgnoreCase(picked);
        int award = correct ? nvl(question.getPoints()) : 0;

        GameQuizRecord record = new GameQuizRecord();
        record.setUserId(userId);
        record.setQuestionId(questionId);
        record.setChosen(picked);
        record.setCorrect(correct ? 1 : 0);
        record.setPointsAwarded(award);
        record.setCreateTime(LocalDateTime.now());
        store.addQuizRecord(record);

        GameUserPoint account = correct ? addPoints(userId, award, true) : ensureAccount(userId);
        List<GameAchievementVO> newly = evaluateAchievements(userId);

        QuizResultVO vo = new QuizResultVO();
        vo.setCorrect(correct);
        vo.setChosen(picked);
        vo.setAnswerKey(question.getAnswerKey());
        vo.setExplanation(question.getExplanation());
        vo.setPointsAwarded(award);
        vo.setPoints(nvl(account.getPoints()));
        vo.setNewAchievements(newly);
        vo.setMessage(correct ? "答对啦！积分 +" + award + " 🎉" : "差一点点，答案是 " + question.getAnswerKey() + " 哦~");
        return vo;
    }

    // ==================================================================
    //  玩法四：幸运抽奖
    // ==================================================================

    @Override
    public DrawResultVO draw(Long userId) {
        checkUser(userId);
        GameUserPoint account = ensureAccount(userId);
        if (nvl(account.getPoints()) < DRAW_COST) {
            throw new IllegalArgumentException("积分不足 " + DRAW_COST + " 分，先去打卡或答题攒一点吧~");
        }

        List<GameCard> pool = allCards().stream()
                .filter(c -> nvl(c.getDropWeight()) > 0)
                .collect(Collectors.toList());
        if (pool.isEmpty()) {
            throw new IllegalArgumentException("卡片池还没准备好，晚点再来抽吧~");
        }

        int totalWeight = pool.stream().mapToInt(c -> nvl(c.getDropWeight())).sum();
        int hit = new Random().nextInt(Math.max(totalWeight, 1));
        GameCard picked = pool.get(pool.size() - 1);
        int cursor = 0;
        for (GameCard c : pool) {
            cursor += nvl(c.getDropWeight());
            if (hit < cursor) {
                picked = c;
                break;
            }
        }

        account = addPoints(userId, -DRAW_COST, false);

        GameUserCard row = findUserCard(userId, picked.getId());
        boolean firstTime;
        if (row == null) {
            row = new GameUserCard();
            row.setUserId(userId);
            row.setCardId(picked.getId());
            row.setCollectCount(1);
            row.setFavorite(0);
            row.setFirstCollectTime(LocalDateTime.now());
            row.setUpdateTime(LocalDateTime.now());
            store.saveUserCard(row);
            firstTime = true;
        } else if (!isCollected(row)) {
            row.setCollectCount(1);
            row.setFirstCollectTime(LocalDateTime.now());
            row.setUpdateTime(LocalDateTime.now());
            store.saveUserCard(row);
            firstTime = true;
        } else {
            row.setCollectCount(nvl(row.getCollectCount()) + 1);
            row.setUpdateTime(LocalDateTime.now());
            store.saveUserCard(row);
            firstTime = false;
        }

        int refund = 0;
        if (!firstTime) {
            refund = DUPLICATE_REFUND;
            account = addPoints(userId, refund, true);
        }

        GameDrawRecord record = new GameDrawRecord();
        record.setUserId(userId);
        record.setCardId(picked.getId());
        record.setRarity(picked.getRarity());
        record.setCostPoints(DRAW_COST);
        record.setCreateTime(LocalDateTime.now());
        store.addDrawRecord(record);

        List<GameAchievementVO> newly = evaluateAchievements(userId);

        DrawResultVO vo = new DrawResultVO();
        vo.setCard(toCardVO(picked, row));
        vo.setRarity(picked.getRarity());
        vo.setRarityName(RARITY_NAME.getOrDefault(picked.getRarity(), "普通"));
        vo.setCostPoints(DRAW_COST);
        vo.setRefundPoints(refund);
        vo.setPoints(nvl(account.getPoints()));
        vo.setFirstTime(firstTime);
        vo.setNewAchievements(newly);
        vo.setMessage(firstTime
                ? "🎉 抽到新卡片「" + picked.getName() + "」！"
                : "这张已经有了，返还 " + refund + " 积分~");
        return vo;
    }

    // ==================================================================
    //  内部工具方法
    // ==================================================================

    private void checkUser(Long userId) {
        if (userId == null) throw new IllegalArgumentException("请先登录后再玩小游戏哦~");
        // userId=0 是前台使用 admin/admin888 登录时的标识
        if (userId != 0 && store.findUserById(userId) == null) {
            throw new IllegalArgumentException("没找到这个用户，请重新登录~");
        }
    }

    private GameCard requireCard(Long cardId) {
        if (cardId == null) throw new IllegalArgumentException("缺少卡片信息哦~");
        GameCard card = store.findGameCard(cardId);
        if (card == null) throw new IllegalArgumentException("这张卡片不存在啦~");
        return card;
    }

    private GameUserPoint ensureAccount(Long userId) {
        GameUserPoint account = store.findPoint(userId);
        if (account == null) {
            account = new GameUserPoint();
            account.setUserId(userId);
            account.setPoints(WELCOME_POINTS);
            account.setTotalEarned(WELCOME_POINTS);
            account.setTotalSpent(0);
            account.setUpdateTime(LocalDateTime.now());
            store.savePoint(account);
        }
        return account;
    }

    private GameUserPoint addPoints(Long userId, int delta, boolean earned) {
        GameUserPoint account = ensureAccount(userId);
        int before = nvl(account.getPoints());
        int after = Math.max(0, before + delta);
        account.setPoints(after);
        if (delta > 0) {
            account.setTotalEarned(nvl(account.getTotalEarned()) + delta);
        } else if (delta < 0) {
            account.setTotalSpent(nvl(account.getTotalSpent()) - delta);
        }
        account.setUpdateTime(LocalDateTime.now());
        return store.savePoint(account);
    }

    private List<GameCard> allCards() {
        return store.listGameCards().stream()
                .sorted(Comparator.comparing(c -> nvl(c.getSort())))
                .collect(Collectors.toList());
    }

    private Map<Long, GameUserCard> userCardMap(Long userId) {
        return store.listUserCards(userId).stream()
                .collect(Collectors.toMap(GameUserCard::getCardId, Function.identity(), (a, b) -> a));
    }

    private GameUserCard findUserCard(Long userId, Long cardId) {
        return store.findUserCard(userId, cardId);
    }

    private boolean isCollected(GameUserCard row) {
        return row != null && nvl(row.getCollectCount()) > 0;
    }

    private int countCollected(Long userId) {
        return (int) store.listUserCards(userId).stream().filter(this::isCollected).count();
    }

    private GameCardVO toCardVO(GameCard card, GameUserCard state) {
        GameCardVO vo = new GameCardVO();
        vo.setId(card.getId());
        vo.setCode(card.getCode());
        vo.setName(card.getName());
        vo.setEmoji(card.getEmoji());
        vo.setSeries(card.getSeries());
        vo.setRarity(card.getRarity());
        vo.setRarityName(RARITY_NAME.getOrDefault(card.getRarity(), "普通"));
        vo.setBg(card.getBg());
        vo.setIntro(card.getIntro());
        vo.setCollected(isCollected(state));
        vo.setFavorite(state != null && state.getFavorite() != null && state.getFavorite() == 1);
        vo.setCount(state == null ? 0 : nvl(state.getCollectCount()));
        return vo;
    }

    private QuizQuestionVO toQuestionVO(GameQuizQuestion q) {
        QuizQuestionVO vo = new QuizQuestionVO();
        vo.setId(q.getId());
        vo.setContent(q.getContent());
        vo.setCategory(q.getCategory());
        vo.setDifficulty(q.getDifficulty());
        vo.setPoints(q.getPoints());
        vo.setOptions(List.of(
                new QuizQuestionVO.Option("A", q.getOptionA()),
                new QuizQuestionVO.Option("B", q.getOptionB()),
                new QuizQuestionVO.Option("C", q.getOptionC()),
                new QuizQuestionVO.Option("D", q.getOptionD())
        ));
        return vo;
    }

    private List<GameCheckin> checkins(Long userId) {
        return store.listCheckins(userId).stream()
                .sorted(Comparator.comparing(GameCheckin::getCheckinDate, Comparator.nullsLast(Comparator.reverseOrder())))
                .collect(Collectors.toList());
    }

    private int currentStreak(Long userId) {
        List<GameCheckin> list = checkins(userId);
        if (list.isEmpty()) return 0;
        GameCheckin latest = list.get(0);
        LocalDate today = LocalDate.now();
        if (today.equals(latest.getCheckinDate()) || today.minusDays(1).equals(latest.getCheckinDate())) {
            return nvl(latest.getStreakDays());
        }
        return 0;
    }

    private int maxStreak(Long userId) {
        return checkins(userId).stream().mapToInt(c -> nvl(c.getStreakDays())).max().orElse(0);
    }

    private int countQuizRecords(Long userId, Boolean correct) {
        return (int) store.listQuizRecords(userId).stream()
                .filter(r -> correct == null || (correct ? nvl(r.getCorrect()) == 1 : nvl(r.getCorrect()) == 0))
                .count();
    }

    private int countQuizToday(Long userId) {
        LocalDateTime start = LocalDate.now().atStartOfDay();
        return (int) store.listQuizRecords(userId).stream()
                .filter(r -> r.getCreateTime() != null && !r.getCreateTime().isBefore(start))
                .count();
    }

    private List<GameAchievementVO> buildAchievements(Long userId, int collected, int maxStreak, int correct) {
        Map<String, LocalDateTime> unlocked = store.listAchievements(userId).stream()
                .collect(Collectors.toMap(GameUserAchievement::getCode,
                        a -> a.getCreateTime() == null ? LocalDateTime.now() : a.getCreateTime(),
                        (a, b) -> a));

        List<GameAchievementVO> list = new ArrayList<>();
        for (AchDef def : ACH_DEFS) {
            int progress = progressOf(def, collected, maxStreak, correct);
            LocalDateTime at = unlocked.get(def.code);
            GameAchievementVO vo = new GameAchievementVO();
            vo.setCode(def.code);
            vo.setTitle(def.title);
            vo.setDesc(def.desc);
            vo.setEmoji(def.emoji);
            vo.setTarget(def.target);
            vo.setProgress(progress);
            vo.setUnlocked(at != null);
            vo.setUnlockedAt(at == null ? null : at.format(TIME_FMT));
            list.add(vo);
        }
        return list;
    }

    private List<GameAchievementVO> evaluateAchievements(Long userId) {
        int collected = countCollected(userId);
        int maxStreak = maxStreak(userId);
        int correct = countQuizRecords(userId, true);

        Map<String, LocalDateTime> unlocked = store.listAchievements(userId).stream()
                .collect(Collectors.toMap(GameUserAchievement::getCode,
                        a -> a.getCreateTime() == null ? LocalDateTime.now() : a.getCreateTime(),
                        (a, b) -> a));

        List<GameAchievementVO> newly = new ArrayList<>();
        for (AchDef def : ACH_DEFS) {
            if (unlocked.containsKey(def.code)) continue;
            int progress = progressOf(def, collected, maxStreak, correct);
            if (progress < def.target) continue;

            LocalDateTime now = LocalDateTime.now();
            GameUserAchievement row = new GameUserAchievement();
            row.setUserId(userId);
            row.setCode(def.code);
            row.setCreateTime(now);
            store.addAchievement(row);

            GameAchievementVO vo = new GameAchievementVO();
            vo.setCode(def.code);
            vo.setTitle(def.title);
            vo.setDesc(def.desc);
            vo.setEmoji(def.emoji);
            vo.setTarget(def.target);
            vo.setProgress(progress);
            vo.setUnlocked(true);
            vo.setUnlockedAt(now.format(TIME_FMT));
            newly.add(vo);
        }
        return newly;
    }

    private int progressOf(AchDef def, int collected, int maxStreak, int correct) {
        return switch (def.type) {
            case COLLECT -> collected;
            case CHECKIN -> maxStreak;
            case QUIZ -> correct;
        };
    }

    private int nvl(Integer value) {
        return value == null ? 0 : value;
    }
}
