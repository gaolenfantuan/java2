package com.example.springboottest.vo;

/**
 * 背包里的零食道具（串门页展示 / 送零食时选择）
 */
public class VisitItemVO {

    private String code;
    private String name;
    private String emoji;
    /** 当前库存 */
    private Integer quantity;
    /** 投喂后对方饱腹值增加 */
    private Integer fullnessGain;
    /** 投喂后对方心情值增加 */
    private Integer moodGain;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmoji() {
        return emoji;
    }

    public void setEmoji(String emoji) {
        this.emoji = emoji;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getFullnessGain() {
        return fullnessGain;
    }

    public void setFullnessGain(Integer fullnessGain) {
        this.fullnessGain = fullnessGain;
    }

    public Integer getMoodGain() {
        return moodGain;
    }

    public void setMoodGain(Integer moodGain) {
        this.moodGain = moodGain;
    }
}
