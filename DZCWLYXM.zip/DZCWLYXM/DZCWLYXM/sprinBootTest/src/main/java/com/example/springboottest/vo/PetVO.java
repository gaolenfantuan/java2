package com.example.springboottest.vo;

import java.util.List;

/**
 * 宠物展示 VO —— 字段与前端 HomePanel 的卡片结构一一对应
 */
public class PetVO {

    private Long id;
    private String emoji;
    private String name;
    private String breed;
    /** 一级分类名（猫咪/狗狗/小宠物） */
    private String categoryName;
    /** 二级分类ID（品种） */
    private Long breedId;
    private String age;
    private String sex;
    private String city;
    private String color;
    /** 标签数组（由数据库逗号分隔字符串转换而来） */
    private List<String> tags;
    /** 状态：1可领养 0已领养 */
    private Integer status;
    /** 是否首页推荐：1是 0否 */
    private Integer featured;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getEmoji() { return emoji; }
    public void setEmoji(String emoji) { this.emoji = emoji; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getBreed() { return breed; }
    public void setBreed(String breed) { this.breed = breed; }
    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }
    public Long getBreedId() { return breedId; }
    public void setBreedId(Long breedId) { this.breedId = breedId; }
    public String getAge() { return age; }
    public void setAge(String age) { this.age = age; }
    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    public Integer getFeatured() { return featured; }
    public void setFeatured(Integer featured) { this.featured = featured; }
}
