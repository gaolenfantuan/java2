package com.example.springboottest.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * 送零食请求体
 *
 * 访客身份由 token 决定；itemCode 不填时默认送小鱼干。
 */
public class VisitTreatRequest {

    @NotNull(message = "缺少要投喂的主人 ID")
    @Positive(message = "主人 ID 不正确")
    private Long hostUserId;

    /** 零食编码，可选：dried_fish / chicken_jerky / cheese_cube / carrot_stick / cookie_bone */
    @Size(max = 32, message = "零食编码不合法")
    private String itemCode;

    public Long getHostUserId() {
        return hostUserId;
    }

    public void setHostUserId(Long hostUserId) {
        this.hostUserId = hostUserId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }
}
