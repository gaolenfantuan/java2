-- ============================================================
-- 宠物领养站 · 首页宠物数据库脚本（含分级分类）
-- 数据库：pet_adoption
-- 表：
--   sys_pet_category —— 宠物分类（parent_id=0 为一级分类，其余为二级品种）
--   sys_pet          —— 宠物主表
-- 导入方式：
--   mysql -u root -p123456 --default-character-set=utf8mb4 < pet.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS pet_adoption
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE pet_adoption;

-- ------------------------------------------------------------
-- 1. 分级分类表：一级分类（猫/狗/小宠...）+ 二级分类（具体品种）
-- ------------------------------------------------------------
DROP TABLE IF EXISTS sys_pet;
DROP TABLE IF EXISTS sys_pet_category;

CREATE TABLE sys_pet_category (
  id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  name        VARCHAR(30)  NOT NULL                COMMENT '分类名称',
  parent_id   BIGINT       NOT NULL DEFAULT 0      COMMENT '父分类ID，0表示一级分类',
  icon        VARCHAR(10)  DEFAULT NULL            COMMENT '分类图标（emoji）',
  sort_order  INT          NOT NULL DEFAULT 0      COMMENT '排序，越小越靠前',
  status      TINYINT      NOT NULL DEFAULT 1      COMMENT '状态：1启用 0停用',
  create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_parent (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='宠物分级分类表';

-- 一级分类
INSERT INTO sys_pet_category (id, name, parent_id, icon, sort_order) VALUES
  (1, '猫咪',   0, '🐱', 1),
  (2, '狗狗',   0, '🐶', 2),
  (3, '小宠物', 0, '🐰', 3);

-- 二级分类（品种），parent_id 指向一级分类
INSERT INTO sys_pet_category (id, name, parent_id, icon, sort_order) VALUES
  (11, '布偶猫',       1, '🐱', 1),
  (12, '中华田园猫',   1, '🐱', 2),
  (13, '英短',         1, '🐱', 3),
  (21, '柯基',         2, '🐶', 1),
  (22, '萨摩耶',       2, '🐶', 2),
  (23, '金毛',         2, '🐶', 3),
  (31, '垂耳兔',       3, '🐰', 1),
  (32, '金丝熊',       3, '🐹', 2);

-- ------------------------------------------------------------
-- 2. 宠物主表
--    category_id = 一级分类ID（1猫咪/2狗狗/3小宠物）
--    breed_id    = 二级分类ID（品种，对应 sys_pet_category.id）
-- ------------------------------------------------------------
CREATE TABLE sys_pet (
  id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  name        VARCHAR(30)  NOT NULL                COMMENT '宠物名字',
  emoji       VARCHAR(10)  NOT NULL DEFAULT '🐾'   COMMENT 'Q版头像（emoji）',
  breed       VARCHAR(30)  NOT NULL                COMMENT '品种名称（冗余，方便展示）',
  category_id BIGINT       NOT NULL                COMMENT '一级分类ID',
  breed_id    BIGINT       DEFAULT NULL            COMMENT '二级分类ID（品种）',
  age         VARCHAR(20)  DEFAULT NULL            COMMENT '年龄',
  sex         VARCHAR(10)  DEFAULT NULL            COMMENT '性别：弟弟/妹妹',
  city        VARCHAR(30)  DEFAULT NULL            COMMENT '所在城市',
  color       VARCHAR(20)  DEFAULT '#ffd84d'       COMMENT '卡片背景色',
  tags        VARCHAR(255) DEFAULT NULL            COMMENT '标签，英文逗号分隔',
  status      TINYINT      NOT NULL DEFAULT 1      COMMENT '状态：1可领养 0已领养',
  featured    TINYINT      NOT NULL DEFAULT 0      COMMENT '是否首页推荐：1是 0否',
  deleted     TINYINT      NOT NULL DEFAULT 0      COMMENT '逻辑删除：0否 1是',
  create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (id),
  KEY idx_category (category_id),
  KEY idx_breed (breed_id),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='宠物信息表';

-- ------------------------------------------------------------
-- 3. 演示数据（12 只，覆盖三个一级分类和多个品种）
-- ------------------------------------------------------------
INSERT INTO sys_pet (name, emoji, breed, category_id, breed_id, age, sex, city, color, tags, status, featured) VALUES
  ('奶糖', '🐱', '布偶猫',       1, 11, '3 个月', '妹妹', '杭州', '#ffd84d', '温顺,已驱虫,超粘人',   1, 1),
  ('可乐', '🐶', '柯基',         2, 21, '6 个月', '弟弟', '上海', '#ff9ec4', '活泼,已打疫苗,短腿萌', 1, 1),
  ('团子', '🐰', '垂耳兔',       3, 31, '1 岁',   '妹妹', '南京', '#8fd9c4', '安静,已绝育,爱吃菜',   1, 1),
  ('橘座', '🐱', '中华田园猫',   1, 12, '2 岁',   '弟弟', '成都', '#9fd3ff', '干饭王,已驱虫,爱晒太阳',1, 1),
  ('糯米', '🐶', '萨摩耶',       2, 22, '8 个月', '妹妹', '北京', '#ffd0a6', '微笑天使,已打疫苗,掉毛怪',1, 1),
  ('豆豆', '🐹', '金丝熊',       3, 32, '4 个月', '弟弟', '广州', '#d8b4ff', '迷你,好养,夜猫子',     1, 0),
  ('雪球', '🐱', '布偶猫',       1, 11, '5 个月', '妹妹', '苏州', '#c7e9ff', '漂亮,亲人,已驱虫',     1, 1),
  ('旺财', '🐶', '金毛',         2, 23, '1 岁',   '弟弟', '武汉', '#ffe0a3', '温顺,聪明,已打疫苗',   1, 0),
  ('小灰', '🐱', '英短',         1, 13, '7 个月', '弟弟', '深圳', '#d5d5ff', '圆脸,乖巧,已绝育',     1, 0),
  (' banana', '🐰', '垂耳兔',    3, 31, '8 个月', '妹妹', '重庆', '#ffd6e0', '软萌,爱干净,已绝育',   1, 0),
  ('布丁', '🐶', '柯基',         2, 21, '3 个月', '妹妹', '西安', '#fff0b3', '奶凶,活泼,已打疫苗',   1, 0),
  ('麻薯', '🐱', '中华田园猫',   1, 12, '1 岁',   '妹妹', '长沙', '#b8f0d0', '黏人,健康,已驱虫',     1, 0);

-- 修正一个带空格的名字（避免展示多余空格）
UPDATE sys_pet SET name = '香蕉' WHERE name = ' banana';

-- 验证
SELECT id, name, breed, category_id, breed_id, city FROM sys_pet ORDER BY id;
SELECT id, name, parent_id FROM sys_pet_category ORDER BY parent_id, sort_order;
