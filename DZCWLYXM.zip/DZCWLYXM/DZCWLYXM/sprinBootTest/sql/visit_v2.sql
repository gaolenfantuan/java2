-- =====================================================================
--  串门轻社交 V2 迁移脚本（可重复执行）
--
--  变更点：
--    1. visit_like 增加 like_date，唯一索引改成 (host, visitor, 日期)
--       —— 支持「每人每天限赞 1 次」，而不是一辈子只能赞一次；
--    2. visit_treat 增加 item_code，去掉「每天一条」的唯一索引
--       —— 改为按真实库存扣减，送什么、送多少由背包决定；
--    3. 新增 pet_user_item 用户零食背包表，并给现有用户发新手零食包。
--
--  执行：
--    "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p123456 \
--        --default-character-set=utf8mb4 < sql/visit_v2.sql
-- =====================================================================

USE pet_adoption;

-- ---------------------------------------------------------------------
-- 1. visit_like 增加 like_date
-- ---------------------------------------------------------------------
SET @has_like_date := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'visit_like' AND COLUMN_NAME = 'like_date'
);
SET @sql := IF(@has_like_date = 0,
  'ALTER TABLE `visit_like` ADD COLUMN `like_date` date NULL COMMENT ''点赞日期（按天限次）'' AFTER `visitor_id`',
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 老数据按 create_time 回填日期
UPDATE `visit_like` SET `like_date` = DATE(`create_time`) WHERE `like_date` IS NULL;
ALTER TABLE `visit_like` MODIFY COLUMN `like_date` date NOT NULL COMMENT '点赞日期（按天限次）';

-- 删掉老的「一辈子只能赞一次」唯一索引
SET @has_old_uk := (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'visit_like' AND INDEX_NAME = 'uk_like'
);
SET @sql := IF(@has_old_uk > 0, 'ALTER TABLE `visit_like` DROP INDEX `uk_like`', 'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 新建「每人每天对同一只毛孩子只能赞一次」的唯一索引
SET @has_new_uk := (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'visit_like' AND INDEX_NAME = 'uk_like_day'
);
SET @sql := IF(@has_new_uk = 0,
  'ALTER TABLE `visit_like` ADD UNIQUE KEY `uk_like_day` (`host_user_id`, `visitor_id`, `like_date`)',
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------------------
-- 2. visit_treat 增加 item_code，放开「每天一条」
-- ---------------------------------------------------------------------
SET @has_item_code := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'visit_treat' AND COLUMN_NAME = 'item_code'
);
SET @sql := IF(@has_item_code = 0,
  'ALTER TABLE `visit_treat` ADD COLUMN `item_code` varchar(32) NOT NULL DEFAULT ''dried_fish'' COMMENT ''零食编码'' AFTER `visitor_id`',
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @has_treat_uk := (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'visit_treat' AND INDEX_NAME = 'uk_treat'
);
SET @sql := IF(@has_treat_uk > 0, 'ALTER TABLE `visit_treat` DROP INDEX `uk_treat`', 'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @has_treat_idx := (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'visit_treat' AND INDEX_NAME = 'idx_treat_day'
);
SET @sql := IF(@has_treat_idx = 0,
  'ALTER TABLE `visit_treat` ADD KEY `idx_treat_day` (`host_user_id`, `visitor_id`, `treat_date`)',
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------------------
-- 3. 用户零食背包
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `pet_user_item` (
  `id`          bigint      NOT NULL AUTO_INCREMENT,
  `user_id`     bigint      NOT NULL COMMENT '所属用户',
  `item_code`   varchar(32) NOT NULL COMMENT '零食编码',
  `item_name`   varchar(32) NOT NULL DEFAULT '' COMMENT '零食名称',
  `quantity`    int         NOT NULL DEFAULT 0 COMMENT '库存数量',
  `update_time` datetime    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_item` (`user_id`, `item_code`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户零食背包';

-- 给所有现有用户补发新手零食包（每种 3 个），已发过的不会重复
INSERT INTO `pet_user_item` (`user_id`, `item_code`, `item_name`, `quantity`, `update_time`)
SELECT u.`id`, t.`code`, t.`name`, 3, NOW()
FROM `sys_user` u
CROSS JOIN (
  SELECT 'dried_fish'    AS `code`, '小鱼干'   AS `name`
  UNION ALL SELECT 'chicken_jerky', '鸡肉干'
  UNION ALL SELECT 'cheese_cube',   '奶酪块'
  UNION ALL SELECT 'carrot_stick',  '胡萝卜条'
  UNION ALL SELECT 'cookie_bone',   '骨头饼干'
) t
WHERE u.`deleted` = 0
  AND NOT EXISTS (
    SELECT 1 FROM `pet_user_item` i
    WHERE i.`user_id` = u.`id` AND i.`item_code` = t.`code`
  );

-- ---------------------------------------------------------------------
-- 校验输出
-- ---------------------------------------------------------------------
SELECT 'visit_like 索引' AS item, GROUP_CONCAT(DISTINCT INDEX_NAME) AS detail FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'visit_like';
SELECT 'visit_treat 索引' AS item, GROUP_CONCAT(DISTINCT INDEX_NAME) AS detail FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'visit_treat';
SELECT '零食背包' AS item, COUNT(*) AS detail FROM `pet_user_item`;
