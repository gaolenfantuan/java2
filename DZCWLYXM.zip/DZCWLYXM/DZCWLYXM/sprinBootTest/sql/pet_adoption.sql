-- ============================================================
-- 宠物领养站 · 用户数据库脚本
-- 数据库：pet_adoption    表：sys_user
-- 密码算法：SHA-256(明文 + 固定盐 hello_kitty_salt)
-- 导入方式：
--   1) 命令行：mysql -u root -p < pet_adoption.sql
--   2) IDEA / Navicat 的 Database 工具中直接执行本文件
-- ============================================================

CREATE DATABASE IF NOT EXISTS pet_adoption
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE pet_adoption;

DROP TABLE IF EXISTS sys_user;

CREATE TABLE sys_user (
  id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  username    VARCHAR(50)  NOT NULL                COMMENT '登录账号（注册时用手机号）',
  nickname    VARCHAR(30)  NOT NULL                COMMENT '昵称',
  password    VARCHAR(100) NOT NULL                COMMENT '密码（SHA-256 + 固定盐）',
  avatar      VARCHAR(255) DEFAULT NULL            COMMENT '头像地址（预留）',
  status      TINYINT      NOT NULL DEFAULT 1      COMMENT '状态：1 正常，0 禁用',
  deleted     TINYINT      NOT NULL DEFAULT 0      COMMENT '逻辑删除：0 否，1 是',
  create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (id),
  UNIQUE KEY uk_sys_user_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='领养站用户表';

-- 测试账号：账号 13800000000，密码 123456（哈希值对应上面的算法）
INSERT INTO sys_user (username, nickname, password, status, deleted)
VALUES ('13800000000', '测试铲屎官', '9daa4d3a5d4819ddacf7cea893f301c6354f5828c5437f4cb4cf614fbdbb2f38', 1, 0);

-- 验证
SELECT id, username, nickname, status FROM sys_user;
