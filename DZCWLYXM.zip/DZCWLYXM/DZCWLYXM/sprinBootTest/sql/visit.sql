-- =====================================================================
--  串门轻社交模块建表脚本（visit_*）
--  执行方式：
--    "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p123456 \
--        --default-character-set=utf8mb4 < sql/visit.sql
--  说明：只新增 visit_ 前缀的表，不动 sys_user / sys_pet 任何数据。
--        末尾的演示数据可以单独删掉，不影响表结构。
-- =====================================================================

USE pet_adoption;

-- ---------------------------------------------------------------------
-- 1. 毛孩子快照：一个用户一条，由前端「我的毛孩子」同步
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `visit_pet` (
  `user_id`     bigint      NOT NULL                COMMENT '主人用户ID',
  `pet_name`    varchar(32) NOT NULL                COMMENT '宠物名字',
  `pet_type`    varchar(16) NOT NULL DEFAULT 'cat'  COMMENT '造型：cat/dog/bunny',
  `pet_color`   varchar(16) NOT NULL DEFAULT '#ffd84d' COMMENT '主色',
  `pet_emoji`   varchar(16) NOT NULL DEFAULT '🐾'   COMMENT '表情 emoji',
  `pet_breed`   varchar(64) NOT NULL DEFAULT ''     COMMENT '品种',
  `mood`        int         NOT NULL DEFAULT 80     COMMENT '心情值 0-100',
  `fullness`    int         NOT NULL DEFAULT 80     COMMENT '饱腹值 0-100',
  `exp`         int         NOT NULL DEFAULT 0      COMMENT '经验值',
  `like_count`  int         NOT NULL DEFAULT 0      COMMENT '收到的赞',
  `treat_count` int         NOT NULL DEFAULT 0      COMMENT '收到的小鱼干',
  `update_time` datetime    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后同步时间',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='串门-毛孩子快照';

-- ---------------------------------------------------------------------
-- 2. 来访足迹：同一访客对同一主人只留最新一条
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `visit_record` (
  `id`           bigint      NOT NULL AUTO_INCREMENT,
  `host_user_id` bigint      NOT NULL COMMENT '被访问的人',
  `visitor_id`   bigint      NOT NULL COMMENT '来访者',
  `visitor_name` varchar(64) NOT NULL COMMENT '来访者昵称快照',
  `visit_time`   datetime    NOT NULL COMMENT '来访时间',
  PRIMARY KEY (`id`),
  KEY `idx_host_time` (`host_user_id`, `visit_time`),
  KEY `idx_host_visitor` (`host_user_id`, `visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='串门-来访足迹';

-- ---------------------------------------------------------------------
-- 3. 点赞：唯一索引保证「同一个人对同一只毛孩子每天只能点一次」
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `visit_like` (
  `id`           bigint   NOT NULL AUTO_INCREMENT,
  `host_user_id` bigint   NOT NULL COMMENT '被点赞的主人',
  `visitor_id`   bigint   NOT NULL COMMENT '点赞的人',
  `like_date`    date     NOT NULL COMMENT '点赞日期（按天限次）',
  `create_time`  datetime NOT NULL COMMENT '点赞时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_like_day` (`host_user_id`, `visitor_id`, `like_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='串门-点赞记录';

-- ---------------------------------------------------------------------
-- 4. 送零食流水：次数由访客背包库存决定
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `visit_treat` (
  `id`           bigint      NOT NULL AUTO_INCREMENT,
  `host_user_id` bigint      NOT NULL,
  `visitor_id`   bigint      NOT NULL,
  `item_code`    varchar(32) NOT NULL DEFAULT 'dried_fish' COMMENT '零食编码',
  `treat_date`   date        NOT NULL COMMENT '送礼日期',
  `create_time`  datetime    NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_treat_day` (`host_user_id`, `visitor_id`, `treat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='串门-送零食记录';

-- ---------------------------------------------------------------------
-- 5. 用户零食背包：送零食时真实扣减这里的库存
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `pet_user_item` (
  `id`          bigint      NOT NULL AUTO_INCREMENT,
  `user_id`     bigint      NOT NULL COMMENT '所属用户',
  `item_code`   varchar(32) NOT NULL COMMENT '零食编码',
  `item_name`   varchar(32) NOT NULL DEFAULT '' COMMENT '零食名称',
  `quantity`    int         NOT NULL DEFAULT 0 COMMENT '库存数量',
  `update_time` datetime    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_item` (`user_id`, `item_code`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户零食背包';

-- =====================================================================
--  以下为演示数据（可选）：两个邻居铲屎官 + 各自一只毛孩子 + 给测试号的访客记录
--  密码统一为 123456（与测试账号 13800000000 相同），可直接登录体验串门
-- =====================================================================
INSERT INTO `sys_user` (`id`, `username`, `nickname`, `password`, `status`, `deleted`)
VALUES
  (2, '13900000002', '橘子汽水', '9daa4d3a5d4819ddacf7cea893f301c6354f5828c5437f4cb4cf614fbdbb2f38', 1, 0),
  (3, '13900000003', '布丁妈妈', '9daa4d3a5d4819ddacf7cea893f301c6354f5828c5437f4cb4cf614fbdbb2f38', 1, 0),
  (4, '13900000004', '小满',     '9daa4d3a5d4819ddacf7cea893f301c6354f5828c5437f4cb4cf614fbdbb2f38', 1, 0)
ON DUPLICATE KEY UPDATE `nickname` = VALUES(`nickname`);

INSERT INTO `visit_pet`
  (`user_id`, `pet_name`, `pet_type`, `pet_color`, `pet_emoji`, `pet_breed`, `mood`, `fullness`, `exp`, `like_count`, `treat_count`)
VALUES
  (2, '芝士', 'cat',   '#ff9ec4', '🐱', '中华田园猫', 88, 72, 240, 12, 5),
  (3, '布丁', 'dog',   '#ffd84d', '🐶', '小柯基',     65, 90, 130, 8,  3),
  (4, '团子', 'bunny', '#a8e6a1', '🐰', '垂耳兔',     42, 36, 60,  3,  1)
ON DUPLICATE KEY UPDATE `pet_name` = VALUES(`pet_name`);

-- 给测试账号（id=1）来几条访客记录，串门模块一进页面就能看到内容
DELETE FROM `visit_record` WHERE `host_user_id` = 1;
INSERT INTO `visit_record` (`host_user_id`, `visitor_id`, `visitor_name`, `visit_time`)
VALUES
  (1, 2, '橘子汽水', DATE_SUB(NOW(), INTERVAL 12 MINUTE)),
  (1, 3, '布丁妈妈', DATE_SUB(NOW(), INTERVAL 3 HOUR)),
  (1, 4, '小满',     DATE_SUB(NOW(), INTERVAL 2 DAY));

-- 给所有用户发新手零食包（每种 3 个），送零食时才有的扣
INSERT INTO `pet_user_item` (`user_id`, `item_code`, `item_name`, `quantity`, `update_time`)
SELECT u.`id`, t.`code`, t.`name`, 3, NOW()
FROM `sys_user` u
CROSS JOIN (
  SELECT 'dried_fish'    AS `code`, '小鱼干'   AS `name`
  UNION ALL SELECT 'chicken_jerky', '鸡肉干'
  UNION ALL SELECT 'cheese_cube',   '奶酪块'
  UNION ALL SELECT 'carrot_stick',  '胡萝卜条'
  UNION ALL SELECT 'cookie_bone',   '骨头饼干'
) t
WHERE u.`deleted` = 0
  AND NOT EXISTS (
    SELECT 1 FROM `pet_user_item` i
    WHERE i.`user_id` = u.`id` AND i.`item_code` = t.`code`
  );
