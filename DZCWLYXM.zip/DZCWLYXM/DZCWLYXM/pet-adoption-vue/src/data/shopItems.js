// 积分商城商品 / 萌宠乐园游戏 / 每日任务 配置
// 纯数据文件，页面只负责渲染与交互

// 商品分类（顺序即 Tab 顺序）
export const shopCategories = [
  { key: '食物', icon: '🍖', color: '#ffd9a8' },
  { key: '玩具', icon: '🧶', color: '#c9ecf9' },
  { key: '道具', icon: '🧴', color: '#c9f2df' },
  { key: '药品', icon: '💊', color: '#ffe0e8' },
  { key: '装饰', icon: '🎀', color: '#e6e0ff' }
]

// 商品：art 对应 ItemArt 组件里的矢量插画，sold 表示已兑换份数（仅展示）
export const shopItems = [
  // 食物
  { id: 'can', name: '三文鱼罐头', category: '食物', price: 56, art: 'can', tag: '热销', desc: '整块三文鱼肉，开罐就是香喷喷的奖励', effect: '喂食后心情 +10，尾巴摇成螺旋桨' },
  { id: 'freeze', name: '冻干鸡胸粒', category: '食物', price: 48, art: 'freeze', tag: '', desc: '低温冻干锁住肉香，一颗一颗停不下来', effect: '喂食后亲密度 +6，训练奖励首选' },
  { id: 'pudding', name: '羊奶布丁杯', category: '食物', price: 36, art: 'pudding', tag: '新手友好', desc: '羊奶做的小布丁，幼宠也能安心吃', effect: '喂食后饱腹感 +8，适合幼宠' },
  // 玩具
  { id: 'yarn', name: '彩色毛线球', category: '玩具', price: 42, art: 'yarn', tag: '', desc: '滚起来会自己拐弯，猫猫能追一下午', effect: '陪玩 10 分钟，活力 +12' },
  { id: 'wand', name: '星星逗猫棒', category: '玩具', price: 52, art: 'wand', tag: '人气王', desc: '带小铃铛的星星头，一晃就上头', effect: '陪玩 15 分钟，亲密度 +10' },
  { id: 'fish', name: '发声小鱼', category: '玩具', price: 58, art: 'fish', tag: '', desc: '一咬就啾啾叫，独自在家也不无聊', effect: '独处安抚，焦虑 -15' },
  // 道具
  { id: 'brush', name: '软毛按摩梳', category: '道具', price: 68, art: 'brush', tag: '', desc: '圆头软齿，梳毛顺便做个小按摩', effect: '梳毛 1 次，毛发顺滑度 +15' },
  { id: 'bottle', name: '便携饮水壶', category: '道具', price: 62, art: 'bottle', tag: '出门必备', desc: '单手按压出水，散步路上随时补水', effect: '外出装备，补水效率 +20' },
  { id: 'scratcher', name: '波浪猫抓板', category: '道具', price: 78, art: 'scratcher', tag: '', desc: '瓦楞纸波浪面，磨爪又不伤沙发', effect: '磨爪 1 次，家具保护 +30' },
  // 药品
  { id: 'vitamin', name: '营养膏', category: '药品', price: 86, art: 'vitamin', tag: '', desc: '术后与换毛期的能量补给，适口性好', effect: '体力 +20，连续 3 天效果更佳' },
  { id: 'deworm', name: '体内驱虫片', category: '药品', price: 72, art: 'deworm', tag: '常备', desc: '三月一次常规驱虫，牛肉味不抗拒', effect: '健康值 +18，建议空腹服用' },
  { id: 'probiotic', name: '益生菌冲剂', category: '药品', price: 64, art: 'probiotic', tag: '', desc: '调理肠胃的小袋装，换粮期好帮手', effect: '肠胃舒适 +15，温水冲开更香' },
  // 装饰
  { id: 'bow', name: '格纹小领巾', category: '装饰', price: 88, art: 'bow', tag: '拍照神器', desc: '软棉格纹领巾，戴上就是街拍小明星', effect: '装扮 1 件，出片率 +40' },
  { id: 'crown', name: '毛孩子小皇冠', category: '装饰', price: 128, art: 'crown', tag: '限定', desc: '轻量绒布皇冠，家里的主子实至名归', effect: '装扮 1 件，气场 +50' },
  { id: 'bell', name: '铃铛项圈', category: '装饰', price: 96, art: 'bell', tag: '', desc: '清脆小铃铛，走到哪都听得见', effect: '装扮 1 件，走失风险 -30' }
]

export function findItem(id) {
  return shopItems.find(item => item.id === id) || null
}

// 出售价：原价 6 折（向下取整到整数）
export function sellPrice(item) {
  return Math.max(1, Math.round((item?.price || 0) * 0.6))
}

// 萌宠乐园游戏：pool 为抓取物 emoji，spawn/life 控制难度（毫秒），perScore 每分兑换币
export const games = [
  {
    id: 'biscuit', name: '接住小饼干', icon: '🍪', tag: '最热门',
    desc: '小饼干从洞口冒出来，手快点住它，一局能抓一大把',
    pool: ['🍪', '🦴', '🥠'], theme: '#ffe6b8', accent: '#ff9b54',
    perScore: 2, cap: 24, spawn: 760, life: 1150, difficulty: 2
  },
  {
    id: 'yarn', name: '毛线球快抓', icon: '🧶', tag: '手速挑战',
    desc: '毛线球滚得飞快，抓满一箩筐就给毛孩子织个小垫子',
    pool: ['🧶', '🎀', '🪡'], theme: '#cfe6ff', accent: '#5fa8e8',
    perScore: 2, cap: 26, spawn: 600, life: 950, difficulty: 3
  },
  {
    id: 'fish', name: '小鱼干大作战', icon: '🐟', tag: '治愈系',
    desc: '慢悠悠的小鱼干浮上来，边玩边放松刚刚好',
    pool: ['🐟', '🐠', '🦐'], theme: '#c9f2df', accent: '#3fae8c',
    perScore: 3, cap: 27, spawn: 900, life: 1450, difficulty: 1
  },
  {
    id: 'paw', name: '爪印大暴走', icon: '🐾', tag: '新上线',
    desc: '一串小爪印到处跑，点到就是毛孩子的亲亲',
    pool: ['🐾', '❤️', '✨'], theme: '#ffe0ec', accent: '#e06a92',
    perScore: 2, cap: 24, spawn: 680, life: 1050, difficulty: 2
  },
  {
    id: 'bubble', name: '泡泡抓抓乐', icon: '🫧', tag: '轻松局',
    desc: '戳破软绵绵的泡泡，噗的一声超解压',
    pool: ['🫧', '🎈', '💧'], theme: '#d8ecff', accent: '#6396d8',
    perScore: 2, cap: 22, spawn: 820, life: 1300, difficulty: 1
  },
  {
    id: 'mint', name: '猫薄荷旋风', icon: '🌿', tag: '限定',
    desc: '薄荷叶打着旋儿飘，抓到就能换一份小零食',
    pool: ['🌿', '🍃', '💚'], theme: '#d9f5c9', accent: '#63a94a',
    perScore: 2, cap: 25, spawn: 700, life: 1080, difficulty: 2
  }
]

export function findGame(id) {
  return games.find(game => game.id === id) || null
}

// 每局基础时长（秒）
export const GAME_DURATION = 15

// 结算规则（页面右侧说明面板）
export const settleRules = [
  { icon: '🎯', title: '按得分结算', desc: '每抓到 1 个 +1 分，1 分 = 2 游戏币，单局封顶 24 币' },
  { icon: '⚡', title: '越高难越值钱', desc: '手速款游戏每分 2 币，治愈款单分 3 币，慢慢玩也不亏' },
  { icon: '📅', title: '每日任务加成', desc: '完成今日任务额外领 8~20 币，签到还能再拿 10 币' },
  { icon: '🔁', title: '不限次数', desc: '玩几局都可以，但每局奖励按分数结算，摸鱼也有收获' }
]

// 每日任务：target 进度目标，progressKey 对应 store.daily 字段
export const dailyTasks = [
  { id: 'signin', icon: '📅', name: '每日签到', desc: '来乐园打个卡，币币自动到账', reward: 10, target: 1, type: 'sign' },
  { id: 'play1', icon: '🎮', name: '玩 1 局小游戏', desc: '任意小游戏完成 1 局即可领取', reward: 8, target: 1, type: 'games' },
  { id: 'play3', icon: '🏆', name: '今日玩满 3 局', desc: '手感来了就多玩两把，奖励翻倍拿', reward: 20, target: 3, type: 'games' },
  { id: 'shop1', icon: '🛍️', name: '逛商城买 1 件', desc: '给毛孩子挑一份小礼物', reward: 15, target: 1, type: 'purchases' }
]
