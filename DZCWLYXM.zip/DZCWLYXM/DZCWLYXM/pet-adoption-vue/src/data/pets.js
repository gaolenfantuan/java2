// 首页分类筛选栏
export const categories = ['全部', '猫猫', '狗狗', '兔兔', '小宠']

// 6 条示例宠物数据。image 留空，替换成真实图片地址即可直接显示。
export const pets = [
  {
    id: 1,
    name: '奶盖',
    breed: '布偶猫',
    category: '猫猫',
    gender: '弟弟',
    age: '3 个月',
    personality: '粘人爱撒娇',
    mood: '开心到冒泡',
    moodEmoji: '😸',
    image: '/pets/naigai.png',
    emoji: '🐱',
    color: '#ffe0b8'
  },
  {
    id: 2,
    name: '芝麻',
    breed: '英短蓝猫',
    category: '猫猫',
    gender: '妹妹',
    age: '8 个月',
    personality: '高冷慢热',
    mood: '有点困',
    moodEmoji: '😽',
    image: '/pets/zhima.png',
    emoji: '🐈',
    color: '#cfe3f5'
  },
  {
    id: 3,
    name: '布丁',
    breed: '金毛寻回犬',
    category: '狗狗',
    gender: '弟弟',
    age: '1 岁',
    personality: '阳光热情',
    mood: '摇尾巴中',
    moodEmoji: '🐶',
    image: '/pets/buding.png',
    emoji: '🐕',
    color: '#ffd98f'
  },
  {
    id: 4,
    name: '可乐',
    breed: '柯基',
    category: '狗狗',
    gender: '妹妹',
    age: '6 个月',
    personality: '贪吃活泼',
    mood: '想要零食',
    moodEmoji: '🥰',
    image: '/pets/kele.png',
    emoji: '🐕‍🦺',
    color: '#ffc9b8'
  },
  {
    id: 5,
    name: '棉花糖',
    breed: '侏儒兔',
    category: '兔兔',
    gender: '妹妹',
    age: '4 个月',
    personality: '安静温顺',
    mood: '啃胡萝卜中',
    moodEmoji: '🐰',
    image: '/pets/mianhuatang.png',
    emoji: '🐇',
    color: '#f7d4e6'
  },
  {
    id: 6,
    name: '豆豆',
    breed: '金丝熊',
    category: '小宠',
    gender: '弟弟',
    age: '2 个月',
    personality: '好奇贪玩',
    mood: '跑轮中',
    moodEmoji: '🐹',
    image: '/pets/doudou.png',
    emoji: '🐹',
    color: '#d8f0d2'
  }
]

export function findPet(id) {
  return pets.find(pet => String(pet.id) === String(id))
}
