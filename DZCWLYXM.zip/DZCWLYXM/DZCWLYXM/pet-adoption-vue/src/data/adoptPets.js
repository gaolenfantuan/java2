// 领养专区专用扩展数据：基于首页 pets 数据补充领养维度字段。
// 纯增量，不改动原有的 pets.js，首页/详情页不受影响。
import { pets } from './pets'

// 每只宠物的领养扩展信息（按 id 对应）
const extra = {
  1: { city: '上海 · 徐汇', health: '健康活泼', sterilized: false, vaccinated: true, listedAt: '2026-11-20', popularity: 96, traits: ['粘人', '温顺', '撒娇'] },
  2: { city: '上海 · 静安', health: '健康状况良好', sterilized: true, vaccinated: true, listedAt: '2026-11-18', popularity: 72, traits: ['高冷', '安静', '慢热'] },
  3: { city: '杭州 · 西湖', health: '健康活泼', sterilized: true, vaccinated: true, listedAt: '2026-11-21', popularity: 91, traits: ['阳光', '活泼', '热情'] },
  4: { city: '杭州 · 滨江', health: '健康活泼', sterilized: false, vaccinated: true, listedAt: '2026-11-16', popularity: 88, traits: ['贪吃', '活泼', '好奇'] },
  5: { city: '南京 · 鼓楼', health: '健康状况良好', sterilized: false, vaccinated: false, listedAt: '2026-11-19', popularity: 65, traits: ['安静', '温顺', '慢热'] },
  6: { city: '苏州 · 园区', health: '健康活泼', sterilized: false, vaccinated: true, listedAt: '2026-11-22', popularity: 78, traits: ['好奇', '活泼', '贪玩'] }
}

// 年龄段归类：幼宠 / 成宠
function ageGroup(age) {
  const month = parseInt(String(age).replace(/[^0-9]/g, ''), 10) || 0
  const isYear = String(age).includes('岁')
  return isYear || month >= 12 ? '成宠' : '幼宠'
}

export const adoptPets = pets.map(pet => ({
  ...pet,
  ...(extra[pet.id] || {}),
  ageGroup: ageGroup(pet.age)
}))

// 高级筛选项配置（多选）
export const filterConfig = {
  city: {
    label: '城市地区',
    icon: '📍',
    options: ['上海', '杭州', '南京', '苏州']
  },
  breed: {
    label: '品种',
    icon: '🐾',
    options: ['布偶猫', '英短蓝猫', '金毛寻回犬', '柯基', '侏儒兔', '金丝熊']
  },
  gender: {
    label: '性别',
    icon: '💕',
    options: ['弟弟', '妹妹']
  },
  ageGroup: {
    label: '年龄段',
    icon: '🎂',
    options: ['幼宠', '成宠']
  },
  sterilized: {
    label: '绝育',
    icon: '✂️',
    options: ['已绝育', '未绝育']
  },
  vaccinated: {
    label: '疫苗',
    icon: '💉',
    options: ['已接种', '未接种']
  },
  traits: {
    label: '性格标签',
    icon: '✨',
    options: ['粘人', '温顺', '撒娇', '高冷', '安静', '慢热', '阳光', '活泼', '热情', '贪吃', '好奇', '贪玩']
  }
}

// 排序方式
export const sortOptions = [
  { label: '最新上架', value: 'latest', icon: '🆕' },
  { label: '人气最高', value: 'popular', icon: '🔥' },
  { label: '年龄最小', value: 'youngest', icon: '🍼' }
]
