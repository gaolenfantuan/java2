// 流浪救助小游戏数据与进度存储：纯前端 localStorage，不依赖后端
// 仅用于「流浪救助」页救助流程，不改动原有救助故事数据。

const PROGRESS_KEY = 'petRescueProgress'   // { [petId]: 已完成步数 0-4 }
const DONE_KEY = 'petRescueDone'           // [petId] 已救助完成的宠物 id
const SYNC_KEY = 'petRescueSync'           // { [adoptId]: originalId } 救助→领养的同步关系

// 领养专区使用的存储 key（与其保持一致，用于状态双向同步）
const ADOPTED_KEY = 'petAdopted'           // [petId] 已领养
const APPLY_KEY = 'petApplyStatuses'       // { [petId]: '预约中' }

// 救助宠物转入领养专区时的 id 偏移量，避免与原有 1-6 号宠物冲突
export const ADOPT_ID_OFFSET = 1000

// 4 步卡通关卡配置（顺序解锁）
export const rescueSteps = [
  { key: 'approach', label: '发现流浪', action: '靠近安抚', icon: '🤲', tip: '轻轻靠近，让它放下戒备', emoji: '👋', color: '#ffd84d' },
  { key: 'feed', label: '投喂安抚', action: '喂小零食', icon: '🍪', tip: '递上香喷喷的小零食', emoji: '🍖', color: '#ffc9a0' },
  { key: 'check', label: '健康检查', action: '做体检', icon: '🩺', tip: '仔细检查身体状况', emoji: '🩺', color: '#9fd3ff' },
  { key: 'treat', label: '治疗康复', action: '治疗护理', icon: '💊', tip: '细心护理，陪它慢慢康复', emoji: '💗', color: '#8fd9c4' }
]

// 完成一步后的萌系文案（用于气泡）
export const stepFeedback = [
  '它慢慢放下戒备啦～',
  '好好吃！谢谢你～💕',
  '身体倍儿棒，真乖！',
  '康复啦，可以回家咯！🎉'
]

function readJSON(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || 'null')
    return value ?? fallback
  } catch {
    return fallback
  }
}

// 读取所有宠物的救助进度 { [petId]: stepCount }
export function getAllProgress() {
  const data = readJSON(PROGRESS_KEY, {})
  return data && typeof data === 'object' ? data : {}
}

// 读取单只宠物已完成步数 0-4
export function getProgress(petId) {
  const all = getAllProgress()
  return Math.min(rescueSteps.length, Math.max(0, Number(all[petId]) || 0))
}

// 保存单只宠物已完成步数
export function setProgress(petId, step) {
  const all = getAllProgress()
  all[petId] = Math.min(rescueSteps.length, Math.max(0, step))
  localStorage.setItem(PROGRESS_KEY, JSON.stringify(all))
}

// 已完成救助的宠物 id 列表
export function getDoneIds() {
  const data = readJSON(DONE_KEY, [])
  return Array.isArray(data) ? data : []
}

export function isDone(petId) {
  return getDoneIds().includes(petId)
}

// 标记救助完成：写入完成列表 + 同步关系，保证进入领养池可追溯、可去重
export function markDone(petId) {
  const ids = getDoneIds()
  if (!ids.includes(petId)) {
    ids.push(petId)
    localStorage.setItem(DONE_KEY, JSON.stringify(ids))
  }
  // 显式记录同步关系：领养池 id -> 救助原始 id（持久化、幂等）
  const sync = readJSON(SYNC_KEY, {}) || {}
  sync[petId + ADOPT_ID_OFFSET] = petId
  localStorage.setItem(SYNC_KEY, JSON.stringify(sync))
  // 完成即把进度写满，保证一致
  setProgress(petId, rescueSteps.length)
}

// 同步关系表 { [adoptId]: originalId }
export function getSyncMap() {
  const data = readJSON(SYNC_KEY, {})
  return data && typeof data === 'object' ? data : {}
}

// 根据领养专区的存储，读取某只已救助宠物当前的领养状态
// 返回 'available' | 'reserved' | 'adopted'；未完成救助返回 null
export function getRescuedPetAdoptState(originalId) {
  if (!isDone(originalId)) return null
  const adoptId = originalId + ADOPT_ID_OFFSET
  const adopted = readJSON(ADOPTED_KEY, [])
  if (Array.isArray(adopted) && adopted.map(Number).includes(adoptId)) return 'adopted'
  const apply = readJSON(APPLY_KEY, {})
  if (apply && apply[adoptId] === '预约中') return 'reserved'
  return 'available'
}

// 是否已完成任意一只宠物的救助（用于「救助萌新」徽章）
export function hasAnyRescueDone() {
  return getDoneIds().length > 0
}

// 4 只待救助宠物：id 与「流浪救助」页救助故事对应，image 复用站点现有 3D 图标
// extra 字段用于在救助完成后同步到领养专区（结构与 adoptPets 一致）
export const rescuePets = [
  {
    id: 1, name: '小黄', emoji: '🐕', image: '/pets/buding.png', color: '#ffe0b8',
    breed: '中华田园犬', category: '狗狗', gender: '弟弟', age: '1 岁', ageGroup: '成宠',
    personality: '忠诚温顺', city: '上海 · 徐汇', health: '健康活泼', sterilized: true,
    vaccinated: true, listedAt: '2026-11-22', popularity: 88, traits: ['温顺', '活泼', '亲人']
  },
  {
    id: 2, name: '煤球', emoji: '🐈', image: '/pets/zhima.png', color: '#d7e3ec',
    breed: '田园猫', category: '猫猫', gender: '妹妹', age: '8 个月', ageGroup: '幼宠',
    personality: '慢热亲人', city: '上海 · 静安', health: '健康状况良好', sterilized: false,
    vaccinated: true, listedAt: '2026-11-22', popularity: 76, traits: ['安静', '慢热', '温顺']
  },
  {
    id: 3, name: '雪球', emoji: '🐇', image: '/pets/mianhuatang.png', color: '#e9dcf5',
    breed: '侏儒兔', category: '兔兔', gender: '妹妹', age: '6 个月', ageGroup: '幼宠',
    personality: '温顺乖巧', city: '南京 · 鼓楼', health: '健康活泼', sterilized: false,
    vaccinated: false, listedAt: '2026-11-22', popularity: 82, traits: ['温顺', '安静', '乖巧']
  },
  {
    id: 4, name: '阿福', emoji: '🐕', image: '/pets/kele.png', color: '#ffe0c4',
    breed: '柯基串串', category: '狗狗', gender: '弟弟', age: '2 岁', ageGroup: '成宠',
    personality: '乖巧乐观', city: '杭州 · 滨江', health: '恢复中', sterilized: true,
    vaccinated: true, listedAt: '2026-11-22', popularity: 91, traits: ['活泼', '亲人', '贪吃']
  }
]

// 供领养专区使用：已完成救助的宠物，状态为「待领养」
// id 加 1000 偏移，避免与原有 1-6 号宠物冲突
export function getRescuedAdoptPets() {
  const done = getDoneIds()
  return rescuePets
    .filter(p => done.includes(p.id))
    .map(p => ({
      ...p,
      id: p.id + 1000,
      mood: '开心到冒泡',
      moodEmoji: '😸',
      rescued: true
    }))
}
