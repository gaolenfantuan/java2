// ============================================================
// 首页内容统一管理数据层
// ------------------------------------------------------------
// 后台「首页内容管理」与前台首页共用这一份响应式数据。
// 任何新增 / 编辑 / 上下架 / 排序操作都会立即同步到首页，
// 并写入 localStorage，刷新页面或多标签页之间也能保持一致。
// ============================================================
import { computed, reactive, watch } from 'vue'

const STORAGE_KEY = 'petHomeManageContent'

// 内置板块：key 是首页渲染的稳定标识，name 可以在后台修改
export const BUILTIN_BOARDS = [
  { key: 'carousel', name: '首页轮播', icon: '🖼️', desc: '首屏大图轮播，支持上传图片与跳转链接' },
  { key: 'featured', name: '推荐宠物', icon: '🐾', desc: '首页精选毛孩子，可绑定宠物 ID' },
  { key: 'notice', name: '首页公告', icon: '📢', desc: '公告栏，支持富文本内容' },
  { key: 'event', name: '首页活动', icon: '🎉', desc: '活动卡片，可配封面与跳转链接' },
  { key: 'tip', name: '首页小贴士', icon: '💡', desc: '养宠小知识，支持富文本' },
  { key: 'popup', name: '首页弹窗', icon: '💌', desc: '进入首页时弹出的消息卡片' }
]

const now = () => new Date().toLocaleString('zh-CN', { hour12: false })

function seedState() {
  const categories = BUILTIN_BOARDS.map((board, index) => ({
    id: `board_${board.key}`,
    key: board.key,
    name: board.name,
    icon: board.icon,
    desc: board.desc,
    builtin: true,
    sort: index + 1,
    createTime: now()
  }))

  const stamp = now()
  const items = [
    {
      id: 'content_1', categoryId: 'board_carousel', title: '把这个秋天交给毛孩子',
      summary: '秋日领养季开启，温柔的 TA 正在等你',
      cover: '', emoji: '🍂', link: '/adopt', html: '', petId: null,
      weight: 100, likes: 128, views: 860, hot: true, status: 1, createTime: stamp
    },
    {
      id: 'content_2', categoryId: 'board_carousel', title: '萌宠乐园每日赚币',
      summary: '玩 15 秒小游戏，兑换零食和玩具',
      cover: '', emoji: '🎮', link: '/playground', html: '', petId: null,
      weight: 90, likes: 96, views: 702, hot: false, status: 1, createTime: stamp
    },
    {
      id: 'content_3', categoryId: 'board_featured', title: '今日特别推荐 · 奶盖',
      summary: '粘人小甜心，最爱趴在窗边晒太阳',
      cover: '', emoji: '🐱', link: '', html: '', petId: 1,
      weight: 100, likes: 212, views: 1032, hot: true, status: 1, createTime: stamp
    },
    {
      id: 'content_4', categoryId: 'board_featured', title: '今日特别推荐 · 芝麻',
      summary: '高冷小傲娇，熟悉之后会偷偷贴贴',
      cover: '', emoji: '🐶', link: '', html: '', petId: 2,
      weight: 90, likes: 178, views: 921, hot: false, status: 1, createTime: stamp
    },
    {
      id: 'content_5', categoryId: 'board_notice', title: '领养申请审核时间调整公告',
      summary: '即日起，工作日的申请将在 24 小时内完成审核',
      cover: '', emoji: '📢', link: '',
      html: '亲爱的毛孩子家长：<br>为了更快回应每一份心意，<strong>工作日提交的领养申请将在 24 小时内完成审核</strong>。周末与节假日顺延至下一个工作日，感谢你的耐心等待 🐾',
      petId: null, weight: 100, likes: 0, views: 460, hot: false, status: 1, createTime: stamp
    },
    {
      id: 'content_6', categoryId: 'board_event', title: '周末线下见面会 · 第 8 期',
      summary: '带上家人朋友，来和毛孩子们面对面吧',
      cover: '', emoji: '🎪', link: '/adopt', html: '', petId: null,
      weight: 100, likes: 88, views: 535, hot: false, status: 1, createTime: stamp
    },
    {
      id: 'content_7', categoryId: 'board_tip', title: '第一次养猫，要准备什么？',
      summary: '猫砂盆、猫粮、水碗和一点耐心',
      cover: '', emoji: '💡', link: '',
      html: '<strong>新手养猫清单</strong>：猫砂盆、猫砂、主粮、水碗、猫抓板和一个安静的小窝。刚到家的头几天不要急着抱，让它自己探索，熟悉气味后再慢慢亲近～',
      petId: null, weight: 100, likes: 76, views: 388, hot: false, status: 1, createTime: stamp
    },
    {
      id: 'content_8', categoryId: 'board_popup', title: '领养前的小小约定 💌',
      summary: '科学喂养、不离不弃，愿每一份喜欢都有回应',
      cover: '', emoji: '💌', link: '/adopt',
      html: '领养不是一时兴起，而是一辈子的陪伴。<br><strong>请确认有稳定住所与陪伴时间，并接受后续回访。</strong>',
      petId: null, weight: 100, likes: 0, views: 0, hot: false, status: 1, createTime: stamp
    }
  ]
  return { categories, items }
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null')
    if (saved && Array.isArray(saved.categories) && Array.isArray(saved.items)) {
      return saved
    }
  } catch { /* 数据损坏时回退到初始内容 */ }
  return seedState()
}

export const contentState = reactive(loadState())

export const contentCategories = computed(() =>
  [...contentState.categories].sort((a, b) => (Number(a.sort) || 0) - (Number(b.sort) || 0))
)
export const contentItems = computed(() => contentState.items)

// 跨标签页同步：另一个窗口改动后，本窗口首页立即刷新
let syncing = false
if (typeof window !== 'undefined') {
  window.addEventListener('storage', event => {
    if (event.key !== STORAGE_KEY || !event.newValue) return
    try {
      const fresh = JSON.parse(event.newValue)
      if (!Array.isArray(fresh.categories) || !Array.isArray(fresh.items)) return
      syncing = true
      contentState.categories = fresh.categories
      contentState.items = fresh.items
      window.dispatchEvent(new CustomEvent('pet-content-updated', { detail: { source: 'storage' } }))
      setTimeout(() => { syncing = false }, 0)
    } catch { /* 忽略非法数据 */ }
  })
}

watch(
  contentState,
  () => {
    if (syncing || typeof localStorage === 'undefined') return
    localStorage.setItem(STORAGE_KEY, JSON.stringify(contentState))
    window.dispatchEvent(new CustomEvent('pet-content-updated', { detail: {} }))
  },
  { deep: true }
)

function notify(detail = {}) {
  if (typeof window === 'undefined') return
  window.dispatchEvent(new CustomEvent('pet-content-updated', { detail }))
}

// ---------------- 通用读写 ----------------
export function findCategory(id) {
  return contentState.categories.find(item => item.id === id) || null
}

export function findContent(id) {
  return contentState.items.find(item => item.id === id) || null
}

export function nextContentId() {
  return `content_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
}

export function nextCategoryId() {
  return `board_custom_${Date.now()}`
}

/** 按板块取已上架内容，权重越大越靠前 */
export function onlineByBoard(boardKey) {
  const category = contentState.categories.find(item => item.key === boardKey)
  if (!category) return []
  return contentState.items
    .filter(item => item.categoryId === category.id && Number(item.status) === 1)
    .sort((a, b) => (Number(b.weight) || 0) - (Number(a.weight) || 0))
}

export function itemsOfCategory(categoryId) {
  return contentState.items.filter(item => item.categoryId === categoryId)
}

export function categoryNameOf(categoryId) {
  return findCategory(categoryId)?.name || '未分类'
}

export function addItem(record) {
  const item = {
    id: nextContentId(), likes: 0, views: 0, hot: false, status: 1,
    cover: '', emoji: '', link: '', html: '', petId: null,
    createTime: now(), ...record
  }
  contentState.items.push(item)
  notify()
  return item
}

export function updateItem(id, patch) {
  const item = findContent(id)
  if (!item) return null
  Object.assign(item, patch, { updateTime: now() })
  notify()
  return item
}

export function deleteItem(id) {
  const index = contentState.items.findIndex(item => item.id === id)
  if (index < 0) return false
  contentState.items.splice(index, 1)
  notify()
  return true
}

export function addCategory(record) {
  const category = {
    id: nextCategoryId(), builtin: false, icon: '🧩', desc: '',
    sort: contentState.categories.length + 1, createTime: now(), ...record
  }
  contentState.categories.push(category)
  notify()
  return category
}

export function updateCategory(id, patch) {
  const category = findCategory(id)
  if (!category) return null
  Object.assign(category, patch)
  notify()
  return category
}

export function deleteCategory(id) {
  const index = contentState.categories.findIndex(item => item.id === id)
  if (index < 0) return false
  contentState.categories.splice(index, 1)
  const removed = contentState.items.filter(item => item.categoryId === id).length
  contentState.items = contentState.items.filter(item => item.categoryId !== id)
  notify()
  return removed
}

/** 重新按传入顺序（从前往后）分配权重，越靠前权重越大 */
export function applyWeightOrder(orderedIds) {
  const total = orderedIds.length
  orderedIds.forEach((id, index) => {
    const item = findContent(id)
    if (item) item.weight = (total - index) * 10
  })
  notify({ action: 'reorder' })
}

export function resetContent() {
  const fresh = seedState()
  contentState.categories = fresh.categories
  contentState.items = fresh.items
  notify({ action: 'reset' })
}

export function restoreBuiltinBoards() {
  BUILTIN_BOARDS.forEach(board => {
    if (contentState.categories.some(item => item.key === board.key)) return
    contentState.categories.push({
      id: `board_${board.key}`, key: board.key, name: board.name, icon: board.icon,
      desc: board.desc, builtin: true, sort: contentState.categories.length + 1, createTime: now()
    })
  })
  notify({ action: 'restore' })
}

export function formatCover(cover, emoji = '🎀') {
  if (!cover) return { image: '', gradient: 'linear-gradient(135deg,#ffe3ef,#ffd9b8)' }
  if (/^(data:|https?:|\/|\.\/)/i.test(cover)) return { image: cover, gradient: '' }
  return { image: '', gradient: cover }
}
