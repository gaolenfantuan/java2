// ============================================================
// 首页展示数据（由后台管理系统维护）
// ------------------------------------------------------------
// 后台「首页宠物管理」把数据写入 localStorage，这里读取后提供给首页 / 搜索。
// 没有管理数据时自动回退到 pets.js 的默认数据，保证旧用户无感。
// ============================================================
import { computed, reactive } from 'vue'
import { pets as defaultPets, categories as defaultCategories } from './pets'

const STORAGE_KEY = 'petHomeManageData'

const state = reactive({
  pets: [],
  categories: [],
  loaded: false
})

function load() {
  if (state.loaded) return
  state.loaded = true
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null')
    if (raw && Array.isArray(raw.pets)) {
      state.pets = raw.pets
      state.categories = Array.isArray(raw.categories) ? raw.categories : [...defaultCategories]
      return
    }
  } catch {
    // 数据损坏时回退默认配置
  }
  state.categories = [...defaultCategories]
}
load()

// 后台管理页与首页在不同标签页时，也能通过 storage 事件同步最新展示数据
if (typeof window !== 'undefined') {
  window.addEventListener('storage', event => {
    if (event.key !== STORAGE_KEY) return
    try {
      const raw = JSON.parse(event.newValue || 'null')
      state.pets = raw && Array.isArray(raw.pets) ? raw.pets : []
      state.categories = raw && Array.isArray(raw.categories)
        ? raw.categories
        : [...defaultCategories]
    } catch {
      state.pets = []
      state.categories = [...defaultCategories]
    }
  })
}

function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    pets: state.pets,
    categories: state.categories,
    updatedAt: new Date().toISOString()
  }))
}

/** 后台读取：包含下架的全部宠物 */
export function managedPets() {
  load()
  return state.pets
}

/** 后台保存完整宠物列表 */
export function saveManagedPets(list) {
  state.pets = list
  persist()
}

/** 后台读取 / 保存首页分类 */
export function managedCategories() {
  load()
  return state.categories
}

export function saveManagedCategories(list) {
  state.categories = list
  persist()
}

/** 恢复为 pets.js 初始数据 */
export function resetHomeData() {
  state.pets = []
  state.categories = [...defaultCategories]
  localStorage.removeItem(STORAGE_KEY)
}

/** 首页可见宠物：下架的不展示，按排序值升序 */
export const homePets = computed(() => {
  load()
  const source = state.pets.length ? state.pets : defaultPets
  return source
    .filter(pet => pet.status !== 0)
    .slice()
    .sort((a, b) => (Number(a.sort) || 0) - (Number(b.sort) || 0))
})

/** 首页分类栏（始终包含「全部」） */
export const homeCategories = computed(() => {
  load()
  const list = state.categories.length ? state.categories : defaultCategories
  return list.includes('全部') ? list : ['全部', ...list]
})

/** 详情页 / 搜索按 id 找宠物，优先使用后台管理数据 */
export function findHomePet(id) {
  return homePets.value.find(pet => String(pet.id) === String(id)) || null
}
