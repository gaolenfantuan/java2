import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import AuthView from '../views/AuthView.vue'
import PetDetail from '../views/PetDetail.vue'
import MyPets from '../views/MyPets.vue'
import AdoptView from '../views/AdoptView.vue'
import RescueView from '../views/RescueView.vue'
import WikiView from '../views/WikiView.vue'
import StoriesView from '../views/StoriesView.vue'
import SubmitView from '../views/SubmitView.vue'
import VolunteerView from '../views/VolunteerView.vue'
import FaqView from '../views/FaqView.vue'
import AboutView from '../views/AboutView.vue'
import Playground from '../views/Playground.vue'
import PetNest from '../views/PetNest.vue'
import ShopView from '../views/ShopView.vue'
import BackpackView from '../views/BackpackView.vue'
import NotFound from '../views/NotFound.vue'
import AdminLogin from '../views/AdminLogin.vue'
import AdminDashboard from '../views/AdminDashboard.vue'

// 准入页的三个入口共用同一个居中卡片页面，靠 meta.authMode 切换形态
const AUTH_META = { public: true }

const routes = [
  {
    path: '/',
    name: 'home',
    component: Home,
    meta: { title: '首页' }
  },
  {
    path: '/login',
    name: 'login',
    component: AuthView,
    meta: { ...AUTH_META, authMode: 'login', title: '登录' }
  },
  {
    path: '/register',
    name: 'register',
    component: AuthView,
    meta: { ...AUTH_META, authMode: 'register', title: '注册' }
  },
  {
    path: '/forgot',
    name: 'forgot',
    component: AuthView,
    meta: { ...AUTH_META, authMode: 'forgot', title: '找回密码' }
  },
  {
    path: '/pet/:id',
    name: 'pet-detail',
    component: PetDetail,
    meta: { title: '毛孩子详情' }
  },
  {
    path: '/my-pets',
    name: 'my-pets',
    component: MyPets,
    meta: { title: '我的毛孩子' }
  },
  {
    path: '/adopt',
    name: 'adopt',
    component: AdoptView,
    meta: { title: '领养专区' }
  },
  { path: '/rescue', name: 'rescue', component: RescueView, meta: { title: '流浪救助' } },
  // 毛孩子的家：已领养宠物的宠物窝，领养成功后自动进入
  { path: '/pet-nest', name: 'pet-nest', component: PetNest, meta: { title: '毛孩子的家' } },
  // 马卡龙萌系玩法：游戏赚币 → 积分商城 → 我的背包
  { path: '/playground', name: 'playground', component: Playground, meta: { title: '萌宠乐园' } },
  { path: '/shop', name: 'shop', component: ShopView, meta: { title: '积分商城' } },
  { path: '/backpack', name: 'backpack', component: BackpackView, meta: { title: '我的背包' } },
  { path: '/wiki', name: 'wiki', component: WikiView, meta: { title: '宠物百科' } },
  { path: '/stories', name: 'stories', component: StoriesView, meta: { title: '领养故事' } },
  { path: '/submit', name: 'submit', component: SubmitView, meta: { title: '送养投稿' } },
  { path: '/volunteer', name: 'volunteer', component: VolunteerView, meta: { title: '志愿者合作' } },
  { path: '/faq', name: 'faq', component: FaqView, meta: { title: '常见问题' } },
  { path: '/about', name: 'about', component: AboutView, meta: { title: '关于我们' } },
  // 后台管理系统：使用独立的 adminToken，与前台 petToken 完全隔离
  {
    path: '/admin/login',
    name: 'admin-login',
    component: AdminLogin,
    meta: { public: true, adminLogin: true, hideNav: true, title: '后台登录' }
  },
  {
    path: '/admin',
    name: 'admin-dashboard',
    component: AdminDashboard,
    meta: { admin: true, hideNav: true, title: '后台管理系统' }
  },
  // 兜底：未匹配的地址统一走萌系 404 页
  { path: '/:pathMatch(.*)*', name: 'not-found', component: NotFound, meta: { title: '页面走丢了' } }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  // 全站统一：切页回到顶部，配合 App.vue 的过渡动效
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) return savedPosition
    return { top: 0 }
  }
})

const SITE_NAME = '毛茸茸领养站'

// 路由守卫：后台走独立的 adminToken；前台准入页公开，其余页面需要 petToken。
// 登录成功回调会先写入对应 token 再跳转，因此不会被这里拦截。
router.beforeEach(to => {
  const adminToken = localStorage.getItem('adminToken')

  // 后台管理页：没登录就跳后台登录页，并带上原目标地址
  if (to.meta.admin) {
    return adminToken ? true : { path: '/admin/login', query: { redirect: to.fullPath } }
  }
  // 后台登录页：已登录时直接进入后台，避免重复登录
  if (to.meta.adminLogin) {
    return adminToken ? { path: '/admin' } : true
  }

  const token = localStorage.getItem('petToken')

  if (to.meta.public) {
    return token ? { path: '/' } : true
  }

  if (!token) {
    return { path: '/login', query: to.fullPath && to.fullPath !== '/' ? { redirect: to.fullPath } : {} }
  }

  return true
})

router.afterEach(to => {
  document.title = to.meta.title ? `${to.meta.title} · ${SITE_NAME}` : SITE_NAME
})

export default router
