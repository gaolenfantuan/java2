import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import LoginView from '../views/LoginView.vue'
import PetDetail from '../views/PetDetail.vue'
import MyPets from '../views/MyPets.vue'
import AdoptView from '../views/AdoptView.vue'
import RescueView from '../views/RescueView.vue'
import WikiView from '../views/WikiView.vue'
import StoriesView from '../views/StoriesView.vue'
import SubmitView from '../views/SubmitView.vue'
import VolunteerView from '../views/VolunteerView.vue'
import FaqView from '../views/FaqView.vue'
import AboutView from '../views/AboutView.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: Home
  },
  {
    path: '/login',
    name: 'login',
    component: LoginView
  },
  {
    path: '/pet/:id',
    name: 'pet-detail',
    component: PetDetail
  },
  {
    path: '/my-pets',
    name: 'my-pets',
    component: MyPets
  },
  {
    path: '/adopt',
    name: 'adopt',
    component: AdoptView
  },
  { path: '/rescue', name: 'rescue', component: RescueView },
  { path: '/wiki', name: 'wiki', component: WikiView },
  { path: '/stories', name: 'stories', component: StoriesView },
  { path: '/submit', name: 'submit', component: SubmitView },
  { path: '/volunteer', name: 'volunteer', component: VolunteerView },
  { path: '/faq', name: 'faq', component: FaqView },
  { path: '/about', name: 'about', component: AboutView }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 路由守卫：未登录访问首页时去登录页；已登录访问登录页时回首页。
// 登录成功回调会先写入 petToken 再调用 router.push('/')，因此不会被这里拦截。
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('petToken')
  if (to.path === '/login' && token) {
    next('/')
    return
  }
  if (to.path !== '/login' && !token) {
    next('/login')
    return
  }
  next()
})

export default router
