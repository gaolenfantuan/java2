// ============================================================
// 后台管理接口封装
// ------------------------------------------------------------
// 后端所有 /api/admin/** 接口都需要在请求头带 X-Admin-Token。
// 业务码放 in body.code：200 成功，401 登录过期。
// ============================================================
import axios from 'axios'

const request = axios.create({
  baseURL: '/api',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

request.interceptors.response.use(
  response => response.data,
  error => Promise.reject(error)
)

const TOKEN_KEY = 'adminToken'

export function getAdminToken() {
  return localStorage.getItem(TOKEN_KEY) || ''
}

export function setAdminSession(session) {
  localStorage.setItem(TOKEN_KEY, session.token)
  localStorage.setItem('adminInfo', JSON.stringify({
    id: session.adminId ?? session.id,
    username: session.username,
    nickname: session.nickname,
    expiresIn: session.expiresIn
  }))
}

export function clearAdminSession() {
  localStorage.removeItem(TOKEN_KEY)
  localStorage.removeItem('adminInfo')
}

export function getAdminInfo() {
  try {
    return JSON.parse(localStorage.getItem('adminInfo') || 'null')
  } catch {
    return null
  }
}

async function call(config) {
  let res
  try {
    res = await request({
      ...config,
      headers: { 'X-Admin-Token': getAdminToken(), ...(config.headers || {}) }
    })
  } catch (error) {
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message)
    }
    throw new Error('网络开小差了，请检查后端服务是否已启动')
  }
  if (!res || (res.code !== 200 && res.code !== 0)) {
    const error = new Error(res?.message || '操作失败，请稍后再试')
    error.code = res?.code
    throw error
  }
  return res.data
}

// 登录 / 会话
export const adminLogin = data => call({ method: 'post', url: '/admin/auth/login', data })
export const adminMe = () => call({ method: 'get', url: '/admin/auth/me' })
export const adminLogout = () => call({ method: 'post', url: '/admin/auth/logout' })

// 概览统计
export const adminStats = () => call({ method: 'get', url: '/admin/stats' })

// 首页内容（后端站点内容）
export const adminItems = params => call({ method: 'get', url: '/admin/items', params })
export const adminCreateItem = data => call({ method: 'post', url: '/admin/items', data })
export const adminUpdateItem = (id, data) => call({ method: 'put', url: `/admin/items/${id}`, data })
export const adminDeleteItem = id => call({ method: 'delete', url: `/admin/items/${id}` })

// 内容分类
export const adminCategories = () => call({ method: 'get', url: '/admin/categories' })
export const adminCreateCategory = data => call({ method: 'post', url: '/admin/categories', data })
export const adminUpdateCategory = (id, data) => call({ method: 'put', url: `/admin/categories/${id}`, data })
export const adminDeleteCategory = id => call({ method: 'delete', url: `/admin/categories/${id}` })
