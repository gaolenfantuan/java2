<script setup>
// 全站统一的空状态 / 错误态插画组件。
// 同一套猫猫插画 + 同一套文案层级，保证各页面调性一致。
defineProps({
  title: { type: String, default: '这里暂时空空的' },
  desc: { type: String, default: '换个条件看看，缘分也许就在下一页 🐾' },
  // empty 打盹 / search 放大镜 / error 出错
  variant: { type: String, default: 'empty' },
  compact: { type: Boolean, default: false }
})
</script>

<template>
  <div class="cute-empty" :class="{ compact }">
    <svg class="ce-art" viewBox="0 0 220 170" role="img" :aria-label="title">
      <!-- 地面 -->
      <ellipse cx="96" cy="150" rx="66" ry="10" fill="#f1d6a2" stroke="#2b2b2b" stroke-width="3" />

      <g stroke="#2b2b2b" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">
        <!-- 尾巴 -->
        <path d="M130 132q24-4 20-26" fill="none" />
        <!-- 身体 -->
        <ellipse cx="96" cy="116" rx="40" ry="32" fill="#fffdf6" />
        <!-- 耳朵 -->
        <path d="M72 48 68 22l24 14z" fill="#fffdf6" />
        <path d="M120 48 124 22l-24 14z" fill="#fffdf6" />
        <path d="M76 44 74 32l11 6z" fill="#ff9ec4" stroke="none" />
        <path d="M116 44 118 32l-11 6z" fill="#ff9ec4" stroke="none" />
        <!-- 头 -->
        <circle cx="96" cy="70" r="30" fill="#fffdf6" />
        <!-- 闭眼（温柔打盹） -->
        <path d="M82 70q6 7 12 0M98 70q6 7 12 0" fill="none" />
        <!-- 鼻子与嘴 -->
        <path d="M96 80l-4 4h8z" fill="#ff8fa8" stroke="none" />
        <path d="M96 84q-6 7-11 1M96 84q6 7 11 1" fill="none" />
        <!-- 腮红 -->
        <ellipse cx="72" cy="80" rx="7" ry="4.5" fill="#ffb3c9" stroke="none" opacity="0.85" />
        <ellipse cx="120" cy="80" rx="7" ry="4.5" fill="#ffb3c9" stroke="none" opacity="0.85" />
        <!-- 胡须 -->
        <path d="M68 74h-12M68 80h-10M124 74h12M124 80h10" fill="none" stroke-width="2" />
        <!-- 小爪 -->
        <path d="M78 136q0-8 8-8M114 136q0-8-8-8" fill="none" />
      </g>

      <!-- 右侧小木牌 -->
      <g stroke="#2b2b2b" stroke-width="3" stroke-linejoin="round">
        <path d="M170 148v-26" fill="none" stroke-linecap="round" />
        <rect x="138" y="86" width="66" height="36" rx="8" fill="#fff8e9" />
      </g>
      <text
        x="171"
        y="113"
        text-anchor="middle"
        font-size="20"
        font-weight="900"
        fill="#ff9b54"
        font-family="inherit"
      >?</text>

      <!-- 变体装饰：放大镜 / 感叹号 / 睡意 -->
      <g v-if="variant === 'search'" stroke="#2b2b2b" stroke-width="3" fill="none" stroke-linecap="round">
        <circle cx="46" cy="40" r="15" fill="#9fd3ff" />
        <path d="M57 51l12 12" stroke-width="4" />
      </g>
      <g v-else-if="variant === 'error'" stroke="#2b2b2b" stroke-width="3" stroke-linecap="round">
        <circle cx="46" cy="40" r="16" fill="#ffd84d" />
        <path d="M46 32v10" />
        <circle cx="46" cy="48" r="1.6" fill="#2b2b2b" stroke="none" />
      </g>
      <g v-else stroke="#c9a87f" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round">
        <path d="M40 52h12l-12 12h12" />
        <path d="M58 34h8l-8 8h8" stroke-width="2.4" />
      </g>

      <!-- 星星点缀 -->
      <g fill="#ffd84d" stroke="#2b2b2b" stroke-width="2">
        <path d="M30 116l2.6 6 6 2.6-6 2.6-2.6 6-2.6-6-6-2.6 6-2.6z" />
        <path d="M196 46l2 4.6 4.6 2-4.6 2-2 4.6-2-4.6-4.6-2 4.6-2z" />
      </g>
    </svg>

    <h3 class="ce-title">{{ title }}</h3>
    <p class="ce-desc">{{ desc }}</p>

    <div v-if="$slots.default" class="ce-actions">
      <slot />
    </div>
  </div>
</template>

<style scoped>
.cute-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 26px 20px 30px;
  text-align: center;
}

.ce-art {
  width: 200px;
  max-width: 72%;
  height: auto;
  margin-bottom: 4px;
  animation: ce-bob 3.6s ease-in-out infinite;
}

@keyframes ce-bob {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -6px; }
}

.ce-title {
  margin: 0;
  font-size: 16px;
  font-weight: 900;
  letter-spacing: 0.3px;
  color: var(--text-1);
}

.ce-desc {
  margin: 0;
  max-width: 340px;
  font-size: 12px;
  font-weight: 700;
  line-height: 1.7;
  color: var(--text-2);
}

.ce-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 10px;
  margin-top: 12px;
}

/* 紧凑模式：嵌在列表里的空态，自带卡片外框 */
.compact {
  padding: 18px 16px 20px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-1);
}
.compact .ce-art { width: 132px; }
.compact .ce-title { font-size: 14px; }
.compact .ce-desc { font-size: 11px; }
</style>
