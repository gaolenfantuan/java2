<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { store, bagTotalCount } from '../store'
import { homePets as pets } from '../data/homePets'
import { highlightHtml } from '../utils/highlight'
import { badges } from '../utils/achievements'
import CoinIcon from './CoinIcon.vue'

const router = useRouter()
const route = useRoute()

// 主页佩戴中的徽章（在「我的毛孩子 - 徽章」里佩戴）
const wornBadge = computed(() => badges.find(b => b.id === store.wornBadge) || null)

// 搜索框与首页筛选通过全局 store 联动（全局导航常驻，不依赖父组件传值）
function onSearchInput(event) {
  store.searchQuery = event.target.value
  // 在其它页面输入搜索时，自动回到首页查看筛选结果
  if (route.path !== '/' && store.searchQuery.trim()) {
    router.push('/')
  }
}

// 主导航菜单：图标全部使用 emoji，不引入图标库
// 萌宠乐园 / 积分商城 是本次新增的玩法入口，常驻主菜单并用马卡龙底色区分
const menuItems = [
  { icon: '🏠', label: '首页', path: '/' },
  { icon: '🐾', label: '领养专区', path: '/adopt' },
  { icon: '🎮', label: '萌宠乐园', path: '/playground', hot: 'mint' },
  { icon: '🛍️', label: '积分商城', path: '/shop', hot: 'pink' },
  { icon: '🏡', label: '毛孩子的家', path: '/pet-nest', hot: 'yellow' },
  { icon: '💕', label: '我的毛孩子', path: '/my-pets' },
  { icon: '🚑', label: '流浪救助', path: '/rescue' },
  { icon: '📚', label: '宠物百科', path: '/wiki' },
  { icon: '📖', label: '领养故事', path: '/stories' },
  { icon: '✍️', label: '送养投稿', path: '/submit' },
  { icon: '🤝', label: '志愿者合作', path: '/volunteer' },
  { icon: '❓', label: '常见问题', path: '/faq' },
  { icon: '💗', label: '关于我们', path: '/about' }
]

// 主要菜单常驻（含两个新玩法入口），次要菜单在窄屏收进「更多」折叠面板
const primaryItems = menuItems.slice(0, 6)
const secondaryItems = menuItems.slice(6)
const moreOpen = ref(false)
const userMenuOpen = ref(false)
const msgOpen = ref(false)

// 搜索实时联想：按名字 / 品种匹配，最多 5 条
const searchFocused = ref(false)
const suggestions = computed(() => {
  const kw = store.searchQuery.trim().toLowerCase()
  if (!kw) return []
  return pets.value
    .filter(pet => pet.name.toLowerCase().includes(kw) || pet.breed.toLowerCase().includes(kw))
    .slice(0, 5)
})

function pickSuggestion(pet) {
  store.searchQuery = ''
  searchFocused.value = false
  router.push(`/pet/${pet.id}`)
}

function goSearchResults() {
  searchFocused.value = false
  if (route.path !== '/') router.push('/')
}

function closeMore() {
  moreOpen.value = false
}

function closeUserMenu() {
  userMenuOpen.value = false
}

// 消息浮层：点击铃铛切换，点页面其它地方收起
function goPlaygroundFromMsg() {
  msgOpen.value = false
  router.push('/playground')
}

// 点击页面其它地方时收起所有浮层
function handleOutsideClick() {
  moreOpen.value = false
  userMenuOpen.value = false
  msgOpen.value = false
}

// 切换页面时收起所有浮层
watch(() => route.path, () => {
  moreOpen.value = false
  userMenuOpen.value = false
  msgOpen.value = false
  searchFocused.value = false
})

onMounted(() => document.addEventListener('click', handleOutsideClick))
onBeforeUnmount(() => document.removeEventListener('click', handleOutsideClick))

// 所有菜单均已接入真实路由，点击直接跳转
function goMenu(item) {
  if (route.path !== item.path) router.push(item.path)
}

function isActive(item) {
  if (item.path === '/') return route.path === '/'
  if (item.path === '/adopt') return route.path === '/adopt' || route.path.startsWith('/pet')
  if (item.path === '/my-pets') return route.path === '/my-pets'
  if (item.path === '/pet-nest') return route.path === '/pet-nest'
  if (item.path === '/playground') return route.path === '/playground'
  if (item.path === '/shop') return route.path === '/shop'
  return route.path === item.path
}

const activeLabel = computed(() => {
  const found = menuItems.find(isActive)
  return found ? found.label : ''
})

// 用户昵称：优先读取本地缓存，未登录时给默认可爱昵称
const nickname = ref('')
function loadNickname() {
  try {
    nickname.value = localStorage.getItem('petNickname') || '小可爱'
  } catch {
    nickname.value = '小可爱'
  }
}
loadNickname()

function goHome() {
  if (route.path !== '/') router.push('/')
}
// 后台管理入口：跳转后台登录页（已有管理员会话则直接进后台）
function goAdmin() {
  router.push('/admin')
}
function goMyPets() {
  userMenuOpen.value = false
  router.push('/my-pets')
}
function goPetNest() {
  userMenuOpen.value = false
  router.push('/pet-nest')
}
// 我的背包 / 积分商城 / 萌宠乐园：头像下拉与币数入口共用
function goBackpack() {
  userMenuOpen.value = false
  router.push('/backpack')
}
function goShop() {
  userMenuOpen.value = false
  router.push('/shop')
}
function goPlayground() {
  userMenuOpen.value = false
  router.push('/playground')
}
function logout() {
  userMenuOpen.value = false
  localStorage.removeItem('petToken')
  router.push('/login')
}
</script>

<template>
  <nav class="main-nav" aria-label="主导航">
    <div class="main-nav-inner">
      <!-- 唯一一组 Logo：站名倾斜，与爪印图标搭配 -->
      <button type="button" class="main-logo" @click="goHome">
        <span class="main-logo-badge" aria-hidden="true">🐾</span>
        <span class="main-logo-text">毛茸茸领养站</span>
      </button>

      <!-- 中间主菜单：主要项常驻，次要项窄屏折叠进「更多」 -->
      <div class="menu-wrap">
        <ul class="main-menu">
          <li v-for="item in primaryItems" :key="item.label">
            <button
              type="button"
              class="main-menu-item"
              :class="[{ active: isActive(item) }, item.hot ? 'hot-' + item.hot : '']"
              :title="activeLabel === item.label ? '当前页面' : ''"
              @click="goMenu(item)"
            >
              <span class="main-menu-icon" aria-hidden="true">{{ item.icon }}</span>
              <span class="main-menu-label">{{ item.label }}</span>
            </button>
          </li>
          <li v-for="item in secondaryItems" :key="item.label" class="sec">
            <button
              type="button"
              class="main-menu-item"
              :class="[{ active: isActive(item) }, item.hot ? 'hot-' + item.hot : '']"
              :title="activeLabel === item.label ? '当前页面' : ''"
              @click="goMenu(item)"
            >
              <span class="main-menu-icon" aria-hidden="true">{{ item.icon }}</span>
              <span class="main-menu-label">{{ item.label }}</span>
            </button>
          </li>
        </ul>

        <div class="more-wrap" @click.stop>
          <button
            type="button"
            class="main-more"
            :class="{ active: moreOpen || secondaryItems.some(isActive) }"
            :aria-expanded="moreOpen"
            aria-haspopup="true"
            @click="moreOpen = !moreOpen"
          >
            更多
            <span class="caret" :class="{ open: moreOpen }" aria-hidden="true">▾</span>
          </button>

          <div v-if="moreOpen" class="more-panel">
            <button
              v-for="item in secondaryItems"
              :key="item.label"
              type="button"
              class="more-item"
              :class="{ active: isActive(item) }"
              @click="goMenu(item); moreOpen = false"
            >
              <span aria-hidden="true">{{ item.icon }}</span>
              {{ item.label }}
            </button>
          </div>
        </div>
      </div>

      <!-- 右侧：管理系统入口 + 搜索框 + 用户头像 + 退出登录 -->
      <div class="main-user">
        <button type="button" class="admin-entry" title="进入后台管理系统" @click="goAdmin">
          <span aria-hidden="true">⚙️</span>
          <span>管理系统</span>
        </button>

        <div class="search-wrap">
          <label class="main-search">
            <span class="main-search-icon" aria-hidden="true">🔍</span>
            <input
              :value="store.searchQuery"
              type="search"
              placeholder="搜名字 / 品种..."
              aria-label="搜索宠物"
              @input="onSearchInput"
              @focus="searchFocused = true"
              @blur="searchFocused = false"
            >
          </label>

          <!-- 实时联想：点选直接进详情 -->
          <div v-if="searchFocused && store.searchQuery.trim()" class="search-pop">
            <p class="sp-title">🔍 联想结果</p>
            <button
              v-for="pet in suggestions"
              :key="pet.id"
              type="button"
              class="sp-item"
              @mousedown.prevent="pickSuggestion(pet)"
            >
              <img :src="pet.image" :alt="pet.name">
              <span class="sp-copy">
                <strong v-html="highlightHtml(pet.name, store.searchQuery)"></strong>
                <small v-html="highlightHtml(pet.breed, store.searchQuery)"></small>
              </span>
              <span class="sp-go" aria-hidden="true">→</span>
            </button>
            <p v-if="!suggestions.length" class="sp-empty">没有找到匹配的毛孩子 🐾</p>
            <button v-else type="button" class="sp-all" @mousedown.prevent="goSearchResults">
              在首页查看全部结果 →
            </button>
          </div>
        </div>
        <!-- 游戏币余额：点一下直接去积分商城 -->
        <button
          type="button"
          class="coin-chip"
          title="我的游戏币，去积分商城逛逛"
          @click="goShop"
        >
          <CoinIcon :size="19" />
          <strong :key="store.coins">{{ store.coins }}</strong>
        </button>

        <!-- 消息通知：与游戏币、搜索框、头像统一圆润风格 -->
        <div class="msg-wrap" @click.stop>
          <button
            type="button"
            class="msg-chip"
            :class="{ open: msgOpen }"
            title="消息通知"
            aria-label="消息通知"
            :aria-expanded="msgOpen"
            @click="msgOpen = !msgOpen"
          >
            <span aria-hidden="true">🔔</span>
            <span class="msg-dot" aria-hidden="true"></span>
          </button>
          <div v-if="msgOpen" class="msg-panel">
            <p class="mp-head">📬 消息通知</p>
            <p class="mp-empty">暂时没有新消息，去萌宠乐园玩一会儿吧 🐾</p>
            <button type="button" class="mp-link" @click="goPlaygroundFromMsg">去萌宠乐园 →</button>
          </div>
        </div>

        <!-- 头像下拉：我的毛孩子 / 我的背包 / 积分商城 / 退出 -->
        <div class="avatar-wrap" @click.stop>
          <button
            type="button"
            class="main-avatar"
            :class="{ open: userMenuOpen }"
            title="打开我的菜单"
            aria-haspopup="true"
            :aria-expanded="userMenuOpen"
            @click="userMenuOpen = !userMenuOpen"
          >
            <span aria-hidden="true">🐱</span>
            <span
              v-if="wornBadge"
              class="avatar-worn"
              :style="{ background: wornBadge.color }"
              :title="`佩戴中：${wornBadge.name}`"
            >{{ wornBadge.icon }}</span>
            <span v-if="store.unlockedBadgeCount" class="avatar-badge-count">{{ store.unlockedBadgeCount }}</span>
          </button>

          <div v-if="userMenuOpen" class="user-panel">
            <div class="up-head">
              <span class="up-avatar" aria-hidden="true">🐱</span>
              <div class="up-identity">
                <strong>{{ nickname }}</strong>
                <small>今天也要好好吸猫 🐾</small>
              </div>
            </div>

            <button
              v-if="wornBadge"
              type="button"
              class="up-worn"
              :style="{ '--worn-color': wornBadge.color }"
              @click="goMyPets()"
            >
              <span class="uw-medal" aria-hidden="true">{{ wornBadge.icon }}</span>
              <span class="uw-copy">
                <small>主页佩戴中</small>
                <strong>{{ wornBadge.name }}</strong>
              </span>
              <span class="uw-arrow" aria-hidden="true">→</span>
            </button>

            <div class="up-wallet">
              <CoinIcon :size="17" />
              <strong :key="store.coins">{{ store.coins }}</strong>
              <span>游戏币</span>
              <button type="button" class="up-earn" @click="goPlayground">赚币</button>
            </div>

            <button type="button" class="up-item" @click="goPetNest">
              <span aria-hidden="true">🏡</span>毛孩子的家
            </button>
            <button type="button" class="up-item" @click="goMyPets">
              <span aria-hidden="true">💕</span>我的毛孩子
            </button>
            <button type="button" class="up-item" @click="goBackpack">
              <span aria-hidden="true">🎒</span>我的背包
              <span v-if="bagTotalCount()" class="up-num">{{ bagTotalCount() }}</span>
            </button>
            <button type="button" class="up-item" @click="goShop">
              <span aria-hidden="true">🛍️</span>积分商城
            </button>

            <span class="up-line" aria-hidden="true"></span>

            <button type="button" class="up-item danger" @click="logout">
              <span aria-hidden="true">🚪</span>退出登录
            </button>
          </div>
        </div>

        <button type="button" class="logout-btn" @click="logout">🚪 退出</button>
      </div>
    </div>
  </nav>
</template>

<style scoped>
/* 完整通栏：通顶白底 + 柔和底部投影。
   移除中间黑色分隔横线（原 border-bottom），sticky 吸顶占据文档流，
   不遮挡下方内容、不影响滚动；主体内容自然位于其下。 */
.main-nav {
  position: sticky;
  top: 0;
  z-index: 20;
  background: #fffdf6;
  box-shadow: 0 5px 0 rgba(43, 43, 43, 0.08);
}

.main-nav-inner {
  max-width: 1440px;
  margin: 0 auto;
  padding: 10px 22px;
  display: flex;
  align-items: center;
  gap: 18px;
}

/* 左侧 Logo（唯一一组）+ 倾斜站名 */
.main-logo {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 4px 8px;
  font: inherit;
  font-size: 19px;
  font-weight: 900;
  color: var(--ink);
  background: transparent;
  border: none;
  cursor: pointer;
  white-space: nowrap;
}
.main-logo-badge {
  width: 40px;
  height: 40px;
  display: grid;
  place-items: center;
  background: var(--pink);
  border: var(--line);
  border-radius: var(--r-sm);
  font-size: 22px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-6deg);
  transition: transform 0.15s;
}
.main-logo:hover .main-logo-badge { transform: rotate(0deg) scale(1.06); }
.main-logo-text {
  display: inline-block;
  font-style: italic;
  transform: skewX(-7deg);
  letter-spacing: 0.5px;
}

/* 中间菜单容器：主菜单 + 「更多」折叠入口 */
.menu-wrap {
  flex: 1 1 auto;
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 6px;
}

/* 中间菜单：五项常驻，其余收进「更多」；菜单整体靠左分组 */
.main-menu {
  flex: 0 1 auto;
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 7px;
  margin: 0;
  padding: 2px 0;
  list-style: none;
  overflow-x: auto;
  scrollbar-width: none;
}
.main-menu::-webkit-scrollbar { display: none; }
.main-menu li { flex: 0 0 auto; }

.main-menu-item {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 7px 11px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  white-space: nowrap;
  transition: transform 0.16s cubic-bezier(0.2, 1.4, 0.4, 1), box-shadow 0.16s, background 0.16s;
}
.main-menu-item:hover {
  transform: translateY(-3px);
  box-shadow: 3px 6px 0 var(--ink);
  background: #fff6d8;
}
.main-menu-item:active {
  transform: translateY(0);
  box-shadow: 1px 2px 0 var(--ink);
}
/* 当前页面高亮：加深底色 + 内描边 + 轻微上浮，一眼可辨 */
.main-menu-item.active {
  background: var(--yellow-deep);
  border-color: #000;
  box-shadow: 3px 5px 0 var(--ink), inset 0 0 0 1.5px rgba(43, 43, 43, 0.16);
  transform: translateY(-2px);
}
.main-menu-icon { font-size: 14px; line-height: 1; }

/* 新玩法入口：马卡龙底色区分 + 右上小红点，一眼能看到 */
.main-menu-item.hot-mint { background: #d9f5ea; }
.main-menu-item.hot-pink { background: #ffe3ee; }
.main-menu-item.hot-yellow { background: #fff0b8; }
.main-menu-item.hot-mint:hover { background: #c6efdf; }
.main-menu-item.hot-pink:hover { background: #ffd6e6; }
.main-menu-item.hot-yellow:hover { background: #ffe89a; }
.main-menu-item.hot-mint::after,
.main-menu-item.hot-pink::after,
.main-menu-item.hot-yellow::after {
  content: "";
  position: absolute;
  top: -4px;
  right: -4px;
  width: 8px;
  height: 8px;
  background: #e2603f;
  border: 1.5px solid var(--ink);
  border-radius: 50%;
}
.main-menu-item.hot-mint.active,
.main-menu-item.hot-pink.active,
.main-menu-item.hot-yellow.active { background: var(--yellow-deep); }

/* 右侧操作区：管理系统入口 + 搜索框 + 头像 + 退出登录 */
.main-user {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 10px;
}

/* 后台管理系统入口：马卡龙粉底 + 硬阴影，和主菜单区分开 */
.admin-entry {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 8px 12px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  white-space: nowrap;
  background: #ffd3e2;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: transform 0.15s, box-shadow 0.15s, background 0.15s;
}
.admin-entry:hover {
  transform: translateY(-3px);
  box-shadow: 3px 6px 0 var(--ink);
  background: var(--yellow);
}
.admin-entry:active { transform: translateY(0); box-shadow: 1px 2px 0 var(--ink); }
.main-search {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 11px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-pill);
  box-shadow: 3px 3px 0 var(--ink);
  transition: border-color 0.15s, box-shadow 0.15s, background 0.15s;
}
.main-search:focus-within {
  background: #fffdf6;
  border-color: var(--orange);
  box-shadow: 3px 3px 0 var(--orange), 0 0 0 3px rgba(255, 155, 84, 0.22);
}
.main-search-icon { font-size: 12px; }
.main-search input {
  width: 90px;
  padding: 2px 0;
  font: inherit;
  font-size: 11px;
  font-weight: 700;
  color: var(--ink);
  background: transparent;
  border: none;
  outline: none;
}
.main-search input::placeholder { color: var(--text-3); }

.main-avatar {
  position: relative;
  width: 40px;
  height: 40px;
  display: grid;
  place-items: center;
  padding: 0;
  border-radius: 50%;
  background: var(--mint);
  border: var(--line);
  box-shadow: 3px 3px 0 var(--ink);
  font-size: 22px;
  cursor: pointer;
  transition: transform 0.15s;
}
.main-avatar:hover { transform: translateY(-3px); }
.main-avatar.open { transform: translateY(-3px); background: var(--yellow); }
.avatar-badge-count {
  position: absolute;
  right: -6px;
  top: -6px;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  display: grid;
  place-items: center;
  font-size: 10px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
}

/* 佩戴中的徽章：别在头像右下角 */
.avatar-worn {
  position: absolute;
  left: -7px;
  bottom: -7px;
  width: 21px;
  height: 21px;
  display: grid;
  place-items: center;
  font-size: 11px;
  line-height: 1;
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: 2px 2px 0 var(--ink);
  animation: worn-pop 2.6s ease-in-out infinite;
}
@keyframes worn-pop {
  0%, 100% { transform: translateY(0) rotate(-6deg); }
  50% { transform: translateY(-3px) rotate(6deg); }
}

/* 下拉里的佩戴徽章条 */
.up-worn {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 9px;
  margin-bottom: 8px;
  font: inherit;
  text-align: left;
  color: var(--ink);
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: 10px;
  cursor: pointer;
  transition: transform 0.14s, box-shadow 0.14s;
}
.up-worn:hover { transform: translate(-1px, -2px); box-shadow: 3px 4px 0 var(--ink); }
.uw-medal {
  width: 26px;
  height: 26px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 14px;
  background: var(--worn-color, var(--yellow));
  border: 2px solid var(--ink);
  border-radius: 50%;
}
.uw-copy { display: flex; flex-direction: column; gap: 1px; line-height: 1.25; }
.uw-copy small { font-size: 9px; font-weight: 900; color: var(--text-3); }
.uw-copy strong { font-size: 11px; }
.uw-arrow { margin-left: auto; font-size: 11px; font-weight: 900; color: var(--text-3); }

/* 游戏币余额小药丸 */
.coin-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 10px 5px 6px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  background: linear-gradient(120deg, #fff5d4, #ffe3b3);
  border: 2px solid var(--ink);
  border-radius: var(--r-pill);
  box-shadow: 2px 2px 0 var(--ink), inset 0 2px 0 rgba(255, 255, 255, 0.85);
  cursor: pointer;
  white-space: nowrap;
}
.coin-chip strong { animation: chip-pop 0.36s cubic-bezier(0.2, 1.6, 0.4, 1); }
@keyframes chip-pop {
  from { opacity: 0.35; transform: translateY(-3px) scale(1.2); }
  to { opacity: 1; transform: none; }
}
.coin-chip:hover {
  background: var(--yellow);
  transform: translateY(-2px);
  box-shadow: 2px 4px 0 var(--ink);
}

/* 消息入口：与游戏币胶囊、搜索框、头像统一圆润描边风格 */
.msg-wrap { position: relative; }
.msg-chip {
  position: relative;
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  padding: 0;
  font-size: 17px;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-pill);
  box-shadow: 3px 3px 0 var(--ink), inset 0 2px 0 rgba(255, 255, 255, 0.9);
  cursor: pointer;
  transition: transform var(--t-fast) var(--ease-pop), background var(--t-fast), box-shadow var(--t-fast);
}
.msg-chip:hover { background: var(--blue-soft); transform: translateY(-3px); box-shadow: 3px 6px 0 var(--ink); }
.msg-chip.open { background: var(--yellow); }
.msg-dot {
  position: absolute;
  top: -3px;
  right: -2px;
  width: 9px;
  height: 9px;
  background: var(--danger);
  border: 1.5px solid var(--ink);
  border-radius: 50%;
}
.msg-panel {
  position: absolute;
  right: 0;
  top: calc(100% + 12px);
  z-index: 42;
  width: 232px;
  padding: 11px;
  background: var(--paper);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-3);
  animation: pop-down 0.18s ease both;
}
.mp-head {
  margin: 0 0 8px;
  padding: 0 3px 8px;
  font-size: 12px;
  font-weight: 900;
  border-bottom: 1.5px dashed rgba(43, 43, 43, 0.22);
}
.mp-empty {
  margin: 8px 3px 11px;
  font-size: 11px;
  font-weight: 700;
  line-height: 1.6;
  color: var(--text-3);
}
.mp-link {
  width: 100%;
  padding: 7px 0;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
  cursor: pointer;
  transition: background var(--t-fast), transform var(--t-fast), box-shadow var(--t-fast);
}
.mp-link:hover { background: #fff0a8; transform: translateY(-2px); box-shadow: 2px 4px 0 var(--ink); }
.mp-link:active { transform: translate(2px, 2px); box-shadow: none; }

/* 头像下拉 */
.avatar-wrap { position: relative; }
.user-panel {
  position: absolute;
  right: 0;
  top: calc(100% + 12px);
  z-index: 43;
  width: 236px;
  padding: 10px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-3);
  animation: pop-down 0.18s ease both;
}
.up-head {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 4px 6px 10px;
}
.up-avatar {
  width: 38px;
  height: 38px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 19px;
  background: var(--mint);
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: 2px 2px 0 var(--ink);
}
.up-identity { min-width: 0; }
.up-identity strong { display: block; font-size: 13px; }
.up-identity small { display: block; font-size: 10px; font-weight: 700; color: var(--text-3); }
.up-wallet {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 7px 9px;
  margin-bottom: 8px;
  font-size: 10px;
  font-weight: 900;
  color: var(--text-2);
  background: #fff3c9;
  border: 2px solid var(--ink);
  border-radius: 10px;
}
.up-wallet strong { font-size: 13px; color: var(--ink); }
.up-earn {
  margin-left: auto;
  padding: 3px 8px;
  font: inherit;
  font-size: 10px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 8px;
  cursor: pointer;
}
.up-earn:hover { background: #ffe27a; }
.up-item {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 9px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  text-align: left;
  background: transparent;
  border: 2px solid transparent;
  border-radius: 10px;
  cursor: pointer;
}
.up-item:hover { background: #fff2c9; border-color: var(--ink); }
.up-item.danger { color: #a63a2b; }
.up-item.danger:hover { background: #ffe3e3; }
.up-num {
  margin-left: auto;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  display: grid;
  place-items: center;
  font-size: 10px;
  background: var(--mint);
  border: 1.5px solid var(--ink);
  border-radius: 7px;
}
.up-line {
  display: block;
  height: 2px;
  margin: 6px 4px;
  background: repeating-linear-gradient(90deg, #ded0bb 0 5px, transparent 5px 10px);
}

.logout-btn {
  padding: 8px 13px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #ffc9cf;
  border: var(--line);
  border-radius: var(--r-pill);
  box-shadow: 3px 3px 0 var(--ink), inset 0 2px 0 rgba(255, 255, 255, 0.75);
  cursor: pointer;
  transition: transform var(--t-fast) var(--ease-pop), box-shadow var(--t-fast), background var(--t-fast);
}
.logout-btn:hover { transform: translateY(-3px); box-shadow: 3px 6px 0 var(--ink); }

/* 「更多」折叠入口：仅在次要菜单收起时出现 */
.more-wrap { position: relative; flex: 0 0 auto; display: none; }

.main-more {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 7px 11px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  white-space: nowrap;
}
.main-more:hover { background: #fff6d8; transform: translateY(-3px); box-shadow: 3px 6px 0 var(--ink); }
.main-more.active {
  background: var(--yellow-deep);
  box-shadow: 3px 5px 0 var(--ink), inset 0 0 0 1.5px rgba(43, 43, 43, 0.16);
  transform: translateY(-2px);
}
.caret { display: inline-block; transition: transform 0.18s ease; }
.caret.open { transform: rotate(180deg); }

.more-panel {
  position: absolute;
  right: 0;
  top: calc(100% + 12px);
  z-index: 41;
  width: 208px;
  padding: 8px;
  display: grid;
  gap: 4px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-3);
  animation: pop-down 0.18s ease both;
}
.more-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  text-align: left;
  background: transparent;
  border: 2px solid transparent;
  border-radius: var(--r-sm);
  cursor: pointer;
  transition: background 0.15s ease, border-color 0.15s ease;
}
.more-item:hover { background: #fff2c9; border-color: var(--ink); }
.more-item.active { background: var(--yellow); border-color: var(--ink); }

/* 搜索联想下拉 */
.search-wrap { position: relative; }
.search-pop {
  position: absolute;
  right: 0;
  top: calc(100% + 10px);
  z-index: 41;
  width: 296px;
  padding: 8px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-3);
  animation: pop-down 0.18s ease both;
}
@keyframes pop-down {
  from { opacity: 0; transform: translateY(-6px) scale(0.98); }
  to { opacity: 1; transform: none; }
}
.sp-title {
  margin: 2px 6px 6px;
  font-size: 10px;
  font-weight: 900;
  letter-spacing: 0.5px;
  color: var(--text-3);
}
.sp-item {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 6px 8px;
  font: inherit;
  color: var(--ink);
  text-align: left;
  background: transparent;
  border: 2px solid transparent;
  border-radius: var(--r-sm);
  cursor: pointer;
  transition: background 0.15s ease, border-color 0.15s ease;
}
.sp-item:hover { background: #fff2c9; border-color: var(--ink); }
.sp-item img {
  width: 32px;
  height: 32px;
  object-fit: contain;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.12);
  border-radius: 8px;
  padding: 1px;
}
.sp-copy { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
.sp-copy strong { font-size: 12px; }
.sp-copy small { font-size: 10px; font-weight: 700; color: var(--text-2); }
.sp-go { font-size: 12px; font-weight: 900; color: var(--text-3); }
.sp-empty {
  margin: 6px 8px 8px;
  font-size: 11px;
  font-weight: 800;
  text-align: center;
  color: var(--text-3);
}
.sp-all {
  width: 100%;
  margin-top: 4px;
  padding: 7px 0;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
  cursor: pointer;
}
.sp-all:hover { background: #ffe27a; }
.sp-copy :deep(.kw) {
  padding: 0 2px;
  background: var(--yellow);
  border-radius: 4px;
  color: var(--ink);
  box-shadow: 0 1px 0 rgba(43, 43, 43, 0.2);
}

/* 次要菜单统一收进「更多」：菜单项较多，常驻展开会在宽屏下被挤压截断 */
.more-wrap { display: block; }
.main-menu li.sec { display: none; }

@media (max-width: 1240px) {
  .main-menu-item { padding: 7px 9px; font-size: 11.5px; }
  .main-search input { width: 78px; }
  .logout-btn { padding: 7px 10px; font-size: 11px; }
}

@media (max-width: 1100px) {
  .main-nav-inner { flex-wrap: wrap; gap: 10px; padding: 10px 14px; }
  .menu-wrap { order: 3; width: 100%; flex-basis: 100%; }
  .main-user { margin-left: auto; }
  .admin-entry { padding: 6px 9px; font-size: 11px; }
  .msg-chip { width: 34px; height: 34px; font-size: 15px; }
  .main-search input { width: 70px; }
  .more-panel { right: auto; left: 0; }
  .user-panel { right: -6px; }
}

@media (max-width: 620px) {
  .main-logo-text { font-size: 16px; }
  .main-logo-badge { width: 34px; height: 34px; font-size: 18px; }
  .logout-btn { display: none; }
  .coin-chip { padding: 5px 8px 5px 5px; font-size: 12px; }
  .search-pop { right: auto; left: 0; width: 236px; }
  .user-panel { right: -10px; }
}
</style>
