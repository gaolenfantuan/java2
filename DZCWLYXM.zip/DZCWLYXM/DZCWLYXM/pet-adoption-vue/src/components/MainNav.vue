<script setup>
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { store } from '../store'

const router = useRouter()
const route = useRoute()

// 搜索框与首页筛选通过全局 store 联动（全局导航常驻，不依赖父组件传值）
function onSearchInput(event) {
  store.searchQuery = event.target.value
  // 在其它页面输入搜索时，自动回到首页查看筛选结果
  if (route.path !== '/' && store.searchQuery.trim()) {
    router.push('/')
  }
}

// 主导航菜单：图标全部使用 emoji，不引入图标库
const menuItems = [
  { icon: '🏠', label: '首页', path: '/' },
  { icon: '🐾', label: '领养专区', path: '/adopt' },
  { icon: '💕', label: '我的毛孩子', path: '/my-pets' },
  { icon: '🚑', label: '流浪救助', path: '/rescue' },
  { icon: '📚', label: '宠物百科', path: '/wiki' },
  { icon: '📖', label: '领养故事', path: '/stories' },
  { icon: '✍️', label: '送养投稿', path: '/submit' },
  { icon: '🤝', label: '志愿者合作', path: '/volunteer' },
  { icon: '❓', label: '常见问题', path: '/faq' },
  { icon: '💗', label: '关于我们', path: '/about' }
]

// 所有菜单均已接入真实路由，点击直接跳转
function goMenu(item) {
  if (route.path !== item.path) router.push(item.path)
}

function isActive(item) {
  if (item.path === '/') return route.path === '/'
  if (item.path === '/adopt') return route.path === '/adopt' || route.path.startsWith('/pet')
  if (item.path === '/my-pets') return route.path === '/my-pets'
  return route.path === item.path
}

const activeLabel = computed(() => {
  const found = menuItems.find(isActive)
  return found ? found.label : ''
})

// 用户昵称：优先读取本地缓存，未登录时给默认可爱昵称
const nickname = ref('')
function loadNickname() {
  try {
    nickname.value = localStorage.getItem('petNickname') || '小可爱'
  } catch {
    nickname.value = '小可爱'
  }
}
loadNickname()

function goHome() {
  if (route.path !== '/') router.push('/')
}
function goMyPets() {
  router.push('/my-pets')
}
function logout() {
  localStorage.removeItem('petToken')
  router.push('/login')
}
</script>

<template>
  <nav class="main-nav" aria-label="主导航">
    <div class="main-nav-inner">
      <!-- 唯一一组 Logo：站名倾斜，与爪印图标搭配 -->
      <button type="button" class="main-logo" @click="goHome">
        <span class="main-logo-badge" aria-hidden="true">🐾</span>
        <span class="main-logo-text">毛茸茸领养站</span>
      </button>

      <!-- 中间主菜单 -->
      <ul class="main-menu">
        <li v-for="item in menuItems" :key="item.label">
          <button
            type="button"
            class="main-menu-item"
            :class="{ active: isActive(item) }"
            :title="activeLabel === item.label ? '当前页面' : ''"
            @click="goMenu(item)"
          >
            <span class="main-menu-icon" aria-hidden="true">{{ item.icon }}</span>
            <span class="main-menu-label">{{ item.label }}</span>
          </button>
        </li>
      </ul>

      <!-- 右侧：搜索框 + 用户头像 + 退出登录（已移除「我的宠物」按钮） -->
      <div class="main-user">
        <label class="main-search">
          <span class="main-search-icon" aria-hidden="true">🔍</span>
          <input
            :value="store.searchQuery"
            type="search"
            placeholder="搜名字 / 品种..."
            aria-label="搜索宠物"
            @input="onSearchInput"
          >
        </label>
        <button type="button" class="main-avatar" title="查看我的徽章" @click="goMyPets">
          <span aria-hidden="true">🐱</span>
          <span v-if="store.unlockedBadgeCount" class="avatar-badge-count">{{ store.unlockedBadgeCount }}</span>
        </button>
        <button type="button" class="logout-btn" @click="logout">🚪 退出登录</button>
      </div>
    </div>
  </nav>
</template>

<style scoped>
/* 完整通栏：通顶白底 + 柔和底部投影。
   移除中间黑色分隔横线（原 border-bottom），sticky 吸顶占据文档流，
   不遮挡下方内容、不影响滚动；主体内容自然位于其下。 */
.main-nav {
  position: sticky;
  top: 0;
  z-index: 20;
  background: #fffdf6;
  box-shadow: 0 5px 0 rgba(43, 43, 43, 0.08);
}

.main-nav-inner {
  max-width: 1440px;
  margin: 0 auto;
  padding: 10px 22px;
  display: flex;
  align-items: center;
  gap: 18px;
}

/* 左侧 Logo（唯一一组）+ 倾斜站名 */
.main-logo {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 4px 8px;
  font: inherit;
  font-size: 19px;
  font-weight: 900;
  color: var(--ink);
  background: transparent;
  border: none;
  cursor: pointer;
  white-space: nowrap;
}
.main-logo-badge {
  width: 40px;
  height: 40px;
  display: grid;
  place-items: center;
  background: var(--pink);
  border: var(--line);
  border-radius: 13px;
  font-size: 22px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-6deg);
  transition: transform 0.15s;
}
.main-logo:hover .main-logo-badge { transform: rotate(0deg) scale(1.06); }
.main-logo-text {
  display: inline-block;
  font-style: italic;
  transform: skewX(-7deg);
  letter-spacing: 0.5px;
}

/* 中间菜单：宽屏全显示，窄屏横向滚动，高度保持稳定 */
.main-menu {
  flex: 1 1 auto;
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 7px;
  margin: 0;
  padding: 2px 0;
  list-style: none;
  overflow-x: auto;
  scrollbar-width: none;
}
.main-menu::-webkit-scrollbar { display: none; }
.main-menu li { flex: 0 0 auto; }

.main-menu-item {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 7px 11px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  white-space: nowrap;
  transition: transform 0.16s cubic-bezier(0.2, 1.4, 0.4, 1), box-shadow 0.16s, background 0.16s;
}
.main-menu-item:hover {
  transform: translateY(-3px);
  box-shadow: 3px 6px 0 var(--ink);
  background: #fff6d8;
}
.main-menu-item:active {
  transform: translateY(0);
  box-shadow: 1px 2px 0 var(--ink);
}
/* 当前页面高亮填充 */
.main-menu-item.active {
  background: var(--yellow);
  box-shadow: 3px 5px 0 var(--ink);
}
.main-menu-icon { font-size: 14px; line-height: 1; }

/* 右侧操作区：搜索框 + 头像 + 退出登录 */
.main-user {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 10px;
}
.main-search {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 9px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 3px 3px 0 var(--ink);
}
.main-search-icon { font-size: 12px; }
.main-search input {
  width: 90px;
  padding: 2px 0;
  font: inherit;
  font-size: 11px;
  font-weight: 700;
  color: var(--ink);
  background: transparent;
  border: none;
  outline: none;
}
.main-search input::placeholder { color: #a99074; }

.main-avatar {
  position: relative;
  width: 40px;
  height: 40px;
  display: grid;
  place-items: center;
  padding: 0;
  border-radius: 50%;
  background: var(--mint);
  border: var(--line);
  box-shadow: 3px 3px 0 var(--ink);
  font-size: 22px;
  cursor: pointer;
  transition: transform 0.15s;
}
.main-avatar:hover { transform: translateY(-3px); }
.avatar-badge-count {
  position: absolute;
  right: -6px;
  top: -6px;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  display: grid;
  place-items: center;
  font-size: 10px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 999px;
}

.logout-btn {
  padding: 8px 13px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #ffc9cf;
  border: var(--line);
  border-radius: 12px;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: transform 0.15s;
}
.logout-btn:hover { transform: translateY(-3px); box-shadow: 3px 6px 0 var(--ink); }

@media (max-width: 1100px) {
  .main-nav-inner { flex-wrap: wrap; gap: 10px; padding: 10px 14px; }
  .main-menu { order: 3; width: 100%; flex-basis: 100%; }
  .main-user { margin-left: auto; }
  .main-search input { width: 70px; }
}
</style>
