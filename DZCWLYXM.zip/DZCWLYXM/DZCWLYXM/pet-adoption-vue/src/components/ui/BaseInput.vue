<script setup>
// 全站统一输入框：内置标签、前置图标、密码可见切换、错误态与抖动
import { computed, ref, useId } from 'vue'

defineOptions({ inheritAttrs: false })

const props = defineProps({
  modelValue: { type: [String, Number], default: '' },
  label: { type: String, default: '' },
  type: { type: String, default: 'text' },
  placeholder: { type: String, default: '' },
  icon: { type: String, default: '' },
  // 错误文案：有值即进入错误态
  error: { type: String, default: '' },
  hint: { type: String, default: '' },
  id: { type: String, default: '' },
  autocomplete: { type: String, default: 'off' },
  maxlength: { type: [String, Number], default: undefined },
  inputmode: { type: String, default: undefined },
  disabled: { type: Boolean, default: false },
  clearable: { type: Boolean, default: false },
  // 是否播放抖动（父级在提交失败时置为 true）
  shake: { type: Boolean, default: false }
})

const emit = defineEmits(['update:modelValue', 'focus', 'blur', 'enter', 'clear'])

const uid = useId()
const inputId = computed(() => props.id || `ui-input-${uid}`)
const revealed = ref(false)
const isPassword = computed(() => props.type === 'password')
const realType = computed(() => (isPassword.value && revealed.value ? 'text' : props.type))
const hasValue = computed(() => String(props.modelValue ?? '').length > 0)

const fieldClass = computed(() => ({
  'ui-field': true,
  'ui-field--icon': !!props.icon,
  'is-error': !!props.error,
  'ui-shake': props.shake
}))

function onInput(e) {
  emit('update:modelValue', e.target.value)
}

function clear() {
  emit('update:modelValue', '')
  emit('clear')
}
</script>

<template>
  <div :class="fieldClass">
    <div v-if="label || hint" class="ui-field__head">
      <label v-if="label" class="ui-field__label" :for="inputId">{{ label }}</label>
      <span v-if="hint" class="ui-field__hint">{{ hint }}</span>
    </div>

    <div class="ui-field__box">
      <span v-if="icon" class="ui-field__icon" aria-hidden="true">{{ icon }}</span>

      <input
        :id="inputId"
        v-bind="$attrs"
        class="ui-input"
        :type="realType"
        :value="modelValue"
        :placeholder="placeholder"
        :autocomplete="autocomplete"
        :maxlength="maxlength"
        :inputmode="inputmode"
        :disabled="disabled"
        :aria-invalid="error ? 'true' : 'false'"
        @input="onInput"
        @focus="$emit('focus', $event)"
        @blur="$emit('blur', $event)"
        @keyup.enter="$emit('enter', $event)"
      >

      <!-- 清除 -->
      <button
        v-if="clearable && hasValue && !disabled"
        type="button"
        class="ui-field__action"
        aria-label="清空"
        @click="clear"
      >✕</button>

      <!-- 密码可见切换 -->
      <button
        v-else-if="isPassword"
        type="button"
        class="ui-field__action"
        :aria-label="revealed ? '隐藏密码' : '显示密码'"
        @click="revealed = !revealed"
      >{{ revealed ? '🙈' : '👁️' }}</button>
    </div>

    <p v-if="error" class="ui-field__err" role="alert">⚠ {{ error }}</p>
  </div>
</template>
