<script setup>
// 全站统一卡片：2px 描边 + 16px 圆角 + 硬阴影，可选 hover 上浮
import { computed } from 'vue'

const props = defineProps({
  hoverable: { type: Boolean, default: false },
  flat: { type: Boolean, default: false },
  // 透传额外的内边距，例如 "14px" / "18px 20px"
  padding: { type: String, default: '' }
})

const style = computed(() => (props.padding ? { padding: props.padding } : null))
const classes = computed(() => ({
  'ui-card': true,
  'ui-card--hover': props.hoverable,
  'ui-card--flat': props.flat
}))
</script>

<template>
  <div :class="classes" :style="style">
    <header v-if="$slots.head || $slots.title" class="ui-card__head">
      <div>
        <h3 v-if="$slots.title" class="ui-card__title"><slot name="title" /></h3>
        <p v-if="$slots.sub" class="ui-card__sub"><slot name="sub" /></p>
        <slot name="head" />
      </div>
      <slot name="extra" />
    </header>
    <slot />
  </div>
</template>
