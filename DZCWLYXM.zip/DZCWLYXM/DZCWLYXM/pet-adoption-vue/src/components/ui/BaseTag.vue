<script setup>
// 全站统一标签 / 角标
import { computed } from 'vue'

const props = defineProps({
  // yellow | mint | pink | blue | orange | ghost | ink
  tone: { type: String, default: 'yellow' },
  size: { type: String, default: 'md' },
  dot: { type: Boolean, default: false }
})

const classes = computed(() => [
  'ui-tag',
  props.tone !== 'yellow' ? `ui-tag--${props.tone}` : '',
  props.size === 'sm' ? 'ui-tag--sm' : ''
])
</script>

<template>
  <span :class="classes">
    <i v-if="dot" class="ui-tag__dot" aria-hidden="true"></i>
    <slot />
  </span>
</template>
