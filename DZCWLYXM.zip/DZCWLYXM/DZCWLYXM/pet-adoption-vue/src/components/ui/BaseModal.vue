<script setup>
// 全站统一弹窗：遮罩 + 居中卡片 + 标题区 / 内容区 / 操作区
import { computed, onBeforeUnmount, watch } from 'vue'

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  title: { type: String, default: '' },
  subtitle: { type: String, default: '' },
  icon: { type: String, default: '' },
  width: { type: Number, default: 480 },
  closable: { type: Boolean, default: true },
  maskClosable: { type: Boolean, default: true },
  // 点击遮罩 / 关闭按钮时是否由父级自己处理
  lockScroll: { type: Boolean, default: true }
})

const emit = defineEmits(['update:modelValue', 'close'])

const modalStyle = computed(() => ({ '--ui-modal-w': `${props.width}px` }))

function close() {
  emit('update:modelValue', false)
  emit('close')
}

function onMaskClick(e) {
  if (props.maskClosable && e.target === e.currentTarget) close()
}

// Esc 关闭
function onKeydown(e) {
  if (e.key === 'Escape' && props.modelValue && props.closable) close()
}

watch(
  () => props.modelValue,
  open => {
    if (!props.lockScroll) return
    document.body.style.overflow = open ? 'hidden' : ''
  },
  { immediate: true }
)

window.addEventListener('keydown', onKeydown)
onBeforeUnmount(() => {
  window.removeEventListener('keydown', onKeydown)
  if (props.lockScroll) document.body.style.overflow = ''
})
</script>

<template>
  <Teleport to="body">
    <Transition name="ui">
      <div v-if="modelValue" class="ui-mask" role="dialog" aria-modal="true" @click="onMaskClick">
        <div class="ui-modal" :style="modalStyle">
          <button
            v-if="closable"
            type="button"
            class="ui-modal__close"
            aria-label="关闭"
            @click="close"
          >✕</button>

          <header v-if="title || $slots.head" class="ui-modal__head">
            <span v-if="icon" class="ui-modal__icon" aria-hidden="true">{{ icon }}</span>
            <div>
              <h2 v-if="title" class="ui-modal__title">{{ title }}</h2>
              <p v-if="subtitle" class="ui-modal__sub">{{ subtitle }}</p>
              <slot name="head" />
            </div>
          </header>

          <div class="ui-modal__body">
            <slot />
          </div>

          <footer v-if="$slots.footer" class="ui-modal__foot">
            <slot name="footer" />
          </footer>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>
