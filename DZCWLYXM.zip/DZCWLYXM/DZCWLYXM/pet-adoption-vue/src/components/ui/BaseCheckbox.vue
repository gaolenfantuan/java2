<script setup>
// 全站统一复选框：自绘方框 + 选中弹跳勾
const props = defineProps({
  modelValue: { type: Boolean, default: false },
  label: { type: String, default: '' },
  disabled: { type: Boolean, default: false },
  error: { type: Boolean, default: false }
})

const emit = defineEmits(['update:modelValue', 'change'])

function onChange(e) {
  emit('update:modelValue', e.target.checked)
  emit('change', e.target.checked)
}
</script>

<template>
  <label class="ui-check" :class="{ 'is-error': error, 'is-disabled': disabled }">
    <input
      type="checkbox"
      :checked="modelValue"
      :disabled="disabled"
      @change="onChange"
    >
    <span class="ui-check__box" aria-hidden="true"></span>
    <span><slot>{{ label }}</slot></span>
  </label>
</template>
