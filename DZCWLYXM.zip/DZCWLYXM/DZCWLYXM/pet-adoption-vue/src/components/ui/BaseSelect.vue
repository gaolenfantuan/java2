<script setup>
// 全站统一下拉选择：自定义面板，和按钮/输入框同一套描边与弹性动效
import { computed, onBeforeUnmount, onMounted, ref, useId } from 'vue'

const props = defineProps({
  modelValue: { type: [String, Number], default: '' },
  // 支持 ['全部', '猫咪'] 或 [{ label, value }]
  options: { type: Array, default: () => [] },
  placeholder: { type: String, default: '请选择' },
  label: { type: String, default: '' },
  disabled: { type: Boolean, default: false }
})

const emit = defineEmits(['update:modelValue', 'change'])

const uid = useId()
const root = ref(null)
const open = ref(false)

const normalized = computed(() =>
  props.options.map(o => (typeof o === 'object' && o !== null ? o : { label: String(o), value: o }))
)

const current = computed(() => {
  const hit = normalized.value.find(o => String(o.value) === String(props.modelValue))
  return hit || null
})

function toggle() {
  if (props.disabled) return
  open.value = !open.value
}

function pick(opt) {
  emit('update:modelValue', opt.value)
  emit('change', opt.value)
  open.value = false
}

function onDocClick(e) {
  if (root.value && !root.value.contains(e.target)) open.value = false
}

onMounted(() => document.addEventListener('click', onDocClick))
onBeforeUnmount(() => document.removeEventListener('click', onDocClick))
</script>

<template>
  <div class="ui-field">
    <label v-if="label" class="ui-field__label" :for="`ui-select-${uid}`">{{ label }}</label>

    <div ref="root" class="ui-select">
      <button
        :id="`ui-select-${uid}`"
        type="button"
        class="ui-select__trigger"
        :class="{ 'is-open': open }"
        :disabled="disabled"
        aria-haspopup="listbox"
        :aria-expanded="open ? 'true' : 'false'"
        @click="toggle"
      >
        <span class="ui-select__value" :class="{ 'is-placeholder': !current }">
          {{ current ? current.label : placeholder }}
        </span>
        <span class="ui-select__caret" aria-hidden="true">▼</span>
      </button>

      <div v-if="open" class="ui-select__panel" role="listbox">
        <button
          v-for="opt in normalized"
          :key="String(opt.value)"
          type="button"
          class="ui-select__opt"
          :class="{ 'is-active': String(opt.value) === String(modelValue) }"
          role="option"
          :aria-selected="String(opt.value) === String(modelValue)"
          @click="pick(opt)"
        >
          <span>{{ opt.label }}</span>
          <span v-if="String(opt.value) === String(modelValue)" class="ui-select__opt-check">✓</span>
        </button>
      </div>
    </div>
  </div>
</template>
