<script setup>
// 全站统一按钮：统一描边 / 圆角 / 硬阴影 / hover 上浮 / 按下缩微
import { computed } from 'vue'

const props = defineProps({
  // yellow | mint | pink | blue | ghost | danger | ink
  variant: { type: String, default: 'yellow' },
  // sm | md | lg
  size: { type: String, default: 'md' },
  block: { type: Boolean, default: false },
  loading: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
  type: { type: String, default: 'button' }
})

defineEmits(['click'])

const classes = computed(() => [
  'ui-btn',
  props.variant !== 'yellow' ? `ui-btn--${props.variant}` : '',
  props.size !== 'md' ? `ui-btn--${props.size}` : '',
  {
    'ui-btn--block': props.block,
    'is-loading': props.loading,
    'is-disabled': props.disabled
  }
])
</script>

<template>
  <button
    :type="type"
    :class="classes"
    :disabled="disabled || loading"
    :aria-busy="loading ? 'true' : 'false'"
    @click="$emit('click', $event)"
  >
    <span v-if="loading" class="ui-spinner" aria-hidden="true"></span>
    <slot />
  </button>
</template>
