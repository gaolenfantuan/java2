<script setup>
// 全站统一空状态：复用 CuteEmpty 插画，外框与按钮交给调用方
import CuteEmpty from '../CuteEmpty.vue'

defineProps({
  title: { type: String, default: '这里暂时空空的' },
  desc: { type: String, default: '换个条件看看，缘分也许就在下一页 🐾' },
  // empty | search | error
  variant: { type: String, default: 'empty' },
  compact: { type: Boolean, default: false },
  // 是否额外包一层卡片外框
  bordered: { type: Boolean, default: false }
})
</script>

<template>
  <div class="ui-empty" :class="{ 'is-bare': !bordered }">
    <CuteEmpty :title="title" :desc="desc" :variant="variant" :compact="compact">
      <slot />
    </CuteEmpty>
  </div>
</template>
