<script setup>
// 全站统一进度条：条纹填充 + 数值标签，颜色可切
import { computed } from 'vue'

const props = defineProps({
  value: { type: Number, default: 0 },
  max: { type: Number, default: 100 },
  // yellow | mint | pink | blue | orange
  tone: { type: String, default: 'yellow' },
  // sm | md | lg
  size: { type: String, default: 'md' },
  label: { type: String, default: '' },
  showValue: { type: Boolean, default: false },
  suffix: { type: String, default: '%' }
})

const percent = computed(() => {
  if (!Number.isFinite(props.value) || !Number.isFinite(props.max) || props.max <= 0) return 0
  return Math.min(100, Math.max(0, Math.round((props.value / props.max) * 100)))
})

const classes = computed(() => [
  'ui-progress',
  props.tone !== 'yellow' ? `ui-progress--${props.tone}` : '',
  props.size !== 'md' ? `ui-progress--${props.size}` : ''
])
</script>

<template>
  <div :class="classes">
    <div v-if="label || showValue" class="ui-progress__meta">
      <span>{{ label }}</span>
      <strong v-if="showValue">{{ percent }}{{ suffix }}</strong>
    </div>
    <div
      class="ui-progress__track"
      role="progressbar"
      :aria-valuenow="percent"
      aria-valuemin="0"
      aria-valuemax="100"
      :aria-label="label || '进度'"
    >
      <div class="ui-progress__fill" :style="{ width: percent + '%' }"></div>
    </div>
  </div>
</template>
