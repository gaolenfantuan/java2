<script setup>
// 全站统一提示条：错误 / 警告 / 信息 / 成功，同一套描边与动效
import { computed } from 'vue'

const props = defineProps({
  // error | warn | info | success
  type: { type: String, default: 'error' },
  icon: { type: String, default: '' }
})

const iconText = computed(() => {
  if (props.icon) return props.icon
  return { error: '⚠', warn: '💡', info: 'ℹ', success: '✅' }[props.type] || '💡'
})

const classes = computed(() => [
  'ui-alert',
  props.type !== 'success' ? `ui-alert--${props.type}` : ''
])
</script>

<template>
  <div :class="classes" role="alert">
    <span class="ui-alert__icon" aria-hidden="true">{{ iconText }}</span>
    <div><slot /></div>
  </div>
</template>
