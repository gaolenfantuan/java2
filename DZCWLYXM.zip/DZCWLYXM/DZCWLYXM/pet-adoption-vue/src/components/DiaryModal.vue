<script setup>
import { computed, ref } from 'vue'
import { store, addDiary, removeDiary } from '../store'
import CuteEmpty from './CuteEmpty.vue'

const props = defineProps({
  // 可选的毛孩子列表（默认展示已领养的，为空则用全部）
  petOptions: { type: Array, default: () => [] },
  preselect: { type: Number, default: 0 }
})

const emit = defineEmits(['close', 'changed'])

const moods = ['🥰', '😸', '🤗', '😴', '🎾', '🍚']
const mood = ref('🥰')
const petId = ref(Number(props.preselect) || 0)
const text = ref('')
const error = ref('')

const entries = computed(() => store.diary)

function submit() {
  const body = text.value.trim()
  if (!body) {
    error.value = '写点什么再保存吧～'
    return
  }
  const pet = props.petOptions.find(p => p.id === Number(petId.value))
  const entry = addDiary({
    petId: pet ? pet.id : 0,
    petName: pet ? pet.name : '日常',
    text: body,
    mood: mood.value
  })
  if (entry) {
    text.value = ''
    error.value = ''
    emit('changed')
  }
}

function remove(id) {
  removeDiary(id)
  emit('changed')
}
</script>

<template>
  <div class="dm-mask" @click.self="emit('close')">
    <div class="dm-card">
      <button type="button" class="dm-close" aria-label="关闭" @click="emit('close')">✕</button>

      <header class="dm-head">
        <div>
          <h2>📔 成长日记</h2>
          <p>把和毛孩子的小事记下来，日子就有了味道。</p>
        </div>
        <span class="dm-count">{{ entries.length }} 篇</span>
      </header>

      <!-- 快速记录 -->
      <section class="dm-writer">
        <div class="dm-row">
          <div class="dm-moods" role="group" aria-label="选择心情">
            <button
              v-for="m in moods"
              :key="m"
              type="button"
              class="dm-mood"
              :class="{ on: mood === m }"
              @click="mood = m"
            >{{ m }}</button>
          </div>
          <select v-model.number="petId" class="dm-select" aria-label="选择毛孩子">
            <option :value="0">日常</option>
            <option v-for="pet in petOptions" :key="pet.id" :value="pet.id">{{ pet.name }}</option>
          </select>
        </div>
        <textarea
          v-model="text"
          class="dm-textarea"
          rows="3"
          maxlength="120"
          placeholder="今天它做了什么可爱的事？比如：第一次主动跳到我腿上睡着了…"
        ></textarea>
        <div class="dm-writer-foot">
          <span class="dm-counter" :class="{ warn: error }">{{ error || `${text.length} / 120` }}</span>
          <button type="button" class="mp-btn primary sm" @click="submit">✍️ 记下来</button>
        </div>
      </section>

      <!-- 时间轴 -->
      <section v-if="entries.length" class="dm-timeline">
        <article v-for="item in entries" :key="item.id" class="dm-item">
          <span class="dm-dot" aria-hidden="true">{{ item.mood }}</span>
          <div class="dm-item-body">
            <div class="dm-item-top">
              <strong>{{ item.petName || '日常' }}</strong>
              <span class="dm-time">{{ item.time }}</span>
              <button type="button" class="dm-del" title="删除这篇" @click="remove(item.id)">🗑</button>
            </div>
            <p>{{ item.text }}</p>
          </div>
        </article>
      </section>

      <CuteEmpty
        v-else
        compact
        title="还没有日记"
        desc="写下第一篇，记录和毛孩子的第一次心动～"
      />
    </div>
  </div>
</template>

<style scoped>
.dm-mask {
  position: fixed;
  inset: 0;
  z-index: 76;
  display: grid;
  place-items: center;
  padding: 22px;
  background: rgba(43, 43, 43, 0.46);
  animation: dm-fade 0.22s ease both;
}
@keyframes dm-fade { from { opacity: 0; } to { opacity: 1; } }

.dm-card {
  position: relative;
  width: min(560px, 100%);
  max-height: 88vh;
  overflow-y: auto;
  padding: 26px 24px 24px;
  background: #fffdf6;
  border: var(--line);
  border-radius: 20px;
  box-shadow: 10px 12px 0 var(--ink);
  animation: dm-pop 0.32s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
@keyframes dm-pop {
  from { opacity: 0; transform: scale(0.9) translateY(16px); }
  to { opacity: 1; transform: none; }
}
.dm-close {
  position: absolute;
  right: 15px;
  top: 15px;
  width: 30px;
  height: 30px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #ffc9cf;
  border: 2px solid var(--ink);
  border-radius: 50%;
  cursor: pointer;
}
.dm-close:hover { background: #ffb3bb; }

.dm-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; margin-bottom: 16px; padding-right: 44px; }
.dm-head h2 { margin: 0 0 5px; font-size: 22px; }
.dm-head p { margin: 0; font-size: 12px; font-weight: 700; color: var(--text-2); }
.dm-count {
  flex: 0 0 auto;
  padding: 5px 10px;
  font-size: 11px;
  font-weight: 900;
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
}

.dm-writer {
  padding: 14px;
  background: #fff8e9;
  border: 2px dashed rgba(43, 43, 43, 0.32);
  border-radius: var(--r-lg);
}
.dm-row { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.dm-moods { display: flex; gap: 5px; }
.dm-mood {
  width: 30px;
  height: 30px;
  display: grid;
  place-items: center;
  font-size: 15px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.18);
  border-radius: 50%;
  cursor: pointer;
  transition: transform 0.15s, border-color 0.15s, background-color 0.15s;
}
.dm-mood:hover { transform: translateY(-2px); border-color: var(--ink); }
.dm-mood.on { background: var(--yellow); border-color: var(--ink); box-shadow: 2px 2px 0 var(--ink); }
.dm-select {
  margin-left: auto;
  padding: 6px 9px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 10px;
  cursor: pointer;
  outline: none;
}
.dm-textarea {
  width: 100%;
  padding: 10px 12px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 700;
  line-height: 1.7;
  color: var(--ink);
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  outline: none;
  resize: vertical;
}
.dm-textarea:focus { box-shadow: 3px 3px 0 var(--pink); }
.dm-textarea::placeholder { color: var(--text-3); font-weight: 700; }
.dm-writer-foot { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 9px; }
.dm-counter { font-size: 10.5px; font-weight: 900; color: var(--text-3); }
.dm-counter.warn { color: #d8385b; }

.dm-timeline {
  position: relative;
  display: grid;
  gap: 12px;
  margin-top: 18px;
  padding-left: 6px;
}
.dm-timeline::before {
  content: '';
  position: absolute;
  left: 21px;
  top: 10px;
  bottom: 10px;
  border-left: 2px dashed #e0cdb0;
}
.dm-item { position: relative; display: flex; gap: 12px; }
.dm-dot {
  position: relative;
  z-index: 1;
  flex: 0 0 auto;
  width: 30px;
  height: 30px;
  display: grid;
  place-items: center;
  font-size: 14px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 50%;
}
.dm-item-body {
  flex: 1;
  min-width: 0;
  padding: 10px 13px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.16);
  border-radius: var(--r-sm);
  transition: border-color 0.15s, transform 0.15s;
}
.dm-item-body:hover { border-color: var(--ink); transform: translateY(-2px); }
.dm-item-top { display: flex; align-items: center; gap: 8px; }
.dm-item-top strong { font-size: 12.5px; }
.dm-time { font-size: 10px; font-weight: 700; color: var(--text-3); }
.dm-del {
  margin-left: auto;
  padding: 2px 5px;
  font-size: 10px;
  line-height: 1;
  color: var(--text-3);
  background: transparent;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  opacity: 0;
  transition: opacity 0.15s, background-color 0.15s;
}
.dm-item-body:hover .dm-del { opacity: 1; }
.dm-del:hover { background: #ffc9cf; }
.dm-item-body p { margin: 5px 0 0; font-size: 12px; font-weight: 700; line-height: 1.75; color: var(--text-2); word-break: break-word; }
</style>
