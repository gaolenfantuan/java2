<script setup>
/**
 * 毛孩子的家：已领养宠物的居家互动模块
 * - 左侧房间：3D 感宠物形象 + 点击抚摸 + 三条状态条
 * - 右侧：四个功能入口 + 背包补给（与积分商城 / 背包共用一份数据）
 * - 下方：成长时间线 + 四个快捷照料操作
 */
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import {
  store,
  bagTotalCount,
  itemCount,
  removeItem,
  petHomes,
  petHomeOf,
  decayPetHome,
  carePet,
  setPetOutfit,
  addPetPhoto,
  removePetPhoto
} from '../store'
import { shopItems, shopCategories } from '../data/shopItems'
import ItemArt from './ItemArt.vue'
import CuteEmpty from './CuteEmpty.vue'

const props = defineProps({
  // 我的领养里的卡片：[{ pet, stage, percent }]
  cards: { type: Array, default: () => [] }
})
const emit = defineEmits(['diary', 'toast'])

const router = useRouter()

/* ---------------- 基础状态 ---------------- */
const activeId = ref(0)
const bubble = ref('')
const particles = ref([])
const floats = ref([])
const petting = ref(false)
const cleaning = ref(false)
const picking = ref('')   // 正在挑选的道具分类：食物 / 玩具 / 药品
const panel = ref('')     // health / dress / album

let bubbleTimer = null
let floatSeed = 0
let lastPetAt = 0
const timers = []

const EMPTY_HOME = {
  hunger: 0, mood: 0, health: 0, outfit: '', photos: [], events: [], adoptedAt: 0, cares: 0
}

/* 疫苗计划：按领养日推算出三针，未到日期的显示「计划接种」 */
const VACCINES = [
  { id: 'vac-1', name: '核心疫苗 · 第一针', icon: '💉', day: 7 },
  { id: 'vac-2', name: '核心疫苗 · 第二针', icon: '💉', day: 21 },
  { id: 'vac-3', name: '狂犬疫苗', icon: '🛡️', day: 35 }
]

/* 抚摸时的对话 */
const MOOD_LINES = [
  '今天也是最幸福的一天！',
  '尾巴摇成螺旋桨啦～',
  '再摸一下嘛，就一下下',
  '你的手心暖暖的，好舒服',
  '我把这里当成自己的家咯'
]

/* 道具效果：与商城里的文案口径保持一致 */
const CATEGORY_PLAN = {
  食物: { hunger: 20, mood: 6, verb: '喂了', icon: '🍚', tone: 'yellow' },
  玩具: { mood: 14, health: 2, verb: '陪玩用了', icon: '🎾', tone: 'pink' },
  药品: { health: 18, mood: 2, verb: '给 TA 服用了', icon: '💊', tone: 'blue' },
  道具: { mood: 8, health: 4, verb: '用了', icon: '🧴', tone: 'mint' },
  装饰: { mood: 6, health: 0, verb: '戴上了', icon: '🎀', tone: 'pink' }
}

const PHOTO_NOTES = [
  '晒着太阳打呼噜',
  '今天也很可爱',
  '偷吃了半块小饼干',
  '窝在沙发上不肯起来',
  '在窗边看了很久的鸟'
]

/* ---------------- 数据 ---------------- */
// 出现在「我的领养」里，就说明已经接回家了，直接给 TA 开一间小屋
const openCards = computed(() => props.cards.filter(c => c.pet))
const activeCard = computed(() => openCards.value.find(c => c.pet.id === activeId.value) || openCards.value[0] || null)
const activePet = computed(() => (activeCard.value ? activeCard.value.pet : null))
const home = computed(() => (activePet.value ? petHomes[String(activePet.value.id)] || EMPTY_HOME : EMPTY_HOME))

// 首次渲染前补全状态；后面新领养的毛孩子也会自动建好房间
watch(
  () => props.cards.map(c => c.pet.id),
  ids => {
    ids.forEach(id => {
      petHomeOf(id)
      decayPetHome(id)
    })
  },
  { immediate: true }
)

// 切换 / 新增已领养的毛孩子时，自动定位到第一个可互动的
watch(openCards, list => {
  if (!list.length) return
  if (!list.some(c => c.pet.id === activeId.value)) activeId.value = list[0].pet.id
}, { immediate: true })

/* ---------------- 背包（与商城共用） ---------------- */
function ownedIn(category) {
  return store.backpack
    .map(it => {
      const meta = shopItems.find(s => s.id === it.id)
      return meta && meta.category === category ? { ...meta, count: it.count } : null
    })
    .filter(Boolean)
}

const pickedList = computed(() => (picking.value ? ownedIn(picking.value) : []))
const decorList = computed(() => ownedIn('装饰'))
const pickCategory = computed(() => shopCategories.find(c => c.key === picking.value) || { key: '', icon: '🎒' })
const quickItems = computed(() => {
  const list = []
  ;['食物', '玩具', '药品', '道具'].forEach(cat => {
    ownedIn(cat).forEach(it => list.push(it))
  })
  return list.sort((a, b) => b.count - a.count).slice(0, 4)
})
const bagTotal = computed(() => bagTotalCount())

/* ---------------- 状态条 ---------------- */
const statsList = computed(() => {
  const h = home.value
  return [
    {
      key: 'hunger', icon: '🍚', label: '饱腹值', value: h.hunger,
      tip: h.hunger < 40 ? '肚子在叫啦' : h.hunger > 80 ? '吃得饱饱' : '还算满足'
    },
    {
      key: 'mood', icon: '🎈', label: '心情值', value: h.mood,
      tip: h.mood < 40 ? '有点低落' : h.mood > 80 ? '开心到冒泡' : '心情不错'
    },
    {
      key: 'health', icon: '❤️', label: '健康值', value: h.health,
      tip: h.health < 40 ? '需要看医生' : h.health > 80 ? '身体倍儿棒' : '状态平稳'
    }
  ]
})

const moodText = computed(() => {
  const m = home.value.mood
  if (m >= 85) return '开心到冒泡'
  if (m >= 65) return '心情不错'
  if (m >= 40) return '有点想你了'
  return '需要抱抱'
})
const moodFace = computed(() => {
  const m = home.value.mood
  if (m >= 85) return '😸'
  if (m >= 65) return '😊'
  if (m >= 40) return '🥺'
  return '😔'
})

/* ---------------- 装扮 ---------------- */
const outfitItem = computed(() => (home.value.outfit ? shopItems.find(i => i.id === home.value.outfit) || null : null))
const outfitSlot = computed(() => (outfitItem.value && outfitItem.value.id === 'crown' ? 'head' : 'neck'))

/* ---------------- 健康 / 时间线 ---------------- */
function pad(n) {
  return String(n).padStart(2, '0')
}
function fullDate(ts) {
  const d = new Date(ts)
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}
function shortDate(ts) {
  const d = new Date(ts)
  return `${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}
function clockText(ts) {
  const d = new Date(ts)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  if (ts >= today.getTime()) return `今天 ${pad(d.getHours())}:${pad(d.getMinutes())}`
  if (ts >= today.getTime() - 86400000) return `昨天 ${pad(d.getHours())}:${pad(d.getMinutes())}`
  return shortDate(ts)
}
function parseStamp(str) {
  if (!str) return Date.now()
  const v = new Date(String(str).replace(/-/g, '/')).getTime()
  return Number.isFinite(v) ? v : Date.now()
}

const vaccineRecords = computed(() => {
  const base = Number(home.value.adoptedAt) || Date.now()
  return VACCINES.map(v => {
    const at = base + v.day * 86400000
    return { ...v, at, done: at <= Date.now(), dateText: fullDate(at) }
  })
})
const doneVaccines = computed(() => vaccineRecords.value.filter(v => v.done).length)
const recentEvents = computed(() => (home.value.events || []).slice(0, 5).map(e => ({ ...e, timeText: clockText(e.at) })))

const timelineNodes = computed(() => {
  const pet = activePet.value
  if (!pet) return []
  const h = home.value
  const base = Number(h.adoptedAt) || Date.now()
  const nodes = [{
    id: 'adopt', icon: '🏡', tone: 'mint', title: `接 ${pet.name} 回家`,
    note: '领养日 · 新的开始', at: base, short: shortDate(base)
  }]

  vaccineRecords.value.forEach(v => {
    nodes.push({
      id: v.id, icon: v.done ? '💉' : '🕒', tone: 'blue', title: v.name,
      note: v.done ? '已接种 · 抗体满满' : '计划接种',
      at: v.at, short: v.done ? shortDate(v.at) : `计划 ${shortDate(v.at)}`,
      pending: !v.done
    })
  })

  ;(h.events || []).forEach(e => {
    nodes.push({ id: e.id, icon: e.icon, tone: e.tone, title: e.title, note: e.note, at: e.at, short: clockText(e.at) })
  })

  store.diary.filter(d => Number(d.petId) === pet.id).forEach(d => {
    const at = parseStamp(d.time)
    nodes.push({ id: `diary-${d.id}`, icon: '📔', tone: 'pink', title: d.text, note: `${d.mood} 成长日记`, at, short: shortDate(at) })
  })

  nodes.sort((a, b) => a.at - b.at)
  const recent = nodes.slice(-4)
  if (!recent.some(n => n.id === 'adopt')) recent.unshift(nodes[0])
  return recent
})

/* ---------------- 成长日记 / 相册计数 ---------------- */
const diaryCount = computed(() => (activePet.value ? store.diary.filter(d => Number(d.petId) === activePet.value.id).length : 0))
const photos = computed(() => (home.value.photos || []).map(p => ({ ...p, timeText: clockText(p.at) })))

/* ---------------- 功能入口 ---------------- */
const entries = computed(() => ([
  {
    key: 'diary', icon: '📔', label: '成长日记', tone: 'pink',
    note: diaryCount.value ? `${diaryCount.value} 篇记录` : '写下第一段回忆',
    run: () => { if (activePet.value) emit('diary', activePet.value.id) }
  },
  {
    key: 'health', icon: '🩺', label: '健康记录', tone: 'mint',
    note: `疫苗 ${doneVaccines.value}/3 已完成`,
    run: () => { panel.value = 'health' }
  },
  {
    key: 'dress', icon: '🎀', label: '宠物装扮', tone: 'blue',
    note: outfitItem.value ? `佩戴中 · ${outfitItem.value.name}` : '还没有配饰',
    run: () => { panel.value = 'dress' }
  },
  {
    key: 'album', icon: '📷', label: '宠物相册', tone: 'yellow',
    note: photos.value.length ? `${photos.value.length} 张照片` : '还没有拍照',
    run: () => { panel.value = 'album' }
  }
]))

/* ---------------- 互动 ---------------- */
function say(text, ms = 2600) {
  bubble.value = text
  clearTimeout(bubbleTimer)
  bubbleTimer = setTimeout(() => { bubble.value = '' }, ms)
}

function pickLine() {
  const h = home.value
  if (h.hunger < 35) return '肚子咕咕叫…有罐头吗？'
  if (h.mood < 40) return '想和你多待一会儿，可以摸摸我吗？'
  if (h.health < 40) return '今天有点没力气，想靠着你睡一会儿'
  return MOOD_LINES[Math.floor(Math.random() * MOOD_LINES.length)]
}

const PARTICLE_EMOJI = ['💗', '✨', '🐾', '💛']

function spawnBurst() {
  const batch = []
  for (let i = 0; i < 4; i += 1) {
    batch.push({
      id: `${Date.now()}-${i}-${Math.random().toString(36).slice(2, 5)}`,
      emoji: PARTICLE_EMOJI[i % PARTICLE_EMOJI.length],
      x: 208 + Math.round(Math.random() * 118),
      y: 152 + Math.round(Math.random() * 38),
      dx: -38 + Math.round(Math.random() * 76),
      rot: -24 + Math.round(Math.random() * 48),
      delay: i * 60
    })
  }
  particles.value = [...particles.value, ...batch]
  const ids = batch.map(p => p.id)
  timers.push(setTimeout(() => {
    particles.value = particles.value.filter(p => !ids.includes(p.id))
  }, 1400))
}

function particleStyle(p) {
  return {
    left: `${p.x}px`,
    top: `${p.y}px`,
    '--dx': `${p.dx}px`,
    '--rot': `${p.rot}deg`,
    animationDelay: `${p.delay}ms`
  }
}

function floatText(text, tone = 'yellow') {
  floatSeed += 1
  const item = { id: `float-${floatSeed}`, text, tone }
  floats.value = [...floats.value, item]
  timers.push(setTimeout(() => {
    floats.value = floats.value.filter(f => f.id !== item.id)
  }, 1300))
}

function petThePet() {
  if (!activePet.value) return
  spawnBurst()
  const now = Date.now()
  if (now - lastPetAt < 420) return
  lastPetAt = now
  petting.value = true
  timers.push(setTimeout(() => { petting.value = false }, 660))
  carePet(activePet.value.id, { mood: 2 })
  say(pickLine())
}

function useItem(item) {
  if (!activePet.value || !item) return
  if (itemCount(item.id) <= 0) {
    emit('toast', '这件已经用完啦，去商城补点货吧～')
    return
  }
  const plan = CATEGORY_PLAN[item.category] || { mood: 6, health: 0, verb: '用了', icon: '✨', tone: 'mint' }
  if (!removeItem(item.id, 1)) return

  const deltas = []
  if (plan.hunger) deltas.push(`饱腹 +${plan.hunger}`)
  if (plan.mood) deltas.push(`心情 +${plan.mood}`)
  if (plan.health) deltas.push(`健康 +${plan.health}`)

  carePet(activePet.value.id, {
    hunger: plan.hunger || 0,
    mood: plan.mood || 0,
    health: plan.health || 0,
    event: {
      icon: plan.icon,
      title: `${plan.verb} ${item.name}`,
      note: deltas.join(' · '),
      tone: plan.tone
    }
  })

  floatText(deltas[0] || '状态提升', plan.tone)
  say(pickLine())
  emit('toast', `${plan.verb}${item.name}，${deltas.join('，')} ✨`)
}

function cleanRoom() {
  if (!activePet.value) return
  if (cleaning.value) {
    emit('toast', '刚刚才打扫过，先让 TA 玩一会儿吧～')
    return
  }
  cleaning.value = true
  carePet(activePet.value.id, {
    health: 5,
    mood: 3,
    event: { icon: '🧹', title: '给小房间做了大扫除', note: '健康 +5 · 心情 +3', tone: 'mint' }
  })
  floatText('干净啦 +5 健康', 'mint')
  say('屋子里香香的，谢谢你～')
  timers.push(setTimeout(() => { cleaning.value = false }, 1200))
}

function openPicker(category) {
  if (!activePet.value) return
  picking.value = category
}
function goShop() {
  picking.value = ''
  panel.value = ''
  router.push('/shop')
}

function toggleOutfit(item) {
  if (!activePet.value) return
  if (home.value.outfit === item.id) {
    setPetOutfit(activePet.value.id, '')
    emit('toast', `已经取下${item.name}啦`)
    return
  }
  setPetOutfit(activePet.value.id, item.id)
  carePet(activePet.value.id, {
    mood: 4,
    event: { icon: '🎀', title: `换上了 ${item.name}`, note: '心情 +4', tone: 'pink' }
  })
  emit('toast', `${activePet.value.name} 换上新造型啦 ✨`)
}

function clearOutfit() {
  if (!activePet.value) return
  setPetOutfit(activePet.value.id, '')
  emit('toast', '配饰都取下来啦')
}

function snapPhoto() {
  if (!activePet.value) return
  addPetPhoto(activePet.value.id, {
    mood: moodFace.value,
    note: PHOTO_NOTES[Math.floor(Math.random() * PHOTO_NOTES.length)]
  })
  emit('toast', '咔嚓！照片已经放进相册啦 📷')
}

function dropPhoto(id) {
  if (!activePet.value) return
  removePetPhoto(activePet.value.id, id)
  emit('toast', '照片已从相册移除')
}

const actions = [
  { key: 'feed', icon: '🍚', label: '喂食', note: '消耗食物', tone: 'feed', run: () => openPicker('食物') },
  { key: 'play', icon: '🎾', label: '玩耍', note: '消耗玩具', tone: 'play', run: () => openPicker('玩具') },
  { key: 'clean', icon: '🧹', label: '打扫', note: '免费 · 健康 +5', tone: 'clean', run: cleanRoom },
  { key: 'cure', icon: '💊', label: '看病', note: '消耗药品', tone: 'cure', run: () => openPicker('药品') }
]

onBeforeUnmount(() => {
  clearTimeout(bubbleTimer)
  timers.forEach(t => clearTimeout(t))
})
</script>

<template>
  <section v-if="cards.length" class="pet-home">
    <!-- 头部 -->
    <header class="ph-head">
      <div class="ph-title">
        <span class="ph-icon" aria-hidden="true">🏡</span>
        <h2>毛孩子的家</h2>
        <span class="ph-live">已入住 {{ openCards.length }} 位</span>
      </div>

      <div v-if="openCards.length > 1" class="ph-switch" role="tablist" aria-label="切换毛孩子">
        <button
          v-for="c in openCards"
          :key="c.pet.id"
          type="button"
          role="tab"
          class="ph-chip"
          :class="{ active: c.pet.id === activeId }"
          :aria-selected="c.pet.id === activeId"
          @click="activeId = c.pet.id"
        >
          <img :src="c.pet.image" :alt="c.pet.name">
          {{ c.pet.name }}
        </button>
      </div>
    </header>

      <div class="ph-body">
        <!-- 左：房间 + 状态条 -->
        <div class="ph-left">
          <div class="ph-room" :class="{ cleaning }">
            <span class="room-wall" aria-hidden="true"></span>
            <span class="room-floor" aria-hidden="true"></span>

            <span class="room-window" aria-hidden="true"><i class="rw-sun"></i><i class="rw-cloud">☁️</i></span>
            <span class="room-frame" aria-hidden="true">🐾</span>
            <span class="room-plant" aria-hidden="true">🪴</span>
            <span class="room-lamp" aria-hidden="true"></span>

            <span v-if="bubble" class="room-speech">{{ bubble }}</span>
            <span v-if="cleaning" class="room-clean" aria-hidden="true">✨ 🧹 ✨</span>

            <span
              v-for="p in particles"
              :key="p.id"
              class="pet-particle"
              :style="particleStyle(p)"
              aria-hidden="true"
            >{{ p.emoji }}</span>

            <span
              v-for="f in floats"
              :key="f.id"
              class="pet-float"
              :class="f.tone"
              aria-hidden="true"
            >{{ f.text }}</span>

            <button
              type="button"
              class="pet-stand"
              :class="{ petting }"
              :aria-label="`摸摸 ${activePet.name}`"
              @click="petThePet"
            >
              <span class="pet-shadow" aria-hidden="true"></span>
              <span class="pet-figure">
                <img :src="activePet.image" :alt="activePet.name">
                <span v-if="outfitItem" class="pet-outfit" :class="outfitSlot">
                  <ItemArt :art="outfitItem.art" />
                </span>
              </span>
            </button>

            <span class="room-name">
              <strong>{{ activePet.name }}</strong>
              <small>{{ moodFace }} {{ moodText }}</small>
            </span>
            <span class="room-care">已照料 {{ home.cares }} 次</span>
          </div>

          <div class="ph-stats">
            <div v-for="s in statsList" :key="s.key" class="ph-stat" :class="s.key">
              <span class="st-icon" aria-hidden="true">{{ s.icon }}</span>
              <span class="st-label">{{ s.label }}</span>
              <span class="st-track">
                <span class="st-fill" :style="{ width: s.value + '%' }"></span>
              </span>
              <strong class="st-num">{{ s.value }}</strong>
              <small class="st-tip">{{ s.tip }}</small>
            </div>
          </div>
        </div>

        <!-- 右：功能入口 + 背包补给 -->
        <div class="ph-right">
          <div class="ph-entries">
            <button
              v-for="e in entries"
              :key="e.key"
              type="button"
              class="ph-entry"
              :class="e.tone"
              @click="e.run"
            >
              <span class="pe-icon" aria-hidden="true">{{ e.icon }}</span>
              <span class="pe-copy">
                <strong>{{ e.label }}</strong>
                <small>{{ e.note }}</small>
              </span>
              <span class="pe-arrow" aria-hidden="true">›</span>
            </button>
          </div>

          <div class="ph-bag">
            <header class="pb-head">
              <span class="pb-title">🎒 背包补给</span>
              <button type="button" class="pb-more" @click="router.push('/backpack')">全部 {{ bagTotal }} 件 ›</button>
            </header>

            <div v-if="quickItems.length" class="pb-list">
              <button
                v-for="it in quickItems"
                :key="it.id"
                type="button"
                class="pb-item"
                :title="it.effect"
                @click="useItem(it)"
              >
                <span class="pbi-art"><ItemArt :art="it.art" /></span>
                <span class="pbi-copy">
                  <strong>{{ it.name }}</strong>
                  <small>{{ it.effect }}</small>
                </span>
                <span class="pbi-count">×{{ it.count }}</span>
              </button>
            </div>
            <div v-else class="pb-empty">
              <span>背包里还没有补给～</span>
              <button type="button" class="mp-btn sm primary" @click="router.push('/shop')">去商城逛逛</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 成长时间线 -->
      <div class="ph-timeline">
        <header class="pt-head">
          <span class="pt-title">🕰️ 成长时间线</span>
          <span class="pt-count">{{ timelineNodes.length }} 个节点</span>
          <button type="button" class="pt-more" @click="panel = 'health'">全部记录 ›</button>
        </header>
        <ol class="tl-list">
          <li
            v-for="n in timelineNodes"
            :key="n.id"
            class="tl-node"
            :class="[n.tone, { pending: n.pending }]"
          >
            <span class="tl-date">{{ n.short }}</span>
            <span class="tl-dot" aria-hidden="true">{{ n.icon }}</span>
            <span class="tl-copy">
              <strong>{{ n.title }}</strong>
              <small>{{ n.note }}</small>
            </span>
          </li>
        </ol>
      </div>

      <!-- 底部操作栏 -->
      <div class="ph-bar">
        <button
          v-for="a in actions"
          :key="a.key"
          type="button"
          class="ph-action"
          :class="a.tone"
          @click="a.run"
        >
          <span class="pa-icon" aria-hidden="true">{{ a.icon }}</span>
          <span class="pa-copy">
            <strong>{{ a.label }}</strong>
            <small>{{ a.note }}</small>
          </span>
        </button>
      </div>
      <p class="ph-foot">🌿 喂食 / 玩耍 / 看病会消耗背包里的道具，状态会实时变化，记得常去商城补给</p>

    <!-- ===== 道具选择弹窗 ===== -->
    <Teleport to="body">
      <div v-if="picking" class="ph-mask" @click.self="picking = ''">
        <div class="ph-modal" role="dialog" aria-modal="true">
          <header class="pm-head">
            <span class="pm-icon" aria-hidden="true">{{ pickCategory.icon }}</span>
            <div class="pm-title">
              <strong>选择{{ picking }}</strong>
              <small>使用后从背包扣减 1 个，状态立即更新</small>
            </div>
            <button type="button" class="pm-close" aria-label="关闭" @click="picking = ''">✕</button>
          </header>

          <div v-if="pickedList.length" class="pm-items">
            <div v-for="it in pickedList" :key="it.id" class="pm-item">
              <span class="pmi-art"><ItemArt :art="it.art" /></span>
              <div class="pmi-copy">
                <strong>{{ it.name }} <em>×{{ it.count }}</em></strong>
                <small>{{ it.desc }}</small>
                <span class="pmi-effect">{{ it.effect }}</span>
              </div>
              <button type="button" class="mp-btn sm primary" @click="useItem(it)">使用</button>
            </div>
          </div>

          <CuteEmpty
            v-else
            compact
            :title="`背包里没有${picking}啦`"
            desc="去积分商城逛一圈，给毛孩子补点小补给吧～"
          >
            <button type="button" class="mp-btn primary" @click="goShop">🛍️ 去积分商城</button>
          </CuteEmpty>
        </div>
      </div>
    </Teleport>

    <!-- ===== 健康记录 ===== -->
    <Teleport to="body">
      <div v-if="panel === 'health'" class="ph-mask" @click.self="panel = ''">
        <div class="ph-modal" role="dialog" aria-modal="true">
          <header class="pm-head">
            <span class="pm-icon mint" aria-hidden="true">🩺</span>
            <div class="pm-title">
              <strong>健康记录</strong>
              <small>{{ activePet ? activePet.name : '' }} 的身体小档案</small>
            </div>
            <button type="button" class="pm-close" aria-label="关闭" @click="panel = ''">✕</button>
          </header>

          <div class="hm-stats">
            <div v-for="s in statsList" :key="s.key" class="hm-stat" :class="s.key">
              <span class="hs-icon" aria-hidden="true">{{ s.icon }}</span>
              <div class="hs-copy">
                <div class="hs-row">
                  <strong>{{ s.label }}</strong>
                  <em>{{ s.value }} / 100</em>
                </div>
                <span class="hs-track"><span class="hs-fill" :style="{ width: s.value + '%' }"></span></span>
                <small>{{ s.tip }}</small>
              </div>
            </div>
          </div>

          <h3 class="pm-sub">疫苗计划 <em>{{ doneVaccines }}/3</em></h3>
          <ul class="hm-vaccines">
            <li v-for="v in vaccineRecords" :key="v.id" :class="{ done: v.done }">
              <span class="hv-dot" aria-hidden="true">{{ v.icon }}</span>
              <span class="hv-copy">
                <strong>{{ v.name }}</strong>
                <small>{{ v.dateText }}</small>
              </span>
              <span class="hv-tag">{{ v.done ? '已接种' : '待接种' }}</span>
            </li>
          </ul>

          <h3 class="pm-sub">最近照料</h3>
          <ul v-if="recentEvents.length" class="hm-events">
            <li v-for="e in recentEvents" :key="e.id">
              <span aria-hidden="true">{{ e.icon }}</span>
              <p>{{ e.title }}</p>
              <small>{{ e.timeText }}</small>
            </li>
          </ul>
          <p v-else class="hm-none">还没有照料记录，从下面的「喂食」开始吧～</p>
        </div>
      </div>
    </Teleport>

    <!-- ===== 宠物装扮 ===== -->
    <Teleport to="body">
      <div v-if="panel === 'dress'" class="ph-mask" @click.self="panel = ''">
        <div class="ph-modal" role="dialog" aria-modal="true">
          <header class="pm-head">
            <span class="pm-icon pink" aria-hidden="true">🎀</span>
            <div class="pm-title">
              <strong>宠物装扮</strong>
              <small>在积分商城兑换「装饰」，就能给 TA 换造型</small>
            </div>
            <button type="button" class="pm-close" aria-label="关闭" @click="panel = ''">✕</button>
          </header>

          <div v-if="decorList.length" class="dm-grid">
            <button
              v-for="it in decorList"
              :key="it.id"
              type="button"
              class="dm-item"
              :class="{ on: home.outfit === it.id }"
              @click="toggleOutfit(it)"
            >
              <span class="dmi-art"><ItemArt :art="it.art" /></span>
              <strong>{{ it.name }}</strong>
              <small>持有 ×{{ it.count }}</small>
              <span class="dmi-tag">{{ home.outfit === it.id ? '佩戴中' : '点击佩戴' }}</span>
            </button>
          </div>

          <CuteEmpty
            v-else
            compact
            title="还没有装饰道具"
            desc="去商城挑个小领巾、铃铛或小皇冠，给 TA 拍张好看的照～"
          >
            <button type="button" class="mp-btn primary" @click="goShop">🛍️ 去积分商城</button>
          </CuteEmpty>

          <div v-if="decorList.length" class="dm-foot">
            <span>💡 装扮会实时显示在小屋里的毛孩子身上</span>
            <button type="button" class="mp-btn sm ghost" :disabled="!home.outfit" @click="clearOutfit">全部取下</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ===== 宠物相册 ===== -->
    <Teleport to="body">
      <div v-if="panel === 'album'" class="ph-mask" @click.self="panel = ''">
        <div class="ph-modal" role="dialog" aria-modal="true">
          <header class="pm-head">
            <span class="pm-icon blue" aria-hidden="true">📷</span>
            <div class="pm-title">
              <strong>宠物相册</strong>
              <small>{{ activePet ? activePet.name : '' }} 的日常留影</small>
            </div>
            <button type="button" class="mp-btn sm primary" @click="snapPhoto">📸 拍一张</button>
            <button type="button" class="pm-close" aria-label="关闭" @click="panel = ''">✕</button>
          </header>

          <div v-if="photos.length" class="am-grid">
            <figure v-for="(p, i) in photos" :key="p.id" class="am-photo" :class="`f${i % 4}`">
              <span class="amp-img"><img :src="activePet.image" :alt="p.note || '宠物照片'"></span>
              <figcaption>
                {{ p.mood }} {{ p.note || '今天也很可爱' }}
                <small>{{ p.timeText }}</small>
              </figcaption>
              <button type="button" class="amp-del" aria-label="删除照片" @click="dropPhoto(p.id)">✕</button>
            </figure>
          </div>

          <CuteEmpty
            v-else
            compact
            title="相册还是空的"
            desc="点右上角「拍一张」，把 TA 今天的可爱模样收进来～"
          >
            <button type="button" class="mp-btn primary" @click="snapPhoto">📸 拍一张</button>
          </CuteEmpty>
        </div>
      </div>
    </Teleport>
  </section>
</template>

<style scoped>
/* ===== 模块外壳 ===== */
.pet-home {
  position: relative;
  margin-bottom: 18px;
  padding: 16px 18px 14px;
  background: linear-gradient(160deg, #fffdf6 0%, #fff7ea 100%);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
}

/* ===== 头部 ===== */
.ph-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-bottom: 14px; }
.ph-title { display: flex; align-items: center; gap: 9px; }
.ph-icon {
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  font-size: 17px;
  background: var(--yellow);
  border: var(--line);
  border-radius: 11px;
  box-shadow: 2px 2px 0 var(--ink);
}
.ph-title h2 { margin: 0; font-size: 17px; letter-spacing: 0.4px; }
.ph-live {
  padding: 2px 9px;
  font-size: 9.5px;
  font-weight: 900;
  background: var(--mint);
  border: 2px solid var(--ink);
  border-radius: 999px;
}

.ph-switch { display: flex; gap: 6px; flex-wrap: wrap; }
.ph-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 3px 10px 3px 3px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.16);
  border-radius: 999px;
  cursor: pointer;
}
.ph-chip img { width: 22px; height: 22px; object-fit: contain; }
.ph-chip:hover { border-color: var(--ink); transform: translateY(-2px); }
.ph-chip.active { background: var(--yellow); border-color: var(--ink); box-shadow: 2px 2px 0 var(--ink); }

/* ===== 主体两栏 ===== */
.ph-body { display: grid; grid-template-columns: minmax(0, 1.34fr) minmax(0, 1fr); gap: 14px; }
.ph-left { min-width: 0; }

/* ===== 房间 ===== */
.ph-room {
  position: relative;
  height: 296px;
  overflow: hidden;
  background: #fff4e2;
  border: var(--line);
  border-radius: 14px;
  isolation: isolate;
}
.room-wall {
  position: absolute;
  inset: 0 0 38% 0;
  background: linear-gradient(#fff7e8, #ffeacd);
}
.room-wall::after {
  content: '';
  position: absolute;
  inset: 0;
  background-image: radial-gradient(rgba(232, 190, 130, 0.5) 1.2px, transparent 1.2px);
  background-size: 15px 15px;
  opacity: 0.6;
}
.room-floor {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 38%;
  background: repeating-linear-gradient(92deg, #f8ddb5 0 30px, #f3d2a5 30px 32px);
  border-top: 2px solid var(--ink);
}
.room-floor::before {
  content: '';
  position: absolute;
  left: 50%;
  bottom: 8px;
  width: 230px;
  height: 44px;
  transform: translateX(-50%);
  background: #ffdbe6;
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: inset 0 -4px 0 rgba(43, 43, 43, 0.08);
}

/* 窗 */
.room-window {
  position: absolute;
  left: 18px;
  top: 16px;
  width: 92px;
  height: 74px;
  background: linear-gradient(#d9f1ff, #eefaff);
  border: 2px solid var(--ink);
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 3px 3px 0 rgba(43, 43, 43, 0.12);
  z-index: 1;
}
.room-window::before {
  content: '';
  position: absolute;
  left: 50%;
  top: 0;
  bottom: 0;
  width: 2px;
  background: var(--ink);
}
.room-window::after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  top: 50%;
  height: 2px;
  background: var(--ink);
}
.rw-sun {
  position: absolute;
  right: 8px;
  top: 6px;
  width: 16px;
  height: 16px;
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 50%;
}
.rw-cloud { position: absolute; left: 6px; bottom: 4px; font-size: 13px; opacity: 0.85; }

/* 挂画 / 绿植 / 吊灯 */
.room-frame {
  position: absolute;
  right: 22px;
  top: 20px;
  width: 50px;
  height: 50px;
  display: grid;
  place-items: center;
  font-size: 21px;
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: 7px;
  transform: rotate(4deg);
  box-shadow: 3px 3px 0 rgba(43, 43, 43, 0.14);
  z-index: 1;
}
.room-plant { position: absolute; right: 96px; top: 66px; font-size: 26px; z-index: 1; }
.room-plant::after {
  content: '';
  position: absolute;
  left: 50%;
  bottom: -8px;
  width: 62px;
  height: 7px;
  transform: translateX(-50%);
  background: #e9c99c;
  border: 2px solid var(--ink);
  border-radius: 3px;
}
.room-lamp {
  position: absolute;
  left: 50%;
  top: 0;
  width: 2px;
  height: 26px;
  margin-left: -1px;
  background: rgba(43, 43, 43, 0.34);
  z-index: 1;
}
.room-lamp::after {
  content: '';
  position: absolute;
  left: 50%;
  bottom: -18px;
  width: 34px;
  height: 20px;
  transform: translateX(-50%);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 4px 4px 15px 15px;
}

/* 宠物 */
.pet-stand {
  position: absolute;
  left: 50%;
  bottom: 4px;
  width: 210px;
  height: 196px;
  margin-left: -105px;
  padding: 0;
  background: none;
  border: none;
  cursor: pointer;
  z-index: 2;
}
.pet-shadow {
  position: absolute;
  left: 50%;
  bottom: 4px;
  width: 132px;
  height: 17px;
  transform: translateX(-50%);
  background: rgba(120, 88, 50, 0.2);
  border-radius: 50%;
  filter: blur(4px);
}
.pet-figure {
  position: absolute;
  left: 50%;
  bottom: 8px;
  width: 180px;
  height: 180px;
  transform: translateX(-50%);
  display: grid;
  place-items: end center;
  animation: pet-idle 3.6s ease-in-out infinite;
}
.pet-figure img {
  width: 172px;
  height: 172px;
  object-fit: contain;
  filter: drop-shadow(0 5px 7px rgba(120, 88, 50, 0.16));
  transition: scale 0.22s cubic-bezier(0.2, 1.4, 0.4, 1);
}
.pet-stand:hover .pet-figure img { scale: 1.06; }
.pet-stand.petting .pet-figure { animation: pet-bounce 0.66s cubic-bezier(0.2, 1.4, 0.4, 1); }

@keyframes pet-idle {
  0%, 100% { transform: translateX(-50%) translateY(0); }
  50% { transform: translateX(-50%) translateY(-6px); }
}
@keyframes pet-bounce {
  0% { transform: translateX(-50%) scale(1, 1); }
  30% { transform: translateX(-50%) scale(1.08, 0.9) translateY(4px); }
  62% { transform: translateX(-50%) scale(0.95, 1.06) translateY(-9px); }
  100% { transform: translateX(-50%) scale(1, 1); }
}

/* 装扮挂件 */
.pet-outfit {
  position: absolute;
  width: 34px;
  height: 34px;
  transform: translateX(-50%);
  filter: drop-shadow(0 2px 2px rgba(43, 43, 43, 0.2));
  animation: outfit-pop 0.36s cubic-bezier(0.2, 1.5, 0.4, 1);
}
.pet-outfit.neck { left: calc(50% - 44px); bottom: 52px; width: 30px; height: 30px; }
.pet-outfit.head { bottom: 150px; width: 34px; height: 34px; }
.pet-outfit :deep(.item-art) { width: 100%; height: 100%; }
@keyframes outfit-pop {
  0% { transform: translateX(-50%) scale(0.4) rotate(-12deg); opacity: 0; }
  100% { transform: translateX(-50%) scale(1) rotate(0); opacity: 1; }
}

/* 对话气泡 */
.room-speech {
  position: absolute;
  left: 50%;
  bottom: 190px;
  max-width: 190px;
  padding: 7px 11px;
  transform: translateX(-42%);
  font-size: 11px;
  font-weight: 900;
  line-height: 1.5;
  text-align: center;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 11px;
  box-shadow: 2px 2px 0 rgba(43, 43, 43, 0.85);
  z-index: 4;
  animation: bubble-in 0.26s cubic-bezier(0.2, 1.5, 0.4, 1);
}
.room-speech::after {
  content: '';
  position: absolute;
  left: 42%;
  bottom: -8px;
  width: 10px;
  height: 10px;
  background: #fff;
  border-right: 2px solid var(--ink);
  border-bottom: 2px solid var(--ink);
  transform: rotate(45deg);
}
@keyframes bubble-in {
  0% { opacity: 0; transform: translateX(-42%) scale(0.85); }
  100% { opacity: 1; transform: translateX(-42%) scale(1); }
}

/* 打扫闪光 */
.room-clean {
  position: absolute;
  left: 50%;
  top: 96px;
  transform: translateX(-50%);
  font-size: 16px;
  letter-spacing: 4px;
  z-index: 4;
  animation: clean-flash 1.2s ease-out forwards;
}
@keyframes clean-flash {
  0% { opacity: 0; transform: translateX(-50%) translateY(10px) scale(0.7); }
  40% { opacity: 1; }
  100% { opacity: 0; transform: translateX(-50%) translateY(-26px) scale(1.15); }
}

/* 抚摸粒子 / 状态飘字 */
.pet-particle {
  position: absolute;
  font-size: 15px;
  pointer-events: none;
  z-index: 5;
  animation: particle-up 1s ease-out forwards;
}
@keyframes particle-up {
  0% { opacity: 0; transform: translate(0, 0) scale(0.6); }
  25% { opacity: 1; }
  100% { opacity: 0; transform: translate(var(--dx), -72px) scale(1.15) rotate(var(--rot)); }
}
.pet-float {
  position: absolute;
  left: 50%;
  bottom: 148px;
  padding: 4px 11px;
  transform: translateX(-50%);
  font-size: 11px;
  font-weight: 900;
  white-space: nowrap;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 2px 2px 0 var(--ink);
  z-index: 6;
  animation: float-up 1.25s ease-out forwards;
}
.pet-float.yellow { background: var(--yellow); }
.pet-float.pink { background: var(--pink); }
.pet-float.blue { background: var(--blue); }
.pet-float.mint { background: var(--mint); }
@keyframes float-up {
  0% { opacity: 0; transform: translate(-50%, 8px) scale(0.85); }
  22% { opacity: 1; transform: translate(-50%, 0) scale(1); }
  100% { opacity: 0; transform: translate(-50%, -46px) scale(1); }
}

/* 房间内的名牌 */
.room-name {
  position: absolute;
  left: 12px;
  bottom: 10px;
  display: grid;
  gap: 1px;
  padding: 5px 10px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 11px;
  box-shadow: 2px 2px 0 var(--ink);
  z-index: 3;
}
.room-name strong { font-size: 12px; }
.room-name small { font-size: 9.5px; font-weight: 900; color: var(--text-2); }
.room-care {
  position: absolute;
  right: 12px;
  bottom: 12px;
  padding: 3px 9px;
  font-size: 9.5px;
  font-weight: 900;
  color: var(--text-2);
  background: rgba(255, 253, 246, 0.92);
  border: 2px solid rgba(43, 43, 43, 0.16);
  border-radius: 999px;
  z-index: 3;
}

/* ===== 状态条 ===== */
.ph-stats { display: grid; gap: 7px; margin-top: 10px; }
.ph-stat {
  display: grid;
  grid-template-columns: 22px 56px minmax(0, 1fr) 30px;
  grid-template-areas:
    'icon label track num'
    'icon tip tip tip';
  align-items: center;
  gap: 3px 8px;
  padding: 7px 11px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: var(--r-sm);
}
.ph-stat:hover { border-color: rgba(43, 43, 43, 0.35); }
.st-icon { grid-area: icon; font-size: 13px; line-height: 1; }
.st-label { grid-area: label; font-size: 11px; font-weight: 900; }
.st-track {
  grid-area: track;
  height: 11px;
  background: #f4ead9;
  border: 2px solid var(--ink);
  border-radius: 999px;
  overflow: hidden;
}
.st-fill {
  display: block;
  height: 100%;
  border-radius: 999px;
  transition: width 0.55s cubic-bezier(0.2, 1, 0.3, 1);
}
.ph-stat.hunger .st-fill { background: repeating-linear-gradient(45deg, #ffb066 0 7px, #ffc187 7px 14px); }
.ph-stat.mood .st-fill { background: repeating-linear-gradient(45deg, #ff9ec4 0 7px, #ffb6d3 7px 14px); }
.ph-stat.health .st-fill { background: repeating-linear-gradient(45deg, #8fd9c4 0 7px, #a6e3d2 7px 14px); }
.st-num { grid-area: num; font-size: 12px; text-align: right; }
.st-tip { grid-area: tip; font-size: 9.5px; font-weight: 700; color: var(--text-3); }

/* ===== 右栏：入口 ===== */
.ph-right { display: grid; grid-template-rows: auto 1fr; gap: 10px; min-width: 0; }
.ph-entries { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.ph-entry {
  position: relative;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 10px 10px;
  text-align: left;
  font: inherit;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
  cursor: pointer;
}
.ph-entry:hover { transform: translateY(-3px); box-shadow: var(--shadow-2); }
.ph-entry:active { transform: translateY(0); box-shadow: 1px 1px 0 var(--ink); }
.pe-icon {
  width: 32px;
  height: 32px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 15px;
  border: 2px solid var(--ink);
  border-radius: 9px;
}
.ph-entry.pink .pe-icon { background: #ffd9e4; }
.ph-entry.mint .pe-icon { background: #d3f3e7; }
.ph-entry.blue .pe-icon { background: #d6ecff; }
.ph-entry.yellow .pe-icon { background: #ffe9b0; }
.pe-copy { flex: 1; min-width: 0; display: grid; gap: 2px; }
.pe-copy strong { font-size: 12px; }
.pe-copy small {
  font-size: 9.5px;
  font-weight: 700;
  color: var(--text-3);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.pe-arrow { font-size: 14px; font-weight: 900; color: var(--text-3); transition: transform 0.16s ease, color 0.16s ease; }
.ph-entry:hover .pe-arrow { color: var(--ink); transform: translateX(2px); }

/* ===== 右栏：背包补给 ===== */
.ph-bag {
  display: flex;
  flex-direction: column;
  padding: 10px 11px 11px;
  background: #fffdf6;
  border: 2px dashed #e2cda8;
  border-radius: var(--r-sm);
}
.pb-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 9px; }
.pb-title { font-size: 11.5px; font-weight: 900; }
.pb-more {
  padding: 2px 7px;
  font: inherit;
  font-size: 9.5px;
  font-weight: 900;
  color: var(--text-2);
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.16);
  border-radius: 999px;
  cursor: pointer;
}
.pb-more:hover { color: var(--ink); border-color: var(--ink); }
.pb-list { display: grid; grid-auto-rows: 1fr; gap: 7px; flex: 1; }
.pb-item {
  display: grid;
  grid-template-columns: 38px minmax(0, 1fr) auto;
  align-items: center;
  gap: 9px;
  padding: 6px 9px;
  font: inherit;
  color: var(--ink);
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: 11px;
  cursor: pointer;
  text-align: left;
}
.pb-item:hover {
  border-color: var(--ink);
  transform: translateY(-2px);
  box-shadow: 2px 3px 0 rgba(43, 43, 43, 0.85);
}
.pb-item:active { transform: translateY(0) scale(0.985); box-shadow: none; }
.pbi-art { width: 38px; height: 38px; display: grid; place-items: center; }
.pbi-art :deep(.item-art) { width: 100%; height: 100%; }
.pbi-copy { min-width: 0; display: grid; gap: 1px; }
.pbi-copy strong { font-size: 11px; }
.pbi-copy small {
  font-size: 9px;
  font-weight: 700;
  color: var(--text-3);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.pbi-count {
  padding: 1px 7px;
  font-size: 9px;
  font-weight: 900;
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 999px;
}
.pb-empty {
  flex: 1;
  display: grid;
  place-items: center;
  gap: 8px;
  padding: 6px 0;
  font-size: 10.5px;
  font-weight: 700;
  color: var(--text-2);
  text-align: center;
}

/* ===== 成长时间线 ===== */
.ph-timeline { margin-top: 14px; padding-top: 13px; border-top: 2px dashed #eddcc0; }
.pt-head { display: flex; align-items: center; gap: 9px; margin-bottom: 8px; }
.pt-title { font-size: 12.5px; font-weight: 900; }
.pt-count {
  padding: 1px 8px;
  font-size: 9.5px;
  font-weight: 900;
  color: var(--text-2);
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.16);
  border-radius: 999px;
}
.pt-more {
  margin-left: auto;
  padding: 2px 8px;
  font: inherit;
  font-size: 9.5px;
  font-weight: 900;
  color: var(--text-2);
  background: none;
  border: none;
  cursor: pointer;
}
.pt-more:hover { color: var(--ink); text-decoration: underline; }

.tl-list {
  display: grid;
  grid-auto-flow: column;
  grid-auto-columns: minmax(0, 1fr);
  gap: 6px;
  position: relative;
  margin: 0;
  padding: 2px 0 0;
  list-style: none;
}
.tl-list::before {
  content: '';
  position: absolute;
  left: 6%;
  right: 6%;
  top: 33px;
  border-top: 2px dashed #e3cfa8;
}
.tl-node { display: grid; justify-items: center; gap: 5px; text-align: center; padding: 0 2px; }
.tl-date { font-size: 9px; font-weight: 900; color: var(--text-3); letter-spacing: 0.2px; }
.tl-dot {
  position: relative;
  z-index: 1;
  width: 28px;
  height: 28px;
  display: grid;
  place-items: center;
  font-size: 12.5px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: 2px 2px 0 rgba(43, 43, 43, 0.22);
}
.tl-node.mint .tl-dot { background: var(--mint); }
.tl-node.blue .tl-dot { background: var(--blue); }
.tl-node.pink .tl-dot { background: var(--pink); }
.tl-node.yellow .tl-dot { background: var(--yellow); }
.tl-node.pending .tl-dot { background: #f4ecdd; border-style: dashed; box-shadow: none; opacity: 0.75; }
.tl-copy { display: grid; gap: 1px; min-width: 0; }
.tl-copy strong {
  font-size: 10.5px;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.tl-copy small { font-size: 9px; font-weight: 700; color: var(--text-3); }
.tl-node.pending .tl-copy small { color: #a68d6a; }

/* ===== 底部操作栏 ===== */
.ph-bar {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  margin-top: 13px;
  padding-top: 13px;
  border-top: 2px dashed #eddcc0;
}
.ph-action {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 8px 10px;
  text-align: left;
  font: inherit;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
  cursor: pointer;
}
.ph-action:hover { transform: translateY(-3px); box-shadow: var(--shadow-2); }
.ph-action:active { transform: translateY(0); box-shadow: 1px 1px 0 var(--ink); }
.pa-icon {
  width: 30px;
  height: 30px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 15px;
  border: 2px solid var(--ink);
  border-radius: 9px;
}
.ph-action.feed .pa-icon { background: #ffd9a8; }
.ph-action.play .pa-icon { background: #ffd0e0; }
.ph-action.clean .pa-icon { background: #c9f0e2; }
.ph-action.cure .pa-icon { background: #d2e8ff; }
.pa-copy { display: grid; gap: 1px; min-width: 0; }
.pa-copy strong { font-size: 12px; }
.pa-copy small { font-size: 9px; font-weight: 700; color: var(--text-3); white-space: nowrap; }

.ph-foot {
  margin: 9px 0 0;
  font-size: 9.5px;
  font-weight: 700;
  color: var(--text-3);
  text-align: center;
}

/* ===== 弹窗 ===== */
.ph-mask {
  position: fixed;
  inset: 0;
  z-index: 74;
  display: grid;
  place-items: center;
  padding: 24px 18px;
  background: rgba(46, 34, 24, 0.42);
  backdrop-filter: blur(3px);
}
.ph-modal {
  width: min(560px, 100%);
  max-height: 84vh;
  overflow: auto;
  padding: 18px 20px 20px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-3);
  animation: modal-in 0.24s cubic-bezier(0.2, 1.4, 0.4, 1);
}
@keyframes modal-in {
  0% { opacity: 0; transform: translateY(14px) scale(0.97); }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}
.pm-head { display: flex; align-items: center; gap: 11px; margin-bottom: 15px; }
.pm-icon {
  width: 38px;
  height: 38px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 18px;
  background: var(--yellow);
  border: var(--line);
  border-radius: 11px;
  box-shadow: 2px 2px 0 var(--ink);
}
.pm-icon.mint { background: #d3f3e7; }
.pm-icon.pink { background: #ffd9e4; }
.pm-icon.blue { background: #d6ecff; }
.pm-title { flex: 1; min-width: 0; display: grid; gap: 2px; }
.pm-title strong { font-size: 16px; }
.pm-title small { font-size: 10.5px; font-weight: 700; color: var(--text-3); }
.pm-close {
  width: 28px;
  height: 28px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 13px;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: 50%;
  cursor: pointer;
}
.pm-close:hover { background: #ffd9e4; transform: rotate(90deg); }

/* 弹窗内的空状态：不要再套一层卡片框，避免「框中框」 */
.ph-modal .cute-empty.compact {
  padding: 16px 8px 6px;
  background: none;
  border: none;
  box-shadow: none;
}

.pm-sub {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 18px 0 9px;
  font-size: 12.5px;
}
.pm-sub em {
  padding: 1px 7px;
  font-style: normal;
  font-size: 9.5px;
  background: var(--mint);
  border: 2px solid var(--ink);
  border-radius: 999px;
}

/* 道具列表 */
.pm-items { display: grid; gap: 9px; }
.pm-item {
  display: flex;
  align-items: center;
  gap: 11px;
  padding: 10px 12px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: var(--r-sm);
}
.pm-item:hover { border-color: var(--ink); }
.pmi-art {
  width: 46px;
  height: 46px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  padding: 2px;
  background: linear-gradient(160deg, #fff, #fff3dd);
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: 11px;
}
.pmi-art :deep(.item-art) { width: 100%; height: 100%; }
.pmi-copy { flex: 1; min-width: 0; display: grid; gap: 2px; }
.pmi-copy strong { font-size: 12.5px; }
.pmi-copy strong em { font-style: normal; font-size: 10px; color: var(--text-3); }
.pmi-copy small {
  font-size: 10px;
  font-weight: 700;
  color: var(--text-2);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.pmi-effect {
  justify-self: start;
  margin-top: 2px;
  padding: 1px 7px;
  font-size: 9px;
  font-weight: 900;
  color: var(--text-2);
  background: #fff6e2;
  border: 2px solid rgba(43, 43, 43, 0.12);
  border-radius: 999px;
}

/* 健康记录 */
.hm-stats { display: grid; gap: 8px; }
.hm-stat {
  display: flex;
  align-items: center;
  gap: 11px;
  padding: 10px 12px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: var(--r-sm);
}
.hs-icon { width: 26px; text-align: center; font-size: 15px; }
.hs-copy { flex: 1; min-width: 0; display: grid; gap: 4px; }
.hs-row { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; }
.hs-row strong { font-size: 11.5px; }
.hs-row em { font-style: normal; font-size: 10px; font-weight: 900; color: var(--text-3); }
.hs-track {
  display: block;
  height: 10px;
  background: #f4ead9;
  border: 2px solid var(--ink);
  border-radius: 999px;
  overflow: hidden;
}
.hs-fill { display: block; height: 100%; border-radius: 999px; transition: width 0.5s ease; }
.hm-stat.hunger .hs-fill { background: repeating-linear-gradient(45deg, #ffb066 0 7px, #ffc187 7px 14px); }
.hm-stat.mood .hs-fill { background: repeating-linear-gradient(45deg, #ff9ec4 0 7px, #ffb6d3 7px 14px); }
.hm-stat.health .hs-fill { background: repeating-linear-gradient(45deg, #8fd9c4 0 7px, #a6e3d2 7px 14px); }
.hs-copy small { font-size: 9.5px; font-weight: 700; color: var(--text-3); }

.hm-vaccines { display: grid; gap: 7px; margin: 0; padding: 0; list-style: none; }
.hm-vaccines li {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 11px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.12);
  border-radius: var(--r-sm);
}
.hm-vaccines li.done { background: #f4fdf9; border-color: rgba(63, 174, 140, 0.45); }
.hv-dot {
  width: 26px;
  height: 26px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 12px;
  background: #fff6e2;
  border: 2px solid var(--ink);
  border-radius: 8px;
}
.hm-vaccines li.done .hv-dot { background: var(--mint); }
.hv-copy { flex: 1; min-width: 0; display: grid; gap: 1px; }
.hv-copy strong { font-size: 11.5px; }
.hv-copy small { font-size: 9.5px; font-weight: 700; color: var(--text-3); }
.hv-tag {
  padding: 2px 8px;
  font-size: 9px;
  font-weight: 900;
  background: #f0e5d2;
  border: 2px solid var(--ink);
  border-radius: 999px;
}
.hm-vaccines li.done .hv-tag { background: var(--mint); }

.hm-events { display: grid; gap: 6px; margin: 0; padding: 0; list-style: none; }
.hm-events li {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 7px 10px;
  font-size: 10.5px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.1);
  border-radius: 10px;
}
.hm-events li p { flex: 1; min-width: 0; margin: 0; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.hm-events li small { font-size: 9px; font-weight: 900; color: var(--text-3); }
.hm-none { margin: 0; padding: 12px; font-size: 10.5px; font-weight: 700; color: var(--text-3); text-align: center; background: #fff; border: 2px dashed #e2cda8; border-radius: 10px; }

/* 装扮 */
.dm-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(148px, 1fr)); gap: 10px; }
.dm-item {
  display: grid;
  justify-items: center;
  gap: 3px;
  padding: 12px 8px 10px;
  font: inherit;
  color: var(--ink);
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: var(--r-sm);
  cursor: pointer;
}
.dm-item:hover { border-color: var(--ink); transform: translateY(-3px); box-shadow: 2px 3px 0 rgba(43, 43, 43, 0.85); }
.dm-item.on { background: #fff6e2; border-color: var(--ink); box-shadow: 2px 2px 0 var(--ink); }
.dmi-art { width: 54px; height: 54px; display: grid; place-items: center; }
.dmi-art :deep(.item-art) { width: 100%; height: 100%; }
.dm-item strong { font-size: 11px; text-align: center; }
.dm-item small { font-size: 9px; font-weight: 700; color: var(--text-3); }
.dmi-tag {
  margin-top: 3px;
  padding: 1px 8px;
  font-size: 9px;
  font-weight: 900;
  background: #f0e5d2;
  border: 2px solid var(--ink);
  border-radius: 999px;
}
.dm-item.on .dmi-tag { background: var(--yellow); }
.dm-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-top: 14px;
  padding-top: 12px;
  border-top: 2px dashed #eddcc0;
  font-size: 9.5px;
  font-weight: 700;
  color: var(--text-3);
}

/* 相册 */
.am-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
.am-photo {
  position: relative;
  margin: 0;
  padding: 7px 7px 6px;
  background: #fff;
  border: var(--line);
  border-radius: 11px;
  box-shadow: 3px 3px 0 rgba(43, 43, 43, 0.18);
}
.am-photo.f0 { transform: rotate(-1.6deg); }
.am-photo.f1 { transform: rotate(1.4deg); }
.am-photo.f2 { transform: rotate(0.8deg); }
.am-photo.f3 { transform: rotate(-0.9deg); }
.amp-img {
  display: grid;
  place-items: center;
  height: 88px;
  background: linear-gradient(160deg, #fff8e9, #ffeede);
  border: 2px solid rgba(43, 43, 43, 0.12);
  border-radius: 8px;
  overflow: hidden;
}
.amp-img img { width: 84px; height: 84px; object-fit: contain; }
.am-photo figcaption { margin-top: 5px; font-size: 9.5px; font-weight: 900; line-height: 1.4; }
.am-photo figcaption small { display: block; font-size: 8.5px; font-weight: 700; color: var(--text-3); }
.amp-del {
  position: absolute;
  right: -7px;
  top: -7px;
  width: 20px;
  height: 20px;
  display: grid;
  place-items: center;
  font-size: 9px;
  color: var(--ink);
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 50%;
  cursor: pointer;
  opacity: 0;
  transition: opacity 0.16s ease;
}
.am-photo:hover .amp-del { opacity: 1; }
.amp-del:hover { background: #ffc9cf; }

/* ===== 窄屏 ===== */
@media (max-width: 1000px) {
  .ph-body { grid-template-columns: minmax(0, 1fr); }
  .ph-room { height: 268px; }
  .ph-bag { margin-top: 4px; }
}
/* 时间线在中等宽度就转成竖向，避免 5 个节点被挤成豆腐块 */
@media (max-width: 880px) {
  .tl-list { grid-auto-flow: row; grid-auto-columns: auto; gap: 10px; }
  .tl-list::before { left: 89px; right: auto; top: 18px; bottom: 18px; width: 0; height: auto; border-top: none; border-left: 2px dashed #e3cfa8; }
  .tl-node { grid-template-columns: 68px 28px minmax(0, 1fr); align-items: center; justify-items: start; gap: 8px; text-align: left; }
  .tl-date { justify-self: end; }
  .tl-copy strong { -webkit-line-clamp: 1; }
}

@media (max-width: 720px) {
  .pet-home { padding: 14px 13px 12px; }
  .ph-switch { width: 100%; }
  .ph-entries { grid-template-columns: 1fr; }
  .ph-bar { grid-template-columns: 1fr 1fr; }
  .am-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .dm-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 480px) {
  .ph-room { height: 240px; }
  .room-frame, .room-plant { display: none; }
  .pet-stand { width: 180px; height: 168px; margin-left: -90px; }
  .pet-figure { width: 152px; height: 152px; }
  .pet-figure img { width: 146px; height: 146px; }
  .pet-outfit.neck { bottom: 46px; }
  .pet-outfit.head { bottom: 126px; }
  .room-speech { bottom: 168px; max-width: 156px; }
  .ph-stat { grid-template-columns: 20px 50px minmax(0, 1fr) 26px; }
}
</style>
