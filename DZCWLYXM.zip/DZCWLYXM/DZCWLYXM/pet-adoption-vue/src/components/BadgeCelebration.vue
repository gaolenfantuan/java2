<script setup>
defineProps({
  badge: { type: Object, required: true }
})
defineEmits(['close'])
</script>

<template>
  <div class="celebrate-mask" @click.self="$emit('close')">
    <div class="celebrate-card" :style="{ '--badge-color': badge.color }">
      <div class="confetti" aria-hidden="true">
        <span v-for="n in 10" :key="n" :style="{ '--i': n }"></span>
      </div>
      <p class="celebrate-label">🎉 解锁新徽章 🎉</p>
      <div class="celebrate-medal">
        <span>{{ badge.icon }}</span>
      </div>
      <h2>{{ badge.name }}</h2>
      <p class="celebrate-desc">{{ badge.desc }}</p>
      <button type="button" @click="$emit('close')">好耶！</button>
    </div>
  </div>
</template>

<style scoped>
.celebrate-mask {
  position: fixed;
  inset: 0;
  z-index: 80;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: rgba(43, 43, 43, 0.42);
}

.celebrate-card {
  position: relative;
  width: min(320px, 100%);
  padding: 30px 24px 24px;
  text-align: center;
  background: #fffdf6;
  border: var(--line);
  border-radius: 26px;
  box-shadow: 10px 11px 0 var(--ink);
  font-family: "Comic Sans MS", "YouYuan", "幼圆", "Microsoft YaHei", sans-serif;
  color: var(--ink);
  animation: celebrate-pop 0.45s cubic-bezier(0.2, 1.5, 0.4, 1) both;
  overflow: hidden;
}

@keyframes celebrate-pop {
  from { opacity: 0; transform: scale(0.7) rotate(-8deg); }
  to { opacity: 1; transform: scale(1) rotate(0); }
}

.celebrate-label {
  margin: 0 0 14px;
  font-size: 13px;
  font-weight: 900;
  color: #d8385b;
}

.celebrate-medal {
  width: 104px;
  height: 104px;
  margin: 0 auto 12px;
  display: grid;
  place-items: center;
  background: var(--badge-color);
  border: var(--line);
  border-radius: 50%;
  box-shadow: 7px 8px 0 var(--ink), inset -8px -10px 0 rgba(43, 43, 43, 0.12);
  animation: medal-bob 2s ease-in-out infinite;
}

.celebrate-medal span {
  font-size: 54px;
  line-height: 1;
  filter: drop-shadow(4px 5px 0 rgba(43, 43, 43, 0.2));
}

@keyframes medal-bob {
  0%, 100% { translate: 0 0; rotate: -4deg; }
  50% { translate: 0 -9px; rotate: 4deg; }
}

.celebrate-card h2 { margin: 0 0 6px; font-size: 24px; }
.celebrate-desc { margin: 0 0 20px; font-size: 12px; font-weight: 700; color: #8a6a4f; }

.celebrate-card button {
  padding: 10px 26px;
  font: inherit;
  font-size: 14px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: 12px;
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
}
.celebrate-card button:active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

.confetti { position: absolute; inset: 0; pointer-events: none; }
.confetti span {
  position: absolute;
  top: -10px;
  left: calc(var(--i) * 10%);
  width: 9px;
  height: 14px;
  background: var(--badge-color);
  border: 1.5px solid var(--ink);
  border-radius: 2px;
  opacity: 0;
  animation: confetti-fall 1.6s ease-in forwards;
  animation-delay: calc(var(--i) * 0.08s);
}
.confetti span:nth-child(even) { background: var(--pink); }
.confetti span:nth-child(3n) { background: var(--mint); }

@keyframes confetti-fall {
  0% { opacity: 0; transform: translateY(0) rotate(0deg); }
  15% { opacity: 1; }
  100% { opacity: 0; transform: translateY(300px) rotate(420deg); }
}
</style>
