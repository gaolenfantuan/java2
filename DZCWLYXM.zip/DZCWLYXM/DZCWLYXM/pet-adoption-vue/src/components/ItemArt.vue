<script setup>
// 商品矢量插画：统一的 3px 黑描边 + 马卡龙配色，保证商城 / 背包 / 首页的气质一致
defineProps({
  art: { type: String, default: 'can' }
})
</script>

<template>
  <svg class="item-art" viewBox="0 0 80 80" role="img" aria-hidden="true">
    <g
      fill="none"
      stroke="#2b2b2b"
      stroke-width="3"
      stroke-linejoin="round"
      stroke-linecap="round"
    >
      <!-- 三文鱼罐头 -->
      <g v-if="art === 'can'">
        <rect x="17" y="24" width="46" height="40" rx="11" fill="#ffb3c9" />
        <ellipse cx="40" cy="23.5" rx="23" ry="7.5" fill="#ffe9c9" />
        <ellipse cx="40" cy="23.5" rx="13" ry="4" fill="#fffdf6" stroke-width="2" />
        <rect x="17" y="39" width="46" height="16" fill="#fffdf6" stroke-width="0" />
        <path d="M17 39h46M17 55h46" stroke-width="2.4" />
        <path d="M28 47q7-5 14 0-7 5-14 0z" fill="#ff9ec4" stroke-width="2.2" />
        <path d="M42 47l7-5v10z" fill="#ff9ec4" stroke-width="2.2" />
        <path d="M24 34v-3" stroke-width="2" opacity="0.45" />
      </g>

      <!-- 冻干袋 -->
      <g v-else-if="art === 'freeze'">
        <path d="M21 25h38l-4 41a7 7 0 0 1-7 6H32a7 7 0 0 1-7-6z" fill="#f6dfb4" />
        <path d="M21 25l6.3 5 6.3-5 6.4 5 6.4-5 6.3 5 6.3-5" fill="none" stroke-width="2.6" />
        <circle cx="40" cy="49" r="13" fill="#fffdf6" />
        <path d="M34 45q6-4 12 0-6 4-12 0z" fill="#ffd84d" stroke-width="2" />
        <path d="M45 45l5-3.5v7z" fill="#ffd84d" stroke-width="2" />
        <path d="M34 56h12" stroke-width="2" opacity="0.45" />
      </g>

      <!-- 羊奶布丁 -->
      <g v-else-if="art === 'pudding'">
        <path d="M22 34h36l-5 29a9 9 0 0 1-8.8 7.5H35.8A9 9 0 0 1 27 63z" fill="#ffe9b8" />
        <ellipse cx="40" cy="34" rx="18" ry="6.5" fill="#fff5d6" />
        <path d="M31 33q4-12 9-3 5 9 9-2 3-6 5 1" stroke-width="3" />
        <circle cx="40" cy="24" r="4.5" fill="#ff9ec4" stroke-width="2.2" />
        <path d="M31 49h18" stroke-width="2" opacity="0.4" />
      </g>

      <!-- 毛线球 -->
      <g v-else-if="art === 'yarn'">
        <path d="M52 30l16-14" stroke-width="4" />
        <path d="M16 64l14-8" stroke-width="4" />
        <circle cx="38" cy="44" r="20" fill="#9fd3ff" />
        <path d="M22 33q23 8 20 29M25 53q17-6 26 8M32 26q15 9 13 33" stroke-width="2.4" />
        <circle cx="30" cy="38" r="1.6" fill="#2b2b2b" stroke="none" opacity="0.3" />
      </g>

      <!-- 星星逗猫棒 -->
      <g v-else-if="art === 'wand'">
        <path d="M20 66L52 30" stroke-width="5" />
        <path d="M58 10l2.6 6.2 6.4.6-4.8 4.4 1.4 6.4L58 24.2 52.4 27.6l1.4-6.4-4.8-4.4 6.4-.6z" fill="#ffd84d" stroke-width="2.6" />
        <circle cx="49" cy="35" r="5" fill="#ffd84d" />
        <path d="M49 33v4" stroke-width="2" />
        <path d="M26 56l4 4M32 50l4 4" stroke-width="2" opacity="0.5" />
      </g>

      <!-- 发声小鱼 -->
      <g v-else-if="art === 'fish'">
        <ellipse cx="36" cy="43" rx="21" ry="14" fill="#9fd3ff" />
        <path d="M55 43l15-11v22z" fill="#9fd3ff" />
        <circle cx="29" cy="39" r="2.8" fill="#2b2b2b" stroke="none" />
        <path d="M33 49q6 5 11 0" stroke-width="2.4" />
        <path d="M36 29v-8M46 31l4-7" stroke-width="2.6" />
        <path d="M20 41q4-4 8-2" stroke-width="2" opacity="0.6" />
        <circle cx="62" cy="20" r="3.4" stroke-width="2.2" />
        <circle cx="52" cy="14" r="2.2" stroke-width="2" />
      </g>

      <!-- 磨牙骨头 -->
      <g v-else-if="art === 'bone'">
        <path d="M27 30a9 9 0 0 0-9 9 9 9 0 0 0 4.5 7.8A9 9 0 1 0 35 53h10a9 9 0 1 0 12.5-6.2A9 9 0 0 0 62 39a9 9 0 0 0-9-9 9 9 0 0 0-6.8 3H33.8A9 9 0 0 0 27 30z" fill="#fffdf6" />
        <path d="M33 40h14" stroke-width="2" opacity="0.35" />
      </g>

      <!-- 按摩梳 -->
      <g v-else-if="art === 'brush'">
        <path d="M40 42v14a9 9 0 0 0 18 0" stroke-width="11" />
        <path d="M40 42v14a9 9 0 0 0 18 0" stroke="#8fd9c4" stroke-width="5" />
        <rect x="21" y="16" width="38" height="26" rx="12" fill="#8fd9c4" />
        <path d="M27 22h26" stroke-width="2" opacity="0.45" />
        <g fill="#2b2b2b" stroke="none">
          <circle cx="28" cy="35" r="1.7" />
          <circle cx="34" cy="35" r="1.7" />
          <circle cx="40" cy="35" r="1.7" />
          <circle cx="46" cy="35" r="1.7" />
          <circle cx="52" cy="35" r="1.7" />
        </g>
      </g>

      <!-- 便携水壶 -->
      <g v-else-if="art === 'bottle'">
        <rect x="27" y="22" width="26" height="44" rx="10" fill="#9fd3ff" />
        <rect x="31" y="12" width="18" height="12" rx="4" fill="#ffd84d" />
        <rect x="27" y="34" width="26" height="15" fill="#fffdf6" stroke-width="0" />
        <path d="M27 34h26M27 49h26" stroke-width="2.4" />
        <path d="M35 41h10" stroke-width="2" />
        <path d="M33 25v5" stroke-width="2" opacity="0.5" />
      </g>

      <!-- 猫抓板 -->
      <g v-else-if="art === 'scratcher'">
        <path d="M14 61l10-35h32l10 35z" fill="#e8c79a" />
        <path d="M21 52h38M23 45h34M25 38h30M27 31h26" stroke-width="2" opacity="0.5" />
        <path d="M40 57q5-6 10-1" stroke-width="2.4" />
        <circle cx="40" cy="24" r="5" fill="#ff9ec4" stroke-width="2.2" />
        <path d="M40 19v-3" stroke-width="2.2" />
      </g>

      <!-- 营养膏 -->
      <g v-else-if="art === 'vitamin'">
        <rect x="26" y="24" width="28" height="42" rx="9" fill="#ffd9a8" />
        <rect x="32" y="14" width="16" height="11" rx="3.5" fill="#ff9ec4" />
        <path d="M26 33h28" stroke-width="2" opacity="0.4" />
        <circle cx="40" cy="50" r="9" fill="#fffdf6" stroke-width="2.4" />
        <path d="M40 44.4l1.6 3.5 3.8.3-2.9 2.5.9 3.8-3.4-2-3.4 2 .9-3.8-2.9-2.5 3.8-.3z" fill="#ffd84d" stroke-width="1.6" />
      </g>

      <!-- 驱虫药瓶 -->
      <g v-else-if="art === 'deworm'">
        <rect x="25" y="26" width="30" height="40" rx="8" fill="#ffb3c9" />
        <rect x="31" y="15" width="18" height="13" rx="3.5" fill="#fffdf6" />
        <rect x="25" y="40" width="30" height="15" fill="#fffdf6" stroke-width="0" />
        <path d="M25 40h30M25 55h30" stroke-width="2.4" />
        <path d="M37 47.5h6M40 44.5v6" stroke-width="3" />
        <path d="M30 32h4M46 32h4" stroke-width="2" opacity="0.45" />
      </g>

      <!-- 益生菌 -->
      <g v-else-if="art === 'probiotic'">
        <path d="M22 28h36v25a11 11 0 0 1-11 11H33a11 11 0 0 1-11-11z" fill="#c9f2df" />
        <path d="M25 25l-3 3 3-11h30l3 11-3-3z" fill="#e8fff5" stroke-width="2.6" />
        <path d="M22 28h36" stroke-width="2.4" />
        <path d="M33 47q7 6 14 0" stroke-width="2.4" />
        <path d="M40 39v4" stroke-width="2.4" />
        <circle cx="33" cy="57" r="2" fill="#2b2b2b" stroke="none" opacity="0.28" />
        <circle cx="47" cy="57" r="2" fill="#2b2b2b" stroke="none" opacity="0.28" />
      </g>

      <!-- 格纹小领巾 -->
      <g v-else-if="art === 'bow'">
        <path d="M40 42C30 30 20 32 20 42s10 12 20 0z" fill="#ff9ec4" />
        <path d="M40 42c10-12 20-10 20 0s-10 12-20 0z" fill="#ff9ec4" />
        <path d="M40 50l-8 17 8-4 8 4-8-17" fill="#ffd84d" stroke-width="2.4" />
        <circle cx="40" cy="42" r="6.5" fill="#ffd84d" />
        <path d="M27 36l7 4M53 36l-7 4" stroke-width="2" opacity="0.5" />
        <path d="M40 60v5" stroke-width="2" opacity="0.4" />
      </g>

      <!-- 小皇冠 -->
      <g v-else-if="art === 'crown'">
        <path d="M16 56l4-28 13 11 7-18 7 18 13-11 4 28z" fill="#ffd84d" />
        <path d="M16 56h48" stroke-width="2.6" />
        <circle cx="40" cy="35" r="3" fill="#ff9ec4" stroke-width="2.2" />
        <circle cx="26" cy="43" r="2.4" fill="#9fd3ff" stroke-width="2" />
        <circle cx="54" cy="43" r="2.4" fill="#8fd9c4" stroke-width="2" />
      </g>

      <!-- 铃铛项圈 -->
      <g v-else-if="art === 'bell'">
        <path d="M31 29c0-7 3-9 3-9M49 29c0-7-3-9-3-9" stroke-width="2.4" />
        <path d="M24 54a16 16 0 0 1 32 0z" fill="#ffd84d" />
        <path d="M20 54h40" stroke-width="3" />
        <circle cx="40" cy="60" r="5" fill="#ff9b54" />
        <path d="M40 54v-7" stroke-width="2" opacity="0.4" />
      </g>

      <!-- 兜底：小爪印 -->
      <g v-else>
        <circle cx="40" cy="45" r="14" fill="#ffd84d" />
        <g fill="#fffdf6" stroke-width="0">
          <ellipse cx="40" cy="49" rx="7" ry="6" />
          <circle cx="33" cy="40" r="3.4" />
          <circle cx="40" cy="38" r="3.4" />
          <circle cx="47" cy="40" r="3.4" />
        </g>
      </g>
    </g>
  </svg>
</template>

<style scoped>
.item-art {
  display: block;
  width: 100%;
  height: 100%;
  overflow: visible;
}
</style>
