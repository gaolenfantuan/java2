<script setup>
// 游戏币图标：全站统一的小金币，避免各处用 emoji 造成的风格差异
defineProps({
  size: { type: [Number, String], default: 20 }
})
</script>

<template>
  <svg
    class="coin-icon"
    :width="size"
    :height="size"
    viewBox="0 0 32 32"
    role="img"
    aria-label="游戏币"
  >
    <!-- 厚度投影 -->
    <circle cx="16" cy="18" r="12.5" fill="#d9a132" stroke="#2b2b2b" stroke-width="2.4" />
    <!-- 币面 -->
    <circle cx="16" cy="15.5" r="12.5" fill="#ffd84d" stroke="#2b2b2b" stroke-width="2.4" />
    <!-- 内圈 -->
    <circle cx="16" cy="15.5" r="8.6" fill="#ffe89b" stroke="#2b2b2b" stroke-width="1.8" />
    <!-- 爪印 -->
    <g fill="#2b2b2b">
      <ellipse cx="16" cy="18.4" rx="3.1" ry="2.6" />
      <circle cx="12.6" cy="14.6" r="1.5" />
      <circle cx="16" cy="13.5" r="1.5" />
      <circle cx="19.4" cy="14.6" r="1.5" />
    </g>
    <!-- 高光 -->
    <path d="M10.2 8.6Q13 6.4 16 6.2" fill="none" stroke="#fffdf6" stroke-width="1.8" stroke-linecap="round" opacity="0.85" />
  </svg>
</template>

<style scoped>
.coin-icon {
  display: inline-block;
  flex: 0 0 auto;
  vertical-align: middle;
}
</style>
