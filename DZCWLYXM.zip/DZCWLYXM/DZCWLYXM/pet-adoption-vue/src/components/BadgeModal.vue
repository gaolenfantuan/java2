<script setup>
import { computed } from 'vue'

const props = defineProps({
  badge: { type: Object, required: true },
  unlocked: { type: Boolean, default: false },
  worn: { type: Boolean, default: false },
  progress: { type: Object, default: () => ({ cur: 0, target: 1 }) },
  unlockedAt: { type: Number, default: 0 }
})

const emit = defineEmits(['close', 'wear', 'unwear', 'goto'])

const percent = computed(() => {
  const target = Math.max(1, Number(props.progress.target) || 1)
  return Math.min(100, Math.round((Number(props.progress.cur) / target) * 100))
})

const remain = computed(() => Math.max(0, (Number(props.progress.target) || 1) - (Number(props.progress.cur) || 0)))

const unlockedDate = computed(() => {
  if (!props.unlockedAt) return ''
  const d = new Date(props.unlockedAt)
  const p = n => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
})
</script>

<template>
  <div class="bm-mask" @click.self="emit('close')">
    <div class="bm-card" :class="{ locked: !unlocked }" :style="{ '--badge-color': badge.color }">
      <button type="button" class="bm-close" aria-label="关闭" @click="emit('close')">✕</button>

      <template v-if="unlocked">
        <p class="bm-label">🎉 已解锁的徽章</p>
        <div class="bm-stage">
          <span class="bm-ray" aria-hidden="true"></span>
          <div class="bm-medal"><span>{{ badge.icon }}</span></div>
        </div>
        <h2>{{ badge.name }}</h2>
        <p class="bm-desc">{{ badge.desc }}</p>
        <p v-if="unlockedDate" class="bm-date">解锁于 {{ unlockedDate }}</p>

        <div class="bm-actions">
          <button
            v-if="!worn"
            type="button"
            class="mp-btn primary"
            @click="emit('wear', badge)"
          >📌 佩戴到主页</button>
          <button
            v-else
            type="button"
            class="mp-btn mint"
            @click="emit('unwear')"
          >✓ 佩戴中 · 点击取下</button>
          <button type="button" class="mp-btn" @click="emit('close')">收起</button>
        </div>
        <p class="bm-foot">佩戴后会在主页和头像上展示，随时可以换～</p>
      </template>

      <template v-else>
        <p class="bm-label locked-label">🔒 还未解锁</p>
        <div class="bm-stage">
          <div class="bm-medal locked-medal"><span>{{ badge.icon }}</span><em>🔒</em></div>
        </div>
        <h2>{{ badge.name }}</h2>
        <p class="bm-desc">{{ badge.desc }}</p>

        <div class="bm-progress">
          <div class="bm-track"><div class="bm-fill" :style="{ width: percent + '%' }"></div></div>
          <div class="bm-progress-row">
            <span>当前进度 {{ progress.cur }} / {{ progress.target }}</span>
            <span v-if="remain">还差 {{ remain }} 步</span>
            <span v-else>马上就好啦</span>
          </div>
        </div>

        <p class="bm-tip">💡 {{ badge.tip }}</p>

        <div class="bm-actions">
          <button type="button" class="mp-btn primary" @click="emit('goto', badge.cta.path)">{{ badge.cta.label }}</button>
          <button type="button" class="mp-btn" @click="emit('close')">先逛逛</button>
        </div>
      </template>
    </div>
  </div>
</template>

<style scoped>
.bm-mask {
  position: fixed;
  inset: 0;
  z-index: 78;
  display: grid;
  place-items: center;
  padding: 22px;
  background: rgba(43, 43, 43, 0.46);
  animation: bm-fade 0.22s ease both;
}
@keyframes bm-fade { from { opacity: 0; } to { opacity: 1; } }

.bm-card {
  position: relative;
  width: min(400px, 100%);
  max-height: 90vh;
  overflow-y: auto;
  padding: 30px 26px 24px;
  text-align: center;
  background: #fffdf6;
  border: var(--line);
  border-radius: 20px;
  box-shadow: 10px 12px 0 var(--ink);
  animation: bm-pop 0.34s cubic-bezier(0.2, 1.45, 0.4, 1) both;
}
@keyframes bm-pop {
  from { opacity: 0; transform: scale(0.86) translateY(18px); }
  to { opacity: 1; transform: none; }
}
.bm-card.locked { background: #fdf8ef; }

.bm-close {
  position: absolute;
  right: 14px;
  top: 14px;
  width: 30px;
  height: 30px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #ffc9cf;
  border: 2px solid var(--ink);
  border-radius: 50%;
  cursor: pointer;
}
.bm-close:hover { background: #ffb3bb; }

.bm-label {
  margin: 0 0 16px;
  font-size: 12px;
  font-weight: 900;
  letter-spacing: 0.4px;
  color: #d8385b;
}
.locked-label { color: var(--text-3); }

.bm-stage {
  position: relative;
  width: 132px;
  height: 132px;
  margin: 0 auto 16px;
  display: grid;
  place-items: center;
}
.bm-ray {
  position: absolute;
  inset: -10px;
  border-radius: 50%;
  background: conic-gradient(
    from 0deg,
    rgba(255, 216, 77, 0.55) 0 8deg,
    transparent 8deg 30deg
  );
  animation: bm-spin 9s linear infinite;
}
@keyframes bm-spin { to { transform: rotate(360deg); } }

.bm-medal {
  position: relative;
  width: 112px;
  height: 112px;
  display: grid;
  place-items: center;
  background: var(--badge-color);
  border: var(--line);
  border-radius: 50%;
  box-shadow: 7px 8px 0 var(--ink), inset -8px -10px 0 rgba(43, 43, 43, 0.12);
  animation: bm-bob 2.6s ease-in-out infinite;
}
.bm-medal span { font-size: 54px; line-height: 1; filter: drop-shadow(4px 5px 0 rgba(43, 43, 43, 0.18)); }
@keyframes bm-bob {
  0%, 100% { translate: 0 0; rotate: -4deg; }
  50% { translate: 0 -8px; rotate: 4deg; }
}
.locked-medal { background: #d9d3c9; box-shadow: 6px 7px 0 #b6ab9c, inset -8px -10px 0 rgba(43, 43, 43, 0.08); filter: grayscale(1); }
.locked-medal span { opacity: 0.55; }
.locked-medal em {
  position: absolute;
  right: -6px;
  bottom: -4px;
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  font-size: 15px;
  font-style: normal;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 50%;
  filter: none;
}

.bm-card h2 { margin: 0 0 6px; font-size: 23px; }
.bm-desc { margin: 0 0 6px; font-size: 12.5px; font-weight: 700; color: var(--text-2); line-height: 1.7; }
.bm-date { margin: 0 0 18px; font-size: 11px; font-weight: 900; color: var(--text-3); }

.bm-progress { margin: 16px 0 4px; }
.bm-track {
  height: 15px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  overflow: hidden;
  box-shadow: 2px 2px 0 var(--ink);
}
.bm-fill {
  height: 100%;
  background: linear-gradient(90deg, #fff0b3, var(--badge-color, var(--yellow)));
  border-right: 2px solid var(--ink);
  border-radius: var(--r-sm);
  transition: width 0.5s cubic-bezier(0.2, 1, 0.4, 1);
}
.bm-progress-row {
  display: flex;
  justify-content: space-between;
  margin-top: 7px;
  font-size: 11px;
  font-weight: 900;
  color: var(--text-3);
}

.bm-tip {
  margin: 14px 0 20px;
  padding: 11px 13px;
  font-size: 11.5px;
  font-weight: 700;
  line-height: 1.7;
  text-align: left;
  color: var(--text-2);
  background: #fff6d9;
  border: 2px dashed rgba(43, 43, 43, 0.35);
  border-radius: var(--r-sm);
}

.bm-actions { display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; }
.bm-foot { margin: 14px 0 0; font-size: 10.5px; font-weight: 700; color: var(--text-3); }
</style>
