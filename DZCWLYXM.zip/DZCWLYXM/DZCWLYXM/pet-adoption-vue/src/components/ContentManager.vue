<script setup>
// ============================================================
// 首页内容统一管理后台
// 分类 / 列表 / 搜索筛选 / 分页 / 拖拽排序 / 上下架 /
// 分类自适应表单（图片上传、跳转链接、富文本、宠物绑定）/ 首页预览
// 数据与前台首页共用 src/data/homeContent.js，改动即时生效。
// ============================================================
import { computed, nextTick, onBeforeUnmount, ref, watch } from 'vue'
import { homePets } from '../data/homePets'
import {
  addCategory, addItem, applyWeightOrder, categoryNameOf, contentCategories,
  contentItems, deleteCategory, deleteItem, findCategory, formatCover,
  itemsOfCategory, restoreBuiltinBoards, resetContent, updateCategory, updateItem
} from '../data/homeContent'

const notifyText = ref('')
let notifyTimer = null
function notify(message, type = 'ok') {
  notifyText.value = { message, type }
  clearTimeout(notifyTimer)
  notifyTimer = setTimeout(() => { notifyText.value = null }, 2600)
}

// ---------------- 分类管理 ----------------
const activeCategoryId = ref('all')
const categoryDialogOpen = ref(false)
const editingCategoryId = ref(null)
const categoryForm = ref({ name: '', icon: '', desc: '' })
const categoryError = ref('')

function openCategoryDialog(category) {
  editingCategoryId.value = category?.id || null
  categoryForm.value = {
    name: category?.name || '',
    icon: category?.icon || '🧩',
    desc: category?.desc || ''
  }
  categoryError.value = ''
  categoryDialogOpen.value = true
}

function saveCategory() {
  const name = categoryForm.value.name.trim()
  if (!name) { categoryError.value = '请输入分类名称'; return }
  if (contentCategories.value.some(c =>
    c.name === name && c.id !== editingCategoryId.value)) {
    categoryError.value = '已经有一个同名分类啦'
    return
  }
  if (editingCategoryId.value) {
    updateCategory(editingCategoryId.value, {
      name,
      icon: categoryForm.value.icon.trim() || '🧩',
      desc: categoryForm.value.desc.trim()
    })
    notify('分类已更新，首页板块名称同步修改')
  } else {
    const created = addCategory({
      name,
      icon: categoryForm.value.icon.trim() || '🧩',
      desc: categoryForm.value.desc.trim()
    })
    activeCategoryId.value = created.id
    notify('分类已新增，首页会出现对应板块')
  }
  categoryDialogOpen.value = false
}

function removeCategory(category) {
  const count = itemsOfCategory(category.id).length
  const tip = count
    ? `删除「${category.name}」会同时删除该板块下的 ${count} 条内容，确定吗？`
    : `确定删除分类「${category.name}」吗？`
  if (!window.confirm(tip)) return
  deleteCategory(category.id)
  if (activeCategoryId.value === category.id) activeCategoryId.value = 'all'
  notify('分类已删除，首页对应板块已移除')
}

function doRestoreBoards() {
  if (!window.confirm('恢复六个内置首页板块（不会删除已有内容），确定吗？')) return
  restoreBuiltinBoards()
  notify('内置板块已恢复')
}

function doResetContent() {
  if (!window.confirm('确定把所有首页内容恢复为初始示例数据吗？当前自定义内容会清空。')) return
  resetContent()
  activeCategoryId.value = 'all'
  notify('首页内容已恢复初始数据')
}

// ---------------- 列表筛选 / 分页 ----------------
const keyword = ref('')
const statusFilter = ref('all')
const page = ref(1)
const size = 8

const filteredItems = computed(() => {
  const kw = keyword.value.trim().toLowerCase()
  return contentItems.value
    .filter(item => {
      if (activeCategoryId.value !== 'all' && item.categoryId !== activeCategoryId.value) return false
      if (statusFilter.value === 'on' && Number(item.status) !== 1) return false
      if (statusFilter.value === 'off' && Number(item.status) === 1) return false
      if (!kw) return true
      return [item.title, item.summary, item.tag, categoryNameOf(item.categoryId)]
        .some(value => String(value || '').toLowerCase().includes(kw))
    })
    .sort((a, b) => (Number(b.weight) || 0) - (Number(a.weight) || 0))
})

const totalPages = computed(() => Math.max(1, Math.ceil(filteredItems.value.length / size)))
const pagedItems = computed(() => filteredItems.value.slice((page.value - 1) * size, page.value * size))

watch([activeCategoryId, keyword, statusFilter], () => { page.value = 1 })

function changePage(delta) {
  page.value = Math.min(totalPages.value, Math.max(1, page.value + delta))
}

function categoryCount(id) {
  return contentItems.value.filter(item => item.categoryId === id).length
}

// ---------------- 拖拽排序 ----------------
const dragId = ref(null)
const dragOverId = ref(null)

function onDragStart(event, item) {
  dragId.value = item.id
  event.dataTransfer.effectAllowed = 'move'
  event.dataTransfer.setData('text/plain', item.id)
}

function onDragOver(event, item) {
  if (!dragId.value || dragId.value === item.id) return
  event.preventDefault()
  dragOverId.value = item.id
}

function onDrop(event, target) {
  event.preventDefault()
  const sourceId = dragId.value
  dragId.value = null
  dragOverId.value = null
  if (!sourceId || sourceId === target.id) return

  const ordered = [...contentItems.value]
    .sort((a, b) => (Number(b.weight) || 0) - (Number(a.weight) || 0))
    .map(item => item.id)
    .filter(id => id !== sourceId)
  const targetIndex = ordered.indexOf(target.id)
  ordered.splice(targetIndex < 0 ? ordered.length : targetIndex, 0, sourceId)
  applyWeightOrder(ordered)
  notify('排序已更新，首页展示顺序同步生效')
}

function onDragEnd() {
  dragId.value = null
  dragOverId.value = null
}

// ---------------- 新增 / 编辑内容 ----------------
const dialogOpen = ref(false)
const editingId = ref(null)
const form = ref({})
const formError = ref('')
const uploadError = ref('')
const editorRef = ref(null)
const fileInputRef = ref(null)

const currentCategoryKey = computed(() =>
  findCategory(form.value.categoryId)?.key || 'custom'
)
const isRichCategory = computed(() => ['notice', 'tip', 'popup'].includes(currentCategoryKey.value))
const needCover = computed(() => ['carousel', 'event', 'popup'].includes(currentCategoryKey.value))
const needLink = computed(() => ['carousel', 'event', 'popup'].includes(currentCategoryKey.value))
const needPet = computed(() => currentCategoryKey.value === 'featured')

const coverPreview = computed(() => formatCover(form.value.cover, form.value.emoji))

function emptyForm() {
  return {
    title: '', summary: '', emoji: '🎀', tag: '',
    categoryId: activeCategoryId.value !== 'all'
      ? activeCategoryId.value
      : (contentCategories.value[0]?.id || ''),
    cover: '', link: '', html: '', petId: null,
    weight: (contentItems.value.reduce((max, item) => Math.max(max, Number(item.weight) || 0), 0) + 10),
    likes: 0, views: 0, hot: false, status: 1
  }
}

function openDialog(item) {
  editingId.value = item?.id || null
  form.value = item
    ? {
        ...item,
        weight: Number(item.weight) || 0,
        status: Number(item.status) === 1 ? 1 : 0,
        hot: !!item.hot,
        html: item.html || '',
        cover: item.cover || '',
        link: item.link || '',
        petId: item.petId || null
      }
    : emptyForm()
  formError.value = ''
  uploadError.value = ''
  dialogOpen.value = true
  if (isRichCategory.value) {
    nextTick(() => {
      if (editorRef.value) editorRef.value.innerHTML = form.value.html || ''
    })
  }
}

watch(currentCategoryKey, key => {
  if (!dialogOpen.value) return
  if (['notice', 'tip', 'popup'].includes(key)) {
    nextTick(() => { if (editorRef.value) editorRef.value.innerHTML = form.value.html || '' })
  }
})

function syncEditor() {
  if (editorRef.value) form.value.html = editorRef.value.innerHTML
}

function exec(command, value = null) {
  editorRef.value?.focus()
  document.execCommand(command, false, value)
  syncEditor()
}

function insertHtml(html) {
  editorRef.value?.focus()
  document.execCommand('insertHTML', false, html)
  syncEditor()
}

function onCoverFile(event) {
  const file = event.target.files?.[0]
  if (!file) return
  if (file.size > 1.5 * 1024 * 1024) {
    uploadError.value = '图片请小于 1.5 MB（本地存储有容量限制）'
    return
  }
  uploadError.value = ''
  const reader = new FileReader()
  reader.onload = () => { form.value.cover = String(reader.result) }
  reader.readAsDataURL(file)
  event.target.value = ''
}

function saveContent() {
  if (!form.value.title?.trim()) { formError.value = '请填写内容标题'; return }
  if (!form.value.categoryId) { formError.value = '请选择所属板块分类'; return }
  const html = String(form.value.html || '').replace(/<script[\s\S]*?<\/script>/gi, '')
  const record = {
    title: form.value.title.trim(),
    summary: String(form.value.summary || '').trim(),
    emoji: String(form.value.emoji || '').trim() || '🎀',
    tag: String(form.value.tag || '').trim(),
    categoryId: form.value.categoryId,
    cover: String(form.value.cover || '').trim(),
    link: String(form.value.link || '').trim(),
    html,
    petId: needPet.value ? (form.value.petId || null) : null,
    weight: Number(form.value.weight) || 0,
    likes: Number(form.value.likes) || 0,
    views: Number(form.value.views) || 0,
    hot: !!form.value.hot,
    status: Number(form.value.status) === 1 ? 1 : 0
  }
  if (editingId.value) {
    updateItem(editingId.value, record)
    notify(record.status === 1 ? '已保存并同步到首页' : '已保存并下架，首页不再展示')
  } else {
    addItem({ ...record, createTime: new Date().toLocaleString('zh-CN', { hour12: false }) })
    notify(record.status === 1 ? '新增成功，首页已展示' : '新增成功（当前为下架状态）')
  }
  dialogOpen.value = false
}

function removeContent(item) {
  if (!window.confirm(`确定删除「${item.title}」吗？首页也会同步移除。`)) return
  deleteItem(item.id)
  notify('内容已删除，首页同步更新')
}

function toggleStatus(item) {
  const next = Number(item.status) === 1 ? 0 : 1
  updateItem(item.id, { status: next })
  notify(next === 1 ? '已上架，首页正在展示' : '已下架，首页不再展示')
}

function previewItem(item) {
  window.open(`/?preview=${encodeURIComponent(item.id)}`, '_blank', 'noopener')
}

function coverStyle(item) {
  const { image, gradient } = formatCover(item.cover, item.emoji)
  return image
    ? `center / cover no-repeat url("${image}")`
    : (gradient || 'linear-gradient(135deg,#ffe3ef,#ffd9b8)')
}

function onKeydown(event) {
  if (event.key === 'Escape') {
    dialogOpen.value = false
    categoryDialogOpen.value = false
  }
}
window.addEventListener('keydown', onKeydown)
onBeforeUnmount(() => {
  window.removeEventListener('keydown', onKeydown)
  clearTimeout(notifyTimer)
})
</script>

<template>
  <div class="cm-page">
    <!-- 分类管理 -->
    <div class="cm-card cm-category-card">
      <div class="cm-card-head">
        <div>
          <h2>🗂️ 首页板块分类</h2>
          <p>每个板块单独归类，点击标签筛选内容；修改分类名称会同步到首页板块标题。</p>
        </div>
        <div class="cm-head-actions">
          <button type="button" class="cm-btn ghost small" @click="doRestoreBoards">恢复内置板块</button>
          <button type="button" class="cm-btn ghost small" @click="doResetContent">恢复初始内容</button>
          <button type="button" class="cm-btn primary small" @click="openCategoryDialog(null)">＋ 新增分类</button>
        </div>
      </div>

      <div class="cm-board-list">
        <button
          type="button"
          class="cm-board-chip"
          :class="{ active: activeCategoryId === 'all' }"
          @click="activeCategoryId = 'all'"
        >🌈 全部内容 <em>{{ contentItems.length }}</em></button>

        <div v-for="category in contentCategories" :key="category.id" class="cm-board-wrap">
          <button
            type="button"
            class="cm-board-chip"
            :class="{ active: activeCategoryId === category.id }"
            @click="activeCategoryId = category.id"
          >
            <span>{{ category.icon || '🧩' }}</span>{{ category.name }}
            <em>{{ categoryCount(category.id) }}</em>
          </button>
          <span class="cm-board-tools">
            <button type="button" title="编辑分类" @click="openCategoryDialog(category)">✏️</button>
            <button type="button" title="删除分类" @click="removeCategory(category)">🗑</button>
          </span>
        </div>
      </div>
      <p class="cm-hint">内置板块：首页轮播 / 推荐宠物 / 首页公告 / 首页活动 / 首页小贴士 / 首页弹窗 · 权重越大展示越靠前</p>
    </div>

    <!-- 内容列表 -->
    <div class="cm-card">
      <div class="cm-toolbar">
        <div class="cm-toolbar-left">
          <label class="cm-search">
            <span>🔍</span>
            <input v-model="keyword" type="search" placeholder="搜索标题 / 简介 / 标签" @keyup.enter="page = 1">
          </label>
          <select v-model="activeCategoryId" class="cm-select" aria-label="按板块筛选">
            <option value="all">全部板块</option>
            <option v-for="category in contentCategories" :key="category.id" :value="category.id">
              {{ category.name }}
            </option>
          </select>
          <select v-model="statusFilter" class="cm-select" aria-label="按状态筛选">
            <option value="all">全部状态</option>
            <option value="on">已上架</option>
            <option value="off">已下架</option>
          </select>
        </div>
        <button type="button" class="cm-btn primary" @click="openDialog(null)">＋ 新增内容</button>
      </div>

      <p class="cm-hint">
        共 {{ filteredItems.length }} 条内容 · 拖动左侧手柄即可调整首页展示顺序 · 所有改动即时同步到前台首页
      </p>

      <div class="cm-table-wrap">
        <table class="cm-table">
          <thead>
            <tr>
              <th class="cm-col-drag">排序</th>
              <th>内容标题</th>
              <th>所属板块</th>
              <th>预览图</th>
              <th>权重</th>
              <th>上架状态</th>
              <th>热度</th>
              <th>创建时间</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in pagedItems"
              :key="item.id"
              draggable="true"
              :class="{ dragging: dragId === item.id, 'drag-over': dragOverId === item.id, offline: Number(item.status) !== 1 }"
              @dragstart="onDragStart($event, item)"
              @dragover="onDragOver($event, item)"
              @drop="onDrop($event, item)"
              @dragend="onDragEnd"
            >
              <td>
                <span class="cm-drag" title="按住拖动排序">⠿</span>
              </td>
              <td>
                <div class="cm-title-cell">
                  <strong>{{ item.title }}</strong>
                  <small>{{ item.summary || '暂无简介' }}</small>
                </div>
              </td>
              <td><span class="cm-chip">{{ categoryNameOf(item.categoryId) }}</span></td>
              <td>
                <span class="cm-cover" :style="{ background: coverStyle(item) }">
                  <img v-if="formatCover(item.cover).image" :src="formatCover(item.cover).image" :alt="item.title">
                  <span v-else>{{ item.emoji || '🎀' }}</span>
                </span>
              </td>
              <td><strong class="cm-weight">{{ item.weight ?? 0 }}</strong></td>
              <td>
                <button
                  type="button"
                  class="cm-switch"
                  :class="{ on: Number(item.status) === 1 }"
                  :aria-pressed="Number(item.status) === 1"
                  @click="toggleStatus(item)"
                >
                  <span class="cm-switch-dot"></span>
                  {{ Number(item.status) === 1 ? '已上架' : '已下架' }}
                </button>
              </td>
              <td>
                <span class="cm-hot" :class="{ on: item.hot }">{{ item.hot ? '🔥 热门' : '普通' }}</span>
              </td>
              <td><small class="cm-time">{{ item.createTime || '—' }}</small></td>
              <td>
                <div class="cm-actions">
                  <button type="button" class="cm-mini" @click="previewItem(item)">预览</button>
                  <button type="button" class="cm-mini" @click="openDialog(item)">编辑</button>
                  <button type="button" class="cm-mini danger" @click="removeContent(item)">删除</button>
                </div>
              </td>
            </tr>
            <tr v-if="!pagedItems.length">
              <td colspan="9" class="cm-empty">🐾 这里还没有内容，点右上角「新增内容」试试吧</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="cm-pager">
        <button type="button" class="cm-btn ghost small" :disabled="page <= 1" @click="changePage(-1)">← 上一页</button>
        <span>第 {{ page }} / {{ totalPages }} 页</span>
        <button type="button" class="cm-btn ghost small" :disabled="page >= totalPages" @click="changePage(1)">下一页 →</button>
      </div>
    </div>

    <!-- 分类弹窗 -->
    <div v-if="categoryDialogOpen" class="cm-mask" @click.self="categoryDialogOpen = false">
      <div class="cm-modal small">
        <div class="cm-modal-head">
          <h2>{{ editingCategoryId ? '✏️ 编辑分类' : '＋ 新增分类' }}</h2>
          <button type="button" class="cm-close" @click="categoryDialogOpen = false">×</button>
        </div>
        <div class="cm-modal-body">
          <div class="cm-form">
            <label>分类名称<input v-model="categoryForm.name" placeholder="例如：首页轮播"></label>
            <label>板块图标<input v-model="categoryForm.icon" maxlength="8" placeholder="🖼️"></label>
            <label class="span-2">板块说明<input v-model="categoryForm.desc" placeholder="这个板块用来展示什么内容"></label>
          </div>
          <p v-if="categoryError" class="cm-error">⚠️ {{ categoryError }}</p>
        </div>
        <div class="cm-modal-foot">
          <button type="button" class="cm-btn ghost" @click="categoryDialogOpen = false">取消</button>
          <button type="button" class="cm-btn primary" @click="saveCategory">保存分类</button>
        </div>
      </div>
    </div>

    <!-- 内容弹窗 -->
    <div v-if="dialogOpen" class="cm-mask" @click.self="dialogOpen = false">
      <div class="cm-modal" role="dialog" aria-modal="true" aria-label="编辑首页内容">
        <div class="cm-modal-head">
          <h2>{{ editingId ? '✏️ 编辑内容' : '＋ 新增内容' }}
            <span class="cm-modal-tag">{{ findCategory(form.categoryId)?.name || '未分类' }}</span>
          </h2>
          <button type="button" class="cm-close" @click="dialogOpen = false">×</button>
        </div>
        <div class="cm-modal-body">
          <div class="cm-form">
            <label class="span-2">内容标题<input v-model="form.title" placeholder="请输入标题"></label>
            <label>所属板块
              <select v-model="form.categoryId">
                <option v-for="category in contentCategories" :key="category.id" :value="category.id">
                  {{ category.icon }} {{ category.name }}
                </option>
              </select>
            </label>
            <label>展示权重<input v-model.number="form.weight" type="number" min="0" placeholder="数字越大越靠前"></label>
            <label>小图标<input v-model="form.emoji" maxlength="8" placeholder="🎀"></label>
            <label>标签<input v-model="form.tag" placeholder="#今日推荐"></label>
            <label>状态
              <select v-model.number="form.status"><option :value="1">上架（首页展示）</option><option :value="0">下架（首页隐藏）</option></select>
            </label>
            <label>点赞数<input v-model.number="form.likes" type="number" min="0"></label>
            <label>浏览数<input v-model.number="form.views" type="number" min="0"></label>
            <label class="cm-check"><input v-model="form.hot" type="checkbox"> 标记为热门内容</label>
          </div>

          <!-- 轮播 / 活动 / 弹窗：图片上传 + 跳转链接 -->
          <template v-if="needCover || needLink">
            <div class="cm-section-title">🖼️ 展示配置</div>
            <div class="cm-form">
              <label class="span-2">
                封面图片（留空则使用下方渐变背景 + 图标）
                <span class="cm-upload-row">
                  <input ref="fileInputRef" type="file" accept="image/*" @change="onCoverFile">
                  <button type="button" class="cm-btn ghost small" @click="fileInputRef?.click()">选择图片</button>
                  <input v-model="form.cover" class="cm-cover-input" placeholder="上传或粘贴图片地址">
                </span>
              </label>
              <label class="span-2">跳转链接
                <input v-model="form.link" placeholder="站内填 /adopt，站外填 https://...">
              </label>
            </div>
            <div class="cm-cover-preview" :style="{ background: coverPreview.gradient || '#fff5d8' }">
              <img v-if="coverPreview.image" :src="coverPreview.image" alt="封面预览">
              <span v-else>{{ coverPreview.emoji }}</span>
              <strong>{{ form.title || '封面预览' }}</strong>
            </div>
            <p v-if="uploadError" class="cm-error">⚠️ {{ uploadError }}</p>
          </template>

          <!-- 推荐宠物：绑定宠物 ID -->
          <template v-if="needPet">
            <div class="cm-section-title">🐾 推荐宠物绑定</div>
            <div class="cm-form">
              <label class="span-2">选择要推荐的毛孩子
                <select v-model="form.petId">
                  <option :value="null">不绑定（使用上方封面展示）</option>
                  <option v-for="pet in homePets" :key="pet.id" :value="pet.id">
                    {{ pet.emoji || '🐾' }} {{ pet.name }} · {{ pet.breed }}
                  </option>
                </select>
              </label>
            </div>
            <p class="cm-hint">绑定后，首页「推荐宠物」板块会展示这只毛孩子的真实卡片，点击可直接进入详情页。</p>
          </template>

          <!-- 公告 / 小贴士 / 弹窗：富文本 -->
          <template v-if="isRichCategory">
            <div class="cm-section-title">📝 富文本内容</div>
            <div class="cm-rich-toolbar">
              <button type="button" title="加粗" @click.prevent="exec('bold')"><b>B</b></button>
              <button type="button" title="斜体" @click.prevent="exec('italic')"><i>I</i></button>
              <button type="button" title="粉色" @click.prevent="exec('foreColor', '#e4558b')">🎀</button>
              <button type="button" title="蓝色" @click.prevent="exec('foreColor', '#3b82c4')">💙</button>
              <button type="button" title="换行" @click.prevent="insertHtml('<br>')">↵</button>
              <button type="button" title="爱心" @click.prevent="insertHtml(' 💕 ')">💕</button>
              <button type="button" title="爪印" @click.prevent="insertHtml(' 🐾 ')">🐾</button>
            </div>
            <div ref="editorRef" class="cm-rich-editor" contenteditable="true" @input="syncEditor"></div>
          </template>

          <label class="cm-summary-label">简短描述
            <textarea v-model="form.summary" rows="2" placeholder="一句话说明这条内容"></textarea>
          </label>

          <p v-if="formError" class="cm-error">⚠️ {{ formError }}</p>
        </div>
        <div class="cm-modal-foot">
          <button type="button" class="cm-btn ghost" @click="dialogOpen = false">取消</button>
          <button type="button" class="cm-btn primary" @click="saveContent">
            {{ editingId ? '保存并同步首页' : '新增并同步首页' }}
          </button>
        </div>
      </div>
    </div>

    <div v-if="notifyText" class="cm-toast" :class="notifyText.type">{{ notifyText.message }}</div>
  </div>
</template>

<style scoped>
.cm-page { display: grid; gap: 16px; }

.cm-card {
  padding: 20px;
  background: var(--paper, #fffdf6);
  border: var(--line, 2px solid #2b2b2b);
  border-radius: var(--r-lg, 18px);
  box-shadow: var(--shadow-2, 5px 6px 0 #2b2b2b), inset 0 2px 8px rgba(255,255,255,.9);
  transition: transform .18s ease, box-shadow .18s ease;
}
.cm-card:hover { transform: translateY(-2px); box-shadow: 6px 9px 0 #2b2b2b, inset 0 2px 8px rgba(255,255,255,.9); }
.cm-card-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 14px; flex-wrap: wrap; margin-bottom: 14px; }
.cm-card-head h2 { margin: 0 0 4px; font-size: 16px; }
.cm-card-head p { margin: 0; font-size: 11px; font-weight: 700; color: var(--text-3, #928879); }
.cm-head-actions { display: flex; flex-wrap: wrap; gap: 8px; }

/* 分类标签 */
.cm-board-list { display: flex; flex-wrap: wrap; gap: 9px; }
.cm-board-wrap { display: inline-flex; align-items: stretch; }
.cm-board-chip {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 8px 13px;
  font: inherit; font-size: 12px; font-weight: 900; color: var(--ink, #2b2b2b);
  background: #fff;
  border: var(--line, 2px solid #2b2b2b);
  border-radius: 99px;
  cursor: pointer;
  transition: transform .15s, box-shadow .15s, background .15s;
}
.cm-board-chip span { font-size: 15px; }
.cm-board-chip em {
  min-width: 18px; padding: 1px 5px; font-size: 10px; font-style: normal;
  background: #fff0b8; border: 1.5px solid #2b2b2b; border-radius: 99px;
}
.cm-board-chip:hover { transform: translateY(-2px); box-shadow: 3px 4px 0 #2b2b2b; }
.cm-board-chip.active { background: var(--yellow, #ffd84d); box-shadow: 3px 3px 0 #2b2b2b; }
.cm-board-wrap .cm-board-chip { border-top-right-radius: 7px; border-bottom-right-radius: 7px; padding-right: 8px; }
.cm-board-tools {
  display: inline-flex; align-items: center; gap: 2px;
  padding: 0 5px 0 3px;
  background: #fff8e9;
  border: 2px solid #2b2b2b; border-left: none;
  border-radius: 0 9px 9px 0;
}
.cm-board-tools button {
  padding: 2px 4px; font-size: 12px; line-height: 1;
  background: transparent; border: none; border-radius: 5px; cursor: pointer;
}
.cm-board-tools button:hover { background: #ffe4ec; }
.cm-hint { margin: 12px 0 0; font-size: 11px; font-weight: 700; color: var(--text-3, #928879); }

/* 工具栏 */
.cm-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-bottom: 6px; }
.cm-toolbar-left { display: flex; flex-wrap: wrap; gap: 9px; }
.cm-search {
  display: inline-flex; align-items: center; gap: 6px; padding: 7px 11px;
  background: #fff; border: var(--line, 2px solid #2b2b2b); border-radius: 12px;
  transition: box-shadow .15s;
}
.cm-search:focus-within { box-shadow: 3px 3px 0 #ff9c4a; }
.cm-search input { width: 190px; font: inherit; font-size: 12px; font-weight: 700; border: none; outline: none; background: transparent; }
.cm-select {
  padding: 8px 10px; font: inherit; font-size: 12px; font-weight: 800;
  color: var(--ink, #2b2b2b); background: #fff;
  border: var(--line, 2px solid #2b2b2b); border-radius: 12px; outline: none;
}

/* 按钮 */
.cm-btn {
  padding: 8px 14px; font: inherit; font-size: 12px; font-weight: 900;
  color: var(--ink, #2b2b2b); background: #fff;
  border: var(--line, 2px solid #2b2b2b); border-radius: 12px;
  box-shadow: 3px 3px 0 #2b2b2b; cursor: pointer;
  transition: transform .15s, box-shadow .15s, filter .15s;
}
.cm-btn.primary { background: var(--yellow, #ffd84d); }
.cm-btn.ghost { background: #fff; box-shadow: none; }
.cm-btn.small { padding: 6px 10px; font-size: 11px; }
.cm-btn:hover:not(:disabled) { transform: translateY(-2px); filter: brightness(1.03); box-shadow: 3px 5px 0 #2b2b2b; }
.cm-btn:active:not(:disabled) { transform: translate(2px, 2px); box-shadow: 1px 1px 0 #2b2b2b; }
.cm-btn:disabled { opacity: .4; cursor: default; }

/* 表格 */
.cm-table-wrap { margin-top: 12px; overflow-x: auto; border: 2px solid rgba(43,43,43,.2); border-radius: 14px; }
.cm-table { width: 100%; min-width: 1020px; border-collapse: collapse; font-size: 12px; }
.cm-table th {
  padding: 11px 10px; text-align: left; white-space: nowrap;
  font-size: 11px; font-weight: 900; color: var(--text-2, #5f574c);
  background: #fff5d8; border-bottom: 2px solid #2b2b2b;
}
.cm-table td { padding: 10px; border-bottom: 1px dashed rgba(43,43,43,.18); vertical-align: middle; }
.cm-table tr:last-child td { border-bottom: none; }
.cm-table tbody tr { transition: background .15s; }
.cm-table tbody tr:hover { background: #fffdf0; }
.cm-table tbody tr.dragging { opacity: .45; }
.cm-table tbody tr.drag-over { background: #fff0b8; box-shadow: inset 0 0 0 2px #2b2b2b; }
.cm-table tbody tr.offline .cm-title-cell strong { color: #9c948a; }
.cm-col-drag { width: 48px; }
.cm-drag { display: inline-grid; place-items: center; width: 24px; height: 26px; font-size: 18px; color: #8c8273; cursor: grab; border-radius: 7px; }
.cm-drag:hover { background: #fff0b8; color: #2b2b2b; }
.cm-drag:active { cursor: grabbing; }
.cm-title-cell { min-width: 190px; max-width: 250px; display: grid; gap: 3px; }
.cm-title-cell strong { font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cm-title-cell small { font-size: 10px; font-weight: 700; color: var(--text-3, #928879); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cm-chip {
  display: inline-block; padding: 4px 9px; font-size: 10px; font-weight: 900;
  background: #d9f5ea; border: 1.5px solid #2b2b2b; border-radius: 99px; white-space: nowrap;
}
.cm-cover {
  width: 48px; height: 38px; display: grid; place-items: center; overflow: hidden;
  font-size: 20px; border: 1.5px solid #2b2b2b; border-radius: 9px;
}
.cm-cover img { width: 100%; height: 100%; object-fit: cover; }
.cm-weight { font-size: 13px; }
.cm-time { font-size: 10px; font-weight: 700; color: var(--text-3, #928879); white-space: nowrap; }

/* 上架开关 */
.cm-switch {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 4px 10px 4px 5px; font: inherit; font-size: 10px; font-weight: 900;
  color: #6c6459; background: #eee9e2;
  border: 2px solid #2b2b2b; border-radius: 99px; cursor: pointer;
  transition: background .15s, transform .15s;
}
.cm-switch-dot { width: 15px; height: 15px; background: #fff; border: 1.5px solid #2b2b2b; border-radius: 50%; }
.cm-switch.on { background: #bdf0d5; color: #1d6b48; }
.cm-switch.on .cm-switch-dot { background: #3fbf83; margin-left: auto; order: 2; }
.cm-switch:hover { transform: translateY(-2px); }
.cm-hot {
  display: inline-block; padding: 3px 8px; font-size: 10px; font-weight: 900;
  background: #fff; border: 1.5px solid #2b2b2b; border-radius: 99px;
}
.cm-hot.on { background: #ffe0e8; color: #b23a63; }
.cm-actions { display: flex; gap: 5px; white-space: nowrap; }
.cm-mini {
  padding: 5px 8px; font: inherit; font-size: 10px; font-weight: 900;
  color: #2b2b2b; background: #fff; border: 1.5px solid #2b2b2b; border-radius: 8px; cursor: pointer;
}
.cm-mini:hover { background: var(--yellow, #ffd84d); transform: translateY(-1px); }
.cm-mini.danger:hover { background: #ffdce4; color: #a3273d; }
.cm-empty { padding: 28px !important; text-align: center; color: var(--text-3, #928879); font-weight: 800; }
.cm-pager { display: flex; align-items: center; justify-content: center; gap: 12px; margin-top: 15px; }
.cm-pager span { font-size: 11px; font-weight: 900; }

/* 弹窗 */
.cm-mask {
  position: fixed; inset: 0; z-index: 120; display: grid; place-items: center; padding: 18px;
  background: rgba(43,43,43,.42); backdrop-filter: blur(2px);
}
.cm-modal {
  width: min(700px, 100%); max-height: 90vh; display: flex; flex-direction: column;
  background: var(--paper, #fffdf6); border: var(--line, 2px solid #2b2b2b);
  border-radius: var(--r-lg, 18px); box-shadow: var(--shadow-4, 8px 10px 0 #2b2b2b);
  animation: cm-pop .2s ease both;
}
.cm-modal.small { width: min(460px, 100%); }
@keyframes cm-pop { from { opacity: 0; transform: translateY(14px) scale(.98); } to { opacity: 1; transform: none; } }
.cm-modal-head {
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  padding: 15px 20px; background: #fff5d8; border-bottom: 2px solid #2b2b2b;
  border-radius: 16px 16px 0 0;
}
.cm-modal-head h2 { display: flex; align-items: center; gap: 9px; margin: 0; font-size: 16px; }
.cm-modal-tag { padding: 3px 9px; font-size: 10px; background: #fff; border: 1.5px solid #2b2b2b; border-radius: 99px; }
.cm-close {
  width: 28px; height: 28px; font-size: 20px; line-height: 1; color: #2b2b2b; background: #fff;
  border: 2px solid #2b2b2b; border-radius: 8px; cursor: pointer;
}
.cm-close:hover { background: #ffdce4; }
.cm-modal-body { padding: 18px 20px; overflow-y: auto; }
.cm-modal-foot { display: flex; justify-content: flex-end; gap: 10px; padding: 14px 20px; border-top: 2px solid #2b2b2b; }

.cm-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.cm-form label { display: grid; gap: 5px; font-size: 11px; font-weight: 900; }
.cm-form .span-2 { grid-column: 1 / -1; }
.cm-form input:not([type="checkbox"]):not([type="file"]), .cm-form select, .cm-form textarea {
  width: 100%; padding: 8px 10px; font: inherit; font-size: 12px; font-weight: 700;
  color: #2b2b2b; background: #fff; border: 2px solid #2b2b2b; border-radius: 10px; outline: none;
}
.cm-form input:focus, .cm-form select:focus, .cm-form textarea:focus { background: #fff9df; }
.cm-check { display: flex !important; align-items: center; gap: 8px; }
.cm-check input { width: 16px; height: 16px; accent-color: #ffca3a; }
.cm-section-title { margin: 18px 0 10px; padding: 7px 11px; font-size: 12px; font-weight: 900; background: #e8f8f1; border: 2px solid #2b2b2b; border-radius: 10px; }
.cm-upload-row { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; }
.cm-upload-row input[type="file"] { display: none; }
.cm-cover-input { flex: 1; min-width: 180px; }
.cm-cover-preview {
  position: relative; height: 140px; margin-top: 11px; display: grid; place-items: center;
  border: 2px solid #2b2b2b; border-radius: 14px; overflow: hidden;
}
.cm-cover-preview img { width: 100%; height: 100%; object-fit: cover; }
.cm-cover-preview > span { font-size: 46px; filter: drop-shadow(3px 4px 0 rgba(43,43,43,.2)); }
.cm-cover-preview strong {
  position: absolute; left: 0; right: 0; bottom: 0; padding: 8px 12px;
  font-size: 13px; color: #2b2b2b; background: rgba(255,253,246,.88); border-top: 2px solid #2b2b2b;
}
.cm-rich-toolbar { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 7px; }
.cm-rich-toolbar button {
  width: 32px; height: 30px; font: inherit; font-size: 13px; font-weight: 900; color: #2b2b2b;
  background: #fff; border: 2px solid #2b2b2b; border-radius: 8px; cursor: pointer;
}
.cm-rich-toolbar button:hover { background: #fff0b8; }
.cm-rich-editor {
  min-height: 120px; padding: 11px 13px; font-size: 12px; font-weight: 700; line-height: 1.7;
  background: #fff; border: 2px solid #2b2b2b; border-radius: 12px; outline: none;
}
.cm-rich-editor:focus { background: #fff9df; box-shadow: 3px 3px 0 #ff9c4a; }
.cm-summary-label { display: grid; gap: 5px; margin-top: 14px; font-size: 11px; font-weight: 900; }
.cm-summary-label textarea {
  padding: 9px 11px; font: inherit; font-size: 12px; font-weight: 700; color: #2b2b2b;
  background: #fff; border: 2px solid #2b2b2b; border-radius: 10px; outline: none; resize: vertical;
}
.cm-error {
  margin: 12px 0 0; padding: 8px 11px; font-size: 11px; font-weight: 900; color: #a3273d;
  background: #ffdce4; border: 1.5px solid #e598a9; border-radius: 9px;
}
.cm-toast {
  position: fixed; left: 50%; bottom: 32px; z-index: 200; translate: -50% 0;
  padding: 11px 18px; font-size: 12px; font-weight: 900; color: #2b2b2b;
  background: var(--yellow, #ffd84d); border: 2px solid #2b2b2b;
  border-radius: 99px; box-shadow: 4px 5px 0 #2b2b2b;
}
.cm-toast.error { background: #ffdce4; color: #a3273d; }

@media (max-width: 760px) {
  .cm-form { grid-template-columns: 1fr; }
  .cm-form .span-2 { grid-column: auto; }
}
</style>
