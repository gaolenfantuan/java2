<script setup>
// 首页弹窗：读取后台「首页弹窗」板块中已上架的内容。
// 每天自动展示一次；后台点「预览」时按内容 ID 强制弹出，方便查看效果。
import { computed, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { findContent, formatCover, onlineByBoard } from '../data/homeContent'

const route = useRoute()
const router = useRouter()
const SEEN_KEY = 'petHomePopupSeen'
const today = () => new Date().toISOString().slice(0, 10)

const popupItems = computed(() => onlineByBoard('popup'))
const previewId = computed(() => String(route.query.preview || ''))
const previewItem = computed(() => findContent(previewId.value))
const show = ref(false)
const current = ref(null)

function seenToday() {
  try { return localStorage.getItem(SEEN_KEY) === today() } catch { return false }
}

function markSeen() {
  try { localStorage.setItem(SEEN_KEY, today()) } catch { /* 忽略隐私模式限制 */ }
}

function maybeShow() {
  if (show.value) return
  // 后台预览其它板块时，不额外弹窗遮挡
  if (previewId.value && previewItem.value &&
      previewItem.value.categoryId !== 'board_popup') return
  const forced = previewItem.value && popupItems.value.some(item => item.id === previewItem.value.id)
  if (forced) {
    current.value = previewItem.value
    show.value = true
    return
  }
  if (previewId.value || seenToday() || !popupItems.value.length) return
  current.value = popupItems.value[0]
  show.value = true
  markSeen()
}

function close() {
  show.value = false
  markSeen()
  if (previewId.value) router.replace({ path: '/', query: {} })
}

function openLink() {
  const link = current.value?.link
  close()
  if (!link) return
  if (/^https?:\/\//i.test(link)) window.open(link, '_blank', 'noopener')
  else router.push(link.startsWith('/') ? link : `/${link}`)
}

const coverStyle = computed(() => {
  if (!current.value) return {}
  const { image, gradient } = formatCover(current.value.cover, current.value.emoji)
  return image
    ? { backgroundImage: `url("${image}")`, backgroundSize: 'cover', backgroundPosition: 'center' }
    : { background: gradient || 'linear-gradient(135deg,#ffe3ef,#ffd9b8)' }
})

watch([popupItems, previewId], maybeShow, { immediate: true, deep: true })
</script>

<template>
  <div v-if="show && current" class="hp-mask" @click.self="close">
    <div class="hp-card" role="dialog" aria-modal="true" :aria-label="current.title" :data-content-id="current.id">
      <button type="button" class="hp-close" aria-label="关闭" @click="close">×</button>
      <div class="hp-cover" :style="coverStyle">
        <span>{{ current.emoji || '💌' }}</span>
      </div>
      <div class="hp-body">
        <span class="hp-tag">💌 来自毛茸茸领养站</span>
        <h2>{{ current.title }}</h2>
        <div v-if="current.html" class="hp-rich" v-html="current.html"></div>
        <p v-else>{{ current.summary }}</p>
        <div class="hp-actions">
          <button type="button" class="hp-ghost" @click="close">稍后再说</button>
          <button v-if="current.link" type="button" class="hp-primary" @click="openLink">去看看 →</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.hp-mask {
  position: fixed; inset: 0; z-index: 90; display: grid; place-items: center; padding: 18px;
  background: rgba(43,43,43,.44); backdrop-filter: blur(3px);
}
.hp-card {
  position: relative; width: min(420px, 100%); overflow: hidden;
  background: #fffdf6; border: var(--line); border-radius: var(--r-lg);
  box-shadow: 9px 11px 0 var(--ink);
  animation: hp-pop .32s cubic-bezier(.2,1.5,.4,1) both;
}
@keyframes hp-pop {
  from { opacity: 0; transform: scale(.8) rotate(-5deg); }
  to { opacity: 1; transform: scale(1) rotate(0); }
}
.hp-close {
  position: absolute; right: 12px; top: 12px; z-index: 3;
  width: 30px; height: 30px; font-size: 20px; line-height: 1; color: var(--ink);
  background: #fffdf6; border: 2px solid var(--ink); border-radius: 9px; cursor: pointer;
}
.hp-close:hover { background: #ffdce4; }
.hp-cover {
  height: 138px; display: grid; place-items: center; border-bottom: 2px solid var(--ink);
}
.hp-cover span { font-size: 66px; filter: drop-shadow(4px 6px 0 rgba(43,43,43,.18)); animation: hp-float 3s ease-in-out infinite; }
@keyframes hp-float { 0%,100% { translate: 0 0; } 50% { translate: 0 -8px; } }
.hp-body { padding: 18px 22px 22px; }
.hp-tag {
  display: inline-block; padding: 4px 10px; margin-bottom: 9px;
  font-size: 10px; font-weight: 900; background: var(--pink);
  border: 1.5px solid var(--ink); border-radius: 99px;
}
.hp-body h2 { margin: 0 0 9px; font-size: 20px; }
.hp-body p, .hp-rich { margin: 0 0 16px; font-size: 12px; font-weight: 700; line-height: 1.75; color: var(--text-2); }
.hp-actions { display: flex; gap: 10px; }
.hp-actions button {
  flex: 1; padding: 10px 0; font: inherit; font-size: 12px; font-weight: 900; color: var(--ink);
  border: var(--line); border-radius: var(--r-sm); box-shadow: 3px 4px 0 var(--ink); cursor: pointer;
}
.hp-ghost { background: #fff; }
.hp-primary { background: var(--yellow); }
.hp-actions button:hover { transform: translate(-1px, -2px); box-shadow: 4px 5px 0 var(--ink); }
.hp-actions button:active { translate: 2px 2px; box-shadow: 1px 1px 0 var(--ink); }
</style>
