<script setup>
// ============================================================
// 首页内容板块渲染
// 读取后台「首页内容管理」的统一数据，只展示已上架内容，
// 按权重从大到小排列，改动后无需重启即可看到效果。
// placement=top    首页轮播 + 首页公告
// placement=middle 推荐宠物 + 首页活动 + 首页小贴士
// placement=extra  管理员新增的自定义板块
// ============================================================
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { contentState, findCategory, findContent, formatCover, onlineByBoard } from '../data/homeContent'
import { homePets } from '../data/homePets'

const props = defineProps({ placement: { type: String, default: 'top' } })
const route = useRoute()
const router = useRouter()

const carousel = computed(() => onlineByBoard('carousel'))
const featured = computed(() => onlineByBoard('featured'))
const notices = computed(() => onlineByBoard('notice'))
const events = computed(() => onlineByBoard('event'))
const tips = computed(() => onlineByBoard('tip'))

const builtinKeys = ['carousel', 'featured', 'notice', 'event', 'tip', 'popup']

// 自定义板块：直接读统一数据，管理员新增的分类也会出现在首页
const extraBoards = computed(() => {
  return contentState.categories
    .filter(category => !builtinKeys.includes(category.key))
    .map(category => ({
      category,
      items: contentState.items
        .filter(item => item.categoryId === category.id && Number(item.status) === 1)
        .sort((a, b) => (Number(b.weight) || 0) - (Number(a.weight) || 0))
    }))
    .filter(board => board.items.length)
})

const categoryName = id => findCategory(id)?.name || '首页板块'

// 轮播自动播放
const slideIndex = ref(0)
let slideTimer = null
function startCarousel() {
  stopCarousel()
  if (carousel.value.length < 2) return
  slideTimer = setInterval(() => {
    slideIndex.value = (slideIndex.value + 1) % carousel.value.length
  }, 4800)
}
function stopCarousel() {
  if (slideTimer) clearInterval(slideTimer)
  slideTimer = null
}
function goSlide(delta) {
  if (!carousel.value.length) return
  slideIndex.value = (slideIndex.value + delta + carousel.value.length) % carousel.value.length
  startCarousel()
}
watch(() => carousel.value.length, () => {
  if (slideIndex.value >= carousel.value.length) slideIndex.value = 0
  startCarousel()
})

// 公告展开
const noticeExpanded = ref(false)

// 链接处理：站内路径走 Vue 路由，站外新窗口打开
function openLink(link) {
  if (!link) return
  if (/^https?:\/\//i.test(link)) {
    window.open(link, '_blank', 'noopener')
  } else {
    router.push(link.startsWith('/') ? link : `/${link}`)
  }
}

function openFeatured(item) {
  if (item.petId) router.push(`/pet/${item.petId}`)
  else openLink(item.link)
}

function coverStyle(item) {
  const { image, gradient } = formatCover(item.cover, item.emoji)
  return image
    ? `center / cover no-repeat url("${image}")`
    : gradient
}

function petOf(item) {
  return homePets.value.find(pet => pet.id === item.petId) || null
}

// 快速预览：新窗口打开首页并定位到这条内容
const previewId = computed(() => String(route.query.preview || ''))
const highlightedId = ref('')
const previewBanner = ref(false)

function locatePreview() {
  const id = previewId.value
  if (!id || props.placement !== 'top') return
  const item = findContent(id)
  if (!item) return
  previewBanner.value = true
  const category = findCategory(item.categoryId)
  // 弹窗由 HomeContentPopup 负责展示
  if (category?.key === 'popup') return
  nextTick(() => {
    const el = document.querySelector(`[data-content-id="${CSS.escape(id)}"]`)
    if (!el) return
    el.scrollIntoView({ behavior: 'smooth', block: 'center' })
    highlightedId.value = id
    setTimeout(() => { highlightedId.value = '' }, 4200)
  })
}

function closePreview() {
  previewBanner.value = false
  router.replace({ path: '/', query: {} })
}

onMounted(() => {
  startCarousel()
  locatePreview()
})
watch(previewId, locatePreview)
onBeforeUnmount(stopCarousel)
</script>

<template>
  <div class="hc-boards">
    <!-- ===== 顶部：首页轮播 + 首页公告 ===== -->
    <template v-if="placement === 'top'">
      <section v-if="carousel.length" class="hc-carousel" aria-label="首页轮播">
        <div
          v-for="(item, index) in carousel"
          :key="item.id"
          class="hc-slide"
          :style="{ background: coverStyle(item) }"
          :data-content-id="item.id"
          :class="{ active: index === slideIndex, highlight: highlightedId === item.id }"
          @mouseenter="stopCarousel"
          @mouseleave="startCarousel"
        >
          <div class="hc-slide-mask"></div>
          <div class="hc-slide-copy">
            <span class="hc-slide-tag">{{ item.tag || '✨ 今日推荐' }}</span>
            <h2>{{ item.title }}</h2>
            <p>{{ item.summary }}</p>
            <button v-if="item.link" type="button" class="hc-slide-btn" @click="openLink(item.link)">
              去看看 →
            </button>
          </div>
          <span class="hc-slide-emoji" aria-hidden="true">{{ item.emoji || '🐾' }}</span>
        </div>
        <div class="hc-carousel-ctrl">
          <button type="button" aria-label="上一张" @click="goSlide(-1)">‹</button>
          <div class="hc-dots">
            <button
              v-for="(item, index) in carousel"
              :key="item.id"
              type="button"
              :class="{ active: index === slideIndex }"
              :aria-label="`第 ${index + 1} 张：${item.title}`"
              @click="slideIndex = index; startCarousel()"
            ></button>
          </div>
          <button type="button" aria-label="下一张" @click="goSlide(1)">›</button>
        </div>
      </section>

      <section v-if="notices.length" class="hc-notice" aria-label="首页公告">
        <div class="hc-notice-head">
          <span class="hc-notice-icon">📢</span>
          <strong>{{ categoryName(notices[0].categoryId) }}</strong>
          <span class="hc-notice-count">{{ notices.length }} 条</span>
          <button type="button" class="hc-notice-toggle" @click="noticeExpanded = !noticeExpanded">
            {{ noticeExpanded ? '收起' : '查看全部' }} ▾
          </button>
        </div>
        <ul class="hc-notice-list">
          <li
            v-for="item in (noticeExpanded ? notices : notices.slice(0, 2))"
            :key="item.id"
            :data-content-id="item.id"
            :class="{ highlight: highlightedId === item.id }"
          >
            <span class="hc-notice-dot">💗</span>
            <div class="hc-notice-copy">
              <strong>{{ item.title }}</strong>
              <div v-if="item.html" class="hc-rich" v-html="item.html"></div>
              <small v-else>{{ item.summary }}</small>
            </div>
          </li>
        </ul>
      </section>
    </template>

    <!-- ===== 中部：推荐宠物 + 活动 + 小贴士 ===== -->
    <template v-else-if="placement === 'middle'">
      <section v-if="featured.length" class="hc-featured" aria-label="推荐宠物">
        <div class="hc-title-row">
          <h2>🐾 {{ categoryName(featured[0].categoryId) }}</h2>
          <p>后台精选的毛孩子，点进去认识一下吧</p>
        </div>
        <div class="hc-featured-grid">
          <article
            v-for="item in featured"
            :key="item.id"
            class="hc-feature-card"
            :data-content-id="item.id"
            :class="{ highlight: highlightedId === item.id }"
            @click="openFeatured(item)"
          >
            <div class="hc-feature-cover" :style="{ background: coverStyle(item) }">
              <template v-if="petOf(item)">
                <img v-if="petOf(item).image" :src="petOf(item).image" :alt="item.title">
                <span v-else class="hc-feature-emoji">{{ petOf(item).emoji || '🐾' }}</span>
              </template>
              <span v-else class="hc-feature-emoji">{{ item.emoji || '🐾' }}</span>
              <em v-if="item.hot">🔥 热门</em>
            </div>
            <div class="hc-feature-body">
              <strong>{{ petOf(item) ? petOf(item).name : item.title }}</strong>
              <small>{{ item.summary }}</small>
              <span class="hc-feature-go">去看看 TA →</span>
            </div>
          </article>
        </div>
      </section>

      <section v-if="events.length" class="hc-events" aria-label="首页活动">
        <div class="hc-title-row">
          <h2>🎉 {{ categoryName(events[0].categoryId) }}</h2>
          <p>最近有哪些好玩的事，别错过啦</p>
        </div>
        <div class="hc-event-grid">
          <article
            v-for="item in events"
            :key="item.id"
            class="hc-event-card"
            :data-content-id="item.id"
            :class="{ highlight: highlightedId === item.id }"
            @click="openLink(item.link)"
          >
            <div class="hc-event-cover" :style="{ background: coverStyle(item) }">
              <span>{{ item.emoji || '🎉' }}</span>
            </div>
            <div class="hc-event-body">
              <strong>{{ item.title }}</strong>
              <small>{{ item.summary }}</small>
              <span class="hc-event-link">{{ item.link ? '查看详情 →' : '了解更多' }}</span>
            </div>
          </article>
        </div>
      </section>

      <section v-if="tips.length" class="hc-tips" aria-label="首页小贴士">
        <div class="hc-title-row">
          <h2>💡 {{ categoryName(tips[0].categoryId) }}</h2>
          <p>养宠路上，这些小知识很有用</p>
        </div>
        <div class="hc-tip-grid">
          <article
            v-for="item in tips"
            :key="item.id"
            class="hc-tip-card"
            :data-content-id="item.id"
            :class="{ highlight: highlightedId === item.id }"
          >
            <span class="hc-tip-emoji">{{ item.emoji || '💡' }}</span>
            <div>
              <strong>{{ item.title }}</strong>
              <div v-if="item.html" class="hc-rich" v-html="item.html"></div>
              <small v-else>{{ item.summary }}</small>
            </div>
          </article>
        </div>
      </section>
    </template>

    <!-- ===== 自定义板块 ===== -->
    <template v-else>
      <section v-for="board in extraBoards" :key="board.category.id" class="hc-custom" :aria-label="board.category.name">
        <div class="hc-title-row">
          <h2>{{ board.category.icon || '🧩' }} {{ board.category.name }}</h2>
          <p>{{ board.category.desc || '由管理员自定义的首页展示板块' }}</p>
        </div>
        <div class="hc-event-grid">
          <article
            v-for="item in board.items"
            :key="item.id"
            class="hc-event-card"
            :data-content-id="item.id"
            :class="{ highlight: highlightedId === item.id }"
            @click="openLink(item.link)"
          >
            <div class="hc-event-cover" :style="{ background: coverStyle(item) }">
              <span>{{ item.emoji || '🎀' }}</span>
            </div>
            <div class="hc-event-body">
              <strong>{{ item.title }}</strong>
              <small>{{ item.summary }}</small>
              <span class="hc-event-link">{{ item.link ? '查看详情 →' : '了解更多' }}</span>
            </div>
          </article>
        </div>
      </section>
    </template>

    <!-- 预览模式提示条 -->
    <div v-if="previewBanner" class="hc-preview-bar">
      <span>👀 正在预览内容在首页的效果</span>
      <button type="button" @click="closePreview">返回后台 ✕</button>
    </div>
  </div>
</template>

<style scoped>
.hc-boards { display: grid; gap: 28px; }

/* 轮播 */
.hc-carousel {
  position: relative; height: 260px; overflow: hidden;
  border: var(--line); border-radius: var(--r-lg);
  box-shadow: var(--shadow-3, 6px 7px 0 #2b2b2b);
  background: linear-gradient(120deg, #ffd8e8, #fff0b8);
}
.hc-slide {
  position: absolute; inset: 0; display: flex; align-items: center;
  padding: 26px 42px; opacity: 0; pointer-events: none;
  transition: opacity .55s ease, transform .55s ease;
  transform: scale(1.02);
}
.hc-slide.active { opacity: 1; pointer-events: auto; transform: scale(1); }
.hc-slide.highlight { outline: 5px dashed #ff6f9c; outline-offset: -9px; }
.hc-slide-mask {
  position: absolute; inset: 0;
  background: linear-gradient(90deg, rgba(255,253,246,.93), rgba(255,253,246,.45) 62%, rgba(255,253,246,.12));
}
.hc-slide-copy { position: relative; z-index: 2; max-width: 62%; }
.hc-slide-tag {
  display: inline-block; padding: 5px 12px; margin-bottom: 10px;
  font-size: 11px; font-weight: 900; background: var(--pink);
  border: 2px solid var(--ink); border-radius: 99px; box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-4deg);
}
.hc-slide-copy h2 { margin: 0 0 8px; font-size: 30px; letter-spacing: 1px; }
.hc-slide-copy p { margin: 0 0 16px; font-size: 14px; font-weight: 800; color: var(--text-2); }
.hc-slide-btn {
  padding: 9px 18px; font: inherit; font-size: 13px; font-weight: 900; color: var(--ink);
  background: var(--yellow); border: var(--line); border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink); cursor: pointer; transition: .15s;
}
.hc-slide-btn:hover { transform: translate(-2px, -2px); box-shadow: 6px 6px 0 var(--ink); }
.hc-slide-emoji {
  position: absolute; right: 48px; top: 50%; translate: 0 -50%; z-index: 1;
  font-size: 112px; filter: drop-shadow(7px 9px 0 rgba(43,43,43,.18));
  animation: hc-float 3.6s ease-in-out infinite;
}
@keyframes hc-float { 0%,100% { translate: 0 -50%; } 50% { translate: 0 -58%; } }
.hc-carousel-ctrl {
  position: absolute; right: 16px; bottom: 14px; z-index: 3;
  display: flex; align-items: center; gap: 9px;
}
.hc-carousel-ctrl > button {
  width: 30px; height: 30px; font: inherit; font-size: 20px; line-height: 1;
  color: var(--ink); background: #fffdf6; border: 2px solid var(--ink);
  border-radius: 50%; box-shadow: 2px 2px 0 var(--ink); cursor: pointer;
}
.hc-carousel-ctrl > button:hover { background: var(--yellow); }
.hc-dots { display: flex; gap: 6px; }
.hc-dots button {
  width: 10px; height: 10px; padding: 0; background: #fffdf6;
  border: 2px solid var(--ink); border-radius: 50%; cursor: pointer;
}
.hc-dots button.active { width: 26px; border-radius: 99px; background: var(--yellow); }

/* 公告 */
.hc-notice {
  padding: 16px 20px; background: #fffdf6; border: var(--line);
  border-radius: var(--r-lg); box-shadow: var(--shadow-2);
}
.hc-notice-head { display: flex; align-items: center; gap: 9px; margin-bottom: 10px; }
.hc-notice-icon { font-size: 22px; }
.hc-notice-head strong { font-size: 15px; }
.hc-notice-count {
  padding: 3px 9px; font-size: 10px; font-weight: 900;
  background: var(--mint-soft, #d9f5ea); border: 1.5px solid var(--ink); border-radius: 99px;
}
.hc-notice-toggle {
  margin-left: auto; padding: 5px 10px; font: inherit; font-size: 11px; font-weight: 900;
  color: var(--ink); background: #fff; border: 1.5px solid var(--ink); border-radius: 9px; cursor: pointer;
}
.hc-notice-toggle:hover { background: var(--yellow); }
.hc-notice-list { display: grid; gap: 8px; margin: 0; padding: 0; list-style: none; }
.hc-notice-list li {
  display: flex; align-items: flex-start; gap: 9px; padding: 9px 12px;
  background: #fffaea; border: 1.5px dashed rgba(43,43,43,.22); border-radius: 12px;
}
.hc-notice-list li.highlight,
.hc-feature-card.highlight,
.hc-event-card.highlight,
.hc-tip-card.highlight { outline: 5px dashed #ff6f9c; outline-offset: 3px; }
.hc-notice-dot { font-size: 14px; }
.hc-notice-copy { min-width: 0; }
.hc-notice-copy strong { display: block; margin-bottom: 3px; font-size: 12px; }
.hc-notice-copy small { font-size: 11px; font-weight: 700; color: var(--text-2); }
.hc-rich { font-size: 11.5px; font-weight: 700; line-height: 1.7; color: var(--text-2); }
.hc-rich :deep(p) { margin: 3px 0; }

/* 通用标题 */
.hc-title-row { display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap; margin-bottom: 12px; }
.hc-title-row h2 { margin: 0; font-size: 21px; }
.hc-title-row p { margin: 0; font-size: 11px; font-weight: 800; color: var(--text-3); }

/* 推荐宠物 */
.hc-featured-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
.hc-feature-card {
  background: #fffdf6; border: var(--line); border-radius: var(--r-lg);
  box-shadow: var(--shadow-2); overflow: hidden; cursor: pointer;
  transition: transform .18s, box-shadow .18s;
}
.hc-feature-card:hover { transform: translate(-2px, -5px); box-shadow: 7px 11px 0 var(--ink); }
.hc-feature-cover {
  position: relative; height: 130px; display: grid; place-items: center; overflow: hidden;
  border-bottom: 2px solid var(--ink);
}
.hc-feature-cover img { width: 100%; height: 100%; object-fit: contain; }
.hc-feature-emoji { font-size: 64px; filter: drop-shadow(4px 5px 0 rgba(43,43,43,.18)); animation: hc-float2 3.2s ease-in-out infinite; }
@keyframes hc-float2 { 0%,100% { translate: 0 0; } 50% { translate: 0 -7px; } }
.hc-feature-cover em {
  position: absolute; left: 10px; top: 10px; padding: 3px 8px;
  font-size: 10px; font-style: normal; font-weight: 900;
  background: #ffe0e8; border: 1.5px solid var(--ink); border-radius: 99px;
}
.hc-feature-body { display: grid; gap: 4px; padding: 13px 15px 15px; }
.hc-feature-body strong { font-size: 15px; }
.hc-feature-body small {
  font-size: 11px; font-weight: 700; color: var(--text-3);
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.hc-feature-go { margin-top: 4px; font-size: 11px; font-weight: 900; color: #d45c85; }

/* 活动 / 自定义 */
.hc-event-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
.hc-event-card {
  background: #fffdf6; border: var(--line); border-radius: var(--r-lg);
  box-shadow: var(--shadow-2); overflow: hidden; cursor: pointer;
  transition: transform .18s, box-shadow .18s;
}
.hc-event-card:hover { transform: translate(-2px, -5px); box-shadow: 7px 11px 0 var(--ink); }
.hc-event-cover { height: 116px; display: grid; place-items: center; border-bottom: 2px solid var(--ink); }
.hc-event-cover span { font-size: 52px; filter: drop-shadow(4px 5px 0 rgba(43,43,43,.18)); }
.hc-event-body { display: grid; gap: 4px; padding: 13px 15px 15px; }
.hc-event-body strong { font-size: 14px; }
.hc-event-body small {
  font-size: 11px; font-weight: 700; color: var(--text-3);
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.hc-event-link { margin-top: 4px; font-size: 11px; font-weight: 900; color: #3b82c4; }

/* 小贴士 */
.hc-tip-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
.hc-tip-card {
  display: flex; align-items: flex-start; gap: 12px; padding: 14px 16px;
  background: #fffdf6; border: var(--line); border-radius: var(--r-lg); box-shadow: var(--shadow-2);
  transition: transform .18s, box-shadow .18s;
}
.hc-tip-card:hover { transform: translateY(-3px); box-shadow: 6px 9px 0 var(--ink); }
.hc-tip-emoji {
  width: 42px; height: 42px; flex: 0 0 auto; display: grid; place-items: center;
  font-size: 22px; background: #fff0b8; border: 2px solid var(--ink); border-radius: 12px;
}
.hc-tip-card > div { min-width: 0; }
.hc-tip-card strong { display: block; margin-bottom: 4px; font-size: 13px; }
.hc-tip-card small { font-size: 11px; font-weight: 700; color: var(--text-2); line-height: 1.6; }

/* 预览条 */
.hc-preview-bar {
  position: fixed; left: 50%; top: 16px; z-index: 80; translate: -50% 0;
  display: flex; align-items: center; gap: 12px; padding: 9px 15px;
  font-size: 12px; font-weight: 900; color: var(--ink);
  background: #fff0b8; border: 2px solid var(--ink); border-radius: 99px;
  box-shadow: 4px 5px 0 var(--ink);
}
.hc-preview-bar button {
  padding: 5px 11px; font: inherit; font-size: 11px; font-weight: 900;
  background: #fff; border: 1.5px solid var(--ink); border-radius: 99px; cursor: pointer;
}
.hc-preview-bar button:hover { background: var(--pink); }

@media (max-width: 900px) {
  .hc-featured-grid, .hc-event-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .hc-slide-copy h2 { font-size: 23px; }
  .hc-slide-emoji { right: 20px; font-size: 78px; }
}
@media (max-width: 640px) {
  .hc-featured-grid, .hc-event-grid, .hc-tip-grid { grid-template-columns: 1fr; }
  .hc-carousel { height: 230px; }
  .hc-slide { padding: 20px; }
  .hc-slide-copy { max-width: 82%; }
  .hc-slide-emoji { font-size: 54px; right: 12px; }
}
</style>
