<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { pets } from '../data/pets'
import BadgeCelebration from '../components/BadgeCelebration.vue'
import { badges, getBadgeProgress, syncAchievements } from '../utils/achievements'
import { store, clearHistory } from '../store'

const router = useRouter()
const route = useRoute()
const adoptedIds = ref([])
const favoriteIds = ref([])
const applications = ref([])
const selectedFavorites = ref([])
const activeTab = ref('adopted')
const unlockedIds = ref([])
const celebrateBadge = ref(null)
let celebrateTimer = null

const tabs = [
  { value: 'adopted', label: '我的领养', icon: '🐾' },
  { value: 'favorites', label: '我的收藏', icon: '💕' },
  { value: 'applications', label: '我的申请', icon: '📝' },
  { value: 'history', label: '浏览历史', icon: '👀' }
]

const adoptedPets = computed(() => adoptedIds.value.map(id => pets.find(p => p.id === Number(id))).filter(Boolean))
const favoritePets = computed(() => favoriteIds.value.map(id => pets.find(p => p.id === Number(id))).filter(Boolean))
const historyPets = computed(() => store.history.map(id => pets.find(p => p.id === Number(id))).filter(Boolean))

const badgeList = computed(() => badges.map(badge => ({
  ...badge,
  unlocked: unlockedIds.value.includes(badge.id),
  progress: getBadgeProgress(badge.id)
})))

function readArr(key) {
  try {
    const val = JSON.parse(localStorage.getItem(key) || '[]')
    return Array.isArray(val) ? val : []
  } catch { return [] }
}

function load() {
  adoptedIds.value = readArr('petAdopted')
  favoriteIds.value = readArr('petFavorites')
  applications.value = readArr('petAdoptApplications')
  selectedFavorites.value = []
}

function refreshAchievements() {
  const result = syncAchievements()
  unlockedIds.value = result.state.unlocked
  store.unlockedBadgeCount = result.state.unlocked.length
  if (result.newlyUnlocked.length) {
    celebrateBadge.value = result.newlyUnlocked[0]
    clearTimeout(celebrateTimer)
    celebrateTimer = setTimeout(() => { celebrateBadge.value = null }, 2600)
  }
}

// 批量取消收藏
function removeSelectedFavorites() {
  const next = favoriteIds.value.filter(id => !selectedFavorites.value.includes(id))
  localStorage.setItem('petFavorites', JSON.stringify(next))
  favoriteIds.value = next
  selectedFavorites.value = []
}
function toggleSelect(id) {
  const idx = selectedFavorites.value.indexOf(id)
  if (idx === -1) selectedFavorites.value.push(id)
  else selectedFavorites.value.splice(idx, 1)
}

// 模拟领养进度
function progressOf(id) {
  const statuses = ['资料审核中', '等待回访', '即将接回家', '已完成领养']
  return statuses[Math.abs(Number(id)) % statuses.length]
}
function progressPercent(id) {
  return [30, 55, 80, 100][Math.abs(Number(id)) % 4]
}

// 申请状态展示
function statusInfo(index) {
  const map = [
    { text: '待审核', cls: 'pending', icon: '⏳', note: '志愿者正在审核你的申请，请耐心等待～' },
    { text: '已通过', cls: 'passed', icon: '✅', note: '恭喜通过！请留意回访联系，准备接 TA 回家～' },
    { text: '未通过', cls: 'rejected', icon: '💛', note: '很遗憾本次未通过，可以试试其它毛孩子哦～' }
  ]
  return map[index % map.length]
}

onMounted(() => {
  document.body.classList.add('home-body')
  load()
  refreshAchievements()
  // 支持从领养专区「我的申请记录」入口跳转过来时定位到申请 Tab
  if (route.query.tab === 'applications') activeTab.value = 'applications'
})
onBeforeUnmount(() => {
  document.body.classList.remove('home-body')
  clearTimeout(celebrateTimer)
})
</script>

<template>
  <div class="my-page">
    <main class="my-main">
      <div class="page-head">
        <div>
          <h1>我的毛孩子 <span>🐾</span></h1>
          <p class="sub">这里收藏着我和毛孩子的所有点点滴滴～</p>
        </div>
        <div class="badge-mini" title="已解锁徽章">
          🏅 <strong>{{ unlockedIds.length }}</strong>
        </div>
      </div>

      <!-- 四个功能 Tab -->
      <div class="my-tabs">
        <button
          v-for="tab in tabs"
          :key="tab.value"
          type="button"
          class="my-tab"
          :class="{ active: activeTab === tab.value }"
          @click="activeTab = tab.value"
        >
          <span>{{ tab.icon }}</span>{{ tab.label }}
          <span v-if="tab.value === 'favorites' && favoriteIds.length" class="tab-count">{{ favoriteIds.length }}</span>
          <span v-if="tab.value === 'applications' && applications.length" class="tab-count">{{ applications.length }}</span>
        </button>
      </div>

      <!-- 我的领养 -->
      <template v-if="activeTab === 'adopted'">
        <div v-if="adoptedPets.length" class="card-list">
          <div v-for="pet in adoptedPets" :key="pet.id" class="adopted-card">
            <button type="button" class="card-pet" @click="router.push(`/pet/${pet.id}`)">
              <span class="pet-emoji">{{ pet.emoji }}</span>
              <span class="pet-meta">
                <strong>{{ pet.name }}</strong>
                <small>{{ pet.breed }} · {{ pet.gender }} · {{ pet.age }}</small>
              </span>
            </button>
            <div class="progress-box">
              <div class="progress-top">
                <span>{{ progressOf(pet.id) }}</span>
                <span>{{ progressPercent(pet.id) }}%</span>
              </div>
              <div class="progress-track"><div class="progress-fill" :style="{ width: progressPercent(pet.id) + '%' }"></div></div>
            </div>
          </div>
        </div>
        <div v-else class="empty-card">🏠 还没有领养的毛孩子哦～<br>去领养专区挑一只带回家吧！</div>

        <!-- 我的徽章（保留原有成就入口） -->
        <section class="badge-section">
          <h2>🏅 我的徽章</h2>
          <div class="badge-grid">
            <div
              v-for="badge in badgeList"
              :key="badge.id"
              class="badge-card"
              :class="{ locked: !badge.unlocked }"
              :style="{ '--badge-color': badge.color }"
            >
              <div class="badge-medal"><span>{{ badge.icon }}</span></div>
              <strong class="badge-name">{{ badge.name }}</strong>
              <p class="badge-desc">{{ badge.desc }}</p>
              <span class="badge-progress">{{ badge.unlocked ? '✓ 已解锁' : badge.progress }}</span>
            </div>
          </div>
        </section>
      </template>

      <!-- 我的收藏 -->
      <template v-else-if="activeTab === 'favorites'">
        <div class="list-toolbar">
          <span>共 {{ favoritePets.length }} 只收藏</span>
          <button
            type="button"
            class="small-btn danger"
            :disabled="!selectedFavorites.length"
            @click="removeSelectedFavorites"
          >💔 取消选中（{{ selectedFavorites.length }}）</button>
        </div>
        <div v-if="favoritePets.length" class="check-list">
          <label v-for="pet in favoritePets" :key="pet.id" class="check-card">
            <input type="checkbox" :checked="selectedFavorites.includes(pet.id)" @change="toggleSelect(pet.id)">
            <span class="pet-emoji">{{ pet.emoji }}</span>
            <span class="pet-meta"><strong>{{ pet.name }}</strong><small>{{ pet.breed }} · {{ pet.personality }}</small></span>
            <button type="button" class="small-btn" @click.stop.prevent="router.push(`/pet/${pet.id}`)">查看 →</button>
          </label>
        </div>
        <div v-else class="empty-card">💕 还没有收藏的毛孩子～<br>去首页点点爱心收藏吧！</div>
      </template>

      <!-- 我的申请 -->
      <template v-else-if="activeTab === 'applications'">
        <div v-if="applications.length" class="card-list">
          <div v-for="(app, index) in applications" :key="app.petId + '-' + index" class="application-card">
            <div class="app-head">
              <span class="app-pet">🐾 {{ app.petName }}</span>
              <span class="app-status" :class="statusInfo(index).cls">{{ statusInfo(index).icon }} {{ statusInfo(index).text }}</span>
            </div>
            <p class="app-note">{{ statusInfo(index).note }}</p>
            <div class="app-detail">
              <span>申请人：{{ app.name }}</span>
              <span>联系方式：{{ app.contact }}</span>
              <span v-if="app.experience">养宠经验：{{ app.experience }}</span>
              <span v-if="app.housing">居住环境：{{ app.housing }}</span>
            </div>
            <p v-if="app.message" class="app-message">💌 {{ app.message }}</p>
            <small class="app-time">提交时间：{{ app.time }}</small>
          </div>
        </div>
        <div v-else class="empty-card">📝 还没有提交过领养申请～<br>去领养专区申请你喜欢的毛孩子吧！</div>
      </template>

      <!-- 浏览历史 -->
      <template v-else>
        <div class="list-toolbar">
          <span>最近看过 {{ historyPets.length }} 只毛孩子</span>
          <button type="button" class="small-btn danger" :disabled="!historyPets.length" @click="clearHistory">🧹 一键清空</button>
        </div>
        <div v-if="historyPets.length" class="history-list">
          <button v-for="pet in historyPets" :key="pet.id" type="button" class="history-card" @click="router.push(`/pet/${pet.id}`)">
            <span class="pet-emoji">{{ pet.emoji }}</span>
            <span class="history-name">{{ pet.name }}</span>
            <span class="history-breed">{{ pet.breed }}</span>
          </button>
        </div>
        <div v-else class="empty-card">👀 还没有浏览记录～<br>去看看毛孩子吧！</div>
      </template>
    </main>

    <BadgeCelebration
      v-if="celebrateBadge"
      :badge="celebrateBadge"
      @close="celebrateBadge = null"
    />
  </div>
</template>

<style scoped>
:global(body.home-body) { display: block; align-items: initial; justify-content: initial; padding: 0; }
.my-page {
  min-height: 100vh;
  font-family: "Comic Sans MS", "YouYuan", "幼圆", "Microsoft YaHei", sans-serif;
  color: var(--ink);
  background-color: #fff8e9;
  background-image: radial-gradient(#f0c98a 1.4px, transparent 1.4px), radial-gradient(#f0c98a 1.4px, transparent 1.4px);
  background-size: 26px 26px, 26px 26px;
  background-position: 0 0, 13px 13px;
}
.my-main { max-width: 980px; margin: 0 auto; padding: 32px 22px 64px; }
.page-head { display: flex; align-items: center; justify-content: space-between; gap: 16px; margin-bottom: 24px; }
.page-head h1 { margin: 0 0 4px; font-size: 30px; }
.page-head h1 span { color: var(--pink); }
.sub { margin: 0; font-size: 13px; font-weight: 700; color: #8a6a4f; }
.badge-mini { padding: 8px 14px; font-size: 14px; font-weight: 900; background: var(--yellow); border: var(--line); border-radius: 12px; box-shadow: 3px 3px 0 var(--ink); }

.my-tabs { display: flex; gap: 12px; margin-bottom: 26px; flex-wrap: wrap; }
.my-tab {
  padding: 11px 20px; font: inherit; font-size: 14px; font-weight: 900; color: var(--ink);
  background: #fff; border: var(--line); border-radius: 13px; box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer; transition: 0.12s; display: inline-flex; align-items: center; gap: 6px;
}
.my-tab:hover { background: #fff6d9; transform: translate(-2px, -2px); box-shadow: 6px 6px 0 var(--ink); }
.my-tab.active { background: var(--yellow); transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }
.tab-count { display: inline-grid; place-items: center; min-width: 20px; height: 20px; padding: 0 5px; font-size: 11px; background: var(--pink); border: 2px solid var(--ink); border-radius: 999px; }

/* 通用卡片 */
.card-list { display: grid; gap: 16px; }
.adopted-card { display: grid; grid-template-columns: 1fr 220px; gap: 18px; align-items: center; padding: 16px 20px; background: #fffdf6; border: var(--line); border-radius: 18px; box-shadow: 6px 7px 0 var(--ink); }
.card-pet { display: flex; align-items: center; gap: 14px; background: none; border: none; font: inherit; text-align: left; cursor: pointer; padding: 0; }
.pet-emoji { font-size: 44px; }
.pet-meta { display: flex; flex-direction: column; gap: 4px; }
.pet-meta strong { font-size: 18px; }
.pet-meta small { font-size: 12px; font-weight: 700; color: #8a6a4f; }
.progress-top { display: flex; justify-content: space-between; font-size: 11px; font-weight: 900; margin-bottom: 6px; }
.progress-track { height: 14px; background: #fff; border: 2px solid var(--ink); border-radius: 999px; overflow: hidden; }
.progress-fill { height: 100%; background: linear-gradient(90deg, #ffd3e2, var(--pink)); transition: width 0.5s; }

/* 收藏 */
.list-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 14px; font-size: 13px; font-weight: 900; }
.check-list { display: grid; gap: 12px; }
.check-card { display: flex; align-items: center; gap: 14px; padding: 14px 18px; background: #fffdf6; border: var(--line); border-radius: 16px; box-shadow: 5px 6px 0 var(--ink); cursor: pointer; transition: 0.15s; }
.check-card:hover { transform: translate(-2px, -3px); box-shadow: 7px 9px 0 var(--ink); }
.check-card input { width: 18px; height: 18px; accent-color: var(--pink); }
.check-card .pet-meta { flex: 1; }
.small-btn { padding: 7px 13px; font: inherit; font-size: 12px; font-weight: 900; color: var(--ink); background: var(--mint); border: 2px solid var(--ink); border-radius: 10px; cursor: pointer; }
.small-btn.danger { background: #ffc9cf; }
.small-btn:disabled { opacity: 0.5; cursor: default; }

/* 申请 */
.application-card { padding: 18px 20px; background: #fffdf6; border: var(--line); border-radius: 18px; box-shadow: 6px 7px 0 var(--ink); }
.app-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 10px; }
.app-pet { font-size: 18px; font-weight: 900; }
.app-status { padding: 5px 11px; font-size: 11px; font-weight: 900; border: 2px solid var(--ink); border-radius: 999px; }
.app-status.pending { background: var(--yellow); }
.app-status.passed { background: var(--mint); }
.app-status.rejected { background: #e6ded2; }
.app-note { margin: 0 0 12px; font-size: 12px; font-weight: 700; color: #8a6a4f; }
.app-detail { display: flex; flex-wrap: wrap; gap: 8px 18px; font-size: 12px; font-weight: 700; }
.app-message { margin: 12px 0 6px; font-size: 12px; font-weight: 700; }
.app-time { color: #a99074; font-size: 11px; }

/* 浏览历史 */
.history-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 16px; }
.history-card { display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 16px 10px; background: #fffdf6; border: var(--line); border-radius: 18px; box-shadow: 5px 6px 0 var(--ink); cursor: pointer; font: inherit; color: var(--ink); transition: 0.15s; }
.history-card:hover { transform: translate(-2px, -4px); box-shadow: 8px 10px 0 var(--ink); }
.history-card .pet-emoji { font-size: 40px; }
.history-name { font-size: 15px; font-weight: 900; }
.history-breed { font-size: 11px; font-weight: 700; color: #8a6a4f; }

.empty-card { padding: 40px; text-align: center; background: #fffdf6; border: var(--line); border-radius: 24px; box-shadow: 8px 8px 0 var(--ink); font-weight: 900; line-height: 2; }

/* 徽章区 */
.badge-section { margin-top: 36px; }
.badge-section h2 { font-size: 22px; margin: 0 0 18px; }
.badge-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 22px; }
.badge-card { padding: 22px 16px 18px; text-align: center; background: #fffdf6; border: var(--line); border-radius: 22px; box-shadow: 7px 8px 0 var(--ink); transition: 0.18s; animation: badge-in 0.4s cubic-bezier(0.2, 1.4, 0.4, 1) both; }
.badge-card:hover { transform: translate(-3px, -5px); box-shadow: 10px 13px 0 var(--ink); }
@keyframes badge-in { from { opacity: 0; transform: translateY(14px) scale(0.95); } to { opacity: 1; transform: none; } }
.badge-card.locked { background: #f5f1ea; box-shadow: 6px 7px 0 #b9afa2; }
.badge-medal { width: 88px; height: 88px; margin: 0 auto 12px; display: grid; place-items: center; background: var(--badge-color); border: var(--line); border-radius: 50%; box-shadow: 6px 7px 0 var(--ink), inset -7px -8px 0 rgba(43,43,43,0.12); animation: badge-bob 3s ease-in-out infinite; }
.badge-medal span { font-size: 44px; line-height: 1; filter: drop-shadow(3px 4px 0 rgba(43,43,43,0.2)); }
@keyframes badge-bob { 0%,100% { translate: 0 0; rotate: -4deg; } 50% { translate: 0 -7px; rotate: 4deg; } }
.badge-card.locked .badge-medal { background: #d7d1c8; box-shadow: 5px 6px 0 #b9afa2; filter: grayscale(1); opacity: 0.7; }
.badge-name { display: block; margin-bottom: 6px; font-size: 16px; }
.badge-desc { margin: 0 0 12px; font-size: 11px; font-weight: 700; line-height: 1.6; color: #8a6a4f; }
.badge-progress { display: inline-block; padding: 5px 12px; font-size: 11px; font-weight: 900; background: var(--mint); border: 2px solid var(--ink); border-radius: 999px; }
.badge-card.locked .badge-progress { background: #e6ded2; }

@media (max-width: 760px) {
  .adopted-card { grid-template-columns: 1fr; }
  .badge-grid { grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 16px; }
  .badge-medal { width: 68px; height: 68px; }
  .badge-medal span { font-size: 34px; }
}
</style>
