<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { pets } from '../data/pets'
import BadgeCelebration from '../components/BadgeCelebration.vue'
import BadgeModal from '../components/BadgeModal.vue'
import DiaryModal from '../components/DiaryModal.vue'
import PetHome from '../components/PetHome.vue'
import CuteEmpty from '../components/CuteEmpty.vue'
import CoinIcon from '../components/CoinIcon.vue'
import { badges, badgeCategories, getBadgeProgressValue, syncAchievements } from '../utils/achievements'
import { store, bagTotalCount, clearHistory, removeHistory, setWornBadge } from '../store'
import '../page.css'

const router = useRouter()
const route = useRoute()

/* ---------------- 基础状态 ---------------- */
const loading = ref(true)
const adoptedIds = ref([])
const favoriteIds = ref([])
const applications = ref([])
const applyStatuses = ref({})
const activeTab = ref('adopted')
const expandedIds = ref([])

/* 收藏批量管理 */
const favManage = ref(false)
const selectedFavorites = ref([])

/* 徽章 */
const unlockedIds = ref([])
const unlockedTimes = ref({})
const newBadgeIds = ref([])
const badgeCategory = ref('all')
const badgeModalId = ref('')
const wornBadgeId = computed(() => store.wornBadge)

/* 弹窗 / 提示 */
const celebrateBadge = ref(null)
const diaryOpen = ref(false)
const diaryPreselect = ref(0)
const confirmState = ref(null)
const toast = ref('')
let celebrateTimer = null
let newBadgeTimer = null
let toastTimer = null
let loadTimer = null

/* ---------------- Tab 配置 ---------------- */
const tabs = [
  { value: 'adopted', label: '我的领养', icon: '🐾' },
  { value: 'favorites', label: '我的收藏', icon: '💕' },
  { value: 'applications', label: '我的申请', icon: '📝' },
  { value: 'history', label: '浏览历史', icon: '🕘' },
  { value: 'badges', label: '我的徽章', icon: '🏅' }
]

// 首次进入就定位到目标 Tab：放在 setup 里而不是 onMounted，避免首屏多一次淡入
const queryTab = String(route.query.tab || '')
if (tabs.some(t => t.value === queryTab)) activeTab.value = queryTab
if (route.query.diary) diaryOpen.value = true

/* 领养流程节点 */const FLOW_STAGES = [
  { key: 'submit', title: '提交申请', icon: '📝' },
  { key: 'review', title: '资料审核', icon: '🔍' },
  { key: 'visit', title: '家访回访', icon: '☎️' },
  { key: 'sign', title: '签署协议', icon: '📄' },
  { key: 'home', title: '接回家', icon: '🏡' }
]

/* 每个节点对应的：状态标签、进度条配色、右下角操作、下一步说明 */
const STAGE_PLANS = [
  {
    label: '已提交申请', color: 'blue', icon: '📝', percent: 18, action: '查看申请',
    short: '申请已送达，正在分配志愿者', next: '等待志愿者联系'
  },
  {
    label: '资料审核中', color: 'yellow', icon: '🔍', percent: 38, action: '补充材料',
    short: '志愿者正在核对你的资料', next: '审核结果 1-2 天出'
  },
  {
    label: '家访排期中', color: 'blue', icon: '☎️', percent: 62, action: '预约家访',
    short: '约个时间聊聊养宠计划吧', next: '确认家访时间'
  },
  {
    label: '待签署协议', color: 'pink', icon: '📄', percent: 84, action: '查看协议',
    short: '协议已准备好，就差你的签名', next: '签完就能接 TA 回家'
  },
  {
    label: '已完成领养', color: 'mint', icon: '🏡', percent: 100, action: '写成长日记',
    short: 'TA 已经是家里的一员啦', next: '常回来看看我们呀'
  }
]

/* 申请状态 */
const APP_STATUS = {
  pending: { key: 'pending', text: '待审核', color: 'yellow', icon: '⏳', note: '志愿者正在审核你的申请，请耐心等待～' },
  passed: { key: 'passed', text: '已通过', color: 'mint', icon: '✅', note: '恭喜通过！请留意回访联系，准备接 TA 回家～' },
  rejected: { key: 'rejected', text: '未通过', color: 'gray', icon: '💛', note: '很遗憾本次未通过，可以试试其它毛孩子哦～' }
}

/* ---------------- 数据读取 ---------------- */
function readArr(key) {
  try {
    const val = JSON.parse(localStorage.getItem(key) || '[]')
    return Array.isArray(val) ? val : []
  } catch { return [] }
}

function load() {
  adoptedIds.value = readArr('petAdopted')
  favoriteIds.value = readArr('petFavorites')
  applications.value = readArr('petAdoptApplications')
  try {
    applyStatuses.value = JSON.parse(localStorage.getItem('petApplyStatuses') || '{}') || {}
  } catch { applyStatuses.value = {} }
  selectedFavorites.value = []
}

/* ---------------- 宠物列表 ---------------- */
const adoptedPets = computed(() => adoptedIds.value.map(id => pets.find(p => p.id === Number(id))).filter(Boolean))
const favoritePets = computed(() => favoriteIds.value.map(id => pets.find(p => p.id === Number(id))).filter(Boolean))

/* ---------------- 领养进度 ---------------- */
function stageOf(petId) {
  const index = 1 + (Math.abs(Number(petId)) % 4)
  return { index, ...STAGE_PLANS[index] }
}

const adoptedCards = computed(() => adoptedPets.value.map(pet => {
  const stage = stageOf(pet.id)
  return { pet, stage, percent: stage.percent }
}))

function isExpanded(id) {
  return expandedIds.value.includes(id)
}
function toggleExpand(id) {
  if (isExpanded(id)) expandedIds.value = expandedIds.value.filter(x => x !== id)
  else expandedIds.value = [...expandedIds.value, id]
}
function flowState(card, index) {
  if (index < card.stage.index) return 'done'
  if (index === card.stage.index) return 'active'
  return 'todo'
}

/* ---------------- 收藏 ---------------- */
const allFavoritesSelected = computed(() =>
  favoritePets.value.length > 0 && selectedFavorites.value.length === favoritePets.value.length
)

function toggleFavManage() {
  favManage.value = !favManage.value
  selectedFavorites.value = []
}
function toggleSelect(id) {
  const idx = selectedFavorites.value.indexOf(id)
  if (idx === -1) selectedFavorites.value = [...selectedFavorites.value, id]
  else selectedFavorites.value = selectedFavorites.value.filter(x => x !== id)
}
function toggleSelectAll() {
  selectedFavorites.value = allFavoritesSelected.value ? [] : favoritePets.value.map(p => p.id)
}

function persistFavorites(next) {
  localStorage.setItem('petFavorites', JSON.stringify(next))
  favoriteIds.value = next
  selectedFavorites.value = selectedFavorites.value.filter(id => next.includes(id))
}

function removeOneFavorite(id) {
  const pet = pets.find(p => p.id === Number(id))
  persistFavorites(favoriteIds.value.filter(x => Number(x) !== Number(id)))
  showToast(`已取消收藏「${pet ? pet.name : '这只毛孩子'}」`)
}

function askRemoveSelected() {
  const count = selectedFavorites.value.length
  if (!count) return
  confirmState.value = {
    icon: '💔',
    title: `取消收藏 ${count} 只毛孩子？`,
    desc: '取消后会从收藏里移除，之后随时可以再点小爱心收回来。',
    okText: '取消收藏',
    tone: 'danger',
    onOk: () => {
      persistFavorites(favoriteIds.value.filter(id => !selectedFavorites.value.includes(id)))
      showToast(`已取消 ${count} 只收藏`)
    }
  }
}

/* ---------------- 申请分组 ---------------- */
function resolveStatus(app, index) {
  const raw = String(app.status || '')
  if (raw.includes('通过') && !raw.includes('未')) return APP_STATUS.passed
  if (raw.includes('未通过') || raw.includes('驳回')) return APP_STATUS.rejected
  if (raw.includes('审核') || raw.includes('待')) return APP_STATUS.pending
  // 真实提交的申请只记录了「预约中」，统一按待审核展示
  if (applyStatuses.value[app.petId] === '预约中') return APP_STATUS.pending
  return [APP_STATUS.pending, APP_STATUS.passed, APP_STATUS.rejected][index % 3]
}

const appGroups = computed(() => {
  const groups = [
    { key: 'pending', label: '待审核', icon: '⏳', color: 'yellow', note: '志愿者一般 1-2 天内回复', items: [] },
    { key: 'passed', label: '已通过', icon: '✅', color: 'mint', note: '准备迎接毛孩子回家啦', items: [] },
    { key: 'rejected', label: '未通过', icon: '💛', color: 'gray', note: '别灰心，还有很多在等你', items: [] }
  ]
  applications.value.forEach((app, index) => {
    const info = resolveStatus(app, index)
    const group = groups.find(g => g.key === info.key) || groups[0]
    const pet = pets.find(p => p.id === Number(app.petId))
    group.items.push({ ...app, info, pet })
  })
  return groups.filter(g => g.items.length)
})

/* ---------------- 浏览历史 ---------------- */
const dayMs = 86400000
function startOfToday() {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d.getTime()
}
function pad(n) {
  return String(n).padStart(2, '0')
}
function historyTime(ts) {
  if (!ts) return ''
  const d = new Date(ts)
  const today = startOfToday()
  if (ts >= today) return `今天 ${pad(d.getHours())}:${pad(d.getMinutes())}`
  if (ts >= today - dayMs) return `昨天 ${pad(d.getHours())}:${pad(d.getMinutes())}`
  return `${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}
function historyGroup(ts) {
  if (!ts) return 'earlier'
  const today = startOfToday()
  if (ts >= today) return 'today'
  if (ts >= today - dayMs) return 'yesterday'
  if (ts >= today - 6 * dayMs) return 'week'
  return 'earlier'
}

const historyGroups = computed(() => {
  const buckets = [
    { key: 'today', label: '今天', icon: '🌞', items: [] },
    { key: 'yesterday', label: '昨天', icon: '🌤', items: [] },
    { key: 'week', label: '近 7 天', icon: '🗓', items: [] },
    { key: 'earlier', label: '更早以前', icon: '📦', items: [] }
  ]
  store.history.forEach(id => {
    const pet = pets.find(p => p.id === Number(id))
    if (!pet) return
    const ts = Number(store.historyLog[id]) || 0
    const bucket = buckets.find(b => b.key === historyGroup(ts)) || buckets[3]
    bucket.items.push({ pet, ts, timeText: historyTime(ts) })
  })
  return buckets.filter(b => b.items.length)
})

const historyCount = computed(() => historyGroups.value.reduce((sum, g) => sum + g.items.length, 0))

function deleteHistoryItem(id) {
  removeHistory(id)
  showToast('已从浏览历史里移除')
}
function askClearHistory() {
  if (!historyCount.value) return
  confirmState.value = {
    icon: '🧹',
    title: '清空全部浏览记录？',
    desc: '清空后这些毛孩子不会再出现在历史里，喜欢的话记得先收藏。',
    okText: '全部清空',
    tone: 'danger',
    onOk: () => {
      clearHistory()
      showToast('浏览历史已清空')
    }
  }
}

/* ---------------- 徽章 ---------------- */
function refreshAchievements() {
  const result = syncAchievements()
  unlockedIds.value = result.state.unlocked
  unlockedTimes.value = result.state.times || {}
  store.unlockedBadgeCount = result.state.unlocked.length
  if (store.wornBadge && !result.state.unlocked.includes(store.wornBadge)) setWornBadge('')
  if (result.newlyUnlocked.length) {
    newBadgeIds.value = result.newlyUnlocked.map(b => b.id)
    celebrateBadge.value = result.newlyUnlocked[0]
    clearTimeout(celebrateTimer)
    celebrateTimer = setTimeout(() => { celebrateBadge.value = null }, 2600)
    clearTimeout(newBadgeTimer)
    newBadgeTimer = setTimeout(() => { newBadgeIds.value = [] }, 6000)
  }
}

const badgeList = computed(() => badges.map(badge => {
  const { cur, target } = getBadgeProgressValue(badge.id)
  const unlocked = unlockedIds.value.includes(badge.id)
  return {
    ...badge,
    cur,
    target,
    unlocked,
    percent: Math.min(100, Math.round((cur / Math.max(1, target)) * 100)),
    unlockedAt: Number(unlockedTimes.value[badge.id]) || 0,
    isNew: newBadgeIds.value.includes(badge.id)
  }
}))

const badgeCategoriesWithCount = computed(() => badgeCategories.map(cat => {
  const list = cat.value === 'all' ? badgeList.value : badgeList.value.filter(b => b.category === cat.value)
  return {
    ...cat,
    total: list.length,
    unlocked: list.filter(b => b.unlocked).length
  }
}))

const filteredBadges = computed(() =>
  badgeCategory.value === 'all'
    ? badgeList.value
    : badgeList.value.filter(b => b.category === badgeCategory.value)
)

const unlockedCount = computed(() => badgeList.value.filter(b => b.unlocked).length)
const badgePercent = computed(() => Math.round((unlockedCount.value / Math.max(1, badgeList.value.length)) * 100))
const nextBadge = computed(() => badgeList.value.find(b => !b.unlocked) || null)
const wornBadge = computed(() => badgeList.value.find(b => b.id === wornBadgeId.value) || null)

const badgeModalData = computed(() => badgeList.value.find(b => b.id === badgeModalId.value) || null)

function openBadge(badge) {
  badgeModalId.value = badge.id
}
function wearBadge(badge) {
  if (!badge || !badge.unlocked) return
  setWornBadge(badge.id)
  badgeModalId.value = ''
  showToast(`已佩戴「${badge.name}」，主页和头像都能看到啦 ✨`)
}
function unwearBadge() {
  setWornBadge('')
  badgeModalId.value = ''
  showToast('徽章已经取下来啦')
}
function gotoFromBadge(path) {
  badgeModalId.value = ''
  if (path) router.push(path)
}

/* ---------------- 待办提醒 ---------------- */
const TODO_KEY = 'petTodoDismissed'
function dayKey() {
  const d = new Date()
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}
const todoDismissed = ref(false)

const focusCard = computed(() => adoptedCards.value.find(c => c.stage.index < 4) || null)
const bagCount = computed(() => bagTotalCount())

const todos = computed(() => {
  const list = []
  if (focusCard.value) {
    list.push({
      id: 'flow',
      icon: focusCard.value.stage.icon,
      color: focusCard.value.stage.color,
      text: `${focusCard.value.pet.name} 正在「${focusCard.value.stage.label}」，${focusCard.value.stage.next}`,
      action: '看进度',
      run: () => {
        goTab('adopted')
        expandedIds.value = [focusCard.value.pet.id]
      }
    })
  }
  const pending = appGroups.value.find(g => g.key === 'pending')
  if (pending) {
    list.push({
      id: 'app',
      icon: '📬',
      color: 'yellow',
      text: `有 ${pending.items.length} 份申请正在审核，记得保持电话畅通`,
      action: '看申请',
      run: () => goTab('applications')
    })
  }
  if (!store.daily.signed) {
    list.push({
      id: 'sign',
      icon: '🎁',
      color: 'pink',
      text: '今天的签到奖励还没领，去萌宠乐园拿 20 游戏币',
      action: '去乐园',
      run: () => router.push('/playground')
    })
  }
  if (bagCount.value) {
    list.push({
      id: 'bag',
      icon: '🎒',
      color: 'blue',
      text: `背包里有 ${bagCount.value} 件物品还没用，去看看能派上什么用场`,
      action: '看背包',
      run: () => router.push('/backpack')
    })
  }
  if (unlockedCount.value && !wornBadgeId.value) {
    list.push({
      id: 'wear',
      icon: '🏅',
      color: 'mint',
      text: `你已解锁 ${unlockedCount.value} 枚徽章，挑一枚佩戴到主页吧`,
      action: '去佩戴',
      run: () => goTab('badges')
    })
  }
  return list.slice(0, 3)
})

const todoVisible = computed(() => !todoDismissed.value && todos.value.length > 0)

function dismissTodos() {
  todoDismissed.value = true
  localStorage.setItem(TODO_KEY, dayKey())
}

/* ---------------- Tabs ---------------- */
const tabCounts = computed(() => ({
  adopted: adoptedPets.value.length,
  favorites: favoritePets.value.length,
  applications: applications.value.length,
  history: historyCount.value,
  badges: unlockedCount.value
}))

function tabCount(tab) {
  if (tab.value === 'badges') return `${unlockedCount.value}/${badgeList.value.length}`
  return tabCounts.value[tab.value] || 0
}

function goTab(tab) {
  activeTab.value = tab
}

/* ---------------- 成长日记 ---------------- */
function openDiary(petId = 0) {
  diaryPreselect.value = Number(petId) || 0
  diaryOpen.value = true
}
function onDiaryChanged() {
  showToast('已经写进成长日记啦 📔')
  refreshAchievements()
}

const latestDiary = computed(() => store.diary[0] || null)

/* ---------------- 操作按钮 ---------------- */
function handleStageAction(card) {
  const index = card.stage.index
  if (index >= 4) {
    openDiary(card.pet.id)
    return
  }
  if (index === 3) {
    showToast('领养协议已发送到你的手机，签完就能接 TA 回家啦 📄')
    return
  }
  if (index === 2) {
    showToast('已记下：本周六 14:00 方便家访，志愿者会再和你确认 ☎️')
    return
  }
  if (index === 1) {
    showToast('补充资料入口已开启，志愿者会尽快联系你 📎')
    return
  }
  showToast('申请已收到，正在为你匹配志愿者 📝')
}

/* ---------------- 轻提示 / 确认 ---------------- */
function showToast(msg) {
  toast.value = msg
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toast.value = '' }, 2200)
}

function closeConfirm() {
  confirmState.value = null
}
function confirmOk() {
  const fn = confirmState.value && confirmState.value.onOk
  closeConfirm()
  if (fn) fn()
}

/* ---------------- 生命周期 ---------------- */
onMounted(() => {
  document.body.classList.add('home-body')
  load()
  refreshAchievements()

  todoDismissed.value = localStorage.getItem(TODO_KEY) === dayKey()

  loadTimer = setTimeout(() => { loading.value = false }, 420)
})

onBeforeUnmount(() => {
  document.body.classList.remove('home-body')
  clearTimeout(celebrateTimer)
  clearTimeout(newBadgeTimer)
  clearTimeout(toastTimer)
  clearTimeout(loadTimer)
})
</script>

<template>
  <div class="my-page app-bg">
    <main class="my-main">
      <!-- 页面标题 -->
      <div class="page-head">
        <div>
          <h1>我的毛孩子 <span>🐾</span></h1>
          <p class="sub">这里收藏着我和毛孩子的所有点点滴滴～</p>
        </div>
        <div class="head-actions">
          <button type="button" class="mp-btn ghost" @click="openDiary()">
            📔 成长日记
            <span class="ha-num">{{ store.diary.length }}</span>
          </button>
          <button type="button" class="mp-btn primary" @click="goTab('badges')">
            🏅 徽章 {{ unlockedCount }}/{{ badgeList.length }}
          </button>
        </div>
      </div>

      <!-- 今日待办提醒栏 -->
      <section v-if="todoVisible" class="todo-bar">
        <div class="tb-head">
          <span class="tb-pin" aria-hidden="true">📌</span>
          今日待办
          <em>{{ todos.length }}</em>
          <button type="button" class="tb-close" title="今天不再提醒" @click="dismissTodos">✕</button>
        </div>
        <ul class="tb-list">
          <li v-for="item in todos" :key="item.id" :class="item.color">
            <span class="tb-icon" aria-hidden="true">{{ item.icon }}</span>
            <p>{{ item.text }}</p>
            <button type="button" class="mp-btn sm" @click="item.run">{{ item.action }} →</button>
          </li>
        </ul>
      </section>

      <!-- 功能 Tab -->
      <div class="my-tabs" role="tablist" aria-label="我的毛孩子分区">
        <button
          v-for="tab in tabs"
          :key="tab.value"
          type="button"
          role="tab"
          class="my-tab"
          :class="{ active: activeTab === tab.value }"
          :aria-selected="activeTab === tab.value"
          @click="goTab(tab.value)"
        >
          <span class="tab-icon" aria-hidden="true">{{ tab.icon }}</span>
          <span class="tab-label">{{ tab.label }}</span>
          <span class="tab-count" :class="{ zero: !tabCounts[tab.value] && tab.value !== 'badges' }">{{ tabCount(tab) }}</span>
        </button>
      </div>

      <!-- 内容区：切换淡入淡出 -->
      <Transition name="tab-fade" mode="out-in">
        <div :key="activeTab" class="tab-panel">
          <!-- 加载骨架屏 -->
          <div v-if="loading" class="skel-list">
            <div v-for="n in 3" :key="n" class="skel-card">
              <span class="sk-avatar"></span>
              <div class="sk-lines">
                <span class="sk-line w60"></span>
                <span class="sk-line w35"></span>
              </div>
              <span class="sk-pill"></span>
            </div>
          </div>

          <!-- 我的领养 -->
          <template v-else-if="activeTab === 'adopted'">
            <button type="button" class="diary-entry" @click="openDiary()">
              <span class="de-art" aria-hidden="true">📔</span>
              <span class="de-copy">
                <span class="de-title">
                  成长日记
                  <em>NEW</em>
                </span>
                <small v-if="latestDiary">{{ latestDiary.mood }} {{ latestDiary.text }}</small>
                <small v-else>记录和毛孩子的每一个第一次，写给未来的自己。</small>
              </span>
              <span class="de-side">
                <strong>{{ store.diary.length }}</strong>
                <small>篇</small>
                <span class="de-arrow" aria-hidden="true">→</span>
              </span>
            </button>

            <!-- 毛孩子的家：已领养宠物的居家互动模块 -->
            <PetHome :cards="adoptedCards" @diary="openDiary" @toast="showToast" />

            <div v-if="adoptedCards.length" class="flow-head">
              <span class="fh-title">🧾 领养流程跟进</span>
              <span class="fh-note">点开卡片可以查看完整节点与进度</span>
            </div>

            <div v-if="adoptedCards.length" class="card-list">
              <article
                v-for="card in adoptedCards"
                :key="card.pet.id"
                class="adopt-card"
                :class="{ open: isExpanded(card.pet.id), done: card.stage.index >= 4 }"
                @click="toggleExpand(card.pet.id)"
              >
                <div class="ac-head">
                  <button type="button" class="ac-pet" @click.stop="router.push(`/pet/${card.pet.id}`)">
                    <span class="ac-avatar">
                      <img :src="card.pet.image" :alt="card.pet.name">
                    </span>
                    <span class="pet-meta">
                      <strong>{{ card.pet.name }}</strong>
                      <small>{{ card.pet.breed }} · {{ card.pet.gender }} · {{ card.pet.age }}</small>
                      <span class="ac-tag" :class="card.stage.color">
                        {{ card.stage.icon }} {{ card.stage.label }}
                      </span>
                    </span>
                  </button>

                  <div class="ac-progress">
                    <div class="ap-row">
                      <span>领养进度</span>
                      <strong>{{ card.percent }}%</strong>
                    </div>
                    <div class="ap-track">
                      <div class="ap-fill" :class="card.stage.color" :style="{ width: card.percent + '%' }"></div>
                    </div>
                    <small class="ap-note">{{ card.stage.short }}</small>
                  </div>

                  <div class="ac-actions" @click.stop>
                    <button type="button" class="mp-btn sm ghost" @click="toggleExpand(card.pet.id)">
                      {{ isExpanded(card.pet.id) ? '收起流程' : '查看流程' }}
                      <span class="chev" :class="{ up: isExpanded(card.pet.id) }" aria-hidden="true">⌄</span>
                    </button>
                    <button type="button" class="mp-btn sm primary" @click="handleStageAction(card)">
                      {{ card.stage.action }}
                    </button>
                  </div>
                </div>

                <!-- 展开：完整流程节点 -->
                <div class="ac-flow" @click.stop>
                  <div class="ac-flow-inner">
                    <ol class="flow-steps">
                      <li
                        v-for="(stage, index) in FLOW_STAGES"
                        :key="stage.key"
                        :class="flowState(card, index)"
                      >
                        <span class="fs-dot" aria-hidden="true">{{ stage.icon }}</span>
                        <strong>
                          {{ stage.title }}
                          <em v-if="flowState(card, index) === 'active'" class="fs-now">当前</em>
                        </strong>
                        <small>{{ flowState(card, index) === 'done' ? '已完成' : flowState(card, index) === 'active' ? card.stage.short : '待进行' }}</small>
                      </li>
                    </ol>
                    <div class="flow-foot">
                      <span>🧑‍⚕️ 对接志愿者：小满</span>
                      <span>📅 下一步：{{ card.stage.next }}</span>
                      <button
                        v-if="card.stage.index >= 4"
                        type="button"
                        class="mp-btn sm mint"
                        @click="openDiary(card.pet.id)"
                      >📔 写今日日记</button>
                    </div>
                  </div>
                </div>
              </article>
            </div>

            <CuteEmpty
              v-else
              title="还没有领养的毛孩子"
              desc="去领养专区挑一只，慢慢熟悉，把 TA 带回家～"
            >
              <button type="button" class="mp-btn primary" @click="router.push('/adopt')">🐾 去领养专区逛逛</button>
              <button type="button" class="mp-btn" @click="router.push('/')">先做缘分测试</button>
            </CuteEmpty>
          </template>

          <!-- 我的收藏 -->
          <template v-else-if="activeTab === 'favorites'">
            <div class="list-toolbar">
              <div class="lt-info">
                <strong>{{ favoritePets.length }}</strong> 只收藏
                <small v-if="favManage">已选 {{ selectedFavorites.length }} 只</small>
              </div>
              <div class="lt-actions">
                <template v-if="favManage">
                  <button type="button" class="mp-btn sm ghost" @click="toggleSelectAll">
                    {{ allFavoritesSelected ? '取消全选' : '全选' }}
                  </button>
                  <button
                    type="button"
                    class="mp-btn sm danger"
                    :disabled="!selectedFavorites.length"
                    @click="askRemoveSelected"
                  >💔 取消收藏</button>
                  <button type="button" class="mp-btn sm" @click="toggleFavManage">完成</button>
                </template>
                <button v-else type="button" class="mp-btn sm ghost" :disabled="!favoritePets.length" @click="toggleFavManage">
                  ☑️ 批量管理
                </button>
              </div>
            </div>

            <div v-if="favoritePets.length" class="fav-list">
              <div
                v-for="pet in favoritePets"
                :key="pet.id"
                class="fav-card"
                :class="{ selected: selectedFavorites.includes(pet.id), managing: favManage }"
                @click="favManage ? toggleSelect(pet.id) : router.push(`/pet/${pet.id}`)"
              >
                <label v-if="favManage" class="fav-check" @click.stop>
                  <input type="checkbox" :checked="selectedFavorites.includes(pet.id)" @change="toggleSelect(pet.id)">
                </label>
                <span class="fav-avatar"><img :src="pet.image" :alt="pet.name"></span>
                <span class="pet-meta">
                  <strong>{{ pet.name }}</strong>
                  <small>{{ pet.breed }} · {{ pet.personality }}</small>
                  <span class="pet-tags">
                    <em>{{ pet.gender }}</em>
                    <em>{{ pet.age }}</em>
                  </span>
                </span>
                <span class="fav-actions" @click.stop>
                  <button type="button" class="fav-heart" title="取消收藏" @click="removeOneFavorite(pet.id)">💗</button>
                  <span class="fav-go" aria-hidden="true">›</span>
                </span>
              </div>
            </div>

            <CuteEmpty
              v-else
              title="还没有收藏的毛孩子"
              desc="在卡片右上角点一下小爱心，喜欢的 TA 就会住进这里～"
            >
              <button type="button" class="mp-btn primary" @click="router.push('/adopt')">💕 去寻找心动毛孩子</button>
            </CuteEmpty>
          </template>

          <!-- 我的申请 -->
          <template v-else-if="activeTab === 'applications'">
            <div v-if="appGroups.length" class="app-groups">
              <section v-for="group in appGroups" :key="group.key" class="app-group">
                <header class="ag-head">
                  <span class="ag-title" :class="group.color">
                    {{ group.icon }} {{ group.label }}
                    <em>{{ group.items.length }}</em>
                  </span>
                  <span class="ag-note">{{ group.note }}</span>
                </header>

                <article
                  v-for="(app, index) in group.items"
                  :key="app.petId + '-' + index"
                  class="application-card"
                >
                  <div class="appc-head">
                    <span v-if="app.pet" class="appc-avatar">
                      <img :src="app.pet.image" :alt="app.pet.name">
                    </span>
                    <span v-else class="appc-avatar emoji">🐾</span>
                    <div class="appc-title">
                      <strong>{{ app.petName }}</strong>
                      <small>提交时间：{{ app.time || '刚刚' }}</small>
                    </div>
                    <span class="app-status" :class="group.color">{{ app.info.icon }} {{ app.info.text }}</span>
                  </div>

                  <p class="app-note">{{ app.info.note }}</p>

                  <div class="app-detail">
                    <span><em>申请人</em>{{ app.name }}</span>
                    <span><em>联系方式</em>{{ app.contact }}</span>
                    <span v-if="app.experience"><em>养宠经验</em>{{ app.experience }}</span>
                    <span v-if="app.housing"><em>居住环境</em>{{ app.housing }}</span>
                  </div>

                  <p v-if="app.message" class="app-message">💌 {{ app.message }}</p>

                  <div class="appc-foot">
                    <button
                      v-if="app.pet"
                      type="button"
                      class="mp-btn sm ghost"
                      @click="router.push(`/pet/${app.pet.id}`)"
                    >看看 {{ app.pet.name }} →</button>
                    <span v-if="group.key === 'pending'" class="appc-hint">⏳ 结果出来会第一时间通知你</span>
                    <span v-else-if="group.key === 'passed'" class="appc-hint ok">✅ 请留意回访电话</span>
                    <span v-else class="appc-hint">💛 再逛逛，也许下一个更合适</span>
                  </div>
                </article>
              </section>
            </div>

            <CuteEmpty
              v-else
              title="还没有提交过领养申请"
              desc="去领养专区挑一只，填几道小问题就能开始流程啦～"
            >
              <button type="button" class="mp-btn primary" @click="router.push('/adopt')">📝 去提交申请</button>
            </CuteEmpty>
          </template>

          <!-- 浏览历史 -->
          <template v-else-if="activeTab === 'history'">
            <div class="list-toolbar">
              <div class="lt-info">
                最近看过 <strong>{{ historyCount }}</strong> 只毛孩子
              </div>
              <div class="lt-actions">
                <button
                  type="button"
                  class="mp-btn sm danger"
                  :disabled="!historyCount"
                  @click="askClearHistory"
                >🧹 清空历史</button>
              </div>
            </div>

            <div v-if="historyGroups.length" class="hist-groups">
              <section v-for="group in historyGroups" :key="group.key" class="hist-group">
                <header class="hg-head">
                  <span aria-hidden="true">{{ group.icon }}</span>
                  {{ group.label }}
                  <em>{{ group.items.length }}</em>
                </header>
                <div class="hist-grid">
                  <div
                    v-for="item in group.items"
                    :key="item.pet.id"
                    class="hist-card"
                    @click="router.push(`/pet/${item.pet.id}`)"
                  >
                    <button
                      type="button"
                      class="hist-del"
                      title="从历史中删除"
                      @click.stop="deleteHistoryItem(item.pet.id)"
                    >✕</button>
                    <span class="hist-avatar"><img :src="item.pet.image" :alt="item.pet.name"></span>
                    <span class="hist-name">{{ item.pet.name }}</span>
                    <span class="hist-breed">{{ item.pet.breed }}</span>
                    <span class="hist-time">{{ item.timeText || '之前看过' }}</span>
                  </div>
                </div>
              </section>
            </div>

            <CuteEmpty
              v-else
              title="还没有浏览记录"
              desc="点开任意一只毛孩子的详情，这里会帮你记住～"
            >
              <button type="button" class="mp-btn primary" @click="router.push('/adopt')">🐾 去逛逛毛孩子</button>
            </CuteEmpty>
          </template>

          <!-- 我的徽章 -->
          <template v-else>
            <section class="badge-overview">
              <div class="bo-top">
                <div class="bo-main">
                  <h2 class="bo-title">徽章收藏进度</h2>
                  <p class="bo-sub">
                    已解锁
                    <strong>{{ unlockedCount }}</strong> / {{ badgeList.length }} 枚
                    <template v-if="nextBadge">· 下一个目标：{{ nextBadge.icon }} {{ nextBadge.name }}</template>
                  </p>
                  <div class="bo-track">
                    <div class="bo-fill" :style="{ width: badgePercent + '%' }">
                      <span v-if="badgePercent >= 18">{{ badgePercent }}%</span>
                    </div>
                  </div>
                </div>

                <div class="bo-stats">
                  <span class="bo-stat">
                    <strong>{{ unlockedCount }}</strong>
                    <small>已解锁</small>
                  </span>
                  <span class="bo-stat">
                    <strong>{{ badgeList.length - unlockedCount }}</strong>
                    <small>待解锁</small>
                  </span>
                </div>
              </div>

              <div class="bo-worn-row">
                <div v-if="wornBadge" class="worn-pill" :style="{ '--worn-color': wornBadge.color }">
                  <span class="wp-medal" aria-hidden="true">{{ wornBadge.icon }}</span>
                  <span class="wp-copy">
                    <small>主页佩戴中</small>
                    <strong>{{ wornBadge.name }}</strong>
                  </span>
                  <button type="button" class="mp-btn sm ghost" @click="unwearBadge">取下</button>
                </div>
                <p v-else class="bo-hint">🏅 点开任意一枚已解锁徽章，就能把它佩戴到主页和头像上。</p>
              </div>
            </section>

            <div class="cat-chips" role="tablist" aria-label="徽章分类">
              <button
                v-for="cat in badgeCategoriesWithCount"
                :key="cat.value"
                type="button"
                class="cat-chip"
                :class="{ active: badgeCategory === cat.value }"
                @click="badgeCategory = cat.value"
              >
                <span aria-hidden="true">{{ cat.icon }}</span>
                {{ cat.label }}
                <em>{{ cat.unlocked }}/{{ cat.total }}</em>
              </button>
            </div>

            <div class="badge-grid">
              <button
                v-for="badge in filteredBadges"
                :key="badge.id"
                type="button"
                class="badge-card"
                :class="{ locked: !badge.unlocked, 'is-new': badge.isNew, worn: badge.id === wornBadgeId }"
                :style="{ '--badge-color': badge.color }"
                @click="openBadge(badge)"
              >
                <span v-if="badge.id === wornBadgeId" class="bc-worn-tag">佩戴中</span>
                <div class="badge-medal"><span>{{ badge.icon }}</span></div>
                <strong class="badge-name">{{ badge.name }}</strong>
                <p class="badge-desc">{{ badge.desc }}</p>

                <div v-if="badge.unlocked" class="badge-foot">
                  <span class="bc-state ok">✓ 已解锁</span>
                  <span class="bc-go">查看 →</span>
                </div>
                <div v-else class="badge-foot locked-foot">
                  <div class="bc-track"><div class="bc-fill" :style="{ width: badge.percent + '%' }"></div></div>
                  <span class="bc-state">{{ badge.cur }} / {{ badge.target }}</span>
                </div>
              </button>
            </div>
          </template>
        </div>
      </Transition>
    </main>

    <!-- 右侧悬浮：游戏币 / 背包 / 日记 -->
    <aside class="my-dock" aria-label="快捷入口">
      <button type="button" class="dock-item coin" @click="router.push('/shop')">
        <CoinIcon :size="20" />
        <strong :key="store.coins">{{ store.coins }}</strong>
        <small>游戏币</small>
      </button>
      <button type="button" class="dock-item bag" @click="router.push('/backpack')">
        <span class="dock-icon" aria-hidden="true">🎒</span>
        <strong>{{ bagCount }}</strong>
        <small>我的背包</small>
      </button>
      <button type="button" class="dock-item diary" @click="openDiary()">
        <span class="dock-icon" aria-hidden="true">📔</span>
        <strong>{{ store.diary.length }}</strong>
        <small>成长日记</small>
      </button>
    </aside>

    <!-- 徽章详情 / 引导 -->
    <BadgeModal
      v-if="badgeModalData"
      :badge="badgeModalData"
      :unlocked="badgeModalData.unlocked"
      :worn="badgeModalData.id === wornBadgeId"
      :progress="{ cur: badgeModalData.cur, target: badgeModalData.target }"
      :unlocked-at="badgeModalData.unlockedAt"
      @close="badgeModalId = ''"
      @wear="wearBadge"
      @unwear="unwearBadge"
      @goto="gotoFromBadge"
    />

    <!-- 成长日记 -->
    <DiaryModal
      v-if="diaryOpen"
      :pet-options="adoptedPets"
      :preselect="diaryPreselect"
      @close="diaryOpen = false"
      @changed="onDiaryChanged"
    />

    <!-- 确认弹窗 -->
    <div v-if="confirmState" class="confirm-mask" @click.self="closeConfirm">
      <div class="confirm-card">
        <span class="cc-icon" aria-hidden="true">{{ confirmState.icon }}</span>
        <h3>{{ confirmState.title }}</h3>
        <p>{{ confirmState.desc }}</p>
        <div class="cc-actions">
          <button
            type="button"
            class="mp-btn"
            :class="confirmState.tone === 'danger' ? 'danger' : 'primary'"
            @click="confirmOk"
          >{{ confirmState.okText }}</button>
          <button type="button" class="mp-btn ghost" @click="closeConfirm">再想想</button>
        </div>
      </div>
    </div>

    <BadgeCelebration
      v-if="celebrateBadge"
      :badge="celebrateBadge"
      @close="celebrateBadge = null"
    />

    <div class="fun-toast" :class="{ show: toast }">{{ toast }}</div>
  </div>
</template>

<style scoped>
:global(body.home-body) { display: block; align-items: initial; justify-content: initial; padding: 0; }

.my-page {
  min-height: 100vh;
  font-family: var(--font-body);
  color: var(--text-1);
}
.my-main { max-width: var(--layout-max); margin: 0 auto; padding: var(--layout-pad-top) var(--layout-pad-x) var(--layout-pad-bottom); }

/* ===== 页头 ===== */
.page-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; flex-wrap: wrap; margin-bottom: 18px; }
.page-head h1 { margin: 0 0 6px; font-size: 32px; letter-spacing: 0.5px; }
.page-head h1 span { color: var(--pink); }
.sub { margin: 0; font-size: 13px; font-weight: 700; color: var(--text-2); }
.head-actions { display: flex; gap: 10px; flex-wrap: wrap; }
.ha-num {
  display: inline-grid;
  place-items: center;
  min-width: 19px;
  height: 18px;
  padding: 0 5px;
  font-size: 9.5px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 8px;
}

/* ===== 待办提醒栏 ===== */
.todo-bar {
  padding: 13px 16px 14px;
  margin-bottom: 20px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
  animation: todo-in 0.4s cubic-bezier(0.2, 1.3, 0.4, 1) backwards;
}
@keyframes todo-in { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: none; } }
.tb-head { display: flex; align-items: center; gap: 7px; margin-bottom: 10px; font-size: 13px; font-weight: 900; }
.tb-pin { font-size: 14px; }
.tb-head em {
  padding: 1px 7px;
  font-style: normal;
  font-size: 10px;
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: 999px;
}
.tb-close {
  margin-left: auto;
  width: 22px;
  height: 22px;
  display: grid;
  place-items: center;
  font-size: 10px;
  font-weight: 900;
  color: var(--text-3);
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.22);
  border-radius: 50%;
  cursor: pointer;
}
.tb-close:hover { color: var(--ink); border-color: var(--ink); background: #ffc9cf; }
.tb-list { margin: 0; padding: 0; list-style: none; display: grid; gap: 8px; }
.tb-list li {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 12px;
  background: #fff8e9;
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: var(--r-sm);
  transition: border-color 0.16s, transform 0.16s;
}
.tb-list li:hover { border-color: var(--ink); transform: translateX(2px); }
.tb-list li.yellow { background: #fff9d9; }
.tb-list li.pink { background: #fff0f5; }
.tb-list li.mint { background: #eefaf5; }
.tb-list li.blue { background: #eef6ff; }
.tb-icon { font-size: 15px; line-height: 1; }
.tb-list .mp-btn { flex: 0 0 auto; min-width: 78px; }
.tb-list p { flex: 1; min-width: 0; margin: 0; font-size: 12px; font-weight: 700; line-height: 1.6; color: var(--text-2); }

/* ===== Tab ===== */
.my-tabs { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 22px; }
.my-tab {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 10px 16px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
  cursor: pointer;
}
.my-tab:hover { background: #fff6d9; transform: translateY(-2px); box-shadow: 4px 5px 0 var(--ink); }
.my-tab.active { background: var(--yellow); transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }
.my-tab.active::after {
  content: '';
  position: absolute;
  left: 50%;
  bottom: -7px;
  width: 9px;
  height: 9px;
  background: var(--yellow);
  border-right: 2px solid var(--ink);
  border-bottom: 2px solid var(--ink);
  border-radius: 0 0 3px 0;
  transform: translateX(-50%) rotate(45deg);
}
.tab-icon { font-size: 14px; line-height: 1; }
.tab-count {
  display: inline-grid;
  place-items: center;
  min-width: 21px;
  height: 21px;
  padding: 0 5px;
  font-size: 10px;
  font-weight: 900;
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  transition: background-color 0.2s ease;
}
.my-tab.active .tab-count { background: #fff; }
.tab-count.zero { background: #efe7da; color: var(--text-3); }

/* Tab 切换淡入淡出 */
.tab-fade-enter-active { transition: opacity 0.22s ease, transform 0.26s cubic-bezier(0.2, 1, 0.4, 1); }
.tab-fade-leave-active { transition: opacity 0.13s ease; }
.tab-fade-enter-from { opacity: 0; transform: translateY(10px); }
.tab-fade-leave-to { opacity: 0; }

/* ===== 骨架屏 ===== */
.skel-list { display: grid; gap: 16px; }
.skel-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-1);
}
.sk-avatar,
.sk-line,
.sk-pill {
  display: block;
  background: linear-gradient(90deg, #e9dcc6 25%, #f8f1e4 37%, #e9dcc6 63%);
  background-size: 400% 100%;
  border-radius: 9px;
  animation: sk-shimmer 1.3s ease-in-out infinite;
}
.sk-avatar { width: 66px; height: 66px; border-radius: 14px; flex: 0 0 auto; }
.sk-lines { flex: 1; display: grid; gap: 9px; }
.sk-line { height: 13px; }
.sk-line.w60 { width: 60%; }
.sk-line.w35 { width: 35%; height: 10px; }
.sk-pill { width: 96px; height: 30px; flex: 0 0 auto; }
@keyframes sk-shimmer {
  0% { background-position: 100% 50%; }
  100% { background-position: 0 50%; }
}

/* ===== 成长日记入口 ===== */
.diary-entry {
  display: flex;
  align-items: center;
  gap: 16px;
  width: 100%;
  margin-bottom: 16px;
  padding: 15px 18px;
  text-align: left;
  font: inherit;
  color: var(--ink);
  background: linear-gradient(115deg, #fff8e9 0%, #fff2f7 100%);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
  cursor: pointer;
}
.diary-entry:hover { transform: translateY(-3px); box-shadow: var(--shadow-3); }
.de-art {
  width: 52px;
  height: 52px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 24px;
  background: var(--yellow);
  border: var(--line);
  border-radius: 14px;
  box-shadow: 3px 3px 0 var(--ink);
}
.de-copy { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 5px; }
.de-title { display: flex; align-items: center; gap: 7px; font-size: 15px; font-weight: 900; }
.de-title em {
  padding: 1px 6px;
  font-style: normal;
  font-size: 9px;
  letter-spacing: 0.4px;
  color: #fff;
  background: #ff6f91;
  border: 2px solid var(--ink);
  border-radius: 999px;
}
.de-copy small {
  font-size: 11.5px;
  font-weight: 700;
  color: var(--text-2);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.de-side { display: flex; align-items: baseline; gap: 3px; flex: 0 0 auto; }
.de-side strong { font-size: 22px; }
.de-side small { font-size: 10px; font-weight: 900; color: var(--text-3); }
.de-arrow { margin-left: 8px; font-size: 15px; font-weight: 900; color: var(--text-3); }
.diary-entry:hover .de-arrow { transform: translateX(4px); color: var(--ink); }

/* ===== 领养流程小标题 ===== */
.flow-head { display: flex; align-items: center; gap: 8px; margin: 4px 2px 9px; }
.fh-title { font-size: 12px; font-weight: 900; }
.fh-note { font-size: 9.5px; font-weight: 700; color: var(--text-3); }

/* ===== 领养卡片 ===== */
.card-list { display: grid; gap: 16px; }
.adopt-card {
  position: relative;
  padding: 18px 20px;
  cursor: pointer;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
  transition: transform 0.2s cubic-bezier(0.2, 1, 0.4, 1), box-shadow 0.2s ease, background-color 0.2s ease;
}
.adopt-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-3); }
.adopt-card.open { background: #fffcf0; }

.ac-head { display: grid; grid-template-columns: minmax(0, 1fr) 220px 122px; gap: 18px; align-items: center; }
.ac-pet { display: flex; align-items: center; gap: 14px; padding: 0; font: inherit; text-align: left; color: var(--ink); background: none; border: none; cursor: pointer; min-width: 0; }
.ac-avatar {
  width: 68px;
  height: 68px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  padding: 4px;
  background: linear-gradient(160deg, #fff, #fff2d8);
  border: 2px solid rgba(43, 43, 43, 0.16);
  border-radius: 16px;
  overflow: hidden;
  transition: border-color 0.2s ease;
}
.ac-avatar img { width: 100%; height: 100%; object-fit: contain; transition: scale 0.25s ease; }
.adopt-card:hover .ac-avatar { border-color: var(--ink); }
.adopt-card:hover .ac-avatar img { scale: 1.08; }

.pet-meta { display: flex; flex-direction: column; gap: 4px; min-width: 0; }
.pet-meta strong { font-size: 18px; }
.pet-meta small { font-size: 11.5px; font-weight: 700; color: var(--text-2); }
.ac-tag {
  align-self: flex-start;
  margin-top: 3px;
  padding: 3px 9px;
  font-size: 10px;
  font-weight: 900;
  border: 2px solid var(--ink);
  border-radius: 8px;
}
.ac-tag.yellow { background: var(--yellow); }
.ac-tag.mint { background: var(--mint); }
.ac-tag.pink { background: var(--pink); }
.ac-tag.blue { background: var(--blue); }
.ac-tag.gray { background: #e6ded2; }

.ac-progress { min-width: 0; }
.ap-row { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; margin-bottom: 6px; }
.ap-row span { font-size: 11px; font-weight: 900; color: var(--text-2); }
.ap-row strong { font-size: 14px; }
.ap-track {
  height: 14px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
  overflow: hidden;
  box-shadow: 1px 1px 0 var(--ink);
}
.ap-fill { height: 100%; border-right: 2px solid var(--ink); border-radius: 999px; transition: width 0.6s cubic-bezier(0.2, 1, 0.4, 1); }
.ap-fill.yellow { background: linear-gradient(90deg, #fff0b3, var(--yellow)); }
.ap-fill.mint { background: linear-gradient(90deg, #c9f2df, var(--mint)); }
.ap-fill.pink { background: linear-gradient(90deg, #ffd3e2, var(--pink)); }
.ap-fill.blue { background: linear-gradient(90deg, #d6ebff, var(--blue)); }
.ap-note { display: block; margin-top: 6px; font-size: 10.5px; font-weight: 700; color: var(--text-3); line-height: 1.5; }

.ac-actions { display: flex; flex-direction: column; gap: 8px; align-self: end; }
.chev { display: inline-block; transition: transform 0.24s ease; }
.chev.up { transform: rotate(180deg); }

/* 展开流程：0fr -> 1fr 平滑过渡 */
.ac-flow { display: grid; grid-template-rows: 0fr; transition: grid-template-rows 0.4s cubic-bezier(0.2, 1, 0.4, 1); }
.adopt-card.open .ac-flow { grid-template-rows: 1fr; }
.ac-flow-inner { overflow: hidden; }

.flow-steps {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 0;
  margin: 16px 0 0;
  padding: 16px 0 4px;
  list-style: none;
  border-top: 2px dashed #e8d8bf;
}
.flow-steps li { position: relative; padding: 0 5px; text-align: center; }
.flow-steps li::after {
  content: '';
  position: absolute;
  top: 17px;
  left: calc(50% + 24px);
  right: 2px;
  border-top: 3px dashed #e2d2b8;
}
.flow-steps li:last-child::after { display: none; }
.flow-steps li.done::after { border-top-color: var(--mint); border-top-style: solid; }
.flow-steps li.active::after { border-top-color: #f0cf6a; }
.fs-dot {
  position: relative;
  z-index: 1;
  width: 36px;
  height: 36px;
  margin: 0 auto 7px;
  display: grid;
  place-items: center;
  font-size: 15px;
  background: #f4ede1;
  border: 2px solid rgba(43, 43, 43, 0.24);
  border-radius: 50%;
  filter: grayscale(0.6);
  opacity: 0.75;
}
.flow-steps li.done .fs-dot { background: var(--mint); border-color: var(--ink); box-shadow: 2px 2px 0 var(--ink); filter: none; opacity: 1; }
.flow-steps li.active .fs-dot { background: var(--yellow); border-color: var(--ink); box-shadow: 2px 2px 0 var(--ink); filter: none; opacity: 1; animation: fs-pulse 2.2s ease-in-out infinite; }
@keyframes fs-pulse {
  0%, 100% { box-shadow: 2px 2px 0 var(--ink), 0 0 0 0 rgba(255, 216, 77, 0.6); }
  50% { box-shadow: 2px 2px 0 var(--ink), 0 0 0 7px rgba(255, 216, 77, 0); }
}
.flow-steps strong { display: block; font-size: 12px; font-weight: 900; }
.flow-steps small { display: block; margin-top: 3px; font-size: 10px; font-weight: 700; line-height: 1.5; color: var(--text-3); }
.fs-now {
  display: inline-block;
  margin-left: 3px;
  padding: 0 5px;
  font-style: normal;
  font-size: 9px;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 999px;
  vertical-align: 1px;
}
.flow-foot {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px 18px;
  margin-top: 12px;
  padding: 10px 12px;
  font-size: 11px;
  font-weight: 700;
  color: var(--text-2);
  background: #fff8e9;
  border: 2px dashed rgba(43, 43, 43, 0.18);
  border-radius: var(--r-sm);
}
.flow-foot button { margin-left: auto; }

/* ===== 列表工具条 ===== */
.list-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 14px;
  padding: 10px 14px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
}
.lt-info { font-size: 12px; font-weight: 900; color: var(--text-2); }
.lt-info strong { font-size: 15px; color: var(--text-1); }
.lt-info small { margin-left: 8px; padding: 2px 7px; font-size: 10px; background: var(--yellow); border: 2px solid var(--ink); border-radius: 999px; }
.lt-actions { display: flex; gap: 8px; flex-wrap: wrap; }

/* ===== 收藏 ===== */
.fav-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 14px; }
.fav-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 13px 15px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-1);
  cursor: pointer;
  transition: transform 0.18s cubic-bezier(0.2, 1, 0.4, 1), box-shadow 0.18s ease, background-color 0.18s ease;
}
.fav-card:hover { transform: translateY(-3px); box-shadow: var(--shadow-3); }
.fav-card.selected { background: #fff6d9; box-shadow: 0 0 0 3px rgba(255, 216, 77, 0.55), var(--shadow-2); }
.fav-check { display: flex; }
.fav-check input { width: 19px; height: 19px; accent-color: var(--pink); cursor: pointer; }
.fav-avatar {
  width: 54px;
  height: 54px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  padding: 3px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.15);
  border-radius: 13px;
  overflow: hidden;
  transition: border-color 0.18s ease;
}
.fav-avatar img { width: 100%; height: 100%; object-fit: contain; transition: scale 0.22s ease; }
.fav-card:hover .fav-avatar { border-color: var(--ink); }
.fav-card:hover .fav-avatar img { scale: 1.08; }
.fav-card .pet-meta { flex: 1; }
.pet-tags { display: flex; gap: 5px; margin-top: 2px; }
.pet-tags em {
  padding: 1px 6px;
  font-style: normal;
  font-size: 9.5px;
  font-weight: 900;
  color: var(--text-2);
  background: #fff3d9;
  border: 1.5px solid rgba(43, 43, 43, 0.24);
  border-radius: 999px;
}
.fav-actions { display: flex; align-items: center; gap: 6px; }
.fav-heart {
  width: 30px;
  height: 30px;
  display: grid;
  place-items: center;
  font-size: 13px;
  background: #fff0f5;
  border: 2px solid rgba(43, 43, 43, 0.24);
  border-radius: 50%;
  cursor: pointer;
  transition: background-color 0.16s ease, border-color 0.16s ease, transform 0.16s ease;
}
.fav-heart:hover { background: #ffc9cf; border-color: var(--ink); transform: scale(1.1); }
.fav-actions { padding-right: 2px; }
.fav-go { font-size: 15px; font-weight: 900; line-height: 1; color: var(--text-3); transition: transform 0.16s ease, color 0.16s ease; }
.fav-card:hover .fav-go { color: var(--ink); transform: translateX(2px); }

/* ===== 申请 ===== */
.app-groups { display: grid; gap: 20px; }
.ag-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
.ag-title {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 5px 12px;
  font-size: 12px;
  font-weight: 900;
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 2px 2px 0 var(--ink);
}
.ag-title.yellow { background: var(--yellow); }
.ag-title.mint { background: var(--mint); }
.ag-title.gray { background: #e6ded2; }
.ag-title em { font-style: normal; font-size: 10px; opacity: 0.8; }
.ag-note { font-size: 11px; font-weight: 700; color: var(--text-3); }

.app-group { display: grid; gap: 12px; }
.application-card {
  padding: 16px 18px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-1);
  transition: transform 0.18s ease, box-shadow 0.18s ease;
}
.application-card:hover { transform: translateY(-3px); box-shadow: var(--shadow-3); }
.appc-head { display: flex; align-items: center; gap: 12px; margin-bottom: 9px; }
.appc-avatar {
  width: 44px;
  height: 44px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  padding: 3px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.15);
  border-radius: 12px;
  overflow: hidden;
  font-size: 18px;
}
.appc-avatar img { width: 100%; height: 100%; object-fit: contain; }
.appc-title { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.appc-title strong { font-size: 16px; }
.appc-title small { font-size: 10.5px; font-weight: 700; color: var(--text-3); }
.app-status {
  margin-left: auto;
  flex: 0 0 auto;
  padding: 4px 10px;
  font-size: 10.5px;
  font-weight: 900;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
}
.app-status.yellow { background: var(--yellow); }
.app-status.mint { background: var(--mint); }
.app-status.gray { background: #e6ded2; }
.app-note { margin: 0 0 11px; font-size: 12px; font-weight: 700; color: var(--text-2); }
.app-detail { display: flex; flex-wrap: wrap; gap: 7px 18px; font-size: 11.5px; font-weight: 700; color: var(--text-2); }
.app-detail em { margin-right: 5px; font-style: normal; font-size: 10px; font-weight: 900; color: var(--text-3); }
.app-message {
  margin: 11px 0 0;
  padding: 9px 12px;
  font-size: 11.5px;
  font-weight: 700;
  line-height: 1.7;
  color: var(--text-2);
  background: #fff8e9;
  border: 2px dashed rgba(43, 43, 43, 0.16);
  border-radius: var(--r-sm);
}
.appc-foot { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin-top: 12px; }
.appc-hint { font-size: 10.5px; font-weight: 900; color: var(--text-3); }
.appc-hint.ok { color: #2f8f70; }

/* ===== 浏览历史 ===== */
.hist-groups { display: grid; gap: 22px; }
.hg-head {
  display: flex;
  align-items: center;
  gap: 7px;
  margin-bottom: 10px;
  font-size: 12px;
  font-weight: 900;
  color: var(--text-2);
}
.hg-head em {
  padding: 1px 7px;
  font-style: normal;
  font-size: 10px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.2);
  border-radius: 999px;
}
.hg-head::after { content: ''; flex: 1; border-top: 2px dashed #e8d8bf; }
.hist-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(154px, 1fr)); gap: 12px; }
.hist-card {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  padding: 14px 10px 11px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-1);
  cursor: pointer;
  transition: transform 0.18s cubic-bezier(0.2, 1, 0.4, 1), box-shadow 0.18s ease;
}
.hist-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-3); }
.hist-avatar {
  width: 52px;
  height: 52px;
  display: grid;
  place-items: center;
  padding: 3px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: 13px;
  overflow: hidden;
  transition: border-color 0.18s ease;
}
.hist-avatar img { width: 100%; height: 100%; object-fit: contain; transition: scale 0.22s ease; }
.hist-card:hover .hist-avatar { border-color: var(--ink); }
.hist-card:hover .hist-avatar img { scale: 1.1; }
.hist-name { margin-top: 3px; font-size: 14px; font-weight: 900; }
.hist-breed { font-size: 10.5px; font-weight: 700; color: var(--text-2); }
.hist-time { font-size: 9.5px; font-weight: 900; color: var(--text-3); }
.hist-del {
  position: absolute;
  right: 7px;
  top: 7px;
  width: 21px;
  height: 21px;
  display: grid;
  place-items: center;
  font-size: 9px;
  font-weight: 900;
  color: var(--ink);
  background: #ffc9cf;
  border: 2px solid var(--ink);
  border-radius: 50%;
  cursor: pointer;
  opacity: 0;
  transition: opacity 0.16s ease, transform 0.16s ease;
}
.hist-card:hover .hist-del { opacity: 1; }
.hist-del:hover { transform: scale(1.12); }

/* ===== 徽章总览 ===== */
.badge-overview {
  padding: 18px 20px 16px;
  margin-bottom: 14px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
}
.bo-top { display: flex; align-items: center; gap: 18px; flex-wrap: wrap; }
.bo-main { flex: 1 1 260px; min-width: 0; }
.bo-title { margin: 0 0 4px; font-size: 18px; }
.bo-sub { margin: 0; font-size: 12px; font-weight: 700; color: var(--text-2); }
.bo-sub strong { font-size: 14px; color: var(--text-1); }
.bo-track {
  margin-top: 10px;
  height: 18px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
  overflow: hidden;
  box-shadow: 2px 2px 0 var(--ink);
}
.bo-fill {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding-right: 6px;
  font-size: 10px;
  font-weight: 900;
  color: var(--ink);
  background: linear-gradient(90deg, #ffe9a3, var(--yellow));
  border-right: 2px solid var(--ink);
  border-radius: 999px;
  transition: width 0.6s cubic-bezier(0.2, 1, 0.4, 1);
}
.bo-stats { display: flex; gap: 10px; }
.bo-stat {
  min-width: 70px;
  padding: 8px 12px;
  text-align: center;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
}
.bo-stat strong { display: block; font-size: 19px; line-height: 1.2; }
.bo-stat small { font-size: 9.5px; font-weight: 900; color: var(--text-3); }
.bo-worn-row { margin-top: 13px; }
.worn-pill {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 7px 10px 7px 7px;
  background: #fff6d9;
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 2px 2px 0 var(--ink);
}
.wp-medal {
  width: 30px;
  height: 30px;
  display: grid;
  place-items: center;
  font-size: 15px;
  background: var(--worn-color, var(--yellow));
  border: 2px solid var(--ink);
  border-radius: 50%;
}
.wp-copy { display: flex; flex-direction: column; line-height: 1.25; }
.wp-copy small { font-size: 9px; font-weight: 900; color: var(--text-3); }
.wp-copy strong { font-size: 12px; }
.worn-pill .mp-btn { margin-left: 4px; }
.bo-hint { margin: 0; font-size: 11.5px; font-weight: 700; color: var(--text-3); }

/* 分类 chips */
.cat-chips { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 16px; }
.cat-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 7px 12px;
  font: inherit;
  font-size: 11.5px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 2px 2px 0 var(--ink);
  cursor: pointer;
  transition: background-color 0.16s ease, transform 0.16s ease, box-shadow 0.16s ease;
}
.cat-chip:hover { background: #fff6d9; transform: translateY(-2px); box-shadow: 3px 4px 0 var(--ink); }
.cat-chip.active { background: var(--yellow); transform: translate(1px, 1px); box-shadow: 1px 1px 0 var(--ink); }
.cat-chip em { font-style: normal; font-size: 9.5px; opacity: 0.72; }

/* ===== 徽章卡片 ===== */
.badge-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(206px, 1fr)); gap: 18px; }
.badge-card {
  position: relative;
  padding: 20px 15px 15px;
  text-align: center;
  font: inherit;
  color: var(--ink);
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
  cursor: pointer;
  transition: transform 0.18s cubic-bezier(0.2, 1, 0.4, 1), box-shadow 0.18s ease, background-color 0.18s ease;
}
.badge-card:hover { transform: translateY(-5px); box-shadow: var(--shadow-3); }
.badge-card.locked { background: #f7f2ea; border-style: dashed; box-shadow: var(--shadow-1); }
.badge-card.worn { background: #fffbe8; box-shadow: 0 0 0 3px rgba(255, 216, 77, 0.65), var(--shadow-2); }
.bc-worn-tag {
  position: absolute;
  left: 50%;
  top: -11px;
  transform: translateX(-50%);
  padding: 2px 9px;
  font-size: 9.5px;
  font-weight: 900;
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 1px 1px 0 var(--ink);
}

.badge-medal {
  position: relative;
  width: 78px;
  height: 78px;
  margin: 0 auto 11px;
  display: grid;
  place-items: center;
  background: var(--badge-color);
  border: var(--line);
  border-radius: 50%;
  box-shadow: 5px 6px 0 var(--ink), inset -6px -7px 0 rgba(43, 43, 43, 0.12);
  animation: badge-bob 3.4s ease-in-out infinite;
}
.badge-medal span { font-size: 38px; line-height: 1; filter: drop-shadow(3px 4px 0 rgba(43, 43, 43, 0.18)); }
@keyframes badge-bob {
  0%, 100% { translate: 0 0; rotate: -3deg; }
  50% { translate: 0 -6px; rotate: 3deg; }
}
.badge-card.locked .badge-medal { background: #d9d3c9; box-shadow: 4px 5px 0 #b6ab9c; filter: grayscale(1); opacity: 0.72; }
.badge-card:hover .badge-medal { animation-play-state: paused; scale: 1.06; }
.badge-name { display: block; margin-bottom: 5px; font-size: 15px; }
.badge-desc { margin: 0 0 11px; font-size: 11px; font-weight: 700; line-height: 1.65; color: var(--text-2); min-height: 36px; }
.badge-foot { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.bc-state {
  padding: 3px 9px;
  font-size: 9.5px;
  font-weight: 900;
  background: #e6ded2;
  border: 2px solid var(--ink);
  border-radius: 8px;
}
.bc-state.ok { background: var(--mint); }
.bc-go { font-size: 10px; font-weight: 900; color: var(--text-3); }
.badge-card:hover .bc-go { color: var(--ink); }
.locked-foot { display: grid; grid-template-columns: 1fr; gap: 6px; }
.bc-track { width: 100%; height: 10px; background: #fff; border: 2px solid var(--ink); border-radius: 999px; overflow: hidden; }
.bc-fill { height: 100%; background: var(--yellow); border-right: 2px solid var(--ink); transition: width 0.5s ease; }
.locked-foot .bc-state { justify-self: center; }

/* 新解锁：弹跳 + 发光 */
.badge-card.is-new { animation: badge-bounce 0.7s cubic-bezier(0.2, 1.5, 0.4, 1) 2; }
.badge-card.is-new::after {
  content: '';
  position: absolute;
  inset: -5px;
  border: 3px solid var(--yellow);
  border-radius: 20px;
  box-shadow: 0 0 0 6px rgba(255, 216, 77, 0.35);
  pointer-events: none;
  animation: badge-glow 1.7s ease-out 3;
}
@keyframes badge-bounce {
  0%, 100% { translate: 0 0; }
  30% { translate: 0 -12px; }
  55% { translate: 0 0; }
  72% { translate: 0 -5px; }
}
@keyframes badge-glow {
  0% { opacity: 0.9; transform: scale(1); }
  100% { opacity: 0; transform: scale(1.12); }
}

/* ===== 右侧悬浮栏 ===== */
.my-dock {
  position: fixed;
  right: 18px;
  top: 50%;
  transform: translateY(-50%);
  z-index: 30;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.dock-item {
  width: 68px;
  padding: 9px 4px 7px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  font: inherit;
  color: var(--ink);
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
  cursor: pointer;
  transition: transform 0.18s cubic-bezier(0.2, 1, 0.4, 1), box-shadow 0.18s ease;
}
.dock-item:hover { transform: translate(-4px, -2px); box-shadow: var(--shadow-3); }
.dock-item.coin { background: #fff3c9; }
.dock-item.bag { background: #eefaf5; }
.dock-item.diary { background: #fff0f5; }
.dock-icon { font-size: 18px; line-height: 1; }
.dock-item strong { font-size: 13px; line-height: 1.2; }
.dock-item small { font-size: 9px; font-weight: 900; color: var(--text-3); }

/* ===== 确认弹窗 ===== */
.confirm-mask {
  position: fixed;
  inset: 0;
  z-index: 82;
  display: grid;
  place-items: center;
  padding: 22px;
  background: rgba(43, 43, 43, 0.46);
  animation: fade-in 0.2s ease both;
}
@keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
.confirm-card {
  width: min(360px, 100%);
  padding: 24px 22px 20px;
  text-align: center;
  background: #fffdf6;
  border: var(--line);
  border-radius: 20px;
  box-shadow: 9px 10px 0 var(--ink);
  animation: confirm-pop 0.28s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
@keyframes confirm-pop { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: none; } }
.cc-icon {
  width: 54px;
  height: 54px;
  margin: 0 auto 10px;
  display: grid;
  place-items: center;
  font-size: 25px;
  background: #fff0f5;
  border: 2px solid var(--ink);
  border-radius: 50%;
}
.confirm-card h3 { margin: 0 0 7px; font-size: 17px; }
.confirm-card p { margin: 0 0 18px; font-size: 11.5px; font-weight: 700; line-height: 1.7; color: var(--text-2); }
.cc-actions { display: flex; justify-content: center; gap: 10px; }

/* ===== 响应式 ===== */
@media (max-width: 1360px) {
  .my-dock { display: none; }
}
@media (max-width: 900px) {
  .ac-head { grid-template-columns: 1fr; gap: 12px; }
  .ac-progress { padding-left: 2px; }
  .ac-actions { flex-direction: row; justify-content: flex-end; }
  .flow-steps { grid-template-columns: repeat(3, 1fr); gap: 14px 0; }
  .flow-steps li:nth-child(3n)::after { display: none; }
  .fav-list { grid-template-columns: 1fr; }
}
@media (max-width: 620px) {
  .my-main { padding: 22px 14px 70px; }
  .page-head h1 { font-size: 25px; }
  .head-actions { width: 100%; }
  .head-actions .mp-btn { flex: 1; }
  .my-tabs { gap: 8px; }
  .my-tab { padding: 8px 12px; font-size: 12px; }
  .tab-label { display: none; }
  .my-tab .tab-icon { font-size: 16px; }
  .badge-grid { grid-template-columns: repeat(auto-fill, minmax(148px, 1fr)); gap: 12px; }
  .badge-medal { width: 62px; height: 62px; }
  .badge-medal span { font-size: 30px; }
  .bo-stats { width: 100%; }
  .bo-stat { flex: 1; }
  .flow-steps { grid-template-columns: 1fr; gap: 12px; }
  .flow-steps li { display: flex; align-items: center; gap: 10px; text-align: left; padding: 0; }
  .flow-steps li::after { display: none; }
  .fs-dot { margin: 0; flex: 0 0 auto; }
  .flow-steps small { margin-top: 1px; }
}
</style>
