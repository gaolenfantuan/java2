<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CuteEmpty from '../components/CuteEmpty.vue'
import { findPet } from '../data/pets'
import { findHomePet } from '../data/homePets'
import { recordHistory } from '../store'

const route = useRoute()
const router = useRouter()
const pet = computed(() => findHomePet(route.params.id) || findPet(route.params.id))
const adopted = ref(false)

// 游戏化属性面板（增量）
const baseStats = {
  1: { friendly: 92, lively: 68, health: 95, gluttony: 55 },
  2: { friendly: 45, lively: 38, health: 90, gluttony: 42 },
  3: { friendly: 88, lively: 95, health: 92, gluttony: 74 },
  4: { friendly: 90, lively: 86, health: 88, gluttony: 96 },
  5: { friendly: 72, lively: 40, health: 94, gluttony: 60 },
  6: { friendly: 66, lively: 92, health: 86, gluttony: 80 }
}
const statItems = [
  { key: 'friendly', label: '亲人度', cls: 'friendly', emoji: '💕' },
  { key: 'lively', label: '活泼度', cls: 'lively', emoji: '⚡' },
  { key: 'health', label: '健康值', cls: 'health', emoji: '🌿' },
  { key: 'gluttony', label: '贪吃值', cls: 'gluttony', emoji: '🍪' }
]
const stats = ref({ friendly: 0, lively: 0, health: 0, gluttony: 0 })
const snackLimit = 3
const snackCount = ref(0)
const isHappy = ref(false)
let happyTimer = null

function loadAdopted() {
  try {
    const ids = JSON.parse(localStorage.getItem('petAdopted') || '[]')
    adopted.value = Array.isArray(ids) && ids.includes(Number(route.params.id))
  } catch {
    adopted.value = false
  }
}

function adopt() {
  if (!pet.value || adopted.value) return
  let ids = []
  try {
    ids = JSON.parse(localStorage.getItem('petAdopted') || '[]')
    if (!Array.isArray(ids)) ids = []
  } catch {
    ids = []
  }
  ids.push(pet.value.id)
  localStorage.setItem('petAdopted', JSON.stringify(ids))
  adopted.value = true
  // 领养成功：自动进入「毛孩子的家」，TA 已经住进窝里啦
  router.push({ path: '/pet-nest', query: { pet: String(pet.value.id), welcome: '1' } })
}

function todayKey() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

function loadStats() {
  const id = route.params.id
  stats.value = { ...(baseStats[id] || baseStats[1]) }
  try {
    const saved = JSON.parse(localStorage.getItem(`petSnack_${id}`) || 'null')
    if (saved && saved.date === todayKey() && typeof saved.count === 'number') {
      snackCount.value = Math.min(snackLimit, saved.count)
      stats.value.gluttony = Math.min(100, stats.value.gluttony + snackCount.value * 2)
    } else {
      snackCount.value = 0
    }
  } catch {
    snackCount.value = 0
  }
}

function feedSnack() {
  if (snackCount.value >= snackLimit) return
  snackCount.value += 1
  stats.value.gluttony = Math.min(100, stats.value.gluttony + 2)
  localStorage.setItem(`petSnack_${route.params.id}`, JSON.stringify({
    date: todayKey(),
    count: snackCount.value
  }))
  isHappy.value = true
  clearTimeout(happyTimer)
  happyTimer = setTimeout(() => { isHappy.value = false }, 900)
}

onMounted(() => {
  document.body.classList.add('home-body')
  loadAdopted()
  recordHistory(route.params.id)
})
onBeforeUnmount(() => document.body.classList.remove('home-body'))

onMounted(() => { loadStats() })
onBeforeUnmount(() => { clearTimeout(happyTimer) })
</script>

<template>
  <div class="detail-page app-bg">
    <main v-if="pet" class="detail-main">
      <section class="detail-card">
        <div class="detail-photo" :class="{ 'is-happy': isHappy }" :style="{ '--pet-color': pet.color }">
          <img v-if="pet.image" :src="pet.image" :alt="pet.name">
          <div v-else class="photo-placeholder"><span>{{ pet.emoji }}</span></div>
          <span class="mood-badge">{{ pet.moodEmoji }} {{ pet.mood }}</span>
          <div v-if="isHappy" class="detail-hearts" aria-hidden="true">
            <span>❤</span><span>💕</span><span>❤</span>
          </div>
        </div>

        <div class="detail-info">
          <span class="detail-tag">{{ pet.category }}</span>
          <h1>{{ pet.name }} <small>{{ pet.breed }}</small></h1>
          <div class="detail-tags">
            <span>{{ pet.gender }}</span>
            <span>{{ pet.age }}</span>
            <span>{{ pet.personality }}</span>
          </div>
          <p class="desc">嗨！我是{{ pet.name }}，现在{{ pet.mood }}～ 喜欢的话就带我回家吧，我会一直陪着你的！</p>
          <button type="button" class="adopt-btn" :disabled="adopted" @click="adopt">
            {{ adopted ? '已加入我的宠物 ✓' : '领养 TA →' }}
          </button>
        </div>
      </section>

      <section class="stats-panel">
        <div class="stats-head">
          <h2>🐾 {{ pet.name }} 的毛孩子档案</h2>
        </div>
        <p class="stats-tip">每天最多喂 {{ snackLimit }} 次，贪吃值会悄悄上涨哦～</p>

        <div class="stat-list">
          <div v-for="item in statItems" :key="item.key" class="stat-row">
            <span class="stat-label">{{ item.emoji }} {{ item.label }}</span>
            <div class="stat-track">
              <div class="stat-fill" :class="item.cls" :style="{ width: stats[item.key] + '%' }"></div>
            </div>
            <span class="stat-value">{{ stats[item.key] }}</span>
          </div>
        </div>

        <div class="feed-area">
          <button
            type="button"
            class="feed-btn"
            :disabled="snackCount >= snackLimit"
            @click="feedSnack"
          >
            {{ snackCount >= snackLimit ? '今天已经喂饱啦，明天再来吧～' : `🍪 喂小零食（${snackLimit - snackCount}/${snackLimit}）` }}
          </button>
        </div>

        <div v-if="isHappy" class="happy-bubble">好好吃！谢谢你～💕</div>
      </section>
    </main>

    <main v-else class="detail-main empty">
      <CuteEmpty
        variant="error"
        title="没有找到这只毛孩子 🐾"
        desc="它可能已经被接回家，或者链接地址不太对。回首页继续看看别的伙伴吧～"
      >
        <button type="button" class="empty-back" @click="router.push('/')">回到首页</button>
      </CuteEmpty>
    </main>
  </div>
</template>

<style scoped>
:global(body.home-body) {
  display: block;
  align-items: initial;
  justify-content: initial;
  padding: 0;
}

.detail-page {
  min-height: 100vh;
  font-family: var(--font-body);
  color: var(--text-1);
}

.topbar { background: #fffdf6; border-bottom: 2px solid var(--ink); }
.topbar-inner {
  max-width: 1180px; margin: 0 auto; padding: 14px 22px;
  display: flex; align-items: center; justify-content: space-between; gap: 16px;
}
.brand { display: flex; align-items: center; gap: 11px; font-size: 21px; font-weight: 900; cursor: pointer; }
.brand-badge {
  width: 42px; height: 42px; display: grid; place-items: center;
  background: var(--pink); border: var(--line); border-radius: var(--r-sm);
  font-size: 23px; box-shadow: 3px 3px 0 var(--ink); transform: rotate(-6deg);
}
.back-btn {
  padding: 10px 18px; font: inherit; font-size: 14px; font-weight: 900;
  background: var(--yellow); border: var(--line); border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink); cursor: pointer;
}
.back-btn:active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

.empty-back { padding: 10px 22px; font: inherit; font-size: 13px; font-weight: 900; color: var(--ink); background: var(--yellow); border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-1); cursor: pointer; }
.empty-back:hover { transform: translate(-1px, -3px); box-shadow: 4px 5px 0 var(--ink); }
.detail-main { max-width: var(--layout-narrow); margin: 0 auto; padding: var(--layout-pad-top) var(--layout-pad-x) var(--layout-pad-bottom); }
.detail-card {
  display: grid; grid-template-columns: 1fr 1fr; gap: 0;
  background: #fffdf6; border: var(--line); border-radius: var(--r-lg);
  box-shadow: var(--shadow-3); overflow: hidden;
}
.detail-photo {
  position: relative; min-height: 380px; display: grid; place-items: center;
  background: var(--pet-color); border-right: 2px solid var(--ink);
}
.detail-photo img { width: 100%; height: 100%; object-fit: contain; padding: 18px; }
.detail-photo {
  box-shadow: inset 0 0 0 2px rgba(255, 255, 255, 0.6);
}
.photo-placeholder {
  width: 100%; height: 100%; min-height: 380px; display: grid; place-items: center;
  background: radial-gradient(circle at 50% 120%, rgba(255, 255, 255, 0.65), transparent 60%),
              repeating-linear-gradient(45deg, rgba(255, 255, 255, 0.18) 0 12px, transparent 12px 24px);
}
.photo-placeholder span { font-size: 150px; filter: drop-shadow(8px 10px 0 rgba(43, 43, 43, 0.2)); }
.mood-badge {
  position: absolute; left: 16px; top: 16px; padding: 7px 13px;
  font-size: 12px; font-weight: 900; background: var(--yellow);
  border: 2px solid var(--ink); border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink); transform: rotate(-5deg);
}
.detail-info { padding: 36px 34px; }
.detail-tag {
  display: inline-block; padding: 5px 12px; font-size: 12px; font-weight: 900;
  background: var(--mint); border: 2px solid var(--ink); border-radius: var(--r-sm);
}
.detail-info h1 { margin: 16px 0 6px; font-size: 34px; }
.detail-info h1 small { font-size: 16px; color: var(--text-2); }
.detail-tags { display: flex; flex-wrap: wrap; gap: 8px; margin: 18px 0 22px; }
.detail-tags span {
  padding: 6px 12px; font-size: 12px; font-weight: 900;
  background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm);
}
.desc { font-size: 14px; font-weight: 700; line-height: 1.8; color: var(--text-2); }
.adopt-btn {
  margin-top: 16px; padding: 13px 26px; font: inherit; font-size: 16px; font-weight: 900;
  background: var(--yellow); border: var(--line); border-radius: var(--r-sm);
  box-shadow: 5px 5px 0 var(--ink); cursor: pointer;
}
.adopt-btn:disabled { background: var(--mint); cursor: default; }
.empty { text-align: center; }
.empty-card {
  display: inline-block; padding: 40px; background: #fffdf6;
  border: var(--line); border-radius: var(--r-lg); box-shadow: 8px 8px 0 var(--ink);
  font-weight: 900; line-height: 2;
}
.empty-card button { margin-top: 10px; padding: 8px 18px; font: inherit; font-weight: 900; border: 2px solid var(--ink); border-radius: var(--r-sm); background: var(--yellow); cursor: pointer; }

@media (max-width: 760px) {
  .detail-card { grid-template-columns: 1fr; }
  .detail-photo, .photo-placeholder { min-height: 260px; }
  .detail-info { padding: 26px 22px; }
}

/* ===== 游戏化属性面板 + 喂小零食（增量） ===== */
.stats-panel {
  position: relative;
  margin-top: 26px;
  padding: 22px 24px 24px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
}

.stats-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}
.stats-head h2 { margin: 0; font-size: 20px; }

.feed-btn {
  padding: 9px 15px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}
.feed-btn:hover:not(:disabled) { transform: translate(-2px, -2px); box-shadow: 6px 6px 0 var(--ink); }
.feed-btn:active:not(:disabled) { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }
.feed-btn:disabled { background: #e6ded2; cursor: default; }

.stats-tip { margin: 8px 0 0; font-size: 12px; font-weight: 700; color: var(--text-2); }
.stat-list { display: grid; gap: 14px; margin-top: 18px; }
.stat-row { display: grid; grid-template-columns: 96px 1fr 38px; align-items: center; gap: 12px; }
.stat-label { font-size: 13px; font-weight: 900; }

.stat-track {
  height: 18px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  overflow: hidden;
  box-shadow: 2px 2px 0 var(--ink);
}
.stat-fill {
  height: 100%;
  border-right: 2px solid var(--ink);
  border-radius: var(--r-sm);
  transition: width 0.6s cubic-bezier(0.2, 1, 0.4, 1);
}
.stat-fill.friendly { background: linear-gradient(90deg, #ffd3e2, var(--pink)); }
.stat-fill.lively { background: linear-gradient(90deg, #fff0b3, var(--yellow)); }
.stat-fill.health { background: linear-gradient(90deg, #c9f2df, var(--mint)); }
.stat-fill.gluttony { background: linear-gradient(90deg, #ffd9ab, #ffb26b); }
.stat-value { font-size: 13px; font-weight: 900; text-align: right; }

.feed-area { display: flex; justify-content: center; margin-top: 22px; }
.feed-area .feed-btn { font-size: 14px; padding: 11px 22px; }

.happy-bubble {
  position: absolute;
  right: 24px;
  top: 72px;
  z-index: 6;
  padding: 9px 13px;
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  font-size: 12px;
  font-weight: 900;
  animation: happy-pop 0.3s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}
@keyframes happy-pop {
  from { opacity: 0; transform: scale(0.8) translateY(6px); }
  to { opacity: 1; transform: scale(1) translateY(0); }
}

/* 喂食开心动画 */
.detail-photo.is-happy .photo-placeholder span,
.detail-photo.is-happy img { animation: happy-bounce 0.45s ease-in-out 2; }

@keyframes happy-bounce {
  0%, 100% { translate: 0 0; rotate: 0deg; }
  30% { translate: 0 -14px; rotate: -8deg; }
  60% { translate: 0 -4px; rotate: 8deg; }
}

.detail-hearts { position: absolute; inset: 0; z-index: 5; pointer-events: none; }
.detail-hearts span {
  position: absolute;
  left: 50%;
  top: 45%;
  font-size: 26px;
  animation: detail-heart-float 0.9s ease-out forwards;
}
.detail-hearts span:nth-child(1) { margin-left: -40px; animation-delay: 0s; }
.detail-hearts span:nth-child(2) { margin-left: 0; font-size: 30px; animation-delay: 0.12s; }
.detail-hearts span:nth-child(3) { margin-left: 38px; animation-delay: 0.22s; }

@keyframes detail-heart-float {
  0% { opacity: 0; transform: translateY(12px) scale(0.6); }
  25% { opacity: 1; }
  100% { opacity: 0; transform: translateY(-70px) scale(1.2); }
}

@media (max-width: 760px) {
  .stats-panel { padding: 18px; }
  .stat-row { grid-template-columns: 80px 1fr 32px; gap: 8px; }
  .happy-bubble { right: 18px; top: 120px; }
}
</style>
