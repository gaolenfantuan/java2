<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import '../page.css'
import BadgeCelebration from '../components/BadgeCelebration.vue'
import { useRouter } from 'vue-router'
import { store } from '../store'
import { syncAchievements } from '../utils/achievements'
import {
  rescueSteps, stepFeedback, rescuePets,
  getProgress, isDone, markDone, setProgress, getRescuedPetAdoptState
} from '../data/rescuePets'

const router = useRouter()

// 领养状态版本号：领养专区改变状态后自增，强制卡片角标重新计算
const adoptStateVersion = ref(0)
function refreshAdoptState() { adoptStateVersion.value += 1 }

const stories = [
  { id: 1, emoji: '🐕', name: '小黄', time: '2026-10-12', place: '城郊垃圾站', experience: '被发现时后腿受伤，缩在角落发抖。志愿者连续投喂一周后成功送医，现在已能欢快奔跑。', fund: 80, treat: 100, status: '已康复 · 待领养' },
  { id: 2, emoji: '🐈', name: '煤球', time: '2026-10-28', place: '老旧小区车库', experience: '一窝小猫中的一只，体质较弱。经过两周精心照料，已恢复健康，正在寻找领养人。', fund: 65, treat: 90, status: '恢复中 · 待领养' },
  { id: 3, emoji: '🐇', name: '雪球', time: '2026-11-05', place: '公园绿化带', experience: '被遗弃的侏儒兔，毛发打结。志愿者剃毛清理后重获新生，性格依然温顺亲人。', fund: 100, treat: 100, status: '已康复 · 已领养' },
  { id: 4, emoji: '🐕', name: '阿福', time: '2026-11-15', place: '工地旁', experience: '患有轻微皮肤病，正在治疗中。每天需要擦药和晒太阳，是个超级乖巧的小家伙。', fund: 45, treat: 60, status: '治疗中' }
]

const LOVE_KEY = 'rescueLoves'
const HELP_KEY = 'rescueReports'
const loves = ref({})        // { [id]: 我的助力次数 }
const totalLoves = ref(0)
const reports = ref([])
const helpShow = ref(false)
const helpForm = reactive({ type: '', place: '', desc: '', contact: '' })
const toastText = ref('')
let toastTimer = null

const badges = [
  { need: 1, icon: '🌱', name: '爱心萌芽' },
  { need: 3, icon: '💛', name: '暖心助力' },
  { need: 6, icon: '🌟', name: '救助之星' },
  { need: 10, icon: '🏅', name: '守护天使' }
]
const unlockedBadges = computed(() => badges.filter(b => totalLoves.value >= b.need))

function load() {
  try {
    const l = JSON.parse(localStorage.getItem(LOVE_KEY) || '{}')
    loves.value = l && typeof l === 'object' ? l : {}
  } catch { loves.value = {} }
  try {
    const r = JSON.parse(localStorage.getItem(HELP_KEY) || '[]')
    reports.value = Array.isArray(r) ? r : []
  } catch { reports.value = [] }
  totalLoves.value = Object.values(loves.value).reduce((a, b) => a + (Number(b) || 0), 0)
}

function cheer(story) {
  loves.value = { ...loves.value, [story.id]: (loves.value[story.id] || 0) + 1 }
  totalLoves.value = Object.values(loves.value).reduce((a, b) => a + (Number(b) || 0), 0)
  localStorage.setItem(LOVE_KEY, JSON.stringify(loves.value))
  const before = totalLoves.value - 1
  const newly = unlockedBadges.value.find(b => before < b.need && totalLoves.value >= b.need)
  showToast(newly ? `🎉 解锁「${newly.name}」徽章！` : `💛 助力成功，累计爱心 ${totalLoves.value}！`)
}

function submitHelp() {
  if (!helpForm.place.trim() || !helpForm.desc.trim()) { showToast('请填写发现地点和情况描述～'); return }
  reports.value = [{ ...helpForm, time: new Date().toLocaleString('zh-CN') }, ...reports.value]
  localStorage.setItem(HELP_KEY, JSON.stringify(reports.value))
  helpShow.value = false
  Object.assign(helpForm, { type: '', place: '', desc: '', contact: '' })
  showToast('🙏 求助已上报，志愿者会尽快核实！')
}

function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2400)
}

// ===== 单只宠物步骤式救助小游戏 =====
const rescueShow = ref(false)          // 救助流程弹窗
const rescueStory = ref(null)          // 当前救助的宠物（故事对象）
const rescueStep = ref(0)              // 当前进行到第几步（0-based，= 已完成步数）
const rescueAnim = ref('')             // 宠物互动动画 class
const rescueBubble = ref('')           // 宠物气泡文案
const rescueSuccess = ref(false)       // 是否显示成功庆祝
const celebrateBadge = ref(null)       // 成功时新解锁的徽章（成功卡内提示）
const showBadgeCelebrate = ref(null)   // 独立的徽章解锁庆祝弹窗
let animTimer = null

// 根据宠物 id 找到完整的 3D 数据（含 image）
function petDataOf(story) {
  return rescuePets.find(p => p.id === story.id) || { ...story, image: '', color: '#ffe0b8' }
}

// 救助页状态角标：与领养专区双向同步
// 未完成救助 -> 原故事状态；已完成 -> 按领养专区状态显示
function rescueStatusLabel(story) {
  void adoptStateVersion.value   // 建立响应式依赖
  const state = getRescuedPetAdoptState(story.id)
  if (state === 'adopted') return '🏠 已回家'
  if (state === 'reserved') return '⏳ 预约中'
  if (state === 'available') return '💛 待领养'
  return story.status
}
function isRescuedDoneUI(story) {
  void adoptStateVersion.value
  return isDone(story.id)
}

function startRescue(story) {
  rescueStory.value = story
  rescueStep.value = getProgress(story.id)   // 续接上次的进度
  rescueSuccess.value = false
  rescueBubble.value = ''
  rescueAnim.value = ''
  rescueShow.value = true
}

function closeRescue() {
  rescueShow.value = false
  rescueAnim.value = ''
  clearTimeout(animTimer)
  // 关闭救助弹窗后，若有新徽章则播放解锁庆祝
  if (celebrateBadge.value) {
    showBadgeCelebrate.value = celebrateBadge.value
    celebrateBadge.value = null
  }
}

// 执行当前步骤操作
function doRescueStep() {
  if (!rescueStory.value || rescueStep.value >= rescueSteps.length) return
  const step = rescueSteps[rescueStep.value]
  rescueAnim.value = step.key          // 触发对应 CSS 动画
  rescueBubble.value = stepFeedback[rescueStep.value]
  clearTimeout(animTimer)
  animTimer = setTimeout(() => { rescueAnim.value = '' }, 1100)

  const finished = rescueStep.value + 1
  // 写入进度（setProgress 内部会限制范围）
  setProgress(rescueStory.value.id, finished)
  rescueStep.value = finished

  if (finished >= rescueSteps.length) {
    finishRescue()
  }
}

// 完成救助：标记完成 + 检查徽章 + 弹庆祝
function finishRescue() {
  markDone(rescueStory.value.id)
  refreshAdoptState()   // 当前标签页 storage 事件不触发，主动刷新角标
  // 同步成就系统，拿到新解锁徽章
  const { newlyUnlocked, state } = syncAchievements()
  store.unlockedBadgeCount = state.unlocked.length
  celebrateBadge.value = newlyUnlocked.find(b => b.id === 'rescue-hero') || null
  rescueSuccess.value = true
}

function goAdoptAfterRescue() {
  rescueShow.value = false
  celebrateBadge.value = null   // 直接跳转，不播放庆祝遮挡
  router.push('/adopt')
}

// 领养专区改变状态后（含跨标签页），刷新救助页角标
const RESCUE_SYNC_KEYS = ['petAdopted', 'petApplyStatuses', 'petRescueDone', 'petRescueSync']
function onAdoptStorage(e) {
  if (e.key && RESCUE_SYNC_KEYS.includes(e.key)) {
    load()
    refreshAdoptState()
  }
}

onMounted(() => {
  document.body.classList.add('home-body')
  load()
  window.addEventListener('storage', onAdoptStorage)
})
onBeforeUnmount(() => {
  document.body.classList.remove('home-body')
  window.removeEventListener('storage', onAdoptStorage)
  clearTimeout(toastTimer)
  clearTimeout(animTimer)
})
</script>

<template>
  <div class="app-bg fun-page">
    <main class="fun-main">
      <div class="fun-head rescue-head">
        <div>
          <h1>流浪救助 <span>🚑</span></h1>
          <p>每一次助力，都是给流浪毛孩子多一份活下去的希望～</p>
        </div>
        <button type="button" class="fun-btn pink" @click="helpShow = true">📣 流浪求助</button>
      </div>

      <!-- 我的爱心徽章 -->
      <section class="love-panel fun-card">
        <div class="love-summary">
          <span class="love-heart">💛</span>
          <div>
            <strong>我的累计爱心：{{ totalLoves }}</strong>
            <small>助力救助故事即可累积，解锁专属徽章</small>
          </div>
        </div>
        <div class="love-badges">
          <div v-for="b in badges" :key="b.need" class="love-badge" :class="{ locked: totalLoves < b.need }">
            <span>{{ b.icon }}</span>
            <small>{{ b.name }}</small>
            <em>爱心{{ b.need }}</em>
          </div>
        </div>
      </section>

      <!-- 救助故事 -->
      <h2 class="section-title">📖 救助故事</h2>
      <div class="story-grid">
        <article v-for="s in stories" :key="s.id" class="story-card fun-card fun-card-hover">
          <div class="story-top">
            <span class="story-emoji">{{ s.emoji }}</span>
            <div class="story-meta">
              <h3>{{ s.name }}</h3>
              <small>{{ s.time }} · {{ s.place }}</small>
            </div>
            <span class="story-status" :class="{ rescued: isRescuedDoneUI(s) }">{{ rescueStatusLabel(s) }}</span>
          </div>
          <p class="story-desc">{{ s.experience }}</p>
          <div class="story-progress">
            <div class="p-row"><span>💰 救助筹款</span><div class="fun-track"><div class="fun-fill yellow" :style="{ width: s.fund + '%' }"></div></div><b>{{ s.fund }}%</b></div>
            <div class="p-row"><span>💊 治疗进度</span><div class="fun-track"><div class="fun-fill mint" :style="{ width: s.treat + '%' }"></div></div><b>{{ s.treat }}%</b></div>
          </div>
          <div class="story-actions">
            <button type="button" class="fun-btn cheer-btn" @click="cheer(s)">💛 助力一下（{{ loves[s.id] || 0 }}）</button>
            <button type="button" class="fun-btn rescue-start-btn" :class="{ done: isDone(s.id) }" @click="startRescue(s)">
              {{ isDone(s.id) ? '✓ 已救助' : (getProgress(s.id) ? `▶ 继续救助 ${getProgress(s.id)}/4` : '🚑 开始救助') }}
            </button>
          </div>
        </article>
      </div>

      <!-- 上报记录 -->
      <section v-if="reports.length" class="report-section fun-card">
        <h2 class="section-title">📣 我的上报记录</h2>
        <div v-for="(r, i) in reports" :key="i" class="report-item">
          <span>🐾 {{ r.type || '流浪动物' }} · {{ r.place }}</span>
          <small>{{ r.time }} · 状态：待志愿者核实</small>
        </div>
      </section>
    </main>

    <!-- 求助上报弹窗 -->
    <div v-if="helpShow" class="fun-mask" @click.self="helpShow = false">
      <div class="fun-modal" role="dialog" aria-modal="true">
        <button type="button" class="fun-close" @click="helpShow = false">✕</button>
        <h2>📣 流浪求助上报</h2>
        <p class="sub">发现流浪毛孩子？填写信息，志愿者会尽快核实救助～</p>
        <div class="fun-form">
          <label><span>动物类型</span>
            <select v-model="helpForm.type"><option value="">请选择</option><option>流浪猫</option><option>流浪狗</option><option>其它小动物</option></select>
          </label>
          <label><span>发现地点</span><input v-model="helpForm.place" type="text" placeholder="如：XX 小区东门车棚"></label>
          <label><span>情况描述</span><textarea v-model="helpForm.desc" rows="3" placeholder="健康状况、是否亲人等"></textarea></label>
          <label><span>联系方式</span><input v-model="helpForm.contact" type="text" placeholder="手机号 / 微信（选填）"></label>
        </div>
        <button type="button" class="fun-btn" style="margin-top:18px;width:100%" @click="submitHelp">提交上报 ✓</button>
      </div>
    </div>

    <!-- 步骤式救助流程弹窗 -->
    <div v-if="rescueShow" class="fun-mask" @click.self="closeRescue">
      <div class="rescue-modal" role="dialog" aria-modal="true">
        <button type="button" class="fun-close" @click="closeRescue">✕</button>

        <!-- 成功庆祝 -->
        <div v-if="rescueSuccess" class="rescue-success">
          <div class="success-confetti" aria-hidden="true">
            <span v-for="n in 12" :key="n" :style="{ '--i': n }"></span>
          </div>
          <div class="success-badge">🎉</div>
          <h2>救助成功啦！</h2>
          <p class="sub">{{ rescueStory.name }} 已经康复，可以去领养专区找到新家咯～</p>

          <!-- 电子救助纪念卡 -->
          <div class="memory-card" :style="{ '--pet-color': petDataOf(rescueStory).color }">
            <div class="memory-card-head">🐾 爱心救助纪念卡</div>
            <div class="memory-pet">
              <img v-if="petDataOf(rescueStory).image" :src="petDataOf(rescueStory).image" :alt="rescueStory.name">
              <span v-else>{{ rescueStory.emoji }}</span>
            </div>
            <div class="memory-name">{{ rescueStory.name }}</div>
            <div class="memory-row"><span>救助关卡</span><b>4 / 4 全部完成 ✓</b></div>
            <div class="memory-row"><span>救助地点</span><b>{{ rescueStory.place }}</b></div>
            <div class="memory-row"><span>救助编号</span><b>R{{ String(rescueStory.id).padStart(4, '0') }}</b></div>
            <div class="memory-stamp">已救助 · 待领养 💛</div>
          </div>

          <div v-if="celebrateBadge" class="new-badge-tip">🏅 解锁新徽章「{{ celebrateBadge.name }}」！</div>
          <div class="success-btns">
            <button type="button" class="fun-btn mint" @click="closeRescue">继续救助其他毛孩子</button>
            <button type="button" class="fun-btn" @click="goAdoptAfterRescue">去领养专区看看 →</button>
          </div>
        </div>

        <!-- 救助流程 -->
        <template v-else>
          <h2>🚑 救助 {{ rescueStory.name }}</h2>
          <p class="sub">按顺序完成 4 步，陪它一步步重获新生～</p>

          <!-- 宠物互动舞台 -->
          <div class="rescue-stage" :class="'anim-' + rescueAnim" :style="{ '--pet-color': petDataOf(rescueStory).color }">
            <div class="stage-deco">✨</div>
            <div class="stage-pet">
              <img v-if="petDataOf(rescueStory).image" :src="petDataOf(rescueStory).image" :alt="rescueStory.name">
              <span v-else>{{ rescueStory.emoji }}</span>
              <span v-if="rescueAnim === 'treat'" class="pet-bandage" aria-hidden="true">🩹</span>
            </div>
            <div class="stage-hearts" aria-hidden="true">
              <span v-for="n in 4" :key="n">💖</span>
            </div>
            <div v-if="rescueBubble" class="stage-bubble">{{ rescueBubble }}</div>
          </div>

          <!-- 总体进度条 -->
          <div class="rescue-progress">
            <div class="rp-label"><span>救助进度</span><b>{{ rescueStep }} / {{ rescueSteps.length }} 步</b></div>
            <div class="fun-track rp-track">
              <div class="fun-fill rescue-fill" :style="{ width: (rescueStep / rescueSteps.length * 100) + '%' }"></div>
            </div>
          </div>

          <!-- 4 步关卡 -->
          <div class="step-list">
            <div
              v-for="(step, i) in rescueSteps"
              :key="step.key"
              class="step-item"
              :class="{ done: i < rescueStep, current: i === rescueStep, locked: i > rescueStep }"
            >
              <div class="step-index">{{ i < rescueStep ? '✓' : (i > rescueStep ? '🔒' : i + 1) }}</div>
              <div class="step-icon">{{ step.icon }}</div>
              <div class="step-info">
                <strong>{{ step.label }}</strong>
                <small>{{ step.tip }}</small>
              </div>
              <button
                v-if="i === rescueStep"
                type="button"
                class="fun-btn step-action"
                @click="doRescueStep"
              >{{ step.action }} →</button>
              <span v-else-if="i < rescueStep" class="step-done-tag">已完成 ✓</span>
            </div>
          </div>
        </template>
      </div>
    </div>

    <!-- 徽章解锁庆祝 -->
    <BadgeCelebration v-if="showBadgeCelebrate" :badge="showBadgeCelebrate" @close="showBadgeCelebrate = null" />

    <div class="fun-toast" :class="{ show: !!toastText }">🐾 {{ toastText }}</div>
  </div>
</template>

<style scoped>
.rescue-head { display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
.love-panel { padding: 18px 22px; margin-bottom: 24px; }
.love-summary { display: flex; align-items: center; gap: 14px; margin-bottom: 16px; }
.love-heart { font-size: 40px; }
.love-summary strong { display: block; font-size: 18px; }
.love-summary small { color: var(--text-2); font-weight: 700; font-size: 12px; }
.love-badges { display: flex; gap: 12px; flex-wrap: wrap; }
.love-badge { width: 82px; padding: 10px 6px; text-align: center; background: var(--yellow); border: 2px solid var(--ink); border-radius: var(--r-sm); box-shadow: 3px 3px 0 var(--ink); }
.love-badge span { font-size: 28px; display: block; }
.love-badge small { display: block; font-size: 10px; font-weight: 900; margin: 4px 0 2px; }
.love-badge em { font-size: 9px; font-style: normal; color: var(--text-2); }
.love-badge.locked { background: #ece5da; filter: grayscale(0.8); opacity: 0.6; }
.section-title { font-size: 20px; margin: 0 0 16px; }
.story-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px; }
.story-card { padding: 18px; }
.story-top { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
.story-emoji { font-size: 44px; }
.story-meta { flex: 1; }
.story-meta h3 { margin: 0 0 3px; font-size: 18px; }
.story-meta small { font-size: 11px; font-weight: 700; color: var(--text-2); }
.story-status { padding: 4px 9px; font-size: 10px; font-weight: 900; background: var(--mint); border: 2px solid var(--ink); border-radius: var(--r-sm); }
.story-desc { font-size: 12px; font-weight: 700; line-height: 1.7; color: var(--text-2); min-height: 62px; }
.story-progress { display: grid; gap: 9px; margin-bottom: 14px; }
.p-row { display: grid; grid-template-columns: 78px 1fr 38px; align-items: center; gap: 8px; font-size: 11px; font-weight: 900; }
.p-row b { text-align: right; }
.cheer-btn { width: 100%; }
.report-section { margin-top: 28px; padding: 20px; }
.report-item { display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap; padding: 10px 0; border-bottom: 2px dashed #e6d3b3; font-size: 13px; font-weight: 900; }
.report-item small { font-weight: 700; color: var(--text-2); }

/* ===== 步骤式救助小游戏 ===== */
.story-status.rescued { background: var(--yellow); }
.story-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.rescue-start-btn { background: var(--pink); }
.rescue-start-btn.done { background: var(--mint); opacity: 0.75; }

.rescue-modal {
  position: relative; width: min(560px, 100%); max-height: 92vh; overflow-y: auto;
  padding: 26px 24px 24px; background: #fffdf6; border: var(--line);
  border-radius: var(--r-lg); box-shadow: 10px 12px 0 var(--ink);
  font-family: "Comic Sans MS", "YouYuan", "幼圆", "Microsoft YaHei", sans-serif;
  color: var(--ink); animation: fun-pop 0.3s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
.rescue-modal h2 { margin: 0 0 6px; font-size: 23px; }
.rescue-modal .sub { margin: 0 0 16px; font-size: 13px; font-weight: 700; color: var(--text-2); }

/* 宠物互动舞台 */
.rescue-stage {
  position: relative; height: 190px; margin-bottom: 16px; overflow: hidden;
  display: grid; place-items: center;
  background-color: var(--pet-color);
  background-image: repeating-linear-gradient(135deg, rgba(255,255,255,0.32) 0 10px, rgba(255,255,255,0) 10px 20px);
  border: var(--line); border-radius: var(--r-lg); box-shadow: 5px 6px 0 var(--ink);
}
.stage-deco { position: absolute; top: 12px; left: 16px; font-size: 22px; }
.stage-pet { position: relative; width: 140px; height: 140px; display: grid; place-items: center; }
.stage-pet img {
  width: 100%; height: 100%; object-fit: contain;
  filter: drop-shadow(0 3px 2px rgba(43,43,43,0.18)) drop-shadow(0 10px 8px rgba(43,43,43,0.14));
  animation: pet-idle 2.4s ease-in-out infinite;
}
.stage-pet > span:first-child { font-size: 96px; animation: pet-idle 2.4s ease-in-out infinite; }
@keyframes pet-idle { 0%, 100% { translate: 0 0; } 50% { translate: 0 -6px; } }
.pet-bandage { position: absolute; right: 6px; top: 20px; font-size: 30px; animation: bandage-in 0.5s cubic-bezier(0.2, 1.5, 0.4, 1) both; }
@keyframes bandage-in { from { opacity: 0; transform: scale(0) rotate(-40deg); } to { opacity: 1; transform: scale(1) rotate(12deg); } }

/* 冒爱心 */
.stage-hearts { position: absolute; inset: 0; pointer-events: none; }
.stage-hearts span { position: absolute; bottom: 30px; font-size: 20px; opacity: 0; }
.stage-hearts span:nth-child(1) { left: 32%; }
.stage-hearts span:nth-child(2) { left: 45%; }
.stage-hearts span:nth-child(3) { left: 58%; }
.stage-hearts span:nth-child(4) { left: 70%; }
.rescue-stage.anim-feed .stage-hearts span,
.rescue-stage.anim-treat .stage-hearts span { animation: heart-float 1.1s ease-out forwards; }
.rescue-stage.anim-feed .stage-hearts span:nth-child(2),
.rescue-stage.anim-treat .stage-hearts span:nth-child(2) { animation-delay: 0.12s; }
.rescue-stage.anim-feed .stage-hearts span:nth-child(3),
.rescue-stage.anim-treat .stage-hearts span:nth-child(3) { animation-delay: 0.24s; }
.rescue-stage.anim-feed .stage-hearts span:nth-child(4),
.rescue-stage.anim-treat .stage-hearts span:nth-child(4) { animation-delay: 0.34s; }
@keyframes heart-float { 0% { opacity: 0; transform: translateY(0) scale(0.6); } 20% { opacity: 1; } 100% { opacity: 0; transform: translateY(-90px) scale(1.1); } }

/* 专属互动动画 */
.rescue-stage.anim-approach .stage-pet { animation: pet-approach 0.7s ease-in-out; }
@keyframes pet-approach { 0%,100% { translate: 0 0; rotate: 0deg; } 30% { translate: -10px 0; rotate: -6deg; } 70% { translate: 6px 0; rotate: 6deg; } }
.rescue-stage.anim-feed .stage-pet img,
.rescue-stage.anim-feed .stage-pet > span:first-child { animation: pet-wag 0.5s ease-in-out 2; }
@keyframes pet-wag { 0%,100% { rotate: 0deg; } 25% { rotate: -12deg; } 75% { rotate: 12deg; } }
.rescue-stage.anim-check .stage-pet { animation: pet-check 0.8s ease-in-out; }
@keyframes pet-check { 0%,100% { translate: 0 0; } 50% { translate: 0 -14px; rotate: 8deg; } }
.rescue-stage.anim-treat .stage-pet img,
.rescue-stage.anim-treat .stage-pet > span:first-child { animation: pet-happy 0.5s ease-in-out 2; }
@keyframes pet-happy { 0%,100% { transform: translateY(0) scale(1); } 50% { transform: translateY(-14px) scale(1.08); } }

.stage-bubble {
  position: absolute; bottom: 12px; left: 50%; transform: translateX(-50%);
  padding: 6px 14px; white-space: nowrap; font-size: 12px; font-weight: 900;
  background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink); animation: bubble-pop 0.3s cubic-bezier(0.2,1.5,0.4,1) both;
}
@keyframes bubble-pop { from { opacity: 0; transform: translateX(-50%) scale(0.6); } to { opacity: 1; transform: translateX(-50%) scale(1); } }

/* 进度条 */
.rescue-progress { margin-bottom: 16px; }
.rp-label { display: flex; justify-content: space-between; font-size: 12px; font-weight: 900; margin-bottom: 6px; }
.rp-track { height: 18px; }
.rescue-fill { background: linear-gradient(90deg, #c9f2df, #ffe08a, #ffc9cf); transition: width 0.6s cubic-bezier(0.2, 1, 0.4, 1); }

/* 步骤关卡 */
.step-list { display: grid; gap: 10px; }
.step-item {
  display: flex; align-items: center; gap: 10px; padding: 10px 12px;
  border: 2px solid var(--ink); border-radius: var(--r-sm); background: #fff;
  box-shadow: 3px 3px 0 var(--ink); transition: 0.2s;
}
.step-item.current { background: #fff7d6; box-shadow: 4px 5px 0 var(--ink); transform: translateY(-2px); }
.step-item.done { background: #eefaf3; }
.step-item.locked { opacity: 0.45; filter: grayscale(0.7); }
.step-index {
  flex: 0 0 26px; height: 26px; display: grid; place-items: center;
  font-size: 13px; font-weight: 900; background: var(--yellow);
  border: 2px solid var(--ink); border-radius: 50%;
}
.step-item.done .step-index { background: var(--mint); }
.step-icon { font-size: 22px; }
.step-info { flex: 1; min-width: 0; }
.step-info strong { display: block; font-size: 13px; font-weight: 900; }
.step-info small { font-size: 10px; font-weight: 700; color: var(--text-2); }
.step-action { font-size: 11px; padding: 7px 12px; }
.step-done-tag { font-size: 10px; font-weight: 900; color: #4a9e7a; white-space: nowrap; }

/* 成功庆祝 + 纪念卡 */
.rescue-success { text-align: center; position: relative; }
.success-badge { font-size: 60px; animation: success-bounce 0.6s cubic-bezier(0.2,1.5,0.4,1) both; }
@keyframes success-bounce { from { transform: scale(0) rotate(-30deg); } to { transform: scale(1) rotate(0); } }
.rescue-success h2 { font-size: 24px; margin: 6px 0; }
.success-confetti { position: absolute; inset: -26px -24px auto; height: 120px; pointer-events: none; overflow: hidden; }
.success-confetti span {
  position: absolute; top: -10px; left: calc(var(--i) * 8%); width: 9px; height: 14px;
  background: var(--yellow); border: 1.5px solid var(--ink); border-radius: 2px; opacity: 0;
  animation: confetti-fall 1.8s ease-in forwards; animation-delay: calc(var(--i) * 0.07s);
}
.success-confetti span:nth-child(even) { background: var(--pink); }
.success-confetti span:nth-child(3n) { background: var(--mint); }
@keyframes confetti-fall { 0% { opacity: 0; transform: translateY(0) rotate(0); } 15% { opacity: 1; } 100% { opacity: 0; transform: translateY(240px) rotate(420deg); } }

.memory-card {
  margin: 16px auto; padding: 16px 18px; max-width: 320px; text-align: left;
  background: linear-gradient(160deg, #fffdf6 60%, var(--pet-color));
  border: var(--line); border-radius: var(--r-lg); box-shadow: 7px 8px 0 var(--ink);
  position: relative; overflow: hidden;
}
.memory-card-head { text-align: center; font-size: 14px; font-weight: 900; margin-bottom: 10px; }
.memory-pet { width: 92px; height: 92px; margin: 0 auto 6px; display: grid; place-items: center; }
.memory-pet img { width: 100%; height: 100%; object-fit: contain; filter: drop-shadow(0 4px 3px rgba(43,43,43,0.18)); }
.memory-pet > span { font-size: 64px; }
.memory-name { text-align: center; font-size: 17px; font-weight: 900; margin-bottom: 10px; }
.memory-row { display: flex; justify-content: space-between; font-size: 11px; font-weight: 700; padding: 4px 0; border-bottom: 1.5px dashed #e6d3b3; }
.memory-row b { font-weight: 900; }
.memory-stamp {
  margin-top: 12px; text-align: center; font-size: 12px; font-weight: 900; color: #d8385b;
  border: 2px dashed #d8385b; border-radius: var(--r-sm); padding: 6px; transform: rotate(-3deg);
}
.new-badge-tip {
  margin: 12px auto 0; padding: 8px 14px; display: inline-block; font-size: 12px; font-weight: 900;
  background: var(--yellow); border: 2px solid var(--ink); border-radius: var(--r-sm); box-shadow: 3px 3px 0 var(--ink);
  animation: bubble-pop 0.4s 0.2s cubic-bezier(0.2,1.5,0.4,1) both;
}
.success-btns { display: flex; gap: 10px; margin-top: 18px; }
.success-btns .fun-btn { flex: 1; font-size: 12px; padding: 10px 8px; }

@media (max-width: 560px) {
  .story-actions { grid-template-columns: 1fr; }
  .success-btns { flex-direction: column; }
}
</style>
