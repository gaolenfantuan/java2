<script setup>
import { onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import '../page.css'

const positions = [
  { icon: '🐾', title: '救助陪护', place: '线下 · 救助站', desc: '照顾受伤流浪动物，协助喂食、清洁与陪护，需要耐心和爱心。', tags: ['周末', '有耐心'] },
  { icon: '🏪', title: '线下领养日', place: '线下 · 各商场', desc: '在领养日活动现场布置展位、接待咨询、协助领养流程。', tags: ['活动', '善沟通'] },
  { icon: '✍️', title: '文案宣传', place: '线上 · 远程', desc: '撰写领养故事、救助推文，制作宣传素材，让更多人看见。', tags: ['远程', '会写作'] },
  { icon: '💬', title: '线上客服', place: '线上 · 远程', desc: '解答领养咨询、审核申请资料，线上即可参与。', tags: ['远程', '细致'] }
]
const volunteers = ['🙋‍♀️', '👩‍🦰', '🧑', '👨‍🦱', '👩', '🧑‍🦰', '🙋‍♂️', '👩‍🦱', '🧔', '👱‍♀️']
const KEY = 'volunteerSignups'
const signups = ref([])
const showForm = ref(false)
const targetPosition = ref('')
const form = reactive({ name: '', contact: '', position: '', time: '' })
const toastText = ref('')
let toastTimer = null

function load() {
  try {
    const s = JSON.parse(localStorage.getItem(KEY) || '[]')
    signups.value = Array.isArray(s) ? s : []
  } catch { signups.value = [] }
}

function openApply(title) {
  targetPosition.value = title || ''
  form.position = title || ''
  showForm.value = true
}
function submit() {
  if (!form.name.trim() || !form.contact.trim() || !form.position) { showToast('请填写姓名、联系方式和意向岗位～'); return }
  signups.value = [{ ...form, time: new Date().toLocaleString('zh-CN') }, ...signups.value]
  localStorage.setItem(KEY, JSON.stringify(signups.value))
  showForm.value = false
  Object.assign(form, { name: '', contact: '', position: '', time: '' })
  showToast('🎉 报名成功！志愿者会尽快与你联系～')
}
function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2400)
}
onMounted(() => { document.body.classList.add('home-body'); load() })
onBeforeUnmount(() => { document.body.classList.remove('home-body'); clearTimeout(toastTimer) })
</script>

<template>
  <div class="app-bg fun-page">
    <main class="fun-main">
      <div class="fun-head">
        <h1>志愿者合作 <span>🤝</span></h1>
        <p>因为你的加入，更多毛孩子能等到回家的那一天～</p>
      </div>

      <!-- 岗位卡片 -->
      <h2 class="section-title">💼 志愿者岗位</h2>
      <div class="position-grid">
        <article v-for="p in positions" :key="p.title" class="position-card fun-card fun-card-hover">
          <span class="pos-icon">{{ p.icon }}</span>
          <h3>{{ p.title }}</h3>
          <small class="pos-place">📍 {{ p.place }}</small>
          <p>{{ p.desc }}</p>
          <div class="pos-tags"><span v-for="t in p.tags" :key="t">{{ t }}</span></div>
          <button type="button" class="fun-btn mint pos-btn" @click="openApply(p.title)">我要报名 →</button>
        </article>
      </div>

      <!-- 志愿者风采 -->
      <section class="volunteer-wall fun-card">
        <h2 class="section-title">🌟 志愿者风采</h2>
        <p class="wall-sub">感谢每一位闪闪发光的你～</p>
        <div class="avatar-wall">
          <span v-for="(v, i) in volunteers" :key="i" class="wall-avatar" :style="{ '--i': i }">{{ v }}</span>
        </div>
      </section>

      <!-- 我的报名 -->
      <section v-if="signups.length" class="signup-section fun-card">
        <h2 class="section-title">📝 我的报名记录</h2>
        <div v-for="(s, i) in signups" :key="i" class="signup-item">
          <span>🤝 {{ s.position }} · {{ s.name }}</span>
          <small>{{ s.time }} · 待联系</small>
        </div>
      </section>
    </main>

    <div v-if="showForm" class="fun-mask" @click.self="showForm = false">
      <div class="fun-modal" role="dialog" aria-modal="true">
        <button type="button" class="fun-close" @click="showForm = false">✕</button>
        <h2>🙋 志愿者报名</h2>
        <p class="sub">填写信息，加入我们的志愿者大家庭～</p>
        <div class="fun-form">
          <label><span>姓名</span><input v-model="form.name" type="text" placeholder="你的姓名"></label>
          <label><span>联系方式</span><input v-model="form.contact" type="text" placeholder="手机号 / 微信"></label>
          <label><span>意向岗位</span>
            <select v-model="form.position"><option value="">请选择岗位</option><option v-for="p in positions" :key="p.title">{{ p.title }}</option></select>
          </label>
          <label><span>可服务时间</span><input v-model="form.time" type="text" placeholder="如：每周六全天"></label>
        </div>
        <button type="button" class="fun-btn" style="margin-top:18px;width:100%" @click="submit">提交报名 ✓</button>
      </div>
    </div>

    <div class="fun-toast" :class="{ show: !!toastText }">🐾 {{ toastText }}</div>
  </div>
</template>

<style scoped>
.section-title { font-size: 20px; margin: 0 0 16px; }
.position-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 18px; margin-bottom: 28px; }
.position-card { padding: 20px; }
.pos-icon { font-size: 38px; }
.position-card h3 { margin: 8px 0 4px; font-size: 18px; }
.pos-place { font-size: 11px; font-weight: 700; color: var(--text-2); }
.position-card p { font-size: 12px; font-weight: 700; line-height: 1.7; color: var(--text-2); min-height: 60px; }
.pos-tags { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 14px; }
.pos-tags span { padding: 3px 9px; font-size: 10px; font-weight: 900; background: var(--blue); border: 2px solid var(--ink); border-radius: var(--r-sm); }
.pos-btn { width: 100%; }
.volunteer-wall { padding: 22px; margin-bottom: 26px; text-align: center; }
.wall-sub { font-size: 12px; font-weight: 700; color: var(--text-2); margin: -8px 0 18px; }
.avatar-wall { display: flex; justify-content: center; flex-wrap: wrap; gap: 14px; }
.wall-avatar { width: 58px; height: 58px; display: grid; place-items: center; font-size: 28px; background: var(--yellow); border: var(--line); border-radius: 50%; box-shadow: 3px 4px 0 var(--ink); animation: bob 3s ease-in-out infinite; animation-delay: calc(var(--i) * 0.15s); }
.wall-avatar:nth-child(3n) { background: var(--pink); }
.wall-avatar:nth-child(3n+1) { background: var(--mint); }
@keyframes bob { 0%,100% { translate: 0 0; } 50% { translate: 0 -6px; } }
.signup-section { padding: 22px; }
.signup-item { display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap; padding: 10px 0; border-bottom: 2px dashed #e6d3b3; font-size: 13px; font-weight: 900; }
.signup-item small { color: var(--text-2); font-weight: 700; }
</style>
