<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import '../page.css'
import CoinIcon from '../components/CoinIcon.vue'
import ItemArt from '../components/ItemArt.vue'
import { shopItems, shopCategories } from '../data/shopItems'
import { store, itemCount, spendCoins, addItem, recordPurchase } from '../store'

const router = useRouter()

const activeCategory = ref('全部')
const sortBy = ref('default')

const categoryTabs = computed(() => [
  { key: '全部', icon: '✨', color: '#ffe9b8', count: shopItems.length },
  ...shopCategories.map(cat => ({
    ...cat,
    count: shopItems.filter(item => item.category === cat.key).length
  }))
])

function categoryOf(key) {
  return shopCategories.find(cat => cat.key === key) || { color: '#ffe9b8', icon: '✨' }
}

const visibleItems = computed(() => {
  const list = activeCategory.value === '全部'
    ? [...shopItems]
    : shopItems.filter(item => item.category === activeCategory.value)

  if (sortBy.value === 'price-asc') list.sort((a, b) => a.price - b.price)
  else if (sortBy.value === 'price-desc') list.sort((a, b) => b.price - a.price)
  else if (sortBy.value === 'owned') list.sort((a, b) => itemCount(b.id) - itemCount(a.id))

  return list
})

// ===== 购买 =====
const buyTarget = ref(null)
const boughtItem = ref(null)
const buying = ref(false)
const toastText = ref('')
let toastTimer = null
let buyTimer = null

function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2200)
}

function buyLabel(item) {
  if (store.coins < item.price) return '币不够 · 去赚币'
  return itemCount(item.id) ? '再买一件' : '立即购买'
}

function openBuy(item) {
  // 币不够时按钮文案已提示「去赚币」，点击直接带去萌宠乐园
  if (store.coins < item.price) {
    goPlayground()
    return
  }
  buyTarget.value = item
}

function closeBuy() {
  if (buying.value) return
  buyTarget.value = null
}

function confirmBuy() {
  const item = buyTarget.value
  if (!item || buying.value) return
  if (!spendCoins(item.price)) {
    showToast('游戏币不够啦，先去赚一点吧～')
    return
  }
  buying.value = true
  clearTimeout(buyTimer)
  // 模拟兑换：稍作停顿，按钮进入 loading 态
  buyTimer = setTimeout(() => {
    addItem(item.id, 1)
    recordPurchase()
    buying.value = false
    buyTarget.value = null
    boughtItem.value = item
  }, 520)
}

function goPlayground() {
  router.push('/playground')
}
function goBackpack() {
  router.push('/backpack')
}

onMounted(() => document.body.classList.add('home-body'))
onBeforeUnmount(() => {
  document.body.classList.remove('home-body')
  clearTimeout(toastTimer)
  clearTimeout(buyTimer)
})
</script>

<template>
  <div class="app-bg fun-page shop-page">
    <main class="shop-main">
      <!-- 页头 -->
      <header class="shop-head">
        <div class="shop-title">
          <span class="shop-title-badge" aria-hidden="true">🛍️</span>
          <div>
            <h1>积分商城</h1>
            <p>用游戏币换点小零食和小玩具，让毛孩子开心一下 🍖</p>
          </div>
        </div>

        <div class="shop-wallet">
          <div class="wallet-main">
            <CoinIcon :size="38" />
            <div>
              <span>我的游戏币</span>
              <strong :key="store.coins">{{ store.coins }}</strong>
            </div>
          </div>
          <button type="button" class="wallet-earn" @click="goPlayground">去赚币 →</button>
        </div>
      </header>

      <!-- 分类 Tab -->
      <nav class="cat-tabs" aria-label="商品分类">
        <button
          v-for="tab in categoryTabs"
          :key="tab.key"
          type="button"
          class="cat-tab"
          :class="{ active: activeCategory === tab.key }"
          :style="{ '--cat-color': tab.color }"
          @click="activeCategory = tab.key"
        >
          <span class="cat-icon" aria-hidden="true">{{ tab.icon }}</span>
          {{ tab.key }}
          <span class="cat-count">{{ tab.count }}</span>
        </button>
      </nav>

      <!-- 工具条 -->
      <div class="shop-toolbar">
        <p class="toolbar-hint">
          <strong>{{ visibleItems.length }}</strong> 件好物 · 已兑换会放进
          <button type="button" class="inline-link" @click="goBackpack">我的背包 →</button>
        </p>
        <div class="toolbar-right">
          <label class="sort-box">
            <span aria-hidden="true">↕</span>
            <select v-model="sortBy" aria-label="商品排序">
              <option value="default">推荐排序</option>
              <option value="price-asc">价格从低到高</option>
              <option value="price-desc">价格从高到低</option>
              <option value="owned">我有的优先</option>
            </select>
          </label>
        </div>
      </div>

      <!-- 商品网格 -->
      <section class="shop-grid">
        <article
          v-for="item in visibleItems"
          :key="item.id"
          class="shop-card"
          :class="{ owned: itemCount(item.id) > 0, poor: store.coins < item.price }"
          :style="{ '--tile': categoryOf(item.category).color }"
        >
          <div class="item-tile">
            <span v-if="item.tag" class="item-tag">{{ item.tag }}</span>
            <span class="item-cat">
              {{ categoryOf(item.category).icon }} {{ item.category }}
            </span>
            <div class="art-box"><ItemArt :art="item.art" /></div>
            <span v-if="itemCount(item.id)" class="owned-chip">已有 ×{{ itemCount(item.id) }}</span>
          </div>

          <div class="item-body">
            <div class="item-name-row">
              <h3>{{ item.name }}</h3>
            </div>
            <p class="item-desc">{{ item.desc }}</p>

            <div class="price-row">
              <CoinIcon :size="22" />
              <strong>{{ item.price }}</strong>
              <span>游戏币</span>
              <em v-if="store.coins < item.price">还差 {{ item.price - store.coins }}</em>
            </div>

            <button
              type="button"
              class="buy-btn"
              :class="{ short: store.coins < item.price }"
              @click="openBuy(item)"
            >{{ buyLabel(item) }}</button>
          </div>
        </article>
      </section>

      <!-- 兑换须知 -->
      <section class="notice-strip" aria-label="兑换须知">
        <div class="notice-item">
          <span aria-hidden="true">🎒</span>
          <div><strong>购买即入背包</strong><small>兑换成功后自动放进「我的背包」，随时可用</small></div>
        </div>
        <div class="notice-item">
          <span aria-hidden="true">♻️</span>
          <div><strong>可出售回收</strong><small>背包里的物品可按 6 折出售，换回游戏币</small></div>
        </div>
        <div class="notice-item">
          <span aria-hidden="true">💛</span>
          <div><strong>虚拟物品</strong><small>游戏币与物品仅站内使用，不可折现哦</small></div>
        </div>
      </section>
    </main>

    <!-- 购买确认 -->
    <div v-if="buyTarget" class="buy-mask" @click.self="closeBuy">
      <div class="buy-modal">
        <button type="button" class="buy-close" aria-label="关闭" @click="closeBuy">×</button>
        <div class="buy-art" :style="{ '--tile': categoryOf(buyTarget.category).color }">
          <ItemArt :art="buyTarget.art" />
        </div>
        <h2>兑换「{{ buyTarget.name }}」</h2>
        <p class="buy-desc">{{ buyTarget.effect }}</p>

        <div class="buy-summary">
          <div class="buy-line">
            <span>商品价格</span>
            <strong><CoinIcon :size="16" /> {{ buyTarget.price }}</strong>
          </div>
          <div class="buy-line">
            <span>当前余额</span>
            <strong><CoinIcon :size="16" /> {{ store.coins }}</strong>
          </div>
          <div class="buy-line total">
            <span>兑换后余额</span>
            <strong><CoinIcon :size="16" /> {{ store.coins - buyTarget.price }}</strong>
          </div>
        </div>

        <div class="buy-actions">
          <button type="button" class="buy-cancel" @click="closeBuy">再想想</button>
          <button type="button" class="buy-confirm" :disabled="buying" @click="confirmBuy">
            {{ buying ? '兑换中…' : '确认兑换 →' }}
          </button>
        </div>
      </div>
    </div>

    <!-- 兑换成功 -->
    <div v-if="boughtItem" class="buy-mask" @click.self="boughtItem = null">
      <div class="buy-modal success">
        <div class="success-art" :style="{ '--tile': categoryOf(boughtItem.category).color }">
          <ItemArt :art="boughtItem.art" />
          <span class="success-spark s1" aria-hidden="true">✨</span>
          <span class="success-spark s2" aria-hidden="true">💛</span>
        </div>
        <h2>兑换成功！</h2>
        <p class="buy-desc">「{{ boughtItem.name }}」已经放进你的背包啦～</p>
        <div class="success-balance">
          <CoinIcon :size="18" /> 剩余 {{ store.coins }} 游戏币
        </div>
        <div class="buy-actions">
          <button type="button" class="buy-cancel" @click="boughtItem = null">继续逛</button>
          <button type="button" class="buy-confirm" @click="goBackpack">去背包看看 →</button>
        </div>
      </div>
    </div>

    <div class="fun-toast" :class="{ show: toastText }">{{ toastText }}</div>
  </div>
</template>

<style scoped>
:global(body.home-body) { display: block; align-items: initial; justify-content: initial; padding: 0; }

.shop-main { max-width: 1200px; margin: 0 auto; padding: 34px 24px 74px; }

/* ===== 页头 ===== */
.shop-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  margin-bottom: 22px;
}
.shop-title { display: flex; align-items: center; gap: 16px; }
.shop-title-badge {
  width: 66px;
  height: 66px;
  display: grid;
  place-items: center;
  font-size: 31px;
  background: var(--pink);
  border: var(--line);
  border-radius: 20px;
  box-shadow: var(--shadow-2);
  transform: rotate(-5deg);
  flex: 0 0 auto;
}
.shop-title h1 { margin: 0 0 4px; font-size: 32px; letter-spacing: 0.5px; }
.shop-title p { margin: 0; font-size: 13px; font-weight: 700; color: var(--text-2); }

.shop-wallet {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px 10px 16px;
  background: linear-gradient(120deg, #fff3c9, #ffe0b4);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
}
.wallet-main { display: flex; align-items: center; gap: 10px; }
.wallet-main span { display: block; font-size: 10px; font-weight: 900; color: var(--text-3); letter-spacing: 0.5px; }
.wallet-main strong { font-size: 26px; line-height: 1.1; display: block; animation: num-pop 0.4s cubic-bezier(0.2, 1.5, 0.4, 1); }
@keyframes num-pop { from { opacity: 0.3; transform: translateY(-4px) scale(1.12); } to { opacity: 1; transform: none; } }
.wallet-earn {
  padding: 8px 12px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
  cursor: pointer;
  white-space: nowrap;
}
.wallet-earn:hover { background: var(--yellow); transform: translateY(-2px); box-shadow: 3px 4px 0 var(--ink); }

/* ===== 分类 Tab ===== */
.cat-tabs { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 18px; }
.cat-tab {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 10px 16px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}
.cat-tab:hover { transform: translateY(-3px); box-shadow: 3px 6px 0 var(--ink); }
.cat-tab.active {
  background: var(--cat-color);
  transform: translate(2px, 2px);
  box-shadow: 1px 1px 0 var(--ink);
}
.cat-icon { font-size: 15px; }
.cat-count {
  display: grid;
  place-items: center;
  min-width: 19px;
  height: 19px;
  padding: 0 5px;
  font-size: 10px;
  font-weight: 900;
  background: #fffdf6;
  border: 1.5px solid var(--ink);
  border-radius: 7px;
}
.cat-tab.active .cat-count { background: #fff; }

/* ===== 工具条 ===== */
.shop-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 2px dashed rgba(43, 43, 43, 0.16);
}
.toolbar-hint { margin: 0; font-size: 12px; font-weight: 700; color: var(--text-2); }
.toolbar-hint strong { font-size: 14px; color: var(--ink); }
.inline-link {
  padding: 0;
  font: inherit;
  font-weight: 900;
  color: #c2543a;
  background: none;
  border: none;
  border-bottom: 2px dashed #c2543a;
  cursor: pointer;
}
.inline-link:hover { color: var(--ink); border-color: var(--ink); }
.toolbar-right { display: flex; align-items: center; gap: 10px; }
.sort-box {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  font-size: 11.5px;
  font-weight: 900;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
}
.sort-box select {
  font: inherit;
  font-size: 11.5px;
  font-weight: 900;
  color: var(--ink);
  background: transparent;
  border: none;
  outline: none;
  cursor: pointer;
}

/* ===== 商品卡片 ===== */
.shop-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 18px;
}
.shop-card {
  display: flex;
  flex-direction: column;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 5px 6px 0 var(--ink);
  overflow: hidden;
  transition: transform 0.18s ease, box-shadow 0.18s ease;
}
.shop-card:hover { transform: translate(-3px, -5px); box-shadow: 8px 11px 0 var(--ink); }

.item-tile {
  position: relative;
  height: 154px;
  display: grid;
  place-items: center;
  background: var(--tile);
  background-image:
    radial-gradient(rgba(43, 43, 43, 0.09) 1.2px, transparent 1.2px),
    radial-gradient(circle at 50% 20%, rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0) 62%);
  background-size: 14px 14px, 100% 100%;
  border-bottom: var(--line);
  overflow: hidden;
}
.art-box {
  width: 120px;
  height: 120px;
  padding: 4px;
  transition: transform 0.22s cubic-bezier(0.2, 1.4, 0.4, 1);
}
.shop-card:hover .art-box { transform: scale(1.09) rotate(-3deg); }
.item-tag {
  position: absolute;
  left: 0;
  top: 12px;
  padding: 4px 10px 4px 9px;
  font-size: 10px;
  font-weight: 900;
  color: #fffdf6;
  background: #e2603f;
  border: 2px solid var(--ink);
  border-left: none;
  border-radius: 0 9px 9px 0;
  z-index: 2;
}
.item-cat {
  position: absolute;
  right: 10px;
  top: 10px;
  padding: 3px 8px;
  font-size: 10px;
  font-weight: 900;
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: 8px;
  z-index: 2;
}
.owned-chip {
  position: absolute;
  left: 10px;
  bottom: 10px;
  padding: 3px 8px;
  font-size: 10px;
  font-weight: 900;
  background: var(--mint);
  border: 2px solid var(--ink);
  border-radius: 8px;
}

.item-body { display: flex; flex-direction: column; gap: 7px; padding: 13px 14px 14px; flex: 1; }
.item-name-row h3 { margin: 0; font-size: 16px; letter-spacing: 0.2px; }
.item-desc {
  margin: 0;
  font-size: 11px;
  font-weight: 700;
  line-height: 1.55;
  color: var(--text-2);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  min-height: 34px;
}
.price-row {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 7px 10px;
  background: #fff5d9;
  border: 2px solid rgba(43, 43, 43, 0.16);
  border-radius: var(--r-sm);
}
.price-row strong { font-size: 19px; line-height: 1; }
.price-row span { font-size: 10px; font-weight: 900; color: var(--text-3); }
.price-row em {
  margin-left: auto;
  font-size: 10px;
  font-style: normal;
  font-weight: 900;
  color: #c2543a;
}
.shop-card.poor .price-row { background: #f6eee3; }

.buy-btn {
  margin-top: auto;
  padding: 10px 0;
  font: inherit;
  font-size: 12.5px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.15s;
}
.buy-btn:hover { background: #ffe27a; transform: translateY(-2px); box-shadow: 3px 5px 0 var(--ink); }
.buy-btn:active { transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }
.buy-btn.short { background: #f1e7d8; color: var(--text-2); }
.buy-btn.short:hover { background: #e8dbca; }

/* ===== 兑换须知 ===== */
.notice-strip {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 14px;
  margin-top: 28px;
  padding: 18px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 5px 6px 0 var(--ink);
}
.notice-item { display: flex; align-items: flex-start; gap: 10px; }
.notice-item > span {
  width: 34px;
  height: 34px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 16px;
  background: #fff3c9;
  border: 2px solid var(--ink);
  border-radius: 10px;
}
.notice-item strong { display: block; margin-bottom: 2px; font-size: 12.5px; }
.notice-item small { font-size: 10.5px; font-weight: 700; line-height: 1.55; color: var(--text-2); }

/* ===== 弹窗 ===== */
.buy-mask {
  position: fixed;
  inset: 0;
  z-index: 60;
  display: grid;
  place-items: center;
  padding: 20px;
  background: rgba(43, 43, 43, 0.48);
}
.buy-modal {
  position: relative;
  width: min(420px, 100%);
  padding: 26px 26px 24px;
  text-align: center;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 10px 12px 0 var(--ink);
  animation: buy-pop 0.26s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
@keyframes buy-pop {
  from { opacity: 0; transform: scale(0.88) translateY(14px); }
  to { opacity: 1; transform: none; }
}
.buy-close {
  position: absolute;
  right: 14px;
  top: 14px;
  width: 32px;
  height: 32px;
  font: inherit;
  font-weight: 900;
  background: #ffc9cf;
  border: 2px solid var(--ink);
  border-radius: 50%;
  cursor: pointer;
}
.buy-close:hover { transform: rotate(90deg); }
.buy-art {
  width: 110px;
  height: 110px;
  margin: 4px auto 14px;
  padding: 8px;
  background: var(--tile);
  border: var(--line);
  border-radius: 26px;
  box-shadow: 5px 6px 0 var(--ink);
  transform: rotate(-3deg);
}
.buy-modal h2 { margin: 0 0 6px; font-size: 21px; }
.buy-desc { margin: 0 0 16px; font-size: 12px; font-weight: 700; line-height: 1.6; color: var(--text-2); }
.buy-summary {
  display: grid;
  gap: 6px;
  padding: 12px 14px;
  margin-bottom: 18px;
  background: #fff;
  border: 2px dashed rgba(43, 43, 43, 0.2);
  border-radius: var(--r-sm);
}
.buy-line { display: flex; align-items: center; justify-content: space-between; font-size: 12px; font-weight: 700; color: var(--text-2); }
.buy-line strong { display: inline-flex; align-items: center; gap: 4px; font-size: 14px; color: var(--ink); }
.buy-line.total { padding-top: 6px; border-top: 2px dashed rgba(43, 43, 43, 0.16); }
.buy-line.total strong { color: #b8581f; }
.buy-actions { display: grid; grid-template-columns: 1fr 1.35fr; gap: 10px; }
.buy-cancel,
.buy-confirm {
  padding: 12px 0;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: var(--r-sm);
  cursor: pointer;
}
.buy-cancel { background: #fff; }
.buy-cancel:hover { background: #f6ece0; }
.buy-confirm { background: var(--yellow); box-shadow: 3px 3px 0 var(--ink); }
.buy-confirm:hover { background: #ffe27a; transform: translateY(-2px); box-shadow: 3px 5px 0 var(--ink); }
.buy-confirm:disabled { opacity: 0.65; cursor: default; transform: none; box-shadow: 3px 3px 0 var(--ink); }

/* 成功弹窗 */
.buy-modal.success { animation: buy-pop 0.3s cubic-bezier(0.2, 1.6, 0.4, 1) both; }
.success-art {
  position: relative;
  width: 118px;
  height: 118px;
  margin: 2px auto 14px;
  padding: 8px;
  background: var(--tile);
  border: var(--line);
  border-radius: 28px;
  box-shadow: 5px 6px 0 var(--ink);
  animation: success-bob 2.6s ease-in-out infinite;
}
@keyframes success-bob {
  0%, 100% { translate: 0 0; rotate: -3deg; }
  50% { translate: 0 -7px; rotate: 3deg; }
}
.success-spark { position: absolute; font-size: 20px; }
.success-spark.s1 { left: -16px; top: 8px; }
.success-spark.s2 { right: -14px; bottom: 12px; }
.success-balance {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 16px;
  padding: 6px 14px;
  font-size: 12px;
  font-weight: 900;
  background: #fff3c9;
  border: 2px solid var(--ink);
  border-radius: 99px;
}

@media (max-width: 1100px) {
  .shop-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
}
@media (max-width: 860px) {
  .shop-head { flex-direction: column; align-items: flex-start; }
  .shop-wallet { width: 100%; justify-content: space-between; }
  .shop-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .notice-strip { grid-template-columns: 1fr; }
}
@media (max-width: 620px) {
  .shop-main { padding: 24px 14px 60px; }
  .shop-title h1 { font-size: 26px; }
  .shop-title-badge { width: 52px; height: 52px; font-size: 25px; }
  .shop-grid { grid-template-columns: 1fr; }
  .shop-toolbar { flex-direction: column; align-items: flex-start; }
  .buy-actions { grid-template-columns: 1fr; }
}
</style>
