<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import '../page.css'

const categories = [
  { value: 'adopt', label: '领养相关', icon: '🐾' },
  { value: 'give', label: '送养相关', icon: '✍️' },
  { value: 'rescue', label: '救助相关', icon: '🚑' },
  { value: 'other', label: '其他问题', icon: '❓' }
]
const activeCat = ref('adopt')
const openIdx = ref(-1)

const faqs = {
  adopt: [
    { q: '领养需要满足什么条件？', a: '需年满 18 周岁，有稳定住所与经济能力，家人同意共同饲养，并承诺长期负责、接受定期回访。' },
    { q: '领养是免费的吗？', a: '本站领养不收取领养费用。部分宠物可能涉及已产生的疫苗/驱虫费用，会在详情页如实说明。' },
    { q: '提交申请后多久有回复？', a: '志愿者一般会在 3-5 个工作日内完成资料审核，请保持联系方式畅通，也可在「我的申请」查看状态。' },
    { q: '可以领养多只宠物吗？', a: '可以，但需根据实际情况评估你的饲养能力。我们会优先保障每只宠物都能得到充分的关爱。' }
  ],
  give: [
    { q: '什么样的宠物可以送养？', a: '需满 6 周龄、身体健康、无严重传染病。请如实告知健康状况与性格，以便为其找到合适的领养人。' },
    { q: '送养审核需要多久？', a: '一般 3-5 个工作日，包含资料审核与必要的实地回访，审核通过后会上架到领养专区。' },
    { q: '送养后我还能查看情况吗？', a: '可以，我们会定期回访并向你反馈毛孩子的生活近况，让你安心。' }
  ],
  rescue: [
    { q: '发现流浪动物该怎么办？', a: '可先确保自身安全，拍照记录位置与健康状况，通过「流浪救助」页面的求助入口上报，志愿者会尽快核实。' },
    { q: '爱心助力有什么用？', a: '你的每一次助力都会累积爱心值，用于支持救助故事中的医疗与食物开支，累计还能解锁专属救助徽章。' },
    { q: '我可以参与线下救助吗？', a: '当然欢迎！可在「志愿者合作」页面报名救助陪护等岗位，和我们一起行动。' }
  ],
  other: [
    { q: '如何修改我的昵称？', a: '目前昵称用于站内展示，可在个人中心（后续版本）修改。如需帮助请联系客服。' },
    { q: '忘记密码怎么办？', a: '可在登录页尝试重新注册或使用找回功能（演示版本暂未开放），请联系客服协助处理。' },
    { q: '数据会丢失吗？', a: '本站为演示项目，收藏、申请等数据保存在浏览器本地（localStorage），刷新不丢失；清除浏览器数据后会被清空。' }
  ]
}
const list = computed(() => faqs[activeCat.value] || [])
function toggle(idx) { openIdx.value = openIdx.value === idx ? -1 : idx }

const toastText = ref('')
let toastTimer = null
function contactService() {
  toastText.value = '📮 客服邮箱：hello@furryhome.cn（演示）'
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 3200)
}
onMounted(() => document.body.classList.add('home-body'))
onBeforeUnmount(() => { document.body.classList.remove('home-body'); clearTimeout(toastTimer) })
</script>

<template>
  <div class="fun-page">
    <main class="fun-main faq-main">
      <div class="fun-head">
        <h1>常见问题 <span>❓</span></h1>
        <p>你想知道的，这里都有答案～</p>
      </div>

      <div class="fun-tabs">
        <button
          v-for="c in categories"
          :key="c.value"
          type="button"
          class="fun-tab"
          :class="{ active: activeCat === c.value }"
          @click="activeCat = c.value; openIdx = -1"
        ><span>{{ c.icon }}</span> {{ c.label }}</button>
      </div>

      <div class="faq-list">
        <div v-for="(item, i) in list" :key="i" class="faq-card fun-card" :class="{ open: openIdx === i }">
          <button type="button" class="faq-q" @click="toggle(i)">
            <span class="faq-num">{{ String(i + 1).padStart(2, '0') }}</span>
            <span class="faq-title">{{ item.q }}</span>
            <span class="faq-icon">{{ openIdx === i ? '−' : '+' }}</span>
          </button>
          <transition name="fold">
            <div v-if="openIdx === i" class="faq-a">💡 {{ item.a }}</div>
          </transition>
        </div>
      </div>

      <div class="contact-tip fun-card">
        <span>🤗</span>
        <div>
          <strong>没找到想要的答案？</strong>
          <p>别着急，联系我们的客服小哥哥小姐姐吧～</p>
        </div>
        <button type="button" class="fun-btn pink" @click="contactService">📮 联系客服</button>
      </div>
    </main>
    <div class="fun-toast" :class="{ show: !!toastText }">{{ toastText }}</div>
  </div>
</template>

<style scoped>
.faq-main { max-width: 820px; }
.faq-list { display: grid; gap: 12px; }
.faq-card { overflow: hidden; }
.faq-q { display: flex; align-items: center; gap: 12px; width: 100%; padding: 15px 18px; font: inherit; font-size: 14px; font-weight: 900; color: var(--ink); background: none; border: none; cursor: pointer; text-align: left; }
.faq-card.open { background: #fff9e6; }
.faq-num { display: grid; place-items: center; width: 28px; height: 28px; flex: 0 0 auto; font-size: 11px; background: var(--yellow); border: 2px solid var(--ink); border-radius: 8px; }
.faq-title { flex: 1; }
.faq-icon { font-size: 20px; }
.faq-a { padding: 0 18px 16px 58px; font-size: 12px; font-weight: 700; line-height: 1.9; color: #6b5744; }
.fold-enter-active, .fold-leave-active { transition: 0.2s; }
.fold-enter-from, .fold-leave-to { opacity: 0; transform: translateY(-6px); }
.contact-tip { display: flex; align-items: center; gap: 14px; margin-top: 28px; padding: 20px; background: #fff2c9; }
.contact-tip > span { font-size: 36px; }
.contact-tip strong { font-size: 15px; }
.contact-tip p { margin: 4px 0 0; font-size: 12px; font-weight: 700; color: #8a6a4f; }
.contact-tip .fun-btn { margin-left: auto; }
@media (max-width: 620px) { .contact-tip { flex-wrap: wrap; } .contact-tip .fun-btn { margin-left: 0; width: 100%; } }
</style>
