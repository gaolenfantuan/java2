<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import '../page.css'

const categories = [
  { value: 'cat', label: '猫猫', icon: '🐱' },
  { value: 'dog', label: '狗狗', icon: '🐶' },
  { value: 'rabbit', label: '兔兔', icon: '🐰' },
  { value: 'small', label: '小宠', icon: '🐹' }
]
const activeCat = ref('cat')

const articles = {
  cat: [
    { id: 'c1', emoji: '🐱', title: '新手养猫必备清单', desc: '猫砂盆、猫粮、猫抓板…一次搞懂刚养猫要准备什么。', detail: '必备：猫砂+猫砂盆、主粮+食碗水碗、猫抓板、指甲剪、猫包、驱虫药。建议先带猫咪做体检和疫苗，家中收好小物件与有毒植物。' },
    { id: 'c2', emoji: '🍃', title: '猫咪常见掉毛怎么办', desc: '换毛季满屋飞毛？科学梳毛与饮食调理看这里。', detail: '每天梳毛 1-2 次，补充鱼油与卵磷脂，选择含膳食纤维的主粮。若局部脱毛伴红肿需就医排查皮肤病。' },
    { id: 'c3', emoji: '💧', title: '猫咪不爱喝水？', desc: '泌尿健康从喝水开始，几个小妙招让它爱上喝水。', detail: '可使用流动饮水机、增加湿粮/罐头比例、在多个角落放置水碗。长期饮水不足易引发泌尿系统疾病。' }
  ],
  dog: [
    { id: 'd1', emoji: '🐶', title: '幼犬疫苗与驱虫时间表', desc: '几针疫苗、多久驱虫，一张表讲清楚。', detail: '幼犬 6-8 周首针，之后每 3-4 周一针，共 3 针+狂犬。体内驱虫每月一次，体外驱虫夏季每月一次。' },
    { id: 'd2', emoji: '🦴', title: '狗狗补钙的误区', desc: '补钙不是越多越好，科学补钙才健康。', detail: '全价犬粮已含足够钙质，一般无需额外补充。过量补钙反而影响骨骼发育，大型犬尤其要注意。' },
    { id: 'd3', emoji: '🎾', title: '每天遛狗多久合适', desc: '不同品种运动量需求大不同。', detail: '小型犬每天 30 分钟，中大型犬 1-2 小时。运动不足易导致拆家、吠叫等行为问题。' }
  ],
  rabbit: [
    { id: 'r1', emoji: '🥕', title: '兔兔的正确食谱', desc: '提摩西草为主，蔬菜为辅，零食要少量。', detail: '无限量提摩西草 + 适量兔粮 + 干净饮水，每日补充新鲜蔬菜。胡萝卜等含糖高只能当零食，避免人类加工食品。' },
    { id: 'r2', emoji: '🦷', title: '兔兔牙齿会一直长', desc: '了解兔兔牙齿结构，防止牙齿过长。', detail: '兔兔牙齿终生生长，需靠磨牙草和磨牙石磨损。若出现流口水、食欲下降，可能牙齿过长需就医。' }
  ],
  small: [
    { id: 's1', emoji: '🐹', title: '仓鼠饲养入门', desc: '独居、垫料、跑轮，养仓鼠的关键点。', detail: '仓鼠多为独居动物须单笼饲养；垫料要厚便于挖掘，配备跑轮和躲避屋；注意通风与定期清理。' },
    { id: 's2', emoji: '🌡️', title: '小宠适宜温度', desc: '太冷太热都危险，注意保温与通风。', detail: '仓鼠、金丝熊适宜 20-28℃，夏季避免阳光直晒，冬季可铺棉花保暖。温度骤变易导致应激。' }
  ]
}

const beginnerGuide = [
  { emoji: '🍽️', title: '科学喂养', desc: '定时定量选主粮' },
  { emoji: '🪱', title: '定期驱虫', desc: '体内外都要做' },
  { emoji: '💉', title: '按时疫苗', desc: '幼年基础免疫' }
]
const healthQA = ref([
  { q: '毛孩子呕吐了要紧吗？', a: '偶发呕吐可能只是舔毛或吃急了，观察精神与食欲。若频繁呕吐、带血或精神萎靡，请尽快就医。', open: false },
  { q: '怎么判断宠物发烧了？', a: '狗狗正常体温约 38-39℃，猫约 38-39.2℃。可用宠物专用体温计测量肛温，超过上限需就医。', open: false },
  { q: '皮肤痒、老挠怎么办？', a: '可能是跳蚤、真菌或过敏。先检查体表有无红点脱毛，保持环境清洁，持续搔痒请就医确诊。', open: false }
])
const openArticle = ref(null)
const list = computed(() => articles[activeCat.value] || [])

function toggleQA(item) { item.open = !item.open }

onMounted(() => document.body.classList.add('home-body'))
onBeforeUnmount(() => document.body.classList.remove('home-body'))
</script>

<template>
  <div class="fun-page">
    <main class="fun-main">
      <div class="fun-head">
        <h1>宠物百科 <span>📚</span></h1>
        <p>科学养宠不踩坑，从小白到达人～</p>
      </div>

      <!-- 新手养宠指南 -->
      <section class="guide-banner fun-card">
        <h2>🌟 新手养宠指南</h2>
        <div class="guide-grid">
          <div v-for="g in beginnerGuide" :key="g.title" class="guide-item">
            <span>{{ g.emoji }}</span><strong>{{ g.title }}</strong><small>{{ g.desc }}</small>
          </div>
        </div>
      </section>

      <div class="wiki-layout">
        <!-- 左侧分类 -->
        <aside class="side-nav fun-card">
          <h3>📂 分类导航</h3>
          <button
            v-for="c in categories"
            :key="c.value"
            type="button"
            class="side-item"
            :class="{ active: activeCat === c.value }"
            @click="activeCat = c.value; openArticle = null"
          ><span>{{ c.icon }}</span>{{ c.label }}</button>
        </aside>

        <!-- 右侧科普列表 -->
        <section class="article-list">
          <article v-for="a in list" :key="a.id" class="article-card fun-card fun-card-hover">
            <button type="button" class="article-head" @click="openArticle = openArticle === a.id ? null : a.id">
              <span class="article-cover">{{ a.emoji }}</span>
              <span class="article-meta"><strong>{{ a.title }}</strong><small>{{ a.desc }}</small></span>
              <span class="article-arrow">{{ openArticle === a.id ? '▴' : '▾' }}</span>
            </button>
            <div v-if="openArticle === a.id" class="article-detail">{{ a.detail }}</div>
          </article>
        </section>
      </div>

      <!-- 常见健康问题 -->
      <section class="qa-section">
        <h2 class="section-title">🩺 常见健康问题</h2>
        <div class="qa-list">
          <div v-for="(item, i) in healthQA" :key="i" class="qa-card fun-card">
            <button type="button" class="qa-q" @click="toggleQA(item)">
              <span>❓ {{ item.q }}</span><span class="qa-icon">{{ item.open ? '−' : '+' }}</span>
            </button>
            <div v-if="item.open" class="qa-a">💡 {{ item.a }}</div>
          </div>
        </div>
      </section>
    </main>
  </div>
</template>

<style scoped>
.guide-banner { padding: 20px 22px; margin-bottom: 24px; background: #fff2c9; }
.guide-banner h2 { margin: 0 0 16px; font-size: 20px; }
.guide-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.guide-item { text-align: center; padding: 12px; background: #fffdf6; border: 2px solid var(--ink); border-radius: 14px; }
.guide-item span { font-size: 30px; display: block; }
.guide-item strong { display: block; font-size: 14px; margin: 6px 0 2px; }
.guide-item small { font-size: 11px; color: #8a6a4f; font-weight: 700; }
.wiki-layout { display: grid; grid-template-columns: 180px 1fr; gap: 20px; align-items: start; }
.side-nav { padding: 16px 12px; position: sticky; top: 84px; }
.side-nav h3 { font-size: 15px; margin: 0 0 12px; }
.side-item { display: flex; align-items: center; gap: 8px; width: 100%; padding: 10px 12px; margin-bottom: 8px; font: inherit; font-size: 13px; font-weight: 900; color: var(--ink); background: #fff; border: 2px solid var(--ink); border-radius: 12px; cursor: pointer; transition: 0.15s; }
.side-item:hover { transform: translateX(3px); }
.side-item.active { background: var(--mint); box-shadow: 3px 3px 0 var(--ink); }
.article-list { display: grid; gap: 14px; }
.article-card { overflow: hidden; }
.article-head { display: flex; align-items: center; gap: 14px; width: 100%; padding: 14px 16px; background: none; border: none; font: inherit; text-align: left; cursor: pointer; color: var(--ink); }
.article-cover { width: 56px; height: 56px; flex: 0 0 auto; display: grid; place-items: center; font-size: 30px; background: var(--blue); border: 2px solid var(--ink); border-radius: 14px; }
.article-meta { flex: 1; display: flex; flex-direction: column; gap: 4px; }
.article-meta strong { font-size: 15px; }
.article-meta small { font-size: 11px; color: #8a6a4f; font-weight: 700; }
.article-arrow { font-size: 18px; font-weight: 900; }
.article-detail { padding: 0 18px 16px; font-size: 12px; font-weight: 700; line-height: 1.8; color: #6b5744; border-top: 2px dashed #e6d3b3; padding-top: 12px; margin: 0 16px; }
.qa-section { margin-top: 32px; }
.section-title { font-size: 20px; margin: 0 0 16px; }
.qa-list { display: grid; gap: 12px; }
.qa-card { overflow: hidden; }
.qa-q { display: flex; align-items: center; justify-content: space-between; width: 100%; padding: 14px 18px; font: inherit; font-size: 14px; font-weight: 900; color: var(--ink); background: none; border: none; cursor: pointer; text-align: left; }
.qa-icon { font-size: 20px; }
.qa-a { padding: 0 18px 16px; font-size: 12px; font-weight: 700; line-height: 1.8; color: #6b5744; }
@media (max-width: 760px) {
  .wiki-layout { grid-template-columns: 1fr; }
  .side-nav { position: static; display: flex; flex-wrap: wrap; gap: 8px; }
  .side-nav h3 { width: 100%; }
  .side-item { width: auto; }
  .guide-grid { grid-template-columns: 1fr; }
}
</style>
