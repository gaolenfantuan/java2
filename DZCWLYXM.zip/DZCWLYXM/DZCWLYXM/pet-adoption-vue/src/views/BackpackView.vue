<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import '../page.css'
import CoinIcon from '../components/CoinIcon.vue'
import ItemArt from '../components/ItemArt.vue'
import CuteEmpty from '../components/CuteEmpty.vue'
import { shopCategories, findItem, sellPrice } from '../data/shopItems'
import { store, addCoins, removeItem } from '../store'

const router = useRouter()
const BAG_CAPACITY = 60

const activeCategory = ref('全部')

// 背包条目：把 localStorage 里的 id + 数量，补全成完整商品信息
const bagEntries = computed(() => store.backpack
  .map(entry => {
    const item = findItem(entry.id)
    return item ? { ...item, count: entry.count, sell: sellPrice(item) } : null
  })
  .filter(Boolean)
  .sort((a, b) => {
    const ai = shopCategories.findIndex(cat => cat.key === a.category)
    const bi = shopCategories.findIndex(cat => cat.key === b.category)
    if (ai !== bi) return ai - bi
    return b.price - a.price
  })
)

const totalCount = computed(() => bagEntries.value.reduce((sum, item) => sum + item.count, 0))
const totalValue = computed(() => bagEntries.value.reduce((sum, item) => sum + item.sell * item.count, 0))
const kindCount = computed(() => bagEntries.value.length)
const capacityPercent = computed(() => Math.min(100, Math.round((totalCount.value / BAG_CAPACITY) * 100)))

const categoryTabs = computed(() => [
  { key: '全部', icon: '🎒', color: '#ffe9b8', count: totalCount.value },
  ...shopCategories.map(cat => ({
    ...cat,
    count: bagEntries.value
      .filter(item => item.category === cat.key)
      .reduce((sum, item) => sum + item.count, 0)
  }))
])

const visibleEntries = computed(() => activeCategory.value === '全部'
  ? bagEntries.value
  : bagEntries.value.filter(item => item.category === activeCategory.value)
)

function categoryOf(key) {
  return shopCategories.find(cat => cat.key === key) || { color: '#ffe9b8', icon: '✨' }
}

// ===== 使用 / 出售 =====
const actionTarget = ref(null)
const actionMode = ref('use')
const toastText = ref('')
let toastTimer = null

function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2300)
}

function askUse(entry) {
  if (entry.count <= 0) return
  actionTarget.value = entry
  actionMode.value = 'use'
}
function askSell(entry) {
  if (entry.count <= 0) return
  actionTarget.value = entry
  actionMode.value = 'sell'
}
function closeAction() {
  actionTarget.value = null
}

function confirmAction() {
  const entry = actionTarget.value
  if (!entry) return

  if (actionMode.value === 'use') {
    if (!removeItem(entry.id, 1)) {
      showToast('背包里已经没有这件物品啦')
      closeAction()
      return
    }
    showToast(`「${entry.name}」已使用，毛孩子开心得直打滚 🐾`)
  } else {
    if (!removeItem(entry.id, 1)) {
      showToast('背包里已经没有这件物品啦')
      closeAction()
      return
    }
    addCoins(entry.sell)
    showToast(`出售成功，+${entry.sell} 游戏币已到账 🪙`)
  }
  closeAction()
}

function goShop() {
  router.push('/shop')
}
function goPlayground() {
  router.push('/playground')
}

onMounted(() => document.body.classList.add('home-body'))
onBeforeUnmount(() => {
  document.body.classList.remove('home-body')
  clearTimeout(toastTimer)
})
</script>

<template>
  <div class="app-bg fun-page bag-page">
    <main class="bag-main">
      <!-- 页头 -->
      <header class="bag-head">
        <div class="bag-title">
          <span class="bag-title-badge" aria-hidden="true">🎒</span>
          <div>
            <h1>我的背包</h1>
            <p>在这里看看给毛孩子攒下的小礼物，随时能用掉或换回游戏币</p>
          </div>
        </div>

        <div class="bag-wallet">
          <div class="wallet-main">
            <CoinIcon :size="36" />
            <div>
              <span>我的游戏币</span>
              <strong :key="store.coins">{{ store.coins }}</strong>
            </div>
          </div>
          <button type="button" class="wallet-btn" @click="goShop">逛商城 →</button>
        </div>
      </header>

      <!-- 背包概览 -->
      <section class="bag-stats" aria-label="背包概览">
        <div class="stat-card">
          <span class="stat-icon" aria-hidden="true">📦</span>
          <div><strong>{{ kindCount }}</strong><small>物品种类</small></div>
        </div>
        <div class="stat-card">
          <span class="stat-icon" aria-hidden="true">🔢</span>
          <div><strong>{{ totalCount }}</strong><small>物品总数</small></div>
        </div>
        <div class="stat-card">
          <span class="stat-icon" aria-hidden="true">🪙</span>
          <div><strong>{{ totalValue }}</strong><small>可出售价值</small></div>
        </div>
        <div class="stat-card capacity">
          <div class="cap-top">
            <span>背包容量</span>
            <strong>{{ totalCount }}/{{ BAG_CAPACITY }}</strong>
          </div>
          <div class="cap-track"><div class="cap-fill" :style="{ width: capacityPercent + '%' }"></div></div>
          <small>{{ capacityPercent }}% 已使用 · 同类物品会自动堆叠</small>
        </div>
      </section>

      <!-- 分类 Tab（自动按物品归类） -->
      <nav class="bag-tabs" aria-label="物品分类">
        <button
          v-for="tab in categoryTabs"
          :key="tab.key"
          type="button"
          class="bag-tab"
          :class="{ active: activeCategory === tab.key }"
          :style="{ '--cat-color': tab.color }"
          @click="activeCategory = tab.key"
        >
          <span aria-hidden="true">{{ tab.icon }}</span>
          {{ tab.key }}
          <span class="bag-count">{{ tab.count }}</span>
        </button>
      </nav>

      <!-- 物品列表 -->
      <section v-if="visibleEntries.length" class="bag-grid">
        <article
          v-for="entry in visibleEntries"
          :key="entry.id"
          class="bag-card"
          :style="{ '--tile': categoryOf(entry.category).color }"
        >
          <div class="bag-tile">
            <span class="bag-qty">×{{ entry.count }}</span>
            <span class="bag-cat">{{ categoryOf(entry.category).icon }} {{ entry.category }}</span>
            <div class="bag-art"><ItemArt :art="entry.art" /></div>
          </div>

          <div class="bag-body">
            <h3>{{ entry.name }}</h3>
            <p class="bag-desc">{{ entry.desc }}</p>
            <p class="bag-effect">✨ {{ entry.effect }}</p>

            <div class="bag-price">
              <span>出售可得</span>
              <strong><CoinIcon :size="15" /> {{ entry.sell }}</strong>
            </div>

            <div class="bag-actions">
              <button type="button" class="use-btn" @click="askUse(entry)">使用</button>
              <button type="button" class="sell-btn" @click="askSell(entry)">出售</button>
            </div>
          </div>
        </article>
      </section>

      <!-- 空状态 -->
      <CuteEmpty
        v-else
        variant="empty"
        :title="activeCategory === '全部' ? '背包还是空的' : `${activeCategory}栏空空的`"
        :desc="activeCategory === '全部' ? '去积分商城换点小零食吧，第一件礼物总是最甜的' : '这个分类还没有物品，去商城挑一件同类的吧'"
      >
        <button type="button" class="empty-shop" @click="goShop">去积分商城逛逛</button>
        <button type="button" class="empty-earn" @click="goPlayground">先赚点游戏币</button>
      </CuteEmpty>

      <p class="bag-note">
        💡 小提示：物品出售按原价 6 折回收；「使用」只是给毛孩子的互动记录，不会真的消耗毛孩子的健康值～
      </p>
    </main>

    <!-- 使用 / 出售 确认 -->
    <div v-if="actionTarget" class="act-mask" @click.self="closeAction">
      <div class="act-modal">
        <button type="button" class="act-close" aria-label="关闭" @click="closeAction">×</button>
        <div class="act-art" :style="{ '--tile': categoryOf(actionTarget.category).color }">
          <ItemArt :art="actionTarget.art" />
        </div>

        <template v-if="actionMode === 'use'">
          <h2>使用「{{ actionTarget.name }}」</h2>
          <p class="act-desc">{{ actionTarget.effect }}</p>
          <div class="act-info">
            <span>背包剩余</span>
            <strong>{{ actionTarget.count }} 件</strong>
          </div>
          <div class="act-actions">
            <button type="button" class="act-cancel" @click="closeAction">再想想</button>
            <button type="button" class="act-confirm mint" @click="confirmAction">确认使用 →</button>
          </div>
        </template>

        <template v-else>
          <h2>出售「{{ actionTarget.name }}」</h2>
          <p class="act-desc">出售后无法找回，按原价 6 折回收成游戏币～</p>
          <div class="act-info">
            <span>可得游戏币</span>
            <strong class="coin"><CoinIcon :size="18" /> +{{ actionTarget.sell }}</strong>
          </div>
          <div class="act-actions">
            <button type="button" class="act-cancel" @click="closeAction">留着吧</button>
            <button type="button" class="act-confirm" @click="confirmAction">确认出售 →</button>
          </div>
        </template>
      </div>
    </div>

    <div class="fun-toast" :class="{ show: toastText }">{{ toastText }}</div>
  </div>
</template>

<style scoped>
:global(body.home-body) { display: block; align-items: initial; justify-content: initial; padding: 0; }

.bag-main { max-width: 1200px; margin: 0 auto; padding: 34px 24px 74px; }

/* ===== 页头 ===== */
.bag-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  margin-bottom: 20px;
}
.bag-title { display: flex; align-items: center; gap: 16px; }
.bag-title-badge {
  width: 66px;
  height: 66px;
  display: grid;
  place-items: center;
  font-size: 31px;
  background: var(--blue);
  border: var(--line);
  border-radius: 20px;
  box-shadow: var(--shadow-2);
  transform: rotate(-5deg);
  flex: 0 0 auto;
}
.bag-title h1 { margin: 0 0 4px; font-size: 32px; letter-spacing: 0.5px; }
.bag-title p { margin: 0; font-size: 13px; font-weight: 700; color: var(--text-2); }

.bag-wallet {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px 10px 16px;
  background: linear-gradient(120deg, #fff3c9, #ffe0b4);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
}
.wallet-main { display: flex; align-items: center; gap: 10px; }
.wallet-main span { display: block; font-size: 10px; font-weight: 900; color: var(--text-3); letter-spacing: 0.5px; }
.wallet-main strong { display: block; font-size: 26px; line-height: 1.1; animation: num-pop 0.4s cubic-bezier(0.2, 1.5, 0.4, 1); }
@keyframes num-pop { from { opacity: 0.3; transform: translateY(-4px) scale(1.12); } to { opacity: 1; transform: none; } }
.wallet-btn {
  padding: 8px 12px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
  cursor: pointer;
  white-space: nowrap;
}
.wallet-btn:hover { background: var(--yellow); transform: translateY(-2px); box-shadow: 3px 4px 0 var(--ink); }

/* ===== 概览 ===== */
.bag-stats {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 0.8fr)) 1.6fr;
  gap: 14px;
  margin-bottom: 22px;
}
.stat-card {
  display: flex;
  align-items: center;
  gap: 11px;
  padding: 14px 16px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 4px 5px 0 var(--ink);
}
.stat-icon {
  width: 38px;
  height: 38px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 18px;
  background: #fff3c9;
  border: 2px solid var(--ink);
  border-radius: 11px;
}
.stat-card strong { font-size: 24px; line-height: 1.05; }
.stat-card small { display: block; margin-top: 2px; font-size: 10px; font-weight: 900; color: var(--text-3); }

.stat-card.capacity { flex-direction: column; align-items: stretch; gap: 8px; }
.cap-top { display: flex; align-items: center; justify-content: space-between; font-size: 11px; font-weight: 900; }
.cap-top strong { font-size: 15px; }
.cap-track {
  height: 12px;
  background: #f3e8d6;
  border: 2px solid var(--ink);
  border-radius: 99px;
  overflow: hidden;
}
.cap-fill {
  height: 100%;
  background: linear-gradient(90deg, #ffd84d, var(--orange));
  transition: width 0.5s ease;
}
.stat-card.capacity small { font-size: 10px; font-weight: 700; color: var(--text-3); }

/* ===== 分类 Tab ===== */
.bag-tabs { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 18px; }
.bag-tab {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 9px 15px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}
.bag-tab:hover { transform: translateY(-3px); box-shadow: 3px 6px 0 var(--ink); }
.bag-tab.active { background: var(--cat-color); transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }
.bag-count {
  display: grid;
  place-items: center;
  min-width: 19px;
  height: 19px;
  padding: 0 5px;
  font-size: 10px;
  font-weight: 900;
  background: #fffdf6;
  border: 1.5px solid var(--ink);
  border-radius: 7px;
}

/* ===== 物品卡片 ===== */
.bag-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 18px;
}
.bag-card {
  display: flex;
  flex-direction: column;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 5px 6px 0 var(--ink);
  overflow: hidden;
  transition: transform 0.18s ease, box-shadow 0.18s ease;
}
.bag-card:hover { transform: translate(-3px, -5px); box-shadow: 8px 11px 0 var(--ink); }

.bag-tile {
  position: relative;
  height: 140px;
  display: grid;
  place-items: center;
  background: var(--tile);
  background-image:
    radial-gradient(rgba(43, 43, 43, 0.09) 1.2px, transparent 1.2px),
    radial-gradient(circle at 50% 18%, rgba(255, 255, 255, 0.62), rgba(255, 255, 255, 0) 62%);
  background-size: 14px 14px, 100% 100%;
  border-bottom: var(--line);
  overflow: hidden;
}
.bag-art { width: 110px; height: 110px; padding: 4px; transition: transform 0.22s cubic-bezier(0.2, 1.4, 0.4, 1); }
.bag-card:hover .bag-art { transform: scale(1.08) rotate(-3deg); }
.bag-qty {
  position: absolute;
  right: 10px;
  bottom: 10px;
  padding: 3px 9px;
  font-size: 11px;
  font-weight: 900;
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: 8px;
  box-shadow: 2px 2px 0 var(--ink);
  z-index: 2;
}
.bag-cat {
  position: absolute;
  left: 10px;
  top: 10px;
  padding: 3px 8px;
  font-size: 10px;
  font-weight: 900;
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: 8px;
  z-index: 2;
}

.bag-body { display: flex; flex-direction: column; gap: 7px; padding: 13px 14px 14px; flex: 1; }
.bag-body h3 { margin: 0; font-size: 16px; }
.bag-desc {
  margin: 0;
  font-size: 11px;
  font-weight: 700;
  line-height: 1.55;
  color: var(--text-2);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.bag-effect {
  margin: 0;
  padding: 5px 8px;
  font-size: 10px;
  font-weight: 800;
  line-height: 1.5;
  color: #7a5622;
  background: #fffaea;
  border: 1.5px dashed rgba(43, 43, 43, 0.18);
  border-radius: 8px;
}
.bag-price {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 5px 9px;
  font-size: 10.5px;
  font-weight: 900;
  color: var(--text-3);
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.12);
  border-radius: var(--r-sm);
}
.bag-price strong { display: inline-flex; align-items: center; gap: 3px; font-size: 13px; color: #8a5c12; }

.bag-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: auto; }
.use-btn,
.sell-btn {
  padding: 9px 0;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
  cursor: pointer;
  transition: 0.15s;
}
.use-btn { background: var(--mint); }
.sell-btn { background: var(--yellow); }
.use-btn:hover,
.sell-btn:hover { transform: translateY(-2px); box-shadow: 2px 4px 0 var(--ink); }
.use-btn:active,
.sell-btn:active { transform: translate(1px, 1px); box-shadow: 1px 1px 0 var(--ink); }

/* 空状态按钮 */
.empty-shop,
.empty-earn {
  padding: 10px 18px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: var(--r-sm);
  cursor: pointer;
}
.empty-shop { background: var(--yellow); box-shadow: 3px 3px 0 var(--ink); }
.empty-earn { background: #fff; box-shadow: 3px 3px 0 var(--ink); }
.empty-shop:hover,
.empty-earn:hover { transform: translateY(-2px); box-shadow: 3px 5px 0 var(--ink); }

.bag-note {
  margin: 24px 0 0;
  padding: 12px 16px;
  font-size: 11px;
  font-weight: 700;
  line-height: 1.7;
  color: var(--text-2);
  background: #fffdf6;
  border: 2px dashed rgba(43, 43, 43, 0.2);
  border-radius: var(--r-sm);
}

/* ===== 确认弹窗 ===== */
.act-mask {
  position: fixed;
  inset: 0;
  z-index: 60;
  display: grid;
  place-items: center;
  padding: 20px;
  background: rgba(43, 43, 43, 0.48);
}
.act-modal {
  position: relative;
  width: min(420px, 100%);
  padding: 26px 26px 24px;
  text-align: center;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 10px 12px 0 var(--ink);
  animation: act-pop 0.26s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
@keyframes act-pop {
  from { opacity: 0; transform: scale(0.88) translateY(14px); }
  to { opacity: 1; transform: none; }
}
.act-close {
  position: absolute;
  right: 14px;
  top: 14px;
  width: 32px;
  height: 32px;
  font: inherit;
  font-weight: 900;
  background: #ffc9cf;
  border: 2px solid var(--ink);
  border-radius: 50%;
  cursor: pointer;
}
.act-close:hover { transform: rotate(90deg); }
.act-art {
  width: 110px;
  height: 110px;
  margin: 4px auto 14px;
  padding: 8px;
  background: var(--tile);
  border: var(--line);
  border-radius: 26px;
  box-shadow: 5px 6px 0 var(--ink);
  transform: rotate(-3deg);
}
.act-modal h2 { margin: 0 0 6px; font-size: 21px; }
.act-desc { margin: 0 0 16px; font-size: 12px; font-weight: 700; line-height: 1.6; color: var(--text-2); }
.act-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 11px 14px;
  margin-bottom: 18px;
  font-size: 12px;
  font-weight: 700;
  color: var(--text-2);
  background: #fff;
  border: 2px dashed rgba(43, 43, 43, 0.2);
  border-radius: var(--r-sm);
}
.act-info strong { font-size: 15px; color: var(--ink); }
.act-info strong.coin { display: inline-flex; align-items: center; gap: 4px; color: #b8581f; }
.act-actions { display: grid; grid-template-columns: 1fr 1.35fr; gap: 10px; }
.act-cancel,
.act-confirm {
  padding: 12px 0;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: var(--r-sm);
  cursor: pointer;
}
.act-cancel { background: #fff; }
.act-cancel:hover { background: #f6ece0; }
.act-confirm { background: var(--yellow); box-shadow: 3px 3px 0 var(--ink); }
.act-confirm.mint { background: var(--mint); }
.act-confirm:hover { transform: translateY(-2px); box-shadow: 3px 5px 0 var(--ink); }

@media (max-width: 1100px) {
  .bag-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
  .bag-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 860px) {
  .bag-head { flex-direction: column; align-items: flex-start; }
  .bag-wallet { width: 100%; justify-content: space-between; }
  .bag-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 620px) {
  .bag-main { padding: 24px 14px 60px; }
  .bag-title h1 { font-size: 26px; }
  .bag-title-badge { width: 52px; height: 52px; font-size: 25px; }
  .bag-grid { grid-template-columns: 1fr; }
  .bag-stats { grid-template-columns: 1fr; }
  .act-actions { grid-template-columns: 1fr; }
}
</style>
