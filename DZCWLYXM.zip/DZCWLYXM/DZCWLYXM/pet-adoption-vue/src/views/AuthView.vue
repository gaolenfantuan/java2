<script setup>
// ============================================================
// 准入页（登录 / 注册 / 找回密码）
// 同一套居中卡片骨架，模式由路由 meta.authMode 决定，
// 表单完全复用 src/components/ui 下的公共输入框与按钮。
// ============================================================
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import BaseButton from '../components/ui/BaseButton.vue'
import BaseInput from '../components/ui/BaseInput.vue'
import BaseCheckbox from '../components/ui/BaseCheckbox.vue'
import BaseAlert from '../components/ui/BaseAlert.vue'
import BaseModal from '../components/ui/BaseModal.vue'
import { login as loginApi, register as registerApi } from '../api'

const route = useRoute()
const router = useRouter()

const REMEMBER_KEY = 'petRemember'
const DEMO_CODE = '123456'

const mode = ref('login')
const loading = ref(false)
const formError = ref('')

const form = reactive({
  account: '',
  nickname: '',
  phone: '',
  code: '',
  password: '',
  confirm: '',
  remember: false,
  agree: false
})

const errors = reactive({ account: '', nickname: '', phone: '', code: '', password: '', confirm: '', agree: '' })
const shaking = reactive({ account: false, nickname: false, phone: false, code: false, password: false, confirm: false, agree: false })

const successOpen = ref(false)
// info（纯提示）/ login / register / reset，决定关闭弹窗后的去向
const successKind = ref('info')
const successTitle = ref('登录成功啦！')
const successText = ref('')
const pendingRedirect = ref('')

// 验证码倒计时
const countdown = ref(0)
const codeSent = ref(false)
let countdownTimer = null

const isRegister = computed(() => mode.value === 'register')
const isForgot = computed(() => mode.value === 'forgot')

const headTitle = computed(() => {
  if (mode.value === 'register') return '加入毛茸茸大家庭！'
  if (mode.value === 'forgot') return '找回你的小窝钥匙'
  return '欢迎回来！'
})
const headSub = computed(() => {
  if (mode.value === 'register') return '填好资料，开启你的领养之旅 ~'
  if (mode.value === 'forgot') return '验证手机号，重新设置一个安全的密码 ~'
  return '登录账号，继续你的领养之旅 ~'
})

/* ---------- 模式同步 ---------- */
function syncMode() {
  const m = route.meta.authMode
  if (m === 'login' || m === 'register' || m === 'forgot') mode.value = m
  clearErrors()
  formError.value = ''
  form.password = ''
  form.confirm = ''
  form.code = ''
  form.agree = false
}

watch(() => route.fullPath, syncMode)

onMounted(() => {
  syncMode()
  restoreRemember()
})

/* ---------- 记住密码 ---------- */
function restoreRemember() {
  try {
    const raw = localStorage.getItem(REMEMBER_KEY)
    if (!raw) return
    const saved = JSON.parse(raw)
    if (!saved || !saved.account) return
    form.account = saved.account
    form.password = decodePwd(saved.password || '')
    form.remember = true
  } catch {
    /* 忽略脏数据 */
  }
}

// 本地记住密码做了轻量编码，避免明文直接躺在 localStorage 里
function encodePwd(pwd) {
  try {
    return btoa(encodeURIComponent(pwd).split('').reverse().join(''))
  } catch {
    return ''
  }
}
function decodePwd(raw) {
  try {
    return decodeURIComponent(atob(raw).split('').reverse().join(''))
  } catch {
    return ''
  }
}

function persistRemember(account, password) {
  try {
    if (form.remember) {
      localStorage.setItem(REMEMBER_KEY, JSON.stringify({ account, password: encodePwd(password) }))
    } else {
      localStorage.removeItem(REMEMBER_KEY)
    }
  } catch {
    /* 隐私模式下忽略 */
  }
}

/* ---------- 校验 ---------- */
function clearErrors() {
  Object.keys(errors).forEach(k => { errors[k] = '' })
  Object.keys(shaking).forEach(k => { shaking[k] = false })
}

function shakeField(key) {
  shaking[key] = false
  requestAnimationFrame(() => {
    shaking[key] = true
    setTimeout(() => { shaking[key] = false }, 420)
  })
}

function setError(key, msg) {
  errors[key] = msg
  shakeField(key)
  return false
}

function validateLogin() {
  let ok = true
  if (!form.account.trim()) ok = setError('account', '请先填写你的手机号或昵称哦～')
  else if (form.account.trim().length < 2) ok = setError('account', '账号至少 2 个字符～')
  if (!form.password) ok = setError('password', '密码不能为空哦～')
  else if (form.password.length < 6) ok = setError('password', '密码至少 6 位，别让毛孩子久等～')
  return ok
}

function validateRegister() {
  let ok = true
  if (form.nickname.trim().length < 2 || form.nickname.trim().length > 12) {
    ok = setError('nickname', '昵称需要 2-12 个字哦～')
  }
  if (!/^1[3-9]\d{9}$/.test(form.phone.trim())) ok = setError('phone', '请输入正确的 11 位手机号～')
  if (form.password.length < 6) ok = setError('password', '密码至少 6 位哦～')
  if (!form.confirm) ok = setError('confirm', '再输入一次密码确认一下～')
  else if (form.confirm !== form.password) ok = setError('confirm', '两次输入的密码不一致～')
  if (!form.agree) ok = setError('agree', '要先同意协议才能领养毛孩子哦～')
  return ok
}

function validateForgot() {
  let ok = true
  if (!/^1[3-9]\d{9}$/.test(form.phone.trim())) ok = setError('phone', '请输入正确的 11 位手机号～')
  if (!/^\d{6}$/.test(form.code.trim())) ok = setError('code', '验证码是 6 位数字哦～')
  else if (form.code.trim() !== DEMO_CODE) ok = setError('code', '验证码不对，演示环境请填 123456')
  if (form.password.length < 6) ok = setError('password', '新密码至少 6 位哦～')
  if (!form.confirm) ok = setError('confirm', '再输入一次新密码～')
  else if (form.confirm !== form.password) ok = setError('confirm', '两次输入的密码不一致～')
  return ok
}

/* ---------- 提交 ---------- */
function cleanRedirect() {
  const target = String(route.query.redirect || '')
  if (!target || target.startsWith('/login') || target.startsWith('/register') || target.startsWith('/forgot')) return '/'
  return target.startsWith('/') ? target : '/'
}

async function submitLogin() {
  formError.value = ''
  clearErrors()
  if (!validateLogin()) return

  loading.value = true
  try {
    const res = await loginApi({ username: form.account.trim(), password: form.password })
    if (res.code === 200) {
      localStorage.setItem('petToken', res.data.token)
      if (res.data.nickname) localStorage.setItem('petNickname', res.data.nickname)
      persistRemember(form.account.trim(), form.password)
      pendingRedirect.value = cleanRedirect()
      successKind.value = 'login'
      successTitle.value = '登录成功啦！'
      successText.value = `欢迎回来，${res.data.nickname || '铲屎官'}！毛孩子们正等着你呢～`
      successOpen.value = true
      setTimeout(() => {
        if (successOpen.value) router.replace(pendingRedirect.value)
      }, 1100)
    } else {
      formError.value = res.message || '账号或密码不对哦～'
    }
  } catch (e) {
    formError.value = '后端服务没启动，或数据库还没连上。请先启动 Spring Boot（8080）后再试～'
  } finally {
    loading.value = false
  }
}

async function submitRegister() {
  formError.value = ''
  clearErrors()
  if (!validateRegister()) return

  loading.value = true
  try {
    // 后端用 username 字段存手机号，昵称单独存 nickname
    const res = await registerApi({
      username: form.phone.trim(),
      nickname: form.nickname.trim(),
      password: form.password
    })
    if (res.code === 200) {
      successKind.value = 'register'
      successTitle.value = '注册成功啦！'
      successText.value = `欢迎加入，${form.nickname.trim()}！已经帮你把手机号填好，直接登录就行～`
      successOpen.value = true
      form.account = form.phone.trim()
      form.remember = true
    } else {
      formError.value = res.message || '注册失败，请稍后再试～'
    }
  } catch (e) {
    formError.value = '后端服务没启动，或数据库还没连上。请先启动 Spring Boot（8080）后再试～'
  } finally {
    loading.value = false
  }
}

async function submitForgot() {
  formError.value = ''
  clearErrors()
  if (!validateForgot()) return

  loading.value = true
  // 演示环境没有短信通道：本地校验通过即视为重置成功
  await new Promise(resolve => setTimeout(resolve, 700))
  loading.value = false

  successKind.value = 'reset'
  form.account = form.phone.trim()
  successTitle.value = '密码重置成功！'
  successText.value = '新密码已经生效，快用新密码登录，别让毛孩子等太久～'
  successOpen.value = true
}

function onSuccessClose() {
  successOpen.value = false
  if (successKind.value === 'login') {
    router.replace(pendingRedirect.value || '/')
    return
  }
  if (successKind.value === 'register') {
    form.phone = ''
    form.nickname = ''
    form.agree = false
    router.replace('/login')
    return
  }
  if (successKind.value === 'reset') router.replace('/login')
  // info：仅关闭提示，不跳转
}

function submit() {
  if (loading.value) return
  if (mode.value === 'register') submitRegister()
  else if (mode.value === 'forgot') submitForgot()
  else submitLogin()
}

/* ---------- 验证码 ---------- */
function sendCode() {
  if (countdown.value > 0) return
  if (!/^1[3-9]\d{9}$/.test(form.phone.trim())) {
    setError('phone', '先填对手机号，才能收到验证码哦～')
    return
  }
  clearErrors()
  codeSent.value = true
  countdown.value = 60
  countdownTimer = setInterval(() => {
    countdown.value -= 1
    if (countdown.value <= 0) {
      clearInterval(countdownTimer)
      countdownTimer = null
    }
  }, 1000)
}

onBeforeUnmount(() => {
  if (countdownTimer) clearInterval(countdownTimer)
})

function socialLogin(way) {
  successKind.value = 'info'
  successTitle.value = '演示提示'
  successText.value = `正在唤起 ${way} 授权，演示页面不会真的跳转哦～`
  successOpen.value = true
}

function goHome() {
  if (localStorage.getItem('petToken')) router.push('/')
}
</script>

<template>
  <div class="auth-page app-bg">
    <!-- 萌系背景装饰 -->
    <div class="auth-deco" aria-hidden="true">
      <span class="ad-blob mint"></span>
      <span class="ad-blob yellow"></span>
      <span class="ad-paw a">🐾</span>
      <span class="ad-paw b">🐾</span>
      <span class="ad-heart">💛</span>
      <span class="ad-bone">🦴</span>
      <span class="ad-star s1">✨</span>
      <span class="ad-star s2">✨</span>
    </div>

    <div class="auth-wrap">
      <!-- 站点标识 -->
      <button type="button" class="auth-brand" @click="goHome">
        <span class="ab-logo" aria-hidden="true">🐾</span>
        <span class="ab-text">
          <strong>毛茸茸领养站</strong>
          <small>每一个它，都在等一个你</small>
        </span>
      </button>

      <div class="auth-card-wrap">
        <span class="auth-card-back" aria-hidden="true"></span>
        <section class="auth-card">
          <span class="auth-sticker">🎁 新朋友见面礼 · 268 游戏币</span>

        <header class="auth-head">
          <span class="auth-mascot" aria-hidden="true">{{ isForgot ? '🔑' : (isRegister ? '🐶' : '🐱') }}</span>
          <div>
            <h1>{{ headTitle }}</h1>
            <p>{{ headSub }}</p>
          </div>
        </header>

        <!-- 登录 / 注册切换 -->
        <div v-if="!isForgot" class="auth-tabs" role="tablist" aria-label="登录或注册">
          <BaseButton
            variant="ghost"
            class="auth-tab"
            :class="{ 'is-active': mode === 'login' }"
            role="tab"
            :aria-selected="mode === 'login'"
            @click="router.replace('/login')"
          >🐾 登录</BaseButton>
          <BaseButton
            variant="ghost"
            class="auth-tab"
            :class="{ 'is-active': mode === 'register' }"
            role="tab"
            :aria-selected="mode === 'register'"
            @click="router.replace('/register')"
          >✨ 注册</BaseButton>
        </div>

        <div v-else class="auth-back">
          <BaseButton variant="ghost" size="sm" @click="router.replace('/login')">← 返回登录</BaseButton>
          <span>忘记密码 · 手机号验证</span>
        </div>

        <BaseAlert v-if="formError" type="error" class="auth-alert">{{ formError }}</BaseAlert>

        <Transition name="auth-swap" mode="out-in">
          <!-- ================= 登录 ================= -->
          <form v-if="mode === 'login'" key="login" class="auth-form" novalidate @submit.prevent="submit">
            <BaseInput
              v-model="form.account"
              label="昵称 / 手机号"
              icon="🐱"
              placeholder="铲屎官，报上名来！"
              autocomplete="username"
              :error="errors.account"
              :shake="shaking.account"
              @enter="submit"
            />

            <BaseInput
              v-model="form.password"
              label="密码"
              type="password"
              icon="🔒"
              placeholder="输入 6 位以上密码"
              autocomplete="current-password"
              :error="errors.password"
              :shake="shaking.password"
              @enter="submit"
            />

            <div class="auth-row">
              <BaseCheckbox v-model="form.remember" label="记住密码" />
              <RouterLink to="/forgot" class="ui-link">忘记密码？</RouterLink>
            </div>

            <BaseButton type="submit" size="lg" block :loading="loading" class="auth-submit">
              {{ loading ? '正在登录…' : '登录领养站 →' }}
            </BaseButton>

            <p class="auth-switch">
              还没有账号？
              <RouterLink to="/register" class="ui-link">免费注册 →</RouterLink>
            </p>

            <div class="ui-divider">或者用以下方式快速登录</div>
            <div class="auth-social">
              <BaseButton variant="ghost" block size="sm" @click="socialLogin('微信')">💬 微信登录</BaseButton>
              <BaseButton variant="ghost" block size="sm" @click="socialLogin('QQ')">🐧 QQ 登录</BaseButton>
            </div>
            <p class="auth-tip">登录即表示同意《领养协议》与《隐私政策》🐾</p>
          </form>

          <!-- ================= 注册 ================= -->
          <form v-else-if="mode === 'register'" key="register" class="auth-form" novalidate @submit.prevent="submit">
            <BaseInput
              v-model="form.nickname"
              label="昵称"
              icon="🐶"
              placeholder="起个可爱的名字（2-12 字）"
              hint="会显示在领养申请里"
              autocomplete="nickname"
              :error="errors.nickname"
              :shake="shaking.nickname"
              @enter="submit"
            />

            <BaseInput
              v-model="form.phone"
              label="手机号"
              icon="📱"
              type="tel"
              inputmode="numeric"
              :maxlength="11"
              placeholder="输入 11 位手机号"
              autocomplete="tel"
              :error="errors.phone"
              :shake="shaking.phone"
              @enter="submit"
            />

            <div class="auth-grid-2">
              <BaseInput
                v-model="form.password"
                label="密码"
                type="password"
                icon="🔒"
                placeholder="至少 6 位"
                autocomplete="new-password"
                :error="errors.password"
                :shake="shaking.password"
                @enter="submit"
              />
              <BaseInput
                v-model="form.confirm"
                label="确认密码"
                type="password"
                icon="🔑"
                placeholder="再输一次"
                autocomplete="new-password"
                :error="errors.confirm"
                :shake="shaking.confirm"
                @enter="submit"
              />
            </div>

            <div class="auth-agree" :class="{ 'ui-shake': shaking.agree }">
              <BaseCheckbox v-model="form.agree" :error="!!errors.agree">
                我已阅读并同意
                <a class="ui-link" href="#" @click.prevent>《领养协议》</a>
                与
                <a class="ui-link" href="#" @click.prevent>《隐私政策》</a>
              </BaseCheckbox>
              <p v-if="errors.agree" class="ui-field__err">⚠ {{ errors.agree }}</p>
            </div>

            <BaseButton type="submit" size="lg" block :loading="loading" class="auth-submit">
              {{ loading ? '正在创建…' : '创建账号 →' }}
            </BaseButton>

            <p class="auth-switch">
              已有账号？
              <RouterLink to="/login" class="ui-link">立即登录 →</RouterLink>
            </p>
            <p class="auth-tip">信息会保存到后端数据库，请勿使用常用密码 🐾</p>
          </form>

          <!-- ================= 找回密码 ================= -->
          <form v-else key="forgot" class="auth-form" novalidate @submit.prevent="submit">
            <BaseInput
              v-model="form.phone"
              label="注册手机号"
              icon="📱"
              type="tel"
              inputmode="numeric"
              :maxlength="11"
              placeholder="输入注册时用的手机号"
              autocomplete="tel"
              :error="errors.phone"
              :shake="shaking.phone"
              @enter="submit"
            />

            <div class="auth-code-row">
              <BaseInput
                v-model="form.code"
                label="短信验证码"
                icon="✉️"
                inputmode="numeric"
                :maxlength="6"
                placeholder="6 位数字"
                :error="errors.code"
                :shake="shaking.code"
                @enter="submit"
              />
              <BaseButton
                variant="mint"
                class="auth-code-btn"
                :disabled="countdown > 0"
                @click="sendCode"
              >{{ countdown > 0 ? `${countdown}s 后重发` : (codeSent ? '重新发送' : '获取验证码') }}</BaseButton>
            </div>
            <p v-if="codeSent" class="auth-code-tip">
              ✅ 验证码已发送（演示环境固定为 <strong>{{ DEMO_CODE }}</strong>）
            </p>

            <div class="auth-grid-2">
              <BaseInput
                v-model="form.password"
                label="新密码"
                type="password"
                icon="🔒"
                placeholder="至少 6 位"
                autocomplete="new-password"
                :error="errors.password"
                :shake="shaking.password"
                @enter="submit"
              />
              <BaseInput
                v-model="form.confirm"
                label="确认新密码"
                type="password"
                icon="🔑"
                placeholder="再输一次"
                autocomplete="new-password"
                :error="errors.confirm"
                :shake="shaking.confirm"
                @enter="submit"
              />
            </div>

            <BaseButton type="submit" size="lg" block :loading="loading" class="auth-submit">
              {{ loading ? '正在重置…' : '重置密码 →' }}
            </BaseButton>

            <p class="auth-switch">
              想起来了？
              <RouterLink to="/login" class="ui-link">返回登录 →</RouterLink>
            </p>
            <p class="auth-tip">收不到验证码？演示环境直接填 123456 即可 🐾</p>
          </form>
        </Transition>
        </section>
      </div>

      <p class="auth-foot">© 2026 毛茸茸领养站 · 用爱发电，陪你回家 🐾</p>
    </div>

    <!-- 统一结果弹窗 -->
    <BaseModal
      v-model="successOpen"
      :title="successTitle"
      icon="🎉"
      :closable="false"
      :width="380"
      @close="onSuccessClose"
    >
      <p class="auth-modal-text">{{ successText }}</p>
      <template #footer>
        <BaseButton block @click="onSuccessClose">好耶，出发！</BaseButton>
      </template>
    </BaseModal>
  </div>
</template>

<style scoped>
/* ===== 页面骨架：居中卡片 ===== */
.auth-page {
  position: relative;
  z-index: var(--z-content);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: 44px 20px 34px;
}

.auth-wrap {
  position: relative;
  z-index: 1;
  width: 100%;
  max-width: 462px;
  display: grid;
  justify-items: center;
  gap: 16px;
}

/* ===== 站点标识 ===== */
.auth-brand {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 6px 14px 6px 6px;
  font: inherit;
  color: var(--ink);
  background: var(--paper);
  border: var(--line);
  border-radius: var(--r-pill);
  box-shadow: var(--shadow-1);
  cursor: pointer;
}
.auth-brand:hover { transform: translateY(-2px) rotate(-1deg); box-shadow: 3px 5px 0 var(--ink); }

.ab-logo {
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  font-size: 20px;
  background: var(--pink);
  border: var(--line);
  border-radius: 50%;
}

.ab-text { display: grid; text-align: left; line-height: 1.25; }
.ab-text strong { font-size: 15px; font-weight: 900; letter-spacing: 0.4px; }
.ab-text small { font-size: 9.5px; font-weight: 700; color: var(--text-3); }

/* ===== 卡片 ===== */
.auth-card-wrap {
  position: relative;
  width: 100%;
}

/* 卡片背后错位的彩色纸层：独立元素，避免负 z-index 盖住卡面 */
.auth-card-back {
  position: absolute;
  inset: 12px -12px -12px 12px;
  background: var(--mint-soft);
  border: var(--line);
  border-radius: var(--r-lg);
  transform: rotate(1.2deg);
}

.auth-card {
  position: relative;
  z-index: 1;
  width: 100%;
  padding: 26px 28px 24px;
  background: var(--paper);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-4);
}

.auth-sticker {
  position: absolute;
  right: 16px;
  top: -14px;
  padding: 4px 10px;
  font-size: 10px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-xs);
  box-shadow: 2px 2px 0 var(--ink);
  transform: rotate(3deg);
}

/* ===== 头部 ===== */
.auth-head {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 18px;
  padding-right: 24px;
}

.auth-mascot {
  flex: 0 0 auto;
  width: 50px;
  height: 50px;
  display: grid;
  place-items: center;
  font-size: 25px;
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-md);
  box-shadow: var(--shadow-1);
  transform: rotate(-4deg);
  animation: auth-mascot 3.6s ease-in-out infinite;
}

@keyframes auth-mascot {
  0%, 100% { transform: rotate(-4deg) translateY(0); }
  50% { transform: rotate(2deg) translateY(-4px); }
}

.auth-head h1 {
  margin: 0 0 3px;
  font-size: 23px;
  font-weight: 900;
  line-height: 1.25;
  letter-spacing: 0.4px;
}

.auth-head p {
  margin: 0;
  font-size: var(--fs-xs);
  font-weight: 700;
  color: var(--text-2);
}

/* ===== 登录 / 注册切换 ===== */
.auth-tabs {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  margin-bottom: 16px;
}

.auth-tabs :deep(.auth-tab) {
  justify-content: center;
  padding: 9px 10px;
  color: var(--text-2);
  background: #fff;
  box-shadow: 2px 2px 0 rgba(43, 43, 43, 0.16);
  transition: transform var(--t-base) var(--ease-pop), box-shadow var(--t-base) ease, background-color var(--t-base) ease;
}
.auth-tabs :deep(.auth-tab:hover) {
  transform: translateY(-2px);
  box-shadow: 2px 4px 0 rgba(43, 43, 43, 0.24);
}
.auth-tabs :deep(.auth-tab.is-active) {
  color: var(--ink);
  background: var(--yellow);
  box-shadow: 2px 2px 0 var(--ink);
}

.auth-back {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 14px;
}
.auth-back span { font-size: var(--fs-micro); font-weight: 900; color: var(--text-3); }

/* ===== 表单 ===== */
.auth-alert { margin-bottom: 14px; }

.auth-form {
  display: grid;
  gap: 13px;
}

.auth-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-top: -1px;
  font-size: var(--fs-sm);
}

.auth-agree { display: grid; gap: 6px; }
.auth-agree :deep(.ui-check) { align-items: flex-start; font-size: var(--fs-xs); font-weight: 800; line-height: 1.7; }
.auth-agree :deep(.ui-check__box) { margin-top: 2px; }

.auth-grid-2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}

.auth-submit {
  margin-top: 4px;
  letter-spacing: 2px;
}

.auth-switch {
  margin: 2px 0 0;
  text-align: center;
  font-size: var(--fs-sm);
  font-weight: 800;
  color: var(--text-2);
}

.auth-social {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
}

.auth-tip {
  margin: 2px 0 0;
  text-align: center;
  font-size: var(--fs-micro);
  font-weight: 700;
  color: var(--text-3);
}

/* 验证码行：输入框 + 发送按钮底对齐 */
.auth-code-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px;
  align-items: end;
}
.auth-code-btn { box-shadow: 2px 2px 0 var(--ink); padding: 11px 13px; font-size: var(--fs-sm); }
.auth-code-tip { margin: -4px 0 0; font-size: var(--fs-micro); font-weight: 800; color: var(--ok); }

.auth-foot {
  margin: 2px 0 0;
  font-size: var(--fs-micro);
  font-weight: 700;
  color: var(--text-3);
}

.auth-modal-text {
  margin: 0;
  font-size: var(--fs-body);
  font-weight: 700;
  line-height: 1.8;
  color: var(--text-2);
}

/* 表单切换过渡 */
.auth-swap-enter-active { transition: opacity 0.22s var(--ease-soft), transform 0.26s var(--ease-pop); }
.auth-swap-leave-active { transition: opacity 0.12s var(--ease-soft); }
.auth-swap-enter-from { opacity: 0; transform: translateX(12px); }
.auth-swap-leave-to { opacity: 0; transform: translateX(-8px); }

/* ===== 背景装饰 ===== */
.auth-deco { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }

.ad-blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(6px);
  opacity: 0.5;
}
.ad-blob.mint { width: 280px; height: 280px; top: -90px; right: -70px; background: var(--mint-soft); }
.ad-blob.yellow { width: 240px; height: 240px; bottom: -80px; left: -70px; background: var(--yellow-soft); }

.ad-paw,
.ad-heart,
.ad-bone,
.ad-star {
  position: absolute;
  font-size: 24px;
  opacity: 0.5;
  animation: bob 4.2s ease-in-out infinite;
}
.ad-paw.a { top: 14%; left: 8%; transform: rotate(-20deg); }
.ad-paw.b { bottom: 18%; right: 9%; font-size: 20px; animation-delay: 1.2s; transform: rotate(14deg); }
.ad-heart { top: 26%; right: 12%; font-size: 20px; animation-delay: 0.6s; }
.ad-bone { bottom: 22%; left: 12%; font-size: 21px; animation-delay: 1.8s; }
.ad-star.s1 { top: 8%; left: 26%; font-size: 16px; }
.ad-star.s2 { bottom: 8%; right: 26%; font-size: 16px; animation-delay: 2.2s; }

/* ===== 窄屏 ===== */
@media (max-width: 620px) {
  .auth-page { padding: 30px 14px 26px; justify-content: flex-start; }
  .auth-wrap { max-width: 100%; }
  .auth-card { padding: 24px 18px 20px; box-shadow: var(--shadow-3); }
  .auth-card-back { inset: 8px -8px -8px 8px; }
  .auth-head h1 { font-size: 20px; }
  .auth-head { padding-right: 16px; }
  .auth-sticker { right: 10px; font-size: 9px; }
  .auth-grid-2 { grid-template-columns: 1fr; }
}

@media (max-width: 420px) {
  .auth-social { grid-template-columns: 1fr; }
  .auth-code-row { grid-template-columns: 1fr; }
  .auth-code-btn { justify-content: center; }
  .ad-paw.a, .ad-bone { display: none; }
}
</style>
