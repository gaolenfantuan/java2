<script setup>
// ============================================================
// 后台管理登录页
// 调用真实后端 POST /api/admin/auth/login（账号 admin / admin888）
// 登录成功后把 token 写入 localStorage，再跳转后台管理系统。
// ============================================================
import { onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { adminLogin, getAdminToken, setAdminSession } from '../api/admin'

const router = useRouter()
const route = useRoute()

const form = reactive({ username: '', password: '' })
const loading = ref(false)
const errorMsg = ref('')
const showPassword = ref(false)

function fillDemo() {
  form.username = 'admin'
  form.password = 'admin888'
  errorMsg.value = ''
}

function goBack() {
  router.push('/')
}

onMounted(() => {
  // 已登录的用户直接进后台，避免重复登录
  if (getAdminToken()) router.replace('/admin')
})

async function submit() {
  errorMsg.value = ''
  if (!form.username.trim() || !form.password) {
    errorMsg.value = '请输入管理员账号和密码'
    return
  }
  loading.value = true
  try {
    const session = await adminLogin({
      username: form.username.trim(),
      password: form.password
    })
    setAdminSession(session)
    router.replace(typeof route.query.redirect === 'string' ? route.query.redirect : '/admin')
  } catch (error) {
    errorMsg.value = error.message || '登录失败，请稍后再试'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <main class="admin-login">
    <div class="login-deco deco-a" aria-hidden="true">🐾</div>
    <div class="login-deco deco-b" aria-hidden="true">🎀</div>
    <div class="login-deco deco-c" aria-hidden="true">🐱</div>

    <div class="login-shell">
      <!-- 左侧品牌介绍 -->
      <section class="login-brand">
        <div class="brand-badge" aria-hidden="true">🐾</div>
        <p class="brand-eyebrow">PET ADOPTION · CONSOLE</p>
        <h1>毛茸茸领养站<br><span>管理后台</span></h1>
        <p class="brand-desc">管理首页展示的毛孩子、分类与站点内容。<br>每一次改动，都会让首页变得更好一点。</p>
        <div class="brand-points">
          <span>✨ 首页卡片实时更新</span>
          <span>🔐 管理员身份验证</span>
          <span>🎀 可爱的马卡龙控制台</span>
        </div>
        <button type="button" class="brand-back" @click="goBack">← 返回领养站首页</button>
      </section>

      <!-- 右侧登录表单 -->
      <section class="login-card">
        <div class="card-head">
          <span class="head-icon" aria-hidden="true">🔑</span>
          <h2>管理员登录</h2>
          <p>请输入后台账号，欢迎回来～</p>
        </div>

        <form class="login-form" @submit.prevent="submit">
          <label class="field">
            <span class="field-label">管理员账号</span>
            <span class="input-wrap">
              <span aria-hidden="true">👤</span>
              <input
                v-model="form.username"
                type="text"
                autocomplete="username"
                placeholder="请输入账号"
                :disabled="loading"
                @input="errorMsg = ''"
              >
            </span>
          </label>

          <label class="field">
            <span class="field-label">密码</span>
            <span class="input-wrap">
              <span aria-hidden="true">🔒</span>
              <input
                v-model="form.password"
                :type="showPassword ? 'text' : 'password'"
                autocomplete="current-password"
                placeholder="请输入密码"
                :disabled="loading"
                @input="errorMsg = ''"
                @keyup.enter="submit"
              >
              <button type="button" class="eye-btn" :aria-label="showPassword ? '隐藏密码' : '显示密码'" @click="showPassword = !showPassword">
                {{ showPassword ? '🙈' : '👀' }}
              </button>
            </span>
          </label>

          <p v-if="errorMsg" class="form-error" role="alert">⚠️ {{ errorMsg }}</p>

          <button type="submit" class="submit-btn" :disabled="loading">
            {{ loading ? '正在登录…' : '进入管理系统 →' }}
          </button>
        </form>

        <div class="demo-tip">
          <span>演示账号：<strong>admin</strong> / <strong>admin888</strong></span>
          <button type="button" @click="fillDemo">一键填入</button>
        </div>
      </section>
    </div>
  </main>
</template>

<style scoped>
.admin-login {
  position: relative;
  min-height: 100vh;
  display: grid;
  place-items: center;
  padding: 32px 18px;
  overflow: hidden;
  background:
    radial-gradient(circle at 12% 18%, #ffe6f1 0, transparent 34%),
    radial-gradient(circle at 88% 82%, #d9f5ea 0, transparent 32%),
    var(--cream);
}
.login-deco {
  position: absolute;
  font-size: 46px;
  opacity: 0.5;
  pointer-events: none;
  animation: floaty 4s ease-in-out infinite;
}
.deco-a { top: 8%; left: 7%; transform: rotate(-14deg); }
.deco-b { bottom: 10%; left: 12%; animation-delay: 0.7s; }
.deco-c { top: 12%; right: 8%; animation-delay: 1.4s; }
@keyframes floaty {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -12px; }
}

.login-shell {
  position: relative;
  z-index: 1;
  width: min(940px, 100%);
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0;
  background: var(--paper);
  border: var(--line);
  border-radius: var(--r-xl);
  box-shadow: var(--shadow-4);
  overflow: hidden;
}

.login-brand {
  padding: 48px 40px;
  color: var(--ink);
  background: linear-gradient(155deg, #ffe3ef 0%, #fff3cf 60%, #d9f5ea 100%);
  border-right: var(--line);
}
.brand-badge {
  width: 58px;
  height: 58px;
  display: grid;
  place-items: center;
  margin-bottom: 26px;
  font-size: 30px;
  background: var(--yellow);
  border: var(--line);
  border-radius: 18px;
  box-shadow: var(--shadow-2);
  transform: rotate(-8deg);
}
.brand-eyebrow {
  margin: 0 0 8px;
  font-size: 11px;
  font-weight: 900;
  letter-spacing: 2px;
  color: var(--text-3);
}
.login-brand h1 {
  margin: 0 0 16px;
  font-size: 34px;
  line-height: 1.35;
  font-weight: 900;
}
.login-brand h1 span {
  display: inline-block;
  padding: 0 8px;
  background: var(--paper);
  border: var(--line);
  border-radius: 10px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-2deg);
}
.brand-desc {
  margin: 0 0 24px;
  font-size: 13px;
  font-weight: 700;
  line-height: 1.9;
  color: var(--text-2);
}
.brand-points { display: grid; gap: 8px; margin-bottom: 32px; }
.brand-points span {
  width: fit-content;
  padding: 5px 11px;
  font-size: 11px;
  font-weight: 900;
  background: rgba(255, 255, 255, 0.72);
  border: 1.5px solid var(--ink);
  border-radius: var(--r-pill);
}
.brand-back {
  padding: 8px 14px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: var(--paper);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
  cursor: pointer;
}
.brand-back:hover { background: var(--yellow); transform: translateY(-2px); }

.login-card { padding: 52px 42px; }
.card-head { text-align: center; margin-bottom: 28px; }
.head-icon { font-size: 34px; }
.card-head h2 { margin: 6px 0 6px; font-size: 26px; font-weight: 900; }
.card-head p { margin: 0; font-size: 12px; font-weight: 700; color: var(--text-3); }

.login-form { display: grid; gap: 18px; }
.field { display: grid; gap: 7px; }
.field-label { font-size: 12px; font-weight: 900; }
.input-wrap {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 10px 12px;
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
  transition: background 0.15s;
}
.input-wrap:focus-within { background: #fff9df; }
.input-wrap input {
  flex: 1;
  min-width: 0;
  font: inherit;
  font-size: 13px;
  font-weight: 700;
  color: var(--ink);
  background: transparent;
  border: none;
  outline: none;
}
.eye-btn {
  padding: 0 3px;
  font-size: 15px;
  background: transparent;
  border: none;
  cursor: pointer;
}
.form-error {
  margin: -4px 0 0;
  padding: 8px 10px;
  font-size: 11px;
  font-weight: 900;
  color: #a3273d;
  background: var(--danger-soft);
  border: 1.5px solid #e598a9;
  border-radius: 9px;
}
.submit-btn {
  margin-top: 4px;
  padding: 13px 16px;
  font: inherit;
  font-size: 15px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-2);
  cursor: pointer;
  transition: transform 0.15s, box-shadow 0.15s;
}
.submit-btn:hover:not(:disabled) { transform: translateY(-3px); box-shadow: var(--shadow-3); }
.submit-btn:disabled { opacity: 0.6; cursor: not-allowed; }
.demo-tip {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-top: 22px;
  padding: 10px 12px;
  font-size: 11px;
  font-weight: 700;
  color: var(--text-3);
  background: #fffdf6;
  border: 2px dashed rgba(43, 43, 43, 0.25);
  border-radius: var(--r-sm);
}
.demo-tip strong { color: var(--ink); }
.demo-tip button {
  flex: 0 0 auto;
  padding: 5px 9px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--mint-soft);
  border: 1.5px solid var(--ink);
  border-radius: 8px;
  cursor: pointer;
}

@media (max-width: 760px) {
  .login-shell { grid-template-columns: 1fr; }
  .login-brand { border-right: none; border-bottom: var(--line); padding: 32px 26px; }
  .login-brand h1 { font-size: 27px; }
  .login-card { padding: 32px 26px; }
}
</style>
