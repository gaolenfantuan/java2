<script setup>
import { onBeforeUnmount, onMounted, ref } from 'vue'
import '../page.css'

const steps = [
  { icon: '🔍', title: '浏览挑选', desc: '在领养专区找到心仪的毛孩子' },
  { icon: '📝', title: '提交申请', desc: '填写领养申请，阅读并同意须知' },
  { icon: '✅', title: '审核回访', desc: '志愿者审核资料并进行回访' },
  { icon: '🏡', title: '接它回家', desc: '完成领养，开启幸福新生活' }
]
const partners = [
  { icon: '🐾', name: '爱心救助联盟' },
  { icon: '🏥', name: '暖心宠物医院' },
  { icon: '🏫', name: '城市动物保护协会' },
  { icon: '🛒', name: '毛孩子生活馆' },
  { icon: '📷', name: ' paw 摄影工作室' },
  { icon: '🎓', name: '宠物行为学院' }
]
const contacts = [
  { icon: '📮', label: '联系邮箱', value: 'hello@furryhome.cn' },
  { icon: '📍', label: '站点地址', value: '毛茸茸市爱心路 88 号' },
  { icon: '🕒', label: '工作时间', value: '周一至周日 9:00 - 18:00' }
]
const toastText = ref('')
let toastTimer = null
function sayHi() {
  toastText.value = '💌 感谢你的关注，欢迎随时联系我们！'
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2600)
}
onMounted(() => document.body.classList.add('home-body'))
onBeforeUnmount(() => { document.body.classList.remove('home-body'); clearTimeout(toastTimer) })
</script>

<template>
  <div class="app-bg fun-page">
    <main class="fun-main">
      <!-- 站点介绍 -->
      <section class="intro fun-card">
        <div class="intro-emoji">🐾💛🐶🐱</div>
        <h1>关于毛茸茸领养站 <span>🏡</span></h1>
        <p>我们相信，每一个毛孩子都值得拥有一个温暖的家。</p>
        <p>毛茸茸领养站成立于 2026 年，是一个公益性质的宠物领养平台。我们连接流浪动物救助志愿者、爱心人士与待领养的毛孩子，通过规范的审核与回访流程，帮助更多毛孩子找到属于自己的家人。</p>
        <p class="motto">「领养代替购买，给它们一个重生的机会」</p>
      </section>

      <!-- 领养流程 -->
      <section class="flow-section">
        <h2 class="section-title">🧭 领养流程</h2>
        <div class="flow-steps">
          <template v-for="(s, i) in steps" :key="s.title">
            <div class="step fun-card">
              <span class="step-icon">{{ s.icon }}</span>
              <strong>{{ i + 1 }}. {{ s.title }}</strong>
              <small>{{ s.desc }}</small>
            </div>
            <span v-if="i < steps.length - 1" class="step-arrow">→</span>
          </template>
        </div>
      </section>

      <!-- 联系方式 -->
      <section class="contact-section">
        <h2 class="section-title">📇 联系方式</h2>
        <div class="contact-grid">
          <div v-for="c in contacts" :key="c.label" class="contact-card fun-card">
            <span>{{ c.icon }}</span>
            <div><strong>{{ c.label }}</strong><p>{{ c.value }}</p></div>
          </div>
        </div>
      </section>

      <!-- 合作伙伴 -->
      <section class="partner-section">
        <h2 class="section-title">🤝 合作伙伴</h2>
        <div class="partner-wall">
          <div v-for="p in partners" :key="p.name" class="partner-card fun-card fun-card-hover">
            <span>{{ p.icon }}</span><small>{{ p.name }}</small>
          </div>
        </div>
      </section>

      <div class="footer-note" @click="sayHi">💛 因为有你，世界更温暖 · 点击打个招呼</div>
    </main>
    <div class="fun-toast" :class="{ show: !!toastText }">{{ toastText }}</div>
  </div>
</template>

<style scoped>
.intro { padding: 32px; text-align: center; background: #fff2c9; margin-bottom: 32px; }
.intro-emoji { font-size: 40px; letter-spacing: 6px; margin-bottom: 12px; }
.intro h1 { margin: 0 0 14px; font-size: 28px; }
.intro h1 span { color: var(--pink); }
.intro p { max-width: 720px; margin: 0 auto 10px; font-size: 13px; font-weight: 700; line-height: 1.9; color: var(--text-2); }
.intro .motto { margin-top: 16px; font-size: 15px; color: #d2691e; }
.section-title { font-size: 20px; margin: 0 0 16px; }
.flow-section, .contact-section, .partner-section { margin-bottom: 32px; }
.flow-steps { display: flex; align-items: stretch; gap: 8px; flex-wrap: wrap; }
.step { flex: 1 1 150px; padding: 18px 12px; text-align: center; }
.step-icon { display: block; font-size: 34px; margin-bottom: 8px; }
.step strong { display: block; font-size: 14px; margin-bottom: 6px; }
.step small { font-size: 11px; color: var(--text-2); font-weight: 700; }
.step-arrow { align-self: center; font-size: 22px; font-weight: 900; color: #d2691e; }
.contact-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.contact-card { display: flex; align-items: center; gap: 12px; padding: 18px; }
.contact-card > span { font-size: 30px; }
.contact-card strong { font-size: 13px; }
.contact-card p { margin: 4px 0 0; font-size: 12px; font-weight: 700; color: var(--text-2); }
.partner-wall { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.partner-card { display: flex; align-items: center; gap: 10px; padding: 14px 16px; }
.partner-card span { font-size: 26px; }
.partner-card small { font-size: 12px; font-weight: 900; }
.footer-note { text-align: center; margin-top: 30px; padding: 18px; font-size: 13px; font-weight: 900; color: var(--text-2); cursor: pointer; }
.footer-note:hover { color: #d2691e; }
@media (max-width: 760px) { .contact-grid, .partner-wall { grid-template-columns: 1fr; } .step-arrow { display: none; } }
</style>
