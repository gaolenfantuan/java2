<script setup>
import { onBeforeUnmount, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import BaseButton from '../components/ui/BaseButton.vue'
import BaseEmpty from '../components/ui/BaseEmpty.vue'

const router = useRouter()

// 与其它长页面一致：进入时临时切换 body 布局
onMounted(() => document.body.classList.add('home-body'))
onBeforeUnmount(() => document.body.classList.remove('home-body'))
</script>

<template>
  <main class="notfound">
    <div class="nf-card">
      <span class="nf-code" aria-hidden="true">404</span>
      <BaseEmpty
        variant="error"
        title="这条路好像走丢了 🐾"
        desc="页面可能被毛孩子叼去玩了。别担心，回首页继续认识新朋友吧～"
      >
        <BaseButton @click="router.push('/')">回到首页</BaseButton>
        <BaseButton variant="ghost" @click="router.push('/adopt')">去领养专区</BaseButton>
      </BaseEmpty>
    </div>
  </main>
</template>

<style scoped>
.notfound {
  position: relative;
  z-index: 1;
  max-width: 640px;
  margin: 0 auto;
  padding: 54px 22px 80px;
}

.nf-card {
  position: relative;
  padding: 18px 12px 8px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-3);
  overflow: hidden;
}

.nf-code {
  position: absolute;
  right: 14px;
  top: 2px;
  font-size: 68px;
  font-weight: 900;
  letter-spacing: 2px;
  color: rgba(43, 43, 43, 0.07);
  pointer-events: none;
  user-select: none;
}

@media (max-width: 620px) {
  .notfound { padding: 30px 14px 60px; }
  .nf-code { font-size: 46px; }
}
</style>
