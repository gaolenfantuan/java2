<script setup>
// ============================================================
// 后台管理系统
// 1. 概览：本地首页数据 + 后端站点数据统计
// 2. 首页宠物管理：增删改查 / 上架下架 / 排序（保存到 localStorage，首页立即生效）
// 3. 分类管理：首页筛选栏分类
// 4. 首页内容管理：轮播 / 推荐宠物 / 公告 / 活动 / 小贴士 / 弹窗 统一管理
// ============================================================
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { adminLogout, adminStats, clearAdminSession, getAdminInfo } from '../api/admin'
import {
  managedCategories, managedPets, resetHomeData,
  saveManagedCategories, saveManagedPets
} from '../data/homePets'
import ContentManager from '../components/ContentManager.vue'

const router = useRouter()
const adminInfo = getAdminInfo()
const activeTab = ref('overview')
const toast = ref('')
let toastTimer = null

function notify(message, type = 'ok') {
  toast.value = { message, type }
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toast.value = null }, 2600)
}

function handleError(error) {
  if (error?.code === 401) {
    clearAdminSession()
    notify('登录已过期，请重新登录', 'error')
    setTimeout(() => router.push('/admin/login'), 700)
    return
  }
  notify(error?.message || '操作失败，请稍后再试', 'error')
}

const tabs = [
  { key: 'overview', icon: '📊', label: '概览' },
  { key: 'pets', icon: '🐾', label: '首页宠物' },
  { key: 'categories', icon: '🏷️', label: '首页分类' },
  { key: 'content', icon: '🎀', label: '首页内容' }
]

// ---------------- 概览 ----------------
const backendStats = ref({})
const backendReady = ref(false)

async function loadStats() {
  try {
    backendStats.value = await adminStats()
    backendReady.value = true
  } catch (error) {
    handleError(error)
  }
}

const petList = ref([])
const categoryList = ref([])
const localStats = computed(() => {
  const all = petList.value
  return {
    total: all.length,
    online: all.filter(p => p.status !== 0).length,
    offline: all.filter(p => p.status === 0).length,
    hot: all.filter(p => p.hot || p.isHot === 1).length
  }
})

// ---------------- 首页宠物管理 ----------------
const petKeyword = ref('')
const petStatus = ref('all')
const filteredPets = computed(() => {
  const kw = petKeyword.value.trim().toLowerCase()
  return petList.value.filter(pet => {
    if (petStatus.value === 'online' && pet.status === 0) return false
    if (petStatus.value === 'offline' && pet.status !== 0) return false
    if (!kw) return true
    return [pet.name, pet.breed, pet.category, pet.personality]
      .some(value => String(value || '').toLowerCase().includes(kw))
  })
})

function loadPets() {
  petList.value = JSON.parse(JSON.stringify(managedPets()))
}

function persistPets(message) {
  saveManagedPets(JSON.parse(JSON.stringify(petList.value)))
  loadPets()
  if (message) notify(message)
}

const petDialogOpen = ref(false)
const editingPetId = ref(null)
const petForm = reactive({})
const petFormError = ref('')

function emptyPet() {
  return {
    name: '', breed: '', category: '猫猫', gender: '弟弟', age: '3 个月',
    personality: '', mood: '开心到冒泡', moodEmoji: '😸', image: '',
    emoji: '🐱', color: '#ffe0b8', status: 1, sort: 99, hot: false
  }
}

function openPetDialog(pet) {
  editingPetId.value = pet ? pet.id : null
  Object.assign(petForm, pet ? JSON.parse(JSON.stringify(pet)) : emptyPet())
  petFormError.value = ''
  petDialogOpen.value = true
}

function savePet() {
  if (!petForm.name.trim()) { petFormError.value = '请填写毛孩子的名字'; return }
  if (!petForm.breed.trim()) { petFormError.value = '请填写品种'; return }
  if (!String(petForm.category || '').trim()) { petFormError.value = '请选择分类'; return }
  const record = JSON.parse(JSON.stringify(petForm))
  record.name = record.name.trim()
  record.breed = record.breed.trim()
  record.category = String(record.category).trim()
  record.sort = Number(record.sort) || 0
  record.updatedAt = new Date().toLocaleString('zh-CN')

  if (editingPetId.value !== null) {
    const index = petList.value.findIndex(p => p.id === editingPetId.value)
    if (index >= 0) petList.value.splice(index, 1, { ...record, id: editingPetId.value })
    persistPets('修改已同步到首页')
  } else {
    record.id = Date.now()
    petList.value.push(record)
    persistPets('新增成功，首页已更新')
  }
  petDialogOpen.value = false
}

function deletePet(pet) {
  if (!window.confirm(`确定要从首页移除「${pet.name}」吗？`)) return
  petList.value = petList.value.filter(p => p.id !== pet.id)
  persistPets('已删除，首页同步更新')
}

function togglePetStatus(pet) {
  pet.status = pet.status === 0 ? 1 : 0
  persistPets(pet.status === 1 ? '已上架，首页可见' : '已下架，首页不再展示')
}

function movePet(pet, delta) {
  const sorted = [...petList.value].sort((a, b) => (Number(a.sort) || 0) - (Number(b.sort) || 0))
  const index = sorted.findIndex(p => p.id === pet.id)
  const target = index + delta
  if (target < 0 || target >= sorted.length) return
  ;[sorted[index], sorted[target]] = [sorted[target], sorted[index]]
  sorted.forEach((item, i) => { item.sort = i + 1 })
  petList.value = sorted
  persistPets('顺序已更新')
}

function resetPets() {
  if (!window.confirm('确定恢复为网站初始的首页数据吗？当前的自定义数据会被清空。')) return
  resetHomeData()
  loadPets()
  loadCategories()
  notify('已恢复初始数据')
}

// ---------------- 首页分类管理 ----------------
const categoryInput = ref('')
const categoryEditIndex = ref(-1)
const categoryEditValue = ref('')

function loadCategories() {
  categoryList.value = managedCategories().filter(c => c !== '全部')
}

function addCategory() {
  const name = categoryInput.value.trim()
  if (!name) { notify('请输入分类名称', 'error'); return }
  if (categoryList.value.includes(name)) { notify('这个分类已经存在啦', 'error'); return }
  categoryList.value.push(name)
  saveManagedCategories(categoryList.value)
  categoryInput.value = ''
  notify('分类已添加')
}

function startEditCategory(index) {
  categoryEditIndex.value = index
  categoryEditValue.value = categoryList.value[index]
}

function saveCategory(index) {
  const name = categoryEditValue.value.trim()
  if (!name) { notify('分类名称不能为空', 'error'); return }
  if (categoryList.value.some((c, i) => i !== index && c === name)) {
    notify('这个分类已经存在啦', 'error')
    return
  }
  const usedBy = petList.value.filter(p => p.category === categoryList.value[index])
  categoryList.value.splice(index, 1, name)
  usedBy.forEach(p => { p.category = name })
  saveManagedCategories(categoryList.value)
  saveManagedPets(petList.value)
  categoryEditIndex.value = -1
  notify('分类已更新')
}

function deleteCategory(index) {
  const name = categoryList.value[index]
  const used = petList.value.filter(p => p.category === name).length
  if (used) { notify(`还有 ${used} 只毛孩子属于「${name}」，请先修改它们的分类`, 'error'); return }
  if (!window.confirm(`确定删除分类「${name}」吗？`)) return
  categoryList.value.splice(index, 1)
  saveManagedCategories(categoryList.value)
  notify('分类已删除')
}

// ---------------- 会话 ----------------
async function logout() {
  try { await adminLogout() } catch { /* 退出时忽略接口异常 */ }
  clearAdminSession()
  router.push('/admin/login')
}

function goSite() {
  router.push('/')
}

onMounted(() => {
  loadPets()
  loadCategories()
  loadStats()
})
</script>

<template>
  <div class="admin-page">
    <!-- 左侧管理菜单 -->
    <aside class="admin-sidebar">
      <div class="side-logo">
        <span class="side-logo-icon">🐾</span>
        <span class="side-logo-text">毛茸茸<small>管理后台</small></span>
      </div>

      <nav class="side-nav" aria-label="后台菜单">
        <button
          v-for="tab in tabs"
          :key="tab.key"
          type="button"
          class="side-nav-item"
          :class="{ active: activeTab === tab.key }"
          @click="activeTab = tab.key"
        >
          <span aria-hidden="true">{{ tab.icon }}</span>{{ tab.label }}
        </button>
      </nav>

      <div class="side-bottom">
        <button type="button" class="side-link" @click="goSite">🏠 返回前台首页</button>
        <button type="button" class="side-link danger" @click="logout">🚪 退出登录</button>
      </div>
    </aside>

    <!-- 右侧内容区 -->
    <main class="admin-main">
      <header class="admin-header">
        <div>
          <p class="header-eyebrow">PET ADOPTION · CONSOLE</p>
          <h1>{{ tabs.find(t => t.key === activeTab)?.label }}</h1>
        </div>
        <div class="admin-user">
          <span class="user-avatar">🦊</span>
          <span class="user-meta">
            <strong>{{ adminInfo?.nickname || '管理员' }}</strong>
            <small>@{{ adminInfo?.username || 'admin' }}</small>
          </span>
        </div>
      </header>

      <!-- 概览 -->
      <section v-if="activeTab === 'overview'" class="panel-grid">
        <div class="stat-card pink">
          <span class="stat-icon">🐾</span>
          <span class="stat-label">首页宠物总数</span>
          <strong class="stat-value">{{ localStats.total }}</strong>
        </div>
        <div class="stat-card mint">
          <span class="stat-icon">✅</span>
          <span class="stat-label">已上架展示</span>
          <strong class="stat-value">{{ localStats.online }}</strong>
        </div>
        <div class="stat-card yellow">
          <span class="stat-icon">💤</span>
          <span class="stat-label">已下架隐藏</span>
          <strong class="stat-value">{{ localStats.offline }}</strong>
        </div>
        <div class="stat-card blue">
          <span class="stat-icon">🎀</span>
          <span class="stat-label">站点内容（后端）</span>
          <strong class="stat-value">{{ backendReady ? backendStats.itemTotal ?? 0 : '—' }}</strong>
        </div>

        <div class="overview-box">
          <h2>👋 欢迎回来，管理员</h2>
          <p>这里管理着首页展示的毛孩子和六大内容板块。改动保存后，回到首页就能立刻看到效果。</p>
          <div class="quick-actions">
            <button type="button" @click="activeTab = 'pets'">🐾 管理首页宠物</button>
            <button type="button" @click="activeTab = 'categories'">🏷️ 管理首页分类</button>
            <button type="button" @click="activeTab = 'content'">🎀 管理首页内容</button>
          </div>
          <div v-if="backendReady" class="backend-strip">
            <span>后端内容 {{ backendStats.itemTotal }} 条</span>
            <span>上架 {{ backendStats.onlineTotal }} 条</span>
            <span>分类 {{ backendStats.categoryTotal }} 个</span>
            <span>累计点赞 {{ backendStats.likeTotal }}</span>
          </div>
          <p v-else class="backend-strip warn">⚠️ 后端接口暂不可用，首页宠物管理仍可正常使用。</p>
        </div>
      </section>

      <!-- 首页宠物管理 -->
      <section v-else-if="activeTab === 'pets'" class="content-panel">
        <div class="panel-toolbar">
          <div class="toolbar-left">
            <label class="tool-search">
              <span aria-hidden="true">🔍</span>
              <input v-model="petKeyword" type="search" placeholder="搜索名字 / 品种 / 性格">
            </label>
            <select v-model="petStatus" class="tool-select" aria-label="状态筛选">
              <option value="all">全部状态</option>
              <option value="online">已上架</option>
              <option value="offline">已下架</option>
            </select>
          </div>
          <div class="toolbar-right">
            <button type="button" class="tool-btn ghost" @click="resetPets">恢复初始</button>
            <button type="button" class="tool-btn primary" @click="openPetDialog(null)">＋ 新增毛孩子</button>
          </div>
        </div>

        <p class="table-hint">共 {{ filteredPets.length }} 只毛孩子 · 改动会自动保存到浏览器并同步到首页</p>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>顺序</th>
                <th>毛孩子</th>
                <th>分类 / 品种</th>
                <th>性格</th>
                <th>状态</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(pet, index) in filteredPets" :key="pet.id">
                <td>
                  <div class="order-cell">
                    <strong>{{ index + 1 }}</strong>
                    <span class="order-btns">
                      <button type="button" title="上移" :disabled="index === 0" @click="movePet(pet, -1)">↑</button>
                      <button type="button" title="下移" :disabled="index === filteredPets.length - 1" @click="movePet(pet, 1)">↓</button>
                    </span>
                  </div>
                </td>
                <td>
                  <div class="pet-cell">
                    <span class="pet-avatar" :style="{ background: pet.color || '#ffe0b8' }">
                      <img v-if="pet.image" :src="pet.image" :alt="pet.name" @error="$event.target.style.display='none'">
                      <span v-else>{{ pet.emoji || '🐱' }}</span>
                    </span>
                    <span class="pet-cell-copy">
                      <strong>{{ pet.name }} <em v-if="pet.hot" class="hot-tag">HOT</em></strong>
                      <small>{{ pet.gender }} · {{ pet.age }}</small>
                    </span>
                  </div>
                </td>
                <td><span class="cell-chip">{{ pet.category }}</span><small class="cell-sub">{{ pet.breed }}</small></td>
                <td>{{ pet.personality || '—' }}</td>
                <td>
                  <button type="button" class="status-pill" :class="pet.status === 0 ? 'off' : 'on'" @click="togglePetStatus(pet)">
                    {{ pet.status === 0 ? '已下架' : '展示中' }}
                  </button>
                </td>
                <td>
                  <div class="row-actions">
                    <button type="button" @click="openPetDialog(pet)">编辑</button>
                    <button type="button" class="danger" @click="deletePet(pet)">删除</button>
                  </div>
                </td>
              </tr>
              <tr v-if="!filteredPets.length">
                <td colspan="6" class="empty-row">🐾 还没有毛孩子，点右上角新增一只吧</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <!-- 首页分类管理 -->
      <section v-else-if="activeTab === 'categories'" class="content-panel">
        <div class="panel-toolbar">
          <div class="toolbar-left">
            <label class="tool-search">
              <span aria-hidden="true">🏷️</span>
              <input v-model="categoryInput" placeholder="输入新分类名称，回车添加" @keyup.enter="addCategory">
            </label>
            <button type="button" class="tool-btn primary" @click="addCategory">＋ 添加分类</button>
          </div>
        </div>
        <p class="table-hint">这些分类就是首页的筛选栏。「全部」由系统自动提供，无需添加。</p>
        <div class="category-list">
          <div v-for="(category, index) in categoryList" :key="index" class="category-row">
            <span class="category-order">{{ index + 1 }}</span>
            <template v-if="categoryEditIndex === index">
              <input v-model="categoryEditValue" class="category-input" @keyup.enter="saveCategory(index)">
              <button type="button" class="tool-btn primary small" @click="saveCategory(index)">保存</button>
              <button type="button" class="tool-btn ghost small" @click="categoryEditIndex = -1">取消</button>
            </template>
            <template v-else>
              <strong>{{ category }}</strong>
              <span class="category-count">{{ petList.filter(p => p.category === category).length }} 只毛孩子</span>
              <button type="button" class="row-edit" @click="startEditCategory(index)">改名</button>
              <button type="button" class="row-edit danger" @click="deleteCategory(index)">删除</button>
            </template>
          </div>
          <p v-if="!categoryList.length" class="empty-row">还没有分类，添加一个吧 🏷️</p>
        </div>
      </section>

      <!-- 首页内容统一管理（轮播 / 推荐宠物 / 公告 / 活动 / 小贴士 / 弹窗） -->
      <ContentManager v-else />
    </main>

    <!-- 新增 / 编辑毛孩子弹窗 -->
    <div v-if="petDialogOpen" class="modal-mask" @click.self="petDialogOpen = false">
      <div class="modal-card" role="dialog" aria-modal="true" aria-label="编辑毛孩子">
        <div class="modal-head">
          <h2>{{ editingPetId === null ? '＋ 新增毛孩子' : '✏️ 编辑毛孩子' }}</h2>
          <button type="button" class="modal-close" @click="petDialogOpen = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-grid">
            <label>名字<input v-model="petForm.name" placeholder="例如：奶盖"></label>
            <label>品种<input v-model="petForm.breed" placeholder="例如：布偶猫"></label>
            <label>分类
              <select v-model="petForm.category">
                <option v-for="c in ['猫猫','狗狗','兔兔','小宠', ...categoryList.filter(x => !['猫猫','狗狗','兔兔','小宠'].includes(x))]" :key="c" :value="c">{{ c }}</option>
              </select>
            </label>
            <label>性别
              <select v-model="petForm.gender"><option>弟弟</option><option>妹妹</option></select>
            </label>
            <label>年龄<input v-model="petForm.age" placeholder="例如：3 个月"></label>
            <label>性格<input v-model="petForm.personality" placeholder="例如：粘人爱撒娇"></label>
            <label>心情<input v-model="petForm.mood" placeholder="例如：开心到冒泡"></label>
            <label>心情表情<input v-model="petForm.moodEmoji" maxlength="4" placeholder="😸"></label>
            <label>展示 Emoji<input v-model="petForm.emoji" maxlength="4" placeholder="🐱"></label>
            <label>卡片底色<input v-model="petForm.color" placeholder="#ffe0b8"></label>
            <label class="span-2">图片地址（留空则显示 Emoji）<input v-model="petForm.image" placeholder="/pets/naigai.png 或 https://..."></label>
            <label>展示顺序<input v-model.number="petForm.sort" type="number" min="0"></label>
            <label>状态
              <select v-model.number="petForm.status"><option :value="1">上架（首页可见）</option><option :value="0">下架（首页隐藏）</option></select>
            </label>
            <label class="checkbox-label span-2">
              <input v-model="petForm.hot" type="checkbox"> 标记为热门毛孩子
            </label>
          </div>
          <p v-if="petFormError" class="form-error">⚠️ {{ petFormError }}</p>
        </div>
        <div class="modal-foot">
          <button type="button" class="tool-btn ghost" @click="petDialogOpen = false">取消</button>
          <button type="button" class="tool-btn primary" @click="savePet">保存到首页</button>
        </div>
      </div>
    </div>

    <!-- 轻提示 -->
    <div v-if="toast" class="toast" :class="toast.type">{{ toast.message }}</div>
  </div>
</template>

<style scoped>
.admin-page {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 224px 1fr;
  background: var(--cream);
}

/* 侧边栏 */
.admin-sidebar {
  position: sticky;
  top: 0;
  height: 100vh;
  display: flex;
  flex-direction: column;
  padding: 22px 14px;
  background: var(--paper);
  border-right: var(--line);
}
.side-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 4px 8px 20px;
}
.side-logo-icon {
  width: 42px;
  height: 42px;
  display: grid;
  place-items: center;
  font-size: 22px;
  background: var(--pink);
  border: var(--line);
  border-radius: 12px;
  box-shadow: var(--shadow-1);
  transform: rotate(-6deg);
}
.side-logo-text {
  display: flex;
  flex-direction: column;
  font-size: 17px;
  font-weight: 900;
  font-style: italic;
  line-height: 1.15;
}
.side-logo-text small { font-size: 10px; font-style: normal; color: var(--text-3); letter-spacing: 2px; }
.side-nav { display: grid; gap: 6px; margin-top: 10px; }
.side-nav-item {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 11px 12px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  text-align: left;
  background: transparent;
  border: 2px solid transparent;
  border-radius: var(--r-sm);
  cursor: pointer;
}
.side-nav-item:hover { background: #fff2c9; }
.side-nav-item.active {
  background: var(--yellow);
  border-color: var(--ink);
  box-shadow: 3px 3px 0 var(--ink);
}
.side-bottom { margin-top: auto; display: grid; gap: 6px; }
.side-link {
  padding: 9px 12px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  text-align: left;
  background: transparent;
  border: none;
  border-radius: 9px;
  cursor: pointer;
}
.side-link:hover { background: var(--mint-soft); }
.side-link.danger:hover { background: var(--danger-soft); color: #a3273d; }

/* 主区域 */
.admin-main { min-width: 0; padding: 26px 30px 48px; }
.admin-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 18px;
  margin-bottom: 22px;
}
.header-eyebrow {
  margin: 0 0 3px;
  font-size: 10px;
  font-weight: 900;
  letter-spacing: 2px;
  color: var(--text-3);
}
.admin-header h1 { margin: 0; font-size: 26px; font-weight: 900; }
.admin-user {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 7px 12px 7px 7px;
  background: var(--paper);
  border: var(--line);
  border-radius: var(--r-pill);
  box-shadow: var(--shadow-1);
}
.user-avatar {
  width: 32px;
  height: 32px;
  display: grid;
  place-items: center;
  background: var(--mint-soft);
  border: 1.5px solid var(--ink);
  border-radius: 50%;
  font-size: 18px;
}
.user-meta { display: flex; flex-direction: column; line-height: 1.2; }
.user-meta strong { font-size: 12px; }
.user-meta small { font-size: 10px; color: var(--text-3); }

/* 概览 */
.panel-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 14px;
}
.stat-card {
  display: grid;
  gap: 4px;
  padding: 17px;
  border: var(--line);
  border-radius: var(--r-md);
  box-shadow: var(--shadow-2);
}
.stat-card.pink { background: #ffe3ef; }
.stat-card.mint { background: #d9f5ea; }
.stat-card.yellow { background: #fff0b8; }
.stat-card.blue { background: #dcecff; }
.stat-icon { font-size: 22px; }
.stat-label { font-size: 11px; font-weight: 900; color: var(--text-3); }
.stat-value { font-size: 29px; font-weight: 900; }
.overview-box {
  grid-column: 1 / -1;
  padding: 24px;
  background: var(--paper);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
}
.overview-box h2 { margin: 0 0 8px; font-size: 19px; }
.overview-box p { margin: 0 0 16px; font-size: 12px; font-weight: 700; color: var(--text-2); }
.quick-actions { display: flex; flex-wrap: wrap; gap: 10px; }
.quick-actions button {
  padding: 10px 14px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
  cursor: pointer;
}
.quick-actions button:nth-child(2) { background: var(--mint-soft); }
.quick-actions button:nth-child(3) { background: var(--pink-soft); }
.quick-actions button:hover { transform: translateY(-2px); }
.backend-strip {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 18px;
}
.backend-strip span {
  padding: 5px 11px;
  font-size: 11px;
  font-weight: 900;
  background: #fff8e9;
  border: 1.5px solid var(--ink);
  border-radius: var(--r-pill);
}
.backend-strip.warn { color: #a3273d; }

/* 内容面板 */
.content-panel {
  padding: 20px;
  background: var(--paper);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
}
.panel-toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
}
.toolbar-left, .toolbar-right { display: flex; flex-wrap: wrap; align-items: center; gap: 9px; }
.tool-search {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 7px 10px;
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
}
.tool-search input {
  width: 190px;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  border: none;
  outline: none;
  background: transparent;
}
.tool-select, .form-grid select {
  padding: 8px 10px;
  font: inherit;
  font-size: 12px;
  font-weight: 800;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  outline: none;
}
.tool-btn {
  padding: 8px 13px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
  cursor: pointer;
  background: var(--paper);
}
.tool-btn.primary { background: var(--yellow); }
.tool-btn.ghost { background: #fff; box-shadow: none; }
.tool-btn.small { padding: 5px 9px; font-size: 11px; }
.tool-btn:hover { transform: translateY(-2px); }
.table-hint { margin: 0 0 12px; font-size: 11px; font-weight: 700; color: var(--text-3); }
.table-wrap { overflow-x: auto; border: 1.5px solid rgba(43, 43, 43, 0.2); border-radius: var(--r-sm); }
.data-table { width: 100%; border-collapse: collapse; font-size: 12px; }
.data-table th {
  padding: 11px 12px;
  text-align: left;
  font-size: 11px;
  font-weight: 900;
  color: var(--text-2);
  background: #fff5d8;
  border-bottom: var(--line);
  white-space: nowrap;
}
.data-table td { padding: 11px 12px; border-bottom: 1px dashed rgba(43, 43, 43, 0.18); vertical-align: middle; }
.data-table tr:last-child td { border-bottom: none; }
.data-table tbody tr:hover { background: #fffdf2; }
.order-cell { display: flex; align-items: center; gap: 7px; }
.order-btns { display: grid; gap: 1px; }
.order-btns button {
  width: 18px;
  height: 14px;
  padding: 0;
  font-size: 10px;
  line-height: 1;
  color: var(--ink);
  background: #fff;
  border: 1px solid var(--ink);
  border-radius: 4px;
  cursor: pointer;
}
.order-btns button:disabled { opacity: 0.3; cursor: default; }
.pet-cell { display: flex; align-items: center; gap: 9px; min-width: 160px; }
.pet-avatar, .item-avatar, .item-emoji {
  width: 38px;
  height: 38px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 20px;
  border: 1.5px solid var(--ink);
  border-radius: 10px;
  overflow: hidden;
}
.pet-avatar img { width: 100%; height: 100%; object-fit: cover; }
.item-emoji { font-size: 19px; }
.pet-cell-copy { min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.pet-cell-copy strong { font-size: 12px; white-space: nowrap; }
.pet-cell-copy small {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 10px;
  font-weight: 700;
  color: var(--text-3);
}
.hot-tag {
  padding: 1px 5px;
  font-size: 8px;
  font-style: normal;
  color: var(--ink);
  background: var(--yellow);
  border: 1px solid var(--ink);
  border-radius: 5px;
}
.cell-chip {
  display: inline-block;
  padding: 3px 8px;
  font-size: 10px;
  font-weight: 900;
  background: var(--mint-soft);
  border: 1.5px solid var(--ink);
  border-radius: var(--r-pill);
}
.cell-sub { display: block; margin-top: 3px; font-size: 10px; color: var(--text-3); }
.status-pill, .mini-status {
  padding: 5px 10px;
  font: inherit;
  font-size: 10px;
  font-weight: 900;
  border: var(--line);
  border-radius: var(--r-pill);
  cursor: pointer;
}
.status-pill.on, .mini-status.on { background: var(--mint-soft); }
.status-pill.off, .mini-status.off { background: #f0e7e2; color: var(--text-3); }
.mini-status { display: inline-block; cursor: default; }
.row-actions { display: flex; gap: 6px; white-space: nowrap; }
.row-actions button, .row-edit {
  padding: 5px 9px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: 1.5px solid var(--ink);
  border-radius: 7px;
  cursor: pointer;
}
.row-actions button:hover, .row-edit:hover { background: var(--yellow); }
.row-actions button.danger, .row-edit.danger:hover { color: #a3273d; }
.row-actions button.danger:hover { background: var(--danger-soft); }
.empty-row { padding: 26px !important; text-align: center; color: var(--text-3); font-weight: 800; }
.pager { display: flex; align-items: center; justify-content: center; gap: 12px; margin-top: 16px; }
.pager button {
  padding: 7px 12px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: 8px;
  cursor: pointer;
}
.pager button:disabled { opacity: 0.4; cursor: default; }
.pager span { font-size: 11px; font-weight: 900; }

/* 分类列表 */
.category-list { display: grid; gap: 8px; }
.category-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 11px 14px;
  background: #fffdf6;
  border: 1.5px solid var(--ink);
  border-radius: var(--r-sm);
}
.category-order {
  width: 22px;
  height: 22px;
  display: grid;
  place-items: center;
  font-size: 11px;
  font-weight: 900;
  background: var(--yellow);
  border: 1.5px solid var(--ink);
  border-radius: 7px;
}
.category-row strong { font-size: 12px; }
.category-count { margin-left: auto; font-size: 10px; font-weight: 800; color: var(--text-3); }
.category-input {
  flex: 1;
  padding: 6px 9px;
  font: inherit;
  font-size: 12px;
  border: var(--line);
  border-radius: 8px;
  outline: none;
}

/* 弹窗 */
.modal-mask {
  position: fixed;
  inset: 0;
  z-index: 100;
  display: grid;
  place-items: center;
  padding: 18px;
  background: rgba(43, 43, 43, 0.42);
  backdrop-filter: blur(2px);
}
.modal-card {
  width: min(620px, 100%);
  max-height: 90vh;
  display: flex;
  flex-direction: column;
  background: var(--paper);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-4);
  animation: modal-in 0.18s ease both;
}
@keyframes modal-in {
  from { opacity: 0; transform: translateY(12px) scale(0.98); }
  to { opacity: 1; transform: none; }
}
.modal-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border-bottom: var(--line);
  background: #fff5d8;
}
.modal-head h2 { margin: 0; font-size: 17px; }
.modal-close {
  width: 28px;
  height: 28px;
  font-size: 20px;
  line-height: 1;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: 8px;
  cursor: pointer;
}
.modal-body { padding: 18px 20px; overflow-y: auto; }
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.form-grid label { display: grid; gap: 5px; font-size: 11px; font-weight: 900; }
.form-grid .span-2 { grid-column: 1 / -1; }
.form-grid input:not([type="checkbox"]), .form-grid select {
  width: 100%;
  padding: 8px 10px;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  outline: none;
}
.form-grid input:focus, .form-grid select:focus { background: #fff9df; }
.form-grid .checkbox-label { display: flex; align-items: center; gap: 7px; }
.form-error {
  margin: 14px 0 0;
  padding: 8px 10px;
  font-size: 11px;
  font-weight: 900;
  color: #a3273d;
  background: var(--danger-soft);
  border: 1.5px solid #e598a9;
  border-radius: 9px;
}
.modal-foot {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 14px 20px;
  border-top: var(--line);
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 34px;
  z-index: 200;
  translate: -50% 0;
  padding: 11px 18px;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-pill);
  box-shadow: var(--shadow-2);
}
.toast.error { background: #ffdce4; color: #a3273d; }

@media (max-width: 1100px) {
  .panel-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 760px) {
  .admin-page { grid-template-columns: 1fr; }
  .admin-sidebar {
    position: static;
    height: auto;
    flex-direction: row;
    align-items: center;
    gap: 10px;
    overflow-x: auto;
  }
  .side-logo { padding: 0 10px 0 0; }
  .side-logo-text { display: none; }
  .side-nav { display: flex; margin: 0; }
  .side-bottom { margin: 0 0 0 auto; display: flex; }
  .admin-main { padding: 18px 14px 34px; }
  .form-grid { grid-template-columns: 1fr; }
  .form-grid .span-2 { grid-column: auto; }
}
</style>
