<script setup>
import ComicPanel from '../components/ComicPanel.vue'
import LoginPanel from '../components/LoginPanel.vue'
</script>

<template>
  <main class="stage">
    <ComicPanel />
    <LoginPanel />
  </main>
</template>
