<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import '../page.css'
import CoinIcon from '../components/CoinIcon.vue'
import { dailyTasks, games, settleRules, GAME_DURATION } from '../data/shopItems'
import { store, ensureDailyFresh, claimTask, isTaskClaimed, recordGameRound } from '../store'

const router = useRouter()

const difficultyFilters = [
  { key: 'all', label: '全部游戏' },
  { key: 'easy', label: '轻松局' },
  { key: 'mid', label: '适中' },
  { key: 'hard', label: '挑战' }
]
const activeDifficulty = ref('all')
const hallRef = ref(null)

const visibleGames = computed(() => {
  if (activeDifficulty.value === 'all') return games
  const map = { easy: 1, mid: 2, hard: 3 }
  return games.filter(game => game.difficulty === map[activeDifficulty.value])
})

function diffStars(n) {
  return '★'.repeat(n) + '☆'.repeat(Math.max(0, 3 - n))
}

// ===== 每日任务 =====
const taskList = computed(() => dailyTasks.map(task => {
  const raw = task.type === 'sign'
    ? (store.daily.signed ? 1 : 0)
    : task.type === 'games'
      ? store.daily.games
      : store.daily.purchases
  return {
    ...task,
    progress: Math.min(raw, task.target),
    done: raw >= task.target,
    claimed: isTaskClaimed(task.id)
  }
}))
const finishedCount = computed(() => taskList.value.filter(task => task.done).length)
const claimableCount = computed(() => taskList.value.filter(task => task.done && !task.claimed).length)

const toastText = ref('')
let toastTimer = null
const flashCoin = ref(false)
let flashTimer = null

function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2200)
}

function pulseCoin() {
  flashCoin.value = true
  clearTimeout(flashTimer)
  flashTimer = setTimeout(() => { flashCoin.value = false }, 900)
}

function taskButtonText(task) {
  if (task.claimed) return '已领取'
  if (task.type === 'sign' && !store.daily.signed) return '签到 +10'
  if (task.done) return `领取 +${task.reward}`
  return '去完成'
}

function handleTask(task) {
  if (task.claimed) return
  // 签到任务：点一下即签到并同步领取
  if (task.type === 'sign' && !store.daily.signed) {
    store.daily.signed = true
    claimTask(task.id, task.reward)
    pulseCoin()
    showToast('签到成功，+10 游戏币已入袋 🪙')
    return
  }
  if (!task.done) {
    hallRef.value?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    showToast('先去玩一局，任务完成就能领币啦～')
    return
  }
  if (claimTask(task.id, task.reward)) {
    pulseCoin()
    showToast(`任务完成，+${task.reward} 游戏币 🎉`)
  }
}

// ===== 小游戏：点住冒出来的小物件，15 秒结算 =====
const playGame = ref(null)
const modalOpen = ref(false)
const gameState = ref('idle') // idle 准备 / playing 游戏中 / over 结算
const holes = ref(Array(6).fill(null))
const score = ref(0)
const timeLeft = ref(GAME_DURATION)
const earnedCoins = ref(0)
const hitIndex = ref(-1)
let tickTimer = null
let spawnTimer = null
let holeTimers = []
let hitTimer = null

function clearGameTimers() {
  clearInterval(tickTimer)
  clearInterval(spawnTimer)
  holeTimers.forEach(t => clearTimeout(t))
  holeTimers = []
  clearTimeout(hitTimer)
}

function openGame(game) {
  clearGameTimers()
  playGame.value = game
  modalOpen.value = true
  gameState.value = 'idle'
  holes.value = Array(6).fill(null)
  score.value = 0
  timeLeft.value = GAME_DURATION
  earnedCoins.value = 0
}

function closeGame() {
  clearGameTimers()
  modalOpen.value = false
  playGame.value = null
  gameState.value = 'idle'
}

function spawn() {
  if (gameState.value !== 'playing' || !playGame.value) return
  const empty = holes.value.map((h, i) => (h ? null : i)).filter(i => i !== null)
  if (!empty.length) return
  const index = empty[Math.floor(Math.random() * empty.length)]
  const pool = playGame.value.pool
  const emoji = pool[Math.floor(Math.random() * pool.length)]
  const uid = `${Date.now()}-${Math.random()}`
  holes.value[index] = { emoji, uid }
  const timer = setTimeout(() => {
    const current = holes.value[index]
    if (current && current.uid === uid) holes.value[index] = null
  }, playGame.value.life)
  holeTimers.push(timer)
}

function startRound() {
  if (!playGame.value) return
  clearGameTimers()
  score.value = 0
  timeLeft.value = GAME_DURATION
  earnedCoins.value = 0
  holes.value = Array(6).fill(null)
  gameState.value = 'playing'
  tickTimer = setInterval(() => {
    timeLeft.value = Math.max(0, Math.round((timeLeft.value - 0.1) * 10) / 10)
    if (timeLeft.value <= 0) endRound()
  }, 100)
  spawnTimer = setInterval(spawn, playGame.value.spawn)
  spawn()
}

function hit(index) {
  if (gameState.value !== 'playing') return
  const current = holes.value[index]
  if (!current) return
  holes.value[index] = null
  score.value += 1
  hitIndex.value = index
  clearTimeout(hitTimer)
  hitTimer = setTimeout(() => { hitIndex.value = -1 }, 200)
}

function endRound() {
  if (gameState.value !== 'playing') return
  clearGameTimers()
  gameState.value = 'over'
  const game = playGame.value
  const coins = Math.min(game.cap, score.value * game.perScore)
  earnedCoins.value = recordGameRound(score.value, coins)
  if (earnedCoins.value > 0) pulseCoin()
}

const resultTitle = computed(() => {
  if (score.value >= 8) return '手感超棒！'
  if (score.value >= 4) return '不错哦～'
  return '再来一局嘛'
})
const resultEmoji = computed(() => {
  if (score.value >= 8) return '🏆'
  if (score.value >= 4) return '🎉'
  return '🐾'
})

function goShop() {
  router.push('/shop')
}

onMounted(() => {
  document.body.classList.add('home-body')
  ensureDailyFresh()
})
onBeforeUnmount(() => {
  document.body.classList.remove('home-body')
  clearGameTimers()
  clearTimeout(toastTimer)
  clearTimeout(flashTimer)
})
</script>

<template>
  <div class="app-bg fun-page pg-page">
    <main class="pg-main">
      <!-- 页头：标题 + 游戏币钱包 -->
      <header class="pg-head">
        <div class="pg-title">
          <span class="pg-title-badge" aria-hidden="true">🎮</span>
          <div>
            <h1>萌宠乐园</h1>
            <p>玩一局小游戏，攒一把游戏币，给毛孩子换点小礼物 🐾</p>
          </div>
        </div>

        <div class="wallet-card" :class="{ flash: flashCoin }">
          <div class="wallet-icon"><CoinIcon :size="42" /></div>
          <div class="wallet-copy">
            <span>我的游戏币</span>
            <strong :key="store.coins">{{ store.coins }}</strong>
          </div>
          <button type="button" class="wallet-btn" @click="goShop">去商城 →</button>
        </div>
      </header>

      <!-- 今日任务 -->
      <section class="task-panel" aria-label="今日任务">
        <div class="task-head">
          <div class="task-head-copy">
            <h2>📋 今日任务</h2>
            <p>每天 0 点刷新，完成就能额外领游戏币</p>
          </div>
          <div class="task-summary">
            <span class="task-done-chip">已完成 {{ finishedCount }}/{{ taskList.length }}</span>
            <span v-if="claimableCount" class="task-claim-chip">可领 {{ claimableCount }} 份奖励</span>
          </div>
        </div>

        <div class="task-grid">
          <article
            v-for="task in taskList"
            :key="task.id"
            class="task-item"
            :class="{ done: task.done, claimed: task.claimed }"
          >
            <div class="task-top">
              <span class="task-icon" aria-hidden="true">{{ task.icon }}</span>
              <div class="task-name">
                <strong>{{ task.name }}</strong>
                <small>{{ task.desc }}</small>
              </div>
            </div>

            <div class="task-progress">
              <div class="task-track">
                <div
                  class="task-fill"
                  :style="{ width: Math.round((task.progress / task.target) * 100) + '%' }"
                ></div>
              </div>
              <span>{{ task.progress }}/{{ task.target }}</span>
            </div>

            <div class="task-foot">
              <span class="task-reward">
                <CoinIcon :size="14" /> +{{ task.reward }}
              </span>
              <button
                type="button"
                class="task-btn"
                :class="{ ready: task.done && !task.claimed }"
                :disabled="task.claimed"
                @click="handleTask(task)"
              >{{ taskButtonText(task) }}</button>
            </div>
          </article>
        </div>
      </section>

      <!-- 小游戏大厅 -->
      <section ref="hallRef" class="hall" aria-label="小游戏大厅">
        <div class="hall-head">
          <div class="hall-title">
            <h2>🎪 小游戏大厅</h2>
            <p>点开就能玩，每局 15 秒，手感越好币越多</p>
          </div>
          <div class="hall-filters">
            <button
              v-for="item in difficultyFilters"
              :key="item.key"
              type="button"
              class="hall-chip"
              :class="{ active: activeDifficulty === item.key }"
              @click="activeDifficulty = item.key"
            >{{ item.label }}</button>
          </div>
        </div>

        <div class="game-grid">
          <article
            v-for="game in visibleGames"
            :key="game.id"
            class="game-card"
            :style="{ '--g-theme': game.theme, '--g-accent': game.accent }"
          >
            <div class="game-art">
              <span class="game-tag">{{ game.tag }}</span>
              <span class="art-bubble b1" aria-hidden="true">{{ game.pool[0] }}</span>
              <span class="art-bubble b2" aria-hidden="true">{{ game.pool[1] }}</span>
              <span class="art-ground" aria-hidden="true"></span>
              <span class="art-main" aria-hidden="true">{{ game.icon }}</span>
              <span class="art-spark s1" aria-hidden="true">✨</span>
              <span class="art-spark s2" aria-hidden="true">✦</span>
            </div>

            <div class="game-body">
              <div class="game-name-row">
                <h3>{{ game.name }}</h3>
                <span class="game-diff" :title="`难度 ${game.difficulty} 星`">{{ diffStars(game.difficulty) }}</span>
              </div>
              <p class="game-desc">{{ game.desc }}</p>

              <div class="game-meta">
                <span>⏱ 15 秒一局</span>
                <span>·</span>
                <span>单局最高 <strong>+{{ game.cap }}</strong> 币</span>
              </div>

              <button type="button" class="game-start" @click="openGame(game)">
                开始游戏
                <span aria-hidden="true">→</span>
              </button>
            </div>
          </article>
        </div>

        <p v-if="!visibleGames.length" class="hall-empty">这个难度暂时没有游戏，换个筛选看看 🐾</p>
      </section>

      <!-- 结算规则 + 今日战绩 -->
      <section class="lower-grid">
        <div class="rules-panel">
          <div class="panel-head">
            <h2>🪙 游戏币结算规则</h2>
            <span class="panel-chip">公开透明</span>
          </div>
          <ul class="rule-list">
            <li v-for="rule in settleRules" :key="rule.title">
              <span class="rule-icon" aria-hidden="true">{{ rule.icon }}</span>
              <div>
                <strong>{{ rule.title }}</strong>
                <small>{{ rule.desc }}</small>
              </div>
            </li>
          </ul>
        </div>

        <div class="record-panel">
          <div class="panel-head">
            <h2>📈 今日战绩</h2>
            <span class="panel-chip">{{ store.daily.date.slice(5).replace('-', '/') }}</span>
          </div>
          <div class="record-grid">
            <div class="record-item">
              <strong>{{ store.daily.games }}</strong>
              <small>今日局数</small>
            </div>
            <div class="record-item">
              <strong>{{ store.daily.bestScore }}</strong>
              <small>单局最高分</small>
            </div>
            <div class="record-item">
              <strong>{{ store.daily.earned }}</strong>
              <small>今日赚币</small>
            </div>
          </div>
          <div class="record-progress" aria-label="今日玩游戏进度">
            <div
              class="record-progress-fill"
              :style="{ width: Math.min(100, (store.daily.games / 3) * 100) + '%' }"
            ></div>
          </div>
          <p class="record-tip">
            <template v-if="store.daily.games >= 3">💡 今日「玩满 3 局」已完成，去上方任务卡领取 20 币奖励吧～</template>
            <template v-else>💡 今日还有 {{ 3 - store.daily.games }} 局就能拿到「玩满 3 局」的 20 币奖励</template>
          </p>
          <button type="button" class="record-shop" @click="goShop">去积分商城逛逛 →</button>
        </div>
      </section>
    </main>

    <!-- 游戏弹窗 -->
    <div v-if="modalOpen && playGame" class="game-mask" @click.self="closeGame">
      <div
        class="game-modal"
        :style="{ '--g-theme': playGame.theme, '--g-accent': playGame.accent }"
      >
        <button type="button" class="game-close" aria-label="关闭游戏" @click="closeGame">×</button>

        <!-- 准备页 -->
        <template v-if="gameState === 'idle'">
          <div class="gm-hero">
            <span class="gm-hero-emoji" aria-hidden="true">{{ playGame.icon }}</span>
            <span class="gm-hero-tag">{{ playGame.tag }}</span>
          </div>
          <h2>{{ playGame.name }}</h2>
          <p class="gm-desc">{{ playGame.desc }}</p>
          <ul class="gm-how">
            <li><span>⏱</span>限时 {{ GAME_DURATION }} 秒，点住冒出来的小物件</li>
            <li><span>🎯</span>每抓到 1 个得 1 分，1 分 = {{ playGame.perScore }} 游戏币</li>
            <li><span>🏁</span>单局最高可拿 {{ playGame.cap }} 游戏币</li>
          </ul>
          <button type="button" class="gm-primary" @click="startRound">开始游戏 →</button>
        </template>

        <!-- 游戏中 -->
        <template v-else-if="gameState === 'playing'">
          <div class="gm-hud">
            <span class="gm-timer" :class="{ urgent: timeLeft <= 5 }">⏱ {{ timeLeft.toFixed(1) }}s</span>
            <span class="gm-score">🎯 {{ score }} 分</span>
          </div>
          <div class="gm-board">
            <button
              v-for="(hole, index) in holes"
              :key="index"
              type="button"
              class="gm-hole"
              :class="{ filled: hole, hit: hitIndex === index }"
              @click="hit(index)"
            >
              <span class="hole-shadow" aria-hidden="true"></span>
              <span v-if="hole" class="gm-item" aria-hidden="true">{{ hole.emoji }}</span>
            </button>
          </div>
          <p class="gm-tip">看到小物件就点住它，别让它溜走～</p>
        </template>

        <!-- 结算页 -->
        <template v-else>
          <div class="gm-result-emoji" aria-hidden="true">{{ resultEmoji }}</div>
          <h2>{{ resultTitle }}</h2>
          <p class="gm-result-desc">本局抓到 <strong>{{ score }}</strong> 个，毛孩子在旁边鼓掌 🐾</p>
          <div class="gm-reward">
            <CoinIcon :size="30" />
            <span>+{{ earnedCoins }}</span>
            <small>游戏币</small>
          </div>
          <p class="gm-balance">当前余额：{{ store.coins }} 游戏币</p>
          <div class="gm-actions">
            <button type="button" class="gm-primary ghost" @click="closeGame">收下啦</button>
            <button type="button" class="gm-primary" @click="startRound">再来一局 →</button>
          </div>
        </template>
      </div>
    </div>

    <div class="fun-toast" :class="{ show: toastText }">{{ toastText }}</div>
  </div>
</template>

<style scoped>
:global(body.home-body) { display: block; align-items: initial; justify-content: initial; padding: 0; }

.pg-page {
  min-height: 100vh;
  /* 全页统一的栅格 / 圆角 / 描边尺度，保证各模块左右对齐、呼吸感一致 */
  --pg-gap: 16px;
  --pg-gap-lg: 24px;
  --pg-pad: 20px;
  --pg-radius: var(--r-lg);
  --pg-card-shadow:
    5px 6px 0 var(--ink),
    0 12px 26px rgba(43, 43, 43, 0.08),
    inset 0 2px 0 rgba(255, 255, 255, 0.92);
  --pg-card-shadow-hover:
    7px 9px 0 var(--ink),
    0 16px 32px rgba(43, 43, 43, 0.13),
    inset 0 2px 0 rgba(255, 255, 255, 0.95);
}
.pg-main {
  max-width: var(--layout-max);
  margin: 0 auto;
  padding: var(--layout-pad-top) var(--layout-pad-x) var(--layout-pad-bottom);
}

/* ===== 页头 ===== */
.pg-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--pg-gap-lg);
  margin-bottom: var(--pg-gap-lg);
}
.pg-title { display: flex; align-items: center; gap: 14px; }
.pg-title-badge {
  width: 66px;
  height: 66px;
  display: grid;
  place-items: center;
  font-size: 32px;
  background: var(--mint);
  border: var(--line);
  border-radius: 20px;
  box-shadow: var(--shadow-2);
  transform: rotate(-5deg);
  flex: 0 0 auto;
}
.pg-title h1 { margin: 0 0 4px; font-size: 32px; letter-spacing: 0.5px; }
.pg-title p { margin: 0; font-size: 13px; font-weight: 700; color: var(--text-2); }

.wallet-card {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 13px 14px 13px 16px;
  background: linear-gradient(120deg, #fff3c9, #ffe2b0);
  border: var(--line);
  border-radius: var(--pg-radius);
  box-shadow: var(--pg-card-shadow);
  transition: transform var(--t-base) var(--ease-soft), box-shadow var(--t-base) var(--ease-soft);
}
.wallet-card:hover { transform: translateY(-2px); box-shadow: var(--pg-card-shadow-hover); }
.wallet-card.flash { animation: wallet-pop 0.6s cubic-bezier(0.2, 1.5, 0.4, 1); }
@keyframes wallet-pop {
  0% { transform: scale(1); }
  40% { transform: scale(1.05) rotate(-1deg); }
  100% { transform: scale(1); }
}
.wallet-icon { transform: rotate(-8deg); }
.wallet-copy { display: flex; flex-direction: column; line-height: 1.1; }
.wallet-copy span { font-size: 10px; font-weight: 900; color: var(--text-3); letter-spacing: 0.5px; }
.wallet-copy strong { font-size: 26px; animation: coin-num 0.4s cubic-bezier(0.2, 1.5, 0.4, 1); }
@keyframes coin-num { from { opacity: 0.3; transform: translateY(-4px) scale(1.15); } to { opacity: 1; transform: none; } }
.wallet-btn {
  padding: 8px 12px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
  cursor: pointer;
  white-space: nowrap;
}
.wallet-btn:hover { background: var(--yellow); transform: translateY(-2px); box-shadow: 3px 4px 0 var(--ink); }

/* ===== 今日任务 ===== */
.task-panel {
  padding: var(--pg-pad) 22px;
  margin-bottom: var(--pg-gap-lg);
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--pg-radius);
  box-shadow: var(--pg-card-shadow);
}
.task-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--pg-gap);
  margin-bottom: var(--pg-gap);
}
.task-head-copy h2 { margin: 0 0 3px; font-size: 19px; }
.task-head-copy p { margin: 0; font-size: 11.5px; font-weight: 700; color: var(--text-3); }
.task-summary { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.task-done-chip,
.task-claim-chip {
  padding: 5px 12px;
  font-size: 11px;
  font-weight: 900;
  border: 2px solid var(--ink);
  border-radius: var(--r-pill);
}
.task-done-chip { background: #fff; box-shadow: 2px 2px 0 var(--ink); }
.task-claim-chip { background: var(--pink); animation: claim-blink 2s ease-in-out infinite; }
@keyframes claim-blink { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-2px); } }

.task-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--pg-gap);
}
.task-item {
  display: flex;
  flex-direction: column;
  gap: 11px;
  padding: 14px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-md);
  box-shadow: 2px 3px 0 rgba(43, 43, 43, 0.1), inset 0 2px 0 rgba(255, 255, 255, 0.92);
  transition: transform var(--t-base) var(--ease-pop), box-shadow var(--t-base) var(--ease-soft), border-color var(--t-base);
}
.task-item:hover {
  transform: translateY(-4px);
  border-color: #000;
  box-shadow: 0 0 0 1px var(--ink), 4px 7px 0 rgba(43, 43, 43, 0.18), inset 0 2px 0 #fff;
}
.task-item.done { background: #fffaea; }
.task-item.claimed { filter: grayscale(0.82); opacity: 0.7; }
.task-top { display: flex; align-items: flex-start; gap: 9px; }
.task-icon {
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  font-size: 17px;
  flex: 0 0 auto;
  background: #fff3c9;
  border: 2px solid var(--ink);
  border-radius: 11px;
  box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.9);
}
.task-name { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.task-name strong { font-size: 13px; font-weight: 900; line-height: 1.3; }
.task-name small { font-size: 10px; font-weight: 700; line-height: 1.5; color: var(--text-3); }
.task-progress { display: flex; align-items: center; gap: 8px; }
.task-progress span { font-size: 10px; font-weight: 900; color: var(--text-3); }
.task-track {
  flex: 1;
  height: 10px;
  background: #f3e7d4;
  border: 1.5px solid rgba(43, 43, 43, 0.25);
  border-radius: 99px;
  overflow: hidden;
  box-shadow: inset 0 1px 3px rgba(43, 43, 43, 0.08);
}
.task-fill {
  height: 100%;
  background: linear-gradient(90deg, #ffd84d 0%, #ffb648 55%, #ff8a5b 100%);
  border-radius: 99px;
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.55), 0 0 8px rgba(255, 184, 72, 0.45);
  transition: width 0.45s var(--ease-soft);
}
.task-foot { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.task-reward {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11px;
  font-weight: 900;
  color: #8a5c12;
}
.task-reward :deep(svg) { filter: drop-shadow(1px 1px 0 rgba(43, 43, 43, 0.22)); }
.task-btn {
  padding: 6px 10px;
  font: inherit;
  font-size: 10.5px;
  font-weight: 900;
  color: var(--ink);
  background: #fff8e9;
  border: 2px solid var(--ink);
  border-radius: 10px;
  box-shadow: 2px 2px 0 var(--ink);
  cursor: pointer;
  white-space: nowrap;
  transition: background var(--t-fast), transform var(--t-fast), box-shadow var(--t-fast);
}
.task-btn:hover:not(:disabled) { background: #fff0b8; transform: translateY(-2px); box-shadow: 2px 4px 0 var(--ink); }
.task-btn:active:not(:disabled) { transform: translate(2px, 2px); box-shadow: none; }
.task-btn.ready { background: var(--yellow); }
.task-btn:disabled {
  background: #eee7dd;
  color: #8b8176;
  border-color: rgba(43, 43, 43, 0.3);
  box-shadow: none;
  opacity: 1;
  cursor: default;
}

/* ===== 游戏大厅 ===== */
.hall-head {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--pg-gap);
  margin-bottom: var(--pg-gap);
}
.hall-title h2 { margin: 0 0 3px; font-size: 21px; }
.hall-title p { margin: 0; font-size: 11.5px; font-weight: 700; color: var(--text-3); }
.hall-filters { display: flex; gap: 8px; flex-wrap: wrap; }
.hall-chip {
  padding: 6px 13px;
  font: inherit;
  font-size: 11.5px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.2);
  border-radius: var(--r-pill);
  cursor: pointer;
  transition: background var(--t-fast), transform var(--t-fast), box-shadow var(--t-fast), border-color var(--t-fast);
}
.hall-chip:hover { border-color: var(--ink); transform: translateY(-2px); }
.hall-chip.active {
  background: var(--yellow);
  border-color: var(--ink);
  box-shadow: 2px 2px 0 var(--ink), inset 0 0 0 1px rgba(43, 43, 43, 0.12);
  transform: translateY(-1px);
}
.hall-chip.active::before { content: '★ '; color: #d4761f; }

.game-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: var(--pg-gap);
}
.game-card {
  display: flex;
  flex-direction: column;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--pg-radius);
  box-shadow: var(--pg-card-shadow);
  overflow: hidden;
  transition: transform var(--t-base) var(--ease-pop), box-shadow var(--t-base) var(--ease-soft), border-color var(--t-base);
}
.game-card:hover {
  transform: translate(-3px, -5px);
  border-color: #000;
  box-shadow: var(--pg-card-shadow-hover);
}

.game-art {
  position: relative;
  height: 148px;
  display: grid;
  place-items: center;
  background: var(--g-theme);
  background-image:
    radial-gradient(rgba(43, 43, 43, 0.1) 1.3px, transparent 1.3px),
    radial-gradient(rgba(255, 255, 255, 0.55) 0%, rgba(255, 255, 255, 0) 60%);
  background-size: 15px 15px, 100% 100%;
  border-bottom: var(--line);
  overflow: hidden;
}
.game-tag {
  position: absolute;
  left: 12px;
  top: 12px;
  padding: 5px 11px;
  font-size: 10.5px;
  font-weight: 900;
  letter-spacing: 0.5px;
  color: var(--ink);
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: var(--r-pill);
  box-shadow: 2px 2px 0 var(--ink), inset 0 1px 0 rgba(255, 255, 255, 0.9);
  transform: rotate(-4deg);
  z-index: 2;
}
.art-ground {
  position: absolute;
  bottom: 22px;
  width: 116px;
  height: 26px;
  background: rgba(255, 255, 255, 0.62);
  border: 2px solid rgba(43, 43, 43, 0.2);
  border-radius: 50%;
}
.art-main {
  position: relative;
  z-index: 2;
  font-size: 58px;
  line-height: 1;
  filter: drop-shadow(4px 5px 0 rgba(43, 43, 43, 0.2));
  animation: art-breathe 3.4s ease-in-out infinite;
}
/* 封面呼吸：轻微放大 + 上下浮动，保持治愈感 */
@keyframes art-breathe {
  0%, 100% { transform: scale(1) rotate(-3deg); translate: 0 0; }
  50% { transform: scale(1.06) rotate(3deg); translate: 0 -6px; }
}
@keyframes art-bob {
  0%, 100% { translate: 0 0; rotate: -3deg; }
  50% { translate: 0 -7px; rotate: 3deg; }
}
.art-bubble {
  position: absolute;
  font-size: 22px;
  opacity: 0.75;
  filter: drop-shadow(2px 3px 0 rgba(43, 43, 43, 0.14));
}
.art-bubble.b1 { top: 30px; right: 34px; animation: bubble-float 4s ease-in-out infinite; }
.art-bubble.b2 { bottom: 26px; left: 34px; font-size: 18px; animation: bubble-float 4s ease-in-out 1.2s infinite; }
@keyframes bubble-float {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -9px; }
}
.art-spark { position: absolute; font-size: 14px; opacity: 0.8; }
.art-spark.s1 { top: 26px; left: 62px; }
.art-spark.s2 { right: 52px; bottom: 34px; }

.game-body { display: flex; flex-direction: column; gap: 9px; padding: 15px 16px 16px; flex: 1; }
.game-name-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.game-name-row h3 { margin: 0; font-size: 17px; font-weight: 900; }
.game-diff {
  flex: 0 0 auto;
  padding: 3px 9px;
  font-size: 12px;
  font-weight: 900;
  letter-spacing: 1.5px;
  color: #c9681a;
  background: #fff3c9;
  border: 1.5px solid var(--ink);
  border-radius: var(--r-pill);
  box-shadow: 1.5px 1.5px 0 var(--ink);
}
.game-desc { margin: 0; font-size: 11.5px; font-weight: 700; line-height: 1.6; color: var(--text-2); }
.game-meta {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 10.5px;
  font-weight: 700;
  color: var(--text-3);
}
.game-meta strong { color: var(--ink); }
.game-start {
  margin-top: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 10px 0;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.15s;
}
.game-start:hover { background: #fff0a8; filter: brightness(1.06); transform: translateY(-2px); box-shadow: 3px 5px 0 var(--ink); }
.game-start:active { transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }
.game-start span { font-size: 15px; }

.hall-empty {
  margin: var(--pg-gap-lg) 0 0;
  padding: 26px;
  font-size: 13px;
  font-weight: 900;
  text-align: center;
  color: var(--text-3);
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--pg-radius);
  box-shadow: var(--pg-card-shadow);
}

/* ===== 规则 + 战绩 ===== */
.lower-grid {
  display: grid;
  grid-template-columns: 1.45fr 1fr;
  gap: var(--pg-gap);
  margin-top: var(--pg-gap-lg);
}
.rules-panel,
.record-panel {
  padding: var(--pg-pad) 22px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--pg-radius);
  box-shadow: var(--pg-card-shadow);
  transition: transform var(--t-base) var(--ease-soft), box-shadow var(--t-base) var(--ease-soft);
}
.rules-panel:hover,
.record-panel:hover { transform: translateY(-2px); box-shadow: var(--pg-card-shadow-hover); }
.panel-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: var(--pg-gap);
}
.panel-head h2 { margin: 0; font-size: 18px; font-weight: 900; }
.panel-chip {
  padding: 4px 11px;
  font-size: 10.5px;
  font-weight: 900;
  background: var(--mint-soft);
  border: 2px solid var(--ink);
  border-radius: var(--r-pill);
}
.rule-list { margin: 0; padding: 0; list-style: none; display: grid; gap: 10px; }
.rule-list li {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 11px 13px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.12);
  border-radius: var(--r-sm);
  box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.9);
}
.rule-icon {
  width: 32px;
  height: 32px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 16px;
  background: #fff3c9;
  border: 2px solid var(--ink);
  border-radius: 10px;
}
.rule-list strong { display: block; margin-bottom: 2px; font-size: 13.5px; font-weight: 900; line-height: 1.35; }
.rule-list small { font-size: 11px; font-weight: 600; line-height: 1.55; color: var(--text-2); }

.record-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.record-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  padding: 13px 6px;
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: var(--r-sm);
  box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.9);
}
.record-item strong { font-size: 30px; font-weight: 900; line-height: 1.1; letter-spacing: -0.5px; }
.record-item small { font-size: 10px; font-weight: 900; color: var(--text-3); }
.record-progress {
  height: 10px;
  margin: 14px 0 0;
  background: #fff0f5;
  border: 1.5px solid rgba(43, 43, 43, 0.18);
  border-radius: var(--r-pill);
  overflow: hidden;
  box-shadow: inset 0 1px 3px rgba(43, 43, 43, 0.07);
}
.record-progress-fill {
  height: 100%;
  border-radius: var(--r-pill);
  background: linear-gradient(90deg, #ffd3e2, #ff9ec4);
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.6);
  transition: width 0.45s var(--ease-soft);
}
.record-tip {
  margin: 10px 0 14px;
  padding: 10px 12px;
  font-size: 11.5px;
  font-weight: 700;
  line-height: 1.6;
  color: var(--text-2);
  background: #fffaea;
  border: 2px solid rgba(43, 43, 43, 0.16);
  border-radius: var(--r-sm);
  box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.85);
}
.record-shop {
  width: 100%;
  padding: 10px 0;
  font: inherit;
  font-size: 12.5px;
  font-weight: 900;
  color: var(--ink);
  background: var(--pink);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: background var(--t-fast), filter var(--t-fast), transform var(--t-fast), box-shadow var(--t-fast);
}
.record-shop:hover {
  background: #ffb6d3;
  filter: brightness(1.05);
  transform: translateY(-2px);
  box-shadow: 3px 5px 0 var(--ink);
}
.record-shop:active { transform: translate(2px, 2px); box-shadow: none; }

/* ===== 游戏弹窗 ===== */
.game-mask {
  position: fixed;
  inset: 0;
  z-index: 60;
  display: grid;
  place-items: center;
  padding: 20px;
  background: rgba(43, 43, 43, 0.48);
}
.game-modal {
  position: relative;
  width: min(520px, 100%);
  max-height: 92vh;
  overflow-y: auto;
  padding: 26px 26px 24px;
  text-align: center;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 10px 12px 0 var(--ink);
  animation: gm-pop 0.26s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
@keyframes gm-pop {
  from { opacity: 0; transform: scale(0.88) translateY(16px); }
  to { opacity: 1; transform: none; }
}
.game-close {
  position: absolute;
  right: 14px;
  top: 14px;
  width: 32px;
  height: 32px;
  font: inherit;
  font-size: 16px;
  font-weight: 900;
  background: #ffc9cf;
  border: 2px solid var(--ink);
  border-radius: 50%;
  cursor: pointer;
  z-index: 3;
}
.game-close:hover { transform: rotate(90deg); }

.gm-hero {
  position: relative;
  width: 132px;
  height: 132px;
  margin: 4px auto 14px;
  display: grid;
  place-items: center;
  background: var(--g-theme);
  border: var(--line);
  border-radius: 34px;
  box-shadow: 6px 7px 0 var(--ink);
  transform: rotate(-3deg);
}
.gm-hero-emoji { font-size: 66px; line-height: 1; animation: art-bob 3s ease-in-out infinite; }
.gm-hero-tag {
  position: absolute;
  right: -14px;
  top: -10px;
  padding: 3px 9px;
  font-size: 10px;
  font-weight: 900;
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  transform: rotate(8deg);
}
.game-modal h2 { margin: 0 0 6px; font-size: 24px; }
.gm-desc { margin: 0 0 14px; font-size: 12px; font-weight: 700; line-height: 1.65; color: var(--text-2); }
.gm-how {
  margin: 0 0 18px;
  padding: 12px 14px;
  list-style: none;
  display: grid;
  gap: 8px;
  text-align: left;
  background: #fff;
  border: 2px dashed rgba(43, 43, 43, 0.2);
  border-radius: var(--r-sm);
}
.gm-how li { display: flex; align-items: center; gap: 8px; font-size: 11.5px; font-weight: 700; color: var(--text-2); }
.gm-how span { font-size: 14px; }
.gm-primary {
  width: 100%;
  padding: 13px 0;
  font: inherit;
  font-size: 15px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
}
.gm-primary:hover { background: #ffe27a; transform: translateY(-2px); box-shadow: 4px 6px 0 var(--ink); }
.gm-primary.ghost { background: #fff; }
.gm-primary.ghost:hover { background: #f6ece0; }

/* HUD + 游戏盘 */
.gm-hud {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 14px;
  padding-right: 36px;
}
.gm-timer,
.gm-score {
  padding: 7px 14px;
  font-size: 14px;
  font-weight: 900;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
}
.gm-timer.urgent { background: #ffc9cf; animation: timer-blink 0.7s ease-in-out infinite; }
@keyframes timer-blink { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.05); } }
.gm-board {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  padding: 16px;
  background: var(--g-theme);
  border: var(--line);
  border-radius: var(--r-lg);
  background-image: radial-gradient(rgba(43, 43, 43, 0.09) 1.4px, transparent 1.4px);
  background-size: 16px 16px;
}
.gm-hole {
  position: relative;
  height: 92px;
  padding: 0;
  display: grid;
  place-items: center;
  background: rgba(255, 255, 255, 0.5);
  border: 2px solid rgba(43, 43, 43, 0.22);
  border-radius: 16px;
  cursor: pointer;
  overflow: hidden;
  transition: background 0.15s, transform 0.1s;
}
.gm-hole:hover { background: rgba(255, 255, 255, 0.8); }
.gm-hole.filled { background: #fffdf6; border-color: var(--ink); }
.gm-hole.hit { animation: hole-hit 0.2s ease; }
@keyframes hole-hit {
  0% { transform: scale(1); }
  45% { transform: scale(1.12) rotate(-3deg); }
  100% { transform: scale(1); }
}
.hole-shadow {
  position: absolute;
  bottom: 12px;
  width: 46px;
  height: 13px;
  background: rgba(43, 43, 43, 0.14);
  border-radius: 50%;
}
.gm-item {
  position: relative;
  z-index: 2;
  font-size: 40px;
  line-height: 1;
  filter: drop-shadow(3px 4px 0 rgba(43, 43, 43, 0.18));
  animation: item-pop 0.22s cubic-bezier(0.2, 1.6, 0.4, 1) both;
}
@keyframes item-pop {
  from { opacity: 0; transform: scale(0.4) translateY(10px); }
  to { opacity: 1; transform: none; }
}
.gm-tip { margin: 14px 0 0; font-size: 11px; font-weight: 700; color: var(--text-3); }

/* 结算页 */
.gm-result-emoji { font-size: 62px; line-height: 1.1; animation: art-bob 2.4s ease-in-out infinite; }
.gm-result-desc { margin: 0 0 14px; font-size: 12.5px; font-weight: 700; color: var(--text-2); }
.gm-reward {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 22px;
  margin-bottom: 8px;
  background: linear-gradient(120deg, #fff3c9, #ffe2b0);
  border: var(--line);
  border-radius: 99px;
  box-shadow: 3px 3px 0 var(--ink);
}
.gm-reward span { font-size: 26px; font-weight: 900; }
.gm-reward small { font-size: 11px; font-weight: 900; color: var(--text-3); }
.gm-balance { margin: 0 0 16px; font-size: 11px; font-weight: 800; color: var(--text-3); }
.gm-actions { display: grid; grid-template-columns: 1fr 1.3fr; gap: 10px; }

@media (max-width: 1080px) {
  .game-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .task-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .lower-grid { grid-template-columns: 1fr; }
}
@media (max-width: 860px) {
  .pg-head { flex-direction: column; align-items: flex-start; }
  .wallet-card { width: 100%; justify-content: space-between; }
  .hall-head { flex-direction: column; align-items: flex-start; }
}
@media (max-width: 640px) {
  .pg-main { padding: 24px 14px 60px; }
  .pg-title h1 { font-size: 26px; }
  .pg-title-badge { width: 52px; height: 52px; font-size: 26px; }
  .task-grid { grid-template-columns: 1fr; }
  .game-grid { grid-template-columns: 1fr; }
  .gm-board { gap: 8px; padding: 12px; }
  .gm-hole { height: 76px; }
  .gm-item { font-size: 32px; }
  .gm-actions { grid-template-columns: 1fr; }
}
</style>
