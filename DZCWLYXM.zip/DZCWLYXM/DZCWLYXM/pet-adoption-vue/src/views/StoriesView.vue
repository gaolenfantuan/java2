<script setup>
import { onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import '../page.css'

const seedStories = [
  { id: 's1', emoji: '🐱', name: '奶盖', owner: '小林', days: 365, text: '一年前的今天，你缩在纸箱里冲我喵了一声。现在你每天踩我脸叫我起床，占领家里每一处阳光。谢谢你选我当你的铲屎官～', likes: 128, tape: '#ffd84d' },
  { id: 's2', emoji: '🐕', name: '布丁', owner: '阿哲', days: 210, text: '刚到家时怕得躲在沙发底，现在听到开门声就冲过来转圈。陪你长大的每一天，都是我最开心的日子！', likes: 96, tape: '#8fd9c4' },
  { id: 's3', emoji: '🐇', name: '棉花糖', owner: '团子', days: 120, text: '从怯生生到会主动蹭我手心，你用了四个月。看你啃胡萝卜的样子，我的世界都变柔软了。', likes: 75, tape: '#ff9ec4' }
]
const LIKES_KEY = 'storyLikes'
const USER_KEY = 'userStories'

const likes = ref({})
const userStories = ref([])
const likedSet = ref([])
const storyShow = ref(false)
const form = reactive({ petName: '', emoji: '🐾', owner: '', days: '', text: '' })
const toastText = ref('')
let toastTimer = null

const allStories = () => [...userStories.value, ...seedStories]

function load() {
  try {
    const l = JSON.parse(localStorage.getItem(LIKES_KEY) || '{}')
    likes.value = l && typeof l === 'object' ? l : {}
  } catch { likes.value = {} }
  try {
    const u = JSON.parse(localStorage.getItem(USER_KEY) || '[]')
    userStories.value = Array.isArray(u) ? u : []
  } catch { userStories.value = [] }
  try {
    const s = JSON.parse(localStorage.getItem('storyLikedSet') || '[]')
    likedSet.value = Array.isArray(s) ? s : []
  } catch { likedSet.value = [] }
}

function like(id) {
  if (likedSet.value.includes(id)) { showToast('你已经点过心啦～💕'); return }
  likedSet.value.push(id)
  likes.value = { ...likes.value, [id]: (likes.value[id] || 0) + 1 }
  localStorage.setItem(LIKES_KEY, JSON.stringify(likes.value))
  localStorage.setItem('storyLikedSet', JSON.stringify(likedSet.value))
  showToast('🥪 已送出点心，谢谢你的喜欢！')
}
function likeCount(s) { return (s.likes || 0) + (likes.value[s.id] || 0) }

function submitStory() {
  if (!form.petName.trim() || !form.owner.trim() || !form.text.trim()) { showToast('请填写毛孩子名字、主人和寄语～'); return }
  const story = {
    id: 'u' + Date.now(), emoji: form.emoji || '🐾', name: form.petName.trim(),
    owner: form.owner.trim(), days: Number(form.days) || 0, text: form.text.trim(),
    likes: 0, tape: '#9fd3ff'
  }
  userStories.value = [story, ...userStories.value]
  localStorage.setItem(USER_KEY, JSON.stringify(userStories.value))
  storyShow.value = false
  Object.assign(form, { petName: '', emoji: '🐾', owner: '', days: '', text: '' })
  showToast('📖 故事投稿成功，已展示在故事墙！')
}

function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2400)
}

onMounted(() => { document.body.classList.add('home-body'); load() })
onBeforeUnmount(() => { document.body.classList.remove('home-body'); clearTimeout(toastTimer) })
</script>

<template>
  <div class="fun-page">
    <main class="fun-main">
      <div class="fun-head story-head">
        <div>
          <h1>领养故事 <span>📖</span></h1>
          <p>每一个回家的毛孩子，都有一段温暖的故事～</p>
        </div>
        <button type="button" class="fun-btn pink" @click="storyShow = true">✍️ 投稿我的故事</button>
      </div>

      <div class="story-wall">
        <article v-for="s in allStories()" :key="s.id" class="story-card">
          <div class="tape" :style="{ background: s.tape }"></div>
          <div class="story-emoji">{{ s.emoji }}</div>
          <h3 class="story-name">{{ s.name }}</h3>
          <div class="story-badges">
            <span>@{{ s.owner }}</span>
            <span>🏡 回家 {{ s.days }} 天</span>
          </div>
          <p class="story-text">{{ s.text }}</p>
          <button type="button" class="like-btn" :class="{ liked: likedSet.includes(s.id) }" @click="like(s.id)">
            🥪 点心 {{ likeCount(s) }}
          </button>
        </article>
      </div>
    </main>

    <div v-if="storyShow" class="fun-mask" @click.self="storyShow = false">
      <div class="fun-modal" role="dialog" aria-modal="true">
        <button type="button" class="fun-close" @click="storyShow = false">✕</button>
        <h2>✍️ 投稿领养故事</h2>
        <p class="sub">分享你和毛孩子的回家日常，温暖更多人～</p>
        <div class="fun-form">
          <label><span>毛孩子名字</span><input v-model="form.petName" type="text" placeholder="如：奶盖"></label>
          <label><span>宠物图标</span>
            <select v-model="form.emoji"><option>🐾</option><option>🐱</option><option>🐶</option><option>🐰</option><option>🐹</option></select>
          </label>
          <label><span>你的称呼</span><input v-model="form.owner" type="text" placeholder="如：小林"></label>
          <label><span>回家天数</span><input v-model="form.days" type="number" placeholder="如：365"></label>
          <label><span>领养寄语</span><textarea v-model="form.text" rows="4" placeholder="写下你们的故事..."></textarea></label>
        </div>
        <button type="button" class="fun-btn" style="margin-top:18px;width:100%" @click="submitStory">发布故事 ✓</button>
      </div>
    </div>

    <div class="fun-toast" :class="{ show: !!toastText }">🐾 {{ toastText }}</div>
  </div>
</template>

<style scoped>
.story-head { display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
.story-wall { columns: 3; column-gap: 20px; }
.story-card { position: relative; break-inside: avoid; margin-bottom: 20px; padding: 24px 20px 18px; background: #fffdf6; border: var(--line); border-radius: 8px 20px 20px 20px; box-shadow: 6px 8px 0 var(--ink); transform: rotate(-0.6deg); transition: 0.2s; }
.story-card:nth-child(even) { transform: rotate(0.7deg); }
.story-card:hover { transform: rotate(0deg) translateY(-5px); box-shadow: 10px 13px 0 var(--ink); }
.tape { position: absolute; top: -8px; left: 50%; transform: translateX(-50%) rotate(-2deg); width: 90px; height: 20px; border: 2px solid var(--ink); border-radius: 3px; opacity: 0.85; }
.story-emoji { font-size: 50px; text-align: center; }
.story-name { margin: 8px 0; text-align: center; font-size: 20px; }
.story-badges { display: flex; justify-content: center; gap: 8px; flex-wrap: wrap; margin-bottom: 12px; }
.story-badges span { padding: 3px 9px; font-size: 10px; font-weight: 900; background: var(--mint); border: 2px solid var(--ink); border-radius: 999px; }
.story-text { font-size: 12px; font-weight: 700; line-height: 1.9; color: #6b5744; }
.like-btn { padding: 7px 14px; font: inherit; font-size: 12px; font-weight: 900; color: var(--ink); background: var(--yellow); border: 2px solid var(--ink); border-radius: 999px; box-shadow: 3px 3px 0 var(--ink); cursor: pointer; transition: 0.15s; }
.like-btn:hover { transform: translateY(-2px); }
.like-btn.liked { background: var(--pink); }
@media (max-width: 900px) { .story-wall { columns: 2; } }
@media (max-width: 600px) { .story-wall { columns: 1; } }
</style>
