<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

function backToLogin() {
  localStorage.removeItem('petToken')
  router.push('/login')
}
</script>

<template>
  <main class="home-stage">
    <section class="home-card">
      <div class="emoji">🐾</div>
      <h1>欢迎来到毛茸茸领养站！</h1>
      <p>登录成功，已经带你回到首页啦～</p>
      <button type="button" @click="backToLogin">退出登录</button>
    </section>
  </main>
</template>

<style scoped>
.home-stage {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  background: #fff8ef;
}

.home-card {
  max-width: 460px;
  width: 100%;
  padding: 40px 32px;
  border-radius: 24px;
  background: #fff;
  box-shadow: 0 12px 40px rgba(180, 120, 60, 0.15);
  text-align: center;
  color: #4a3b32;
}

.emoji {
  font-size: 56px;
  line-height: 1;
}

h1 {
  margin: 16px 0 8px;
  font-size: 26px;
}

p {
  margin: 0 0 24px;
  color: #8a7565;
  font-size: 15px;
}

button {
  border: 0;
  border-radius: 999px;
  padding: 12px 28px;
  background: #ff9f68;
  color: #fff;
  font-size: 15px;
  font-weight: 700;
  cursor: pointer;
}

button:hover {
  background: #ff8a48;
}
</style>
