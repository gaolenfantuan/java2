<script setup>
/**
 * 毛孩子的家（宠物窝）：独立页面
 * - 顶部：标题栏 + 状态标签 + 去串门 / 装扮 / 背包
 * - 中间：3D 毛绒质感 Q 版宠物坐软垫，点击抚摸出爱心粒子、表情切换
 * - 下方：心情 / 饱腹 / 清洁 / 健康 四条状态条，数值实时变化
 * - 左下：成长日记（自动记录喂食 / 抚摸 / 互动 / 串门）
 * - 右侧：每日任务 · 道具背包 · 成就徽章墙
 */
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  store,
  addCoins,
  addDiary,
  itemCount,
  removeItem,
  bagTotalCount,
  petHomeOf,
  decayPetHome,
  carePet,
  setPetOutfit
} from '../store'
import { shopItems, shopCategories } from '../data/shopItems'
import { findHomePet } from '../data/homePets'
import { pets as defaultPets } from '../data/pets'
import { badges, syncAchievements } from '../utils/achievements'
import ItemArt from '../components/ItemArt.vue'
import CoinIcon from '../components/CoinIcon.vue'
import CuteEmpty from '../components/CuteEmpty.vue'
import '../page.css'

const router = useRouter()
const route = useRoute()

/* ---------------- 已领养宠物 ---------------- */
function resolvePet(id) {
  const num = Number(id)
  return findHomePet(num) || defaultPets.find(p => p.id === num) || null
}
function loadAdoptedPets() {
  const ids = new Set()
  try {
    (JSON.parse(localStorage.getItem('petAdopted') || '[]') || []).forEach(id => ids.add(Number(id)))
  } catch { /* ignore */ }
  // 申请审核通过也视为已领养，自动进窝
  try {
    (JSON.parse(localStorage.getItem('petAdoptApplications') || '[]') || []).forEach(app => {
      if (String(app.status || '').includes('通过')) ids.add(Number(app.petId))
    })
  } catch { /* ignore */ }
  try {
    const statuses = JSON.parse(localStorage.getItem('petApplyStatuses') || '{}') || {}
    Object.keys(statuses).forEach(pid => {
      if (String(statuses[pid]).includes('通过')) ids.add(Number(pid))
    })
  } catch { /* ignore */ }
  return [...ids].map(resolvePet).filter(Boolean)
}

const myPets = ref(loadAdoptedPets())
const activeId = ref(0)
function onStorage(e) {
  if (!e.key || ['petAdopted', 'petAdoptApplications', 'petHomeState'].includes(e.key)) {
    myPets.value = loadAdoptedPets()
  }
}

const activePet = computed(() => myPets.value.find(p => p.id === activeId.value) || myPets.value[0] || null)
watch(myPets, list => {
  if (list.length && !list.some(p => p.id === activeId.value)) activeId.value = list[0].id
}, { immediate: true })
// 支持 /pet-nest?pet=3 直达某只毛孩子
watch(() => route.query.pet, id => {
  if (id != null && myPets.value.some(p => p.id === Number(id))) activeId.value = Number(id)
}, { immediate: true })

const home = computed(() => {
  if (!activePet.value) return null
  decayPetHome(activePet.value.id)
  return petHomeOf(activePet.value.id)
})

/* ---------------- 四条状态 ---------------- */
const statDefs = [
  { key: 'mood', label: '心情值', icon: '🎈', tone: 'pink' },
  { key: 'hunger', label: '饱腹值', icon: '🍚', tone: 'yellow' },
  { key: 'clean', label: '清洁值', icon: '🛁', tone: 'blue' },
  { key: 'health', label: '健康值', icon: '🌿', tone: 'mint' }
]
function statValue(key) {
  const v = Number(home.value?.[key])
  return Number.isFinite(v) ? Math.max(0, Math.min(100, Math.round(v))) : 0
}
const stats = computed(() => statDefs.map(d => ({ ...d, value: statValue(d.key) })))
const lowestStat = computed(() => Math.min(...stats.value.map(s => s.value)))

const moodFace = computed(() => {
  if (expression.value === 'sad') return '🥺'
  if (expression.value === 'blink') return '😉'
  return '😸'
})
const moodText = computed(() => {
  const s = stats.value
  if (lowestStat.value < 35) return '有点委屈，需要你的陪伴'
  if (s[0].value >= 85 && s[1].value >= 75) return '开心到冒泡，尾巴摇成螺旋桨'
  if (s[2].value < 45) return '想洗个香香澡啦'
  if (s[1].value < 45) return '肚子咕咕叫，想吃小零食'
  return '心情不错，正舒服地晒太阳'
})

/* ---------------- 表情 / 闲置动画 ---------------- */
const expression = ref('happy') // happy / blink / sad / stretch
const bubble = ref('')
const petting = ref(false)
let bubbleTimer = null
let expressionTimer = null
let idleTimer = null
const timers = []

const IDLE_LINES = [
  '今天也要元气满满呀～', '你的手心暖暖的，好舒服',
  '尾巴摇成螺旋桨啦！', '再摸一下嘛，就一下下',
  '我把这里当成自己的家咯', '晒着太阳好想睡午觉…',
  '有你在，哪里都是最好的地方'
]

function say(text, ms = 2800) {
  bubble.value = text
  clearTimeout(bubbleTimer)
  bubbleTimer = setTimeout(() => { bubble.value = '' }, ms)
}
function setExpression(name, ms = 2200) {
  expression.value = name
  clearTimeout(expressionTimer)
  expressionTimer = setTimeout(() => {
    expression.value = lowestStat.value < 35 ? 'sad' : 'happy'
  }, ms)
}
function scheduleIdle() {
  clearTimeout(idleTimer)
  idleTimer = setTimeout(() => {
    if (!activePet.value) return
    if (Math.random() < 0.45) {
      setExpression('stretch', 1800)
      say('伸个懒腰～好舒服呀 🥱')
    } else {
      say(IDLE_LINES[Math.floor(Math.random() * IDLE_LINES.length)])
    }
    scheduleIdle()
  }, 6000 + Math.random() * 5000)
}

// 状态偏低时自动委屈脸
watch(lowestStat, v => {
  if (v < 35 && expression.value !== 'sad') setExpression('sad', 3600)
})

/* ---------------- 爱心粒子 / 飘字 ---------------- */
const particles = ref([])
const floats = ref([])
let seed = 0
const HEARTS = ['💗', '💖', '💕', '✨', '🐾']

function burst(count = 6) {
  const batch = []
  for (let i = 0; i < count; i += 1) {
    batch.push({
      id: `p-${++seed}`,
      emoji: HEARTS[i % HEARTS.length],
      x: 50 + (Math.random() - 0.5) * 26,
      delay: i * 70,
      dx: (Math.random() - 0.5) * 120,
      rot: (Math.random() - 0.5) * 60
    })
  }
  particles.value = [...particles.value, ...batch]
  const ids = batch.map(p => p.id)
  timers.push(setTimeout(() => {
    particles.value = particles.value.filter(p => !ids.includes(p.id))
  }, 1500))
}
function floatText(text, tone = 'pink') {
  const id = `f-${++seed}`
  floats.value = [...floats.value, { id, text, tone }]
  timers.push(setTimeout(() => { floats.value = floats.value.filter(f => f.id !== id) }, 1400))
}

/* ---------------- 互动行为 ---------------- */
function petThePet() {
  if (!activePet.value) return
  const id = activePet.value.id
  const name = activePet.value.name
  burst(7)
  petting.value = true
  timers.push(setTimeout(() => { petting.value = false }, 700))
  setExpression(lowestStat.value < 35 ? 'sad' : 'happy', 1500)
  carePet(id, { mood: 3, event: { icon: '🤲', title: `摸了摸 ${name}`, note: '心情 +3 · 舒服得眯起眼睛', tone: 'pink' } })
  addDiary({ petId: id, petName: name, text: `摸摸 ${name} 的头，TA 眯着眼睛蹭了蹭手心`, mood: '🤗' })
  floatText('心情 +3')
  say(IDLE_LINES[Math.floor(Math.random() * IDLE_LINES.length)])
  bumpTask('touch')
}

/* 道具效果映射：与商城文案口径一致 */
const CATEGORY_PLAN = {
  食物: { hunger: 22, mood: 6, verb: '喂了', icon: '🍚', tone: 'yellow', task: 'feed' },
  玩具: { mood: 14, health: 2, verb: '陪玩用了', icon: '🎾', tone: 'pink', task: '' },
  药品: { health: 18, mood: 2, verb: '服用了', icon: '💊', tone: 'mint', task: '' },
  道具: { clean: 20, health: 4, verb: '清洁用了', icon: '🧴', tone: 'blue', task: 'clean' },
  装饰: { mood: 6, verb: '戴上了', icon: '🎀', tone: 'pink', task: '' }
}

function useItem(item) {
  if (!activePet.value || !item) return
  const plan = CATEGORY_PLAN[item.category] || { mood: 6, verb: '用了', icon: '✨', tone: 'yellow', task: '' }
  if (item.category === '装饰') { toggleOutfit(item); return }
  if (itemCount(item.id) <= 0) { showToast('这件已经用完啦，去商城补点货吧～'); return }
  if (!removeItem(item.id, 1)) return

  const deltas = []
  if (plan.hunger) deltas.push(`饱腹 +${plan.hunger}`)
  if (plan.mood) deltas.push(`心情 +${plan.mood}`)
  if (plan.clean) deltas.push(`清洁 +${plan.clean}`)
  if (plan.health) deltas.push(`健康 +${plan.health}`)

  const id = activePet.value.id
  const name = activePet.value.name
  carePet(id, {
    hunger: plan.hunger || 0, mood: plan.mood || 0,
    clean: plan.clean || 0, health: plan.health || 0,
    event: { icon: plan.icon, title: `${plan.verb} ${item.name}`, note: deltas.join(' · '), tone: plan.tone }
  })
  addDiary({ petId: id, petName: name, text: `给 ${name} ${plan.verb}「${item.name}」，${deltas.join('，')}`, mood: '🥰' })
  burst(4)
  floatText(deltas[0] || '状态提升', plan.tone)
  setExpression(lowestStat.value < 35 ? 'sad' : 'happy', 1400)
  say(`${item.name} 好棒，谢谢你～`)
  if (plan.task) bumpTask(plan.task)
  showToast(`${plan.verb}${item.name}，${deltas.join('，')} ✨`)
}

/* 免费打扫：清洁 +12，心情 +2 */
function cleanNest() {
  if (!activePet.value || cleaning.value) return
  cleaning.value = true
  const id = activePet.value.id
  const name = activePet.value.name
  carePet(id, { clean: 12, mood: 2, event: { icon: '🧹', title: '给小窝做了大扫除', note: '清洁 +12 · 心情 +2', tone: 'blue' } })
  addDiary({ petId: id, petName: name, text: `把 ${name} 的小窝打扫得香香的`, mood: '✨' })
  floatText('清洁 +12', 'blue')
  burst(3)
  bumpTask('clean')
  showToast('小窝干净啦，毛孩子开心地打了个滚～')
  timers.push(setTimeout(() => { cleaning.value = false }, 1200))
}
const cleaning = ref(false)

/* ---------------- 装扮 ---------------- */
const decorList = computed(() => store.backpack
  .map(it => ({ ...it, meta: shopItems.find(s => s.id === it.id) }))
  .filter(it => it.meta && it.meta.category === '装饰'))
const outfitItem = computed(() => {
  const id = home.value?.outfit
  return id ? shopItems.find(i => i.id === id) || null : null
})
function toggleOutfit(item) {
  if (!activePet.value) return
  const isOff = home.value?.outfit === item.id
  setPetOutfit(activePet.value.id, isOff ? '' : item.id)
  if (!isOff) {
    carePet(activePet.value.id, { mood: 4, event: { icon: '🎀', title: `换上了 ${item.name}`, note: '心情 +4', tone: 'pink' } })
    setExpression('happy')
    burst(5)
    showToast(`${activePet.value.name} 换上新造型啦 ✨`)
  } else {
    showToast('配饰取下来啦')
  }
}
const dressOpen = ref(false)

/* ---------------- 每日任务（窝专属） ---------------- */
const TASK_KEY = 'petNestDaily'
const TASK_DEFS = [
  { id: 'touch', icon: '🤲', name: '摸摸毛孩子', desc: '抚摸 TA 一次', reward: 8 },
  { id: 'feed', icon: '🍚', name: '喂一顿好吃的', desc: '使用食物道具一次', reward: 12 },
  { id: 'clean', icon: '🛁', name: '打扫小窝', desc: '清洁一次小窝', reward: 10 },
  { id: 'visit', icon: '🏠', name: '去串门', desc: '拜访一位邻居', reward: 15 }
]
function todayStr() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}
function loadNestDaily() {
  try {
    const raw = JSON.parse(localStorage.getItem(TASK_KEY) || 'null')
    if (raw && raw.date === todayStr()) return { date: raw.date, done: raw.done || {}, claimed: raw.claimed || [] }
  } catch { /* ignore */ }
  return { date: todayStr(), done: {}, claimed: [] }
}
const nestDaily = ref(loadNestDaily())
function persistNestDaily() {
  try { localStorage.setItem(TASK_KEY, JSON.stringify(nestDaily.value)) } catch { /* ignore */ }
}
function bumpTask(id) {
  if (!id || nestDaily.value.done[id]) return
  nestDaily.value.done[id] = true
  persistNestDaily()
}
function claimReward(task) {
  if (!nestDaily.value.done[task.id] || nestDaily.value.claimed.includes(task.id)) return
  nestDaily.value.claimed.push(task.id)
  persistNestDaily()
  addCoins(task.reward)
  showToast(`领到 ${task.reward} 游戏币啦 🎉`)
}
const tasks = computed(() => TASK_DEFS.map(t => ({
  ...t,
  done: !!nestDaily.value.done[t.id],
  claimed: nestDaily.value.claimed.includes(t.id)
})))
const taskDoneCount = computed(() => tasks.value.filter(t => t.done).length)

/* ---------------- 成就徽章墙 ---------------- */
const unlockedBadgeIds = ref([])
function refreshBadges() {
  const result = syncAchievements()
  unlockedBadgeIds.value = result.state.unlocked
  store.unlockedBadgeCount = result.state.unlocked.length
}
const badgeWall = computed(() => badges.slice(0, 8).map(b => ({ ...b, unlocked: unlockedBadgeIds.value.includes(b.id) })))

/* ---------------- 成长日记 ---------------- */
function pad(n) { return String(n).padStart(2, '0') }
function clockText(ts) {
  const d = new Date(ts)
  const today = new Date(); today.setHours(0, 0, 0, 0)
  if (ts >= today.getTime()) return `今天 ${pad(d.getHours())}:${pad(d.getMinutes())}`
  if (ts >= today.getTime() - 86400000) return `昨天 ${pad(d.getHours())}:${pad(d.getMinutes())}`
  return `${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}
const diaryList = computed(() => {
  const id = activePet.value?.id
  if (!id) return []
  const fromEvents = (home.value?.events || []).map(e => ({
    id: e.id, icon: e.icon, title: e.title, note: e.note, tone: e.tone, at: e.at, timeText: clockText(e.at)
  }))
  const fromDiary = store.diary.filter(d => Number(d.petId) === id).map(d => ({
    id: `d-${d.id}`, icon: d.mood || '📔', title: d.text, note: '成长日记', tone: 'pink',
    at: new Date(String(d.time || '').replace(/-/g, '/')).getTime() || Date.now(), timeText: d.time || ''
  }))
  return [...fromEvents, ...fromDiary].sort((a, b) => b.at - a.at).slice(0, 6)
})

/* ---------------- 串门 ---------------- */
const NEIGHBORS = [
  { id: 'n1', owner: '棉花糖妈妈', pet: resolvePet(1) || { name: '奶盖', image: '/pets/naigai.png', emoji: '🐱' }, moodFace: '😸', line: '欢迎来我家玩呀～' },
  { id: 'n2', owner: '布丁爸爸', pet: resolvePet(3) || { name: '布丁', image: '/pets/buding.png', emoji: '🐶' }, moodFace: '🐶', line: '要一起玩接球吗？' },
  { id: 'n3', owner: '芝麻姐姐', pet: resolvePet(2) || { name: '芝麻', image: '/pets/zhima.png', emoji: '🐈' }, moodFace: '😽', line: '有点慢热，但很温柔哦' }
].filter(n => n.pet)

const visitOpen = ref(false)
const visiting = ref(null)
const visitHearts = ref(false)
function openVisits() {
  visitOpen.value = true
  visiting.value = null
}
function enterNeighbor(n) {
  visiting.value = n
  visitHearts.value = false
  bumpTask('visit')
  say(`来 ${n.owner} 家串门啦～`)
}
function feedNeighbor() {
  if (!visiting.value) return
  burst(8)
  visitHearts.value = true
  setExpression('happy')
  addDiary({ petId: 0, petName: visiting.value.pet.name, text: `去「${visiting.value.owner}」家串门，投喂了 ${visiting.value.pet.name}`, mood: '🎁' })
  showToast(`${visiting.value.pet.name} 吃得可香啦，还冲你摇尾巴 🐾`)
  timers.push(setTimeout(() => { visitHearts.value = false }, 1600))
}
function playNeighbor() {
  if (!visiting.value) return
  burst(8)
  setExpression('happy')
  say(`${visiting.value.pet.name}：${visiting.value.line}`)
  timers.push(setTimeout(() => { visitHearts.value = false }, 1600))
  showToast(`和 ${visiting.value.pet.name} 玩得好开心 ✨`)
}

/* ---------------- 通用 ---------------- */
const toast = ref('')
let toastTimer = null
function showToast(msg) {
  toast.value = msg
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toast.value = '' }, 2400)
}
function goShop() { router.push('/shop') }
function goBackpack() { router.push('/backpack') }
function goAdopt() { router.push('/adopt') }
// 空窝体验：把示例宠物记为已领养，立即加载进小窝（随时可去领养专区正式领养）
function tryDemo() {
  const demoId = 1
  try {
    const ids = JSON.parse(localStorage.getItem('petAdopted') || '[]')
    const next = Array.isArray(ids) ? ids : []
    if (!next.includes(demoId)) next.push(demoId)
    localStorage.setItem('petAdopted', JSON.stringify(next))
  } catch { localStorage.setItem('petAdopted', JSON.stringify([demoId])) }
  myPets.value = loadAdoptedPets()
  activeId.value = demoId
  petHomeOf(demoId); decayPetHome(demoId)
  refreshBadges()
  say('欢迎来到小窝，快摸摸我吧～')
  showToast('✨ 已为你准备好示例小窝，开始体验吧')
}

onMounted(() => {
  document.body.classList.add('home-body')
  myPets.value.forEach(p => { petHomeOf(p.id); decayPetHome(p.id) })
  nestDaily.value = loadNestDaily()
  refreshBadges()
  scheduleIdle()
  window.addEventListener('storage', onStorage)
  if (route.query.welcome === '1' && activePet.value) {
    setTimeout(() => {
      say(`欢迎回家！我是${activePet.value.name}，以后请多多关照啦～`, 4200)
      burst(9)
      showToast(`🎉 领养成功！${activePet.value.name} 已经住进小窝啦`)
    }, 500)
  }
})
onBeforeUnmount(() => {
  document.body.classList.remove('home-body')
  window.removeEventListener('storage', onStorage)
  clearTimeout(bubbleTimer); clearTimeout(expressionTimer); clearTimeout(idleTimer); clearTimeout(toastTimer)
  timers.forEach(t => clearTimeout(t))
})
</script>

<template>
  <div class="nest-page app-bg">
    <main class="nest-main">
      <!-- ===== 顶部标题栏 ===== -->
      <header class="nest-head">
        <div class="nh-title">
          <span class="nh-icon" aria-hidden="true">🏡</span>
          <div>
            <h1>毛孩子的家 <span>🐾</span></h1>
            <p>这里是我们和毛孩子一起生活的小小天地～</p>
          </div>
        </div>
        <div class="nh-actions">
          <button type="button" class="nest-btn ghost" @click="goBackpack">
            <span aria-hidden="true">🎒</span> 背包
            <em v-if="bagTotalCount()">{{ bagTotalCount() }}</em>
          </button>
          <button type="button" class="nest-btn ghost" :disabled="!activePet || !decorList.length" @click="dressOpen = true">
            <span aria-hidden="true">🎀</span> 装扮
          </button>
          <button type="button" class="nest-btn primary" :disabled="!myPets.length" @click="openVisits">
            <span aria-hidden="true">🚪</span> 去串门
          </button>
        </div>
      </header>

      <!-- ===== 空窝 ===== -->
      <CuteEmpty
        v-if="!myPets.length"
        title="小窝还空着呢"
        desc="领养一只毛孩子，这里就会变得暖暖的～ 去领养专区挑一只吧！"
      >
        <div class="empty-actions">
          <button type="button" class="nest-btn primary lg" @click="goAdopt">🐾 去领养专区逛逛</button>
          <button type="button" class="nest-btn ghost lg" @click="tryDemo">✨ 先体验示例小窝</button>
        </div>
        <p class="empty-tip">领养成功后毛孩子会自动住进来；也可以先点「体验示例小窝」看看完整玩法～</p>
      </CuteEmpty>

      <template v-else>
        <!-- 切换毛孩子 -->
        <div v-if="myPets.length > 1" class="nest-switch" role="tablist" aria-label="切换毛孩子">
          <button
            v-for="p in myPets" :key="p.id" type="button" role="tab"
            class="ns-chip" :class="{ active: p.id === activePet?.id }"
            :aria-selected="p.id === activePet?.id" @click="activeId = p.id"
          >
            <img :src="p.image" :alt="p.name">
            <span>{{ p.name }}</span>
          </button>
        </div>

        <div class="nest-grid">
          <!-- ===== 左侧主区 ===== -->
          <div class="nest-left">
            <!-- 房间舞台 -->
            <section class="room-card">
              <div class="rc-stamp">🏠 {{ activePet.name }} 的小窝</div>
              <div
                class="room-stage"
                :class="[expression, { petting }]"
                role="button" tabindex="0"
                :aria-label="`摸摸 ${activePet.name}`"
                @click="petThePet" @keydown.enter="petThePet"
              >
                <span class="stage-sun" aria-hidden="true"></span>
                <span class="stage-window" aria-hidden="true"><i></i><i></i><b>☁️</b></span>
                <span class="stage-plant" aria-hidden="true">🪴</span>
                <span class="stage-frame" aria-hidden="true">🐾</span>

                <!-- 对话气泡 -->
                <span v-if="bubble" class="stage-bubble">{{ bubble }}</span>

                <!-- 粒子 / 飘字 -->
                <span
                  v-for="p in particles" :key="p.id" class="heart-particle"
                  :style="{ left: p.x + '%', '--dx': p.dx + 'px', '--rot': p.rot + 'deg', animationDelay: p.delay + 'ms' }"
                  aria-hidden="true"
                >{{ p.emoji }}</span>
                <span
                  v-for="f in floats" :key="f.id" class="stage-float" :class="f.tone"
                  aria-hidden="true"
                >{{ f.text }}</span>

                <!-- 软垫 -->
                <span class="pet-cushion" aria-hidden="true"></span>
                <!-- 宠物（3D 毛绒质感） -->
                <span class="plush-wrap">
                  <span class="plush-glow" aria-hidden="true"></span>
                  <img class="plush-pet" :src="activePet.image" :alt="activePet.name">
                  <span v-if="outfitItem" class="plush-outfit" :class="outfitItem.id === 'crown' ? 'head' : 'neck'" aria-hidden="true">
                    <ItemArt :art="outfitItem.art" />
                  </span>
                  <span class="plush-face" aria-hidden="true">{{ moodFace }}</span>
                </span>
                <span class="pet-nameplate">
                  <strong>{{ activePet.name }}</strong>
                  <small>{{ moodFace }} {{ moodText }}</small>
                </span>
              </div>
              <p class="rc-hint">👆 点一点毛孩子，摸摸 TA 会有爱心飘出来哦～</p>
            </section>

            <!-- 四条状态条 -->
            <section class="stats-card">
              <div class="sc-head">
                <h2>📊 今日状态</h2>
                <span class="sc-note" :class="{ low: lowestStat < 35 }">
                  {{ lowestStat < 35 ? '有状态偏低啦，快照顾一下 TA' : '状态很棒，继续保持～' }}
                </span>
              </div>
              <div class="stat-list">
                <div v-for="s in stats" :key="s.key" class="stat-row" :class="[s.tone, { low: s.value < 35 }]">
                  <span class="sr-icon" aria-hidden="true">{{ s.icon }}</span>
                  <span class="sr-label">{{ s.label }}</span>
                  <span class="sr-track">
                    <span class="sr-fill" :style="{ width: s.value + '%' }"></span>
                  </span>
                  <strong class="sr-num">{{ s.value }}</strong>
                </div>
              </div>
              <div class="stat-actions">
                <button type="button" class="nest-btn sm mint" :disabled="cleaning" @click="cleanNest">🧹 打扫小窝</button>
                <button type="button" class="nest-btn sm ghost" @click="goShop">🛍️ 道具补给</button>
              </div>
            </section>

            <!-- 成长日记 -->
            <section class="diary-card">
              <div class="dc-head">
                <h2>📔 成长日记</h2>
                <span class="dc-count">{{ diaryList.length }} 条记录</span>
              </div>
              <ul v-if="diaryList.length" class="diary-list">
                <li v-for="d in diaryList" :key="d.id" class="diary-item" :class="d.tone">
                  <span class="di-icon" aria-hidden="true">{{ d.icon }}</span>
                  <span class="di-copy">
                    <strong>{{ d.title }}</strong>
                    <small v-if="d.note">{{ d.note }}</small>
                  </span>
                  <time>{{ d.timeText }}</time>
                </li>
              </ul>
              <p v-else class="diary-empty">还没有记录～ 摸摸 TA、喂顿饭，日常小事都会自动写进来 🐾</p>
            </section>
          </div>

          <!-- ===== 右侧三栏 ===== -->
          <aside class="nest-right">
            <!-- 每日任务 -->
            <section class="side-card tasks-card">
              <div class="side-head">
                <h2>✅ 每日任务</h2>
                <span class="side-chip">{{ taskDoneCount }}/{{ tasks.length }}</span>
              </div>
              <ul class="task-list">
                <li v-for="t in tasks" :key="t.id" class="task-item" :class="{ done: t.done && !t.claimed }">
                  <span class="ti-icon" aria-hidden="true">{{ t.icon }}</span>
                  <span class="ti-copy">
                    <strong>{{ t.name }}</strong>
                    <small>{{ t.desc }}</small>
                  </span>
                  <button
                    type="button" class="ti-btn"
                    :class="{ ready: t.done && !t.claimed, claimed: t.claimed }"
                    :disabled="!t.done || t.claimed"
                    @click="claimReward(t)"
                  >
                    {{ t.claimed ? '已领取' : t.done ? `+${t.reward}币` : '未完成' }}
                  </button>
                </li>
              </ul>
            </section>

            <!-- 道具背包 -->
            <section class="side-card bag-card">
              <div class="side-head">
                <h2>🎒 道具背包</h2>
                <button type="button" class="side-link" @click="goShop">商城 ›</button>
              </div>
              <div v-if="store.backpack.length" class="bag-list">
                <button
                  v-for="it in store.backpack" :key="it.id" type="button"
                  class="bag-item" :disabled="it.count <= 0"
                  @click="useItem(shopItems.find(s => s.id === it.id))"
                >
                  <span class="bi-art"><ItemArt :art="shopItems.find(s => s.id === it.id)?.art" /></span>
                  <span class="bi-copy">
                    <strong>{{ shopItems.find(s => s.id === it.id)?.name || it.id }}</strong>
                    <small>{{ shopItems.find(s => s.id === it.id)?.effect || '好用的小道具' }}</small>
                  </span>
                  <span class="bi-count">×{{ it.count }}</span>
                </button>
              </div>
              <div v-else class="bag-empty">
                <span>背包空空的，去商城给 TA 备点小礼物吧～</span>
                <button type="button" class="nest-btn sm primary" @click="goShop">去商城逛逛</button>
              </div>
            </section>

            <!-- 成就徽章墙 -->
            <section class="side-card badge-card">
              <div class="side-head">
                <h2>🏅 成就徽章墙</h2>
                <span class="side-chip">{{ unlockedBadgeIds.length }}/{{ badges.length }}</span>
              </div>
              <div class="badge-grid">
                <div
                  v-for="b in badgeWall" :key="b.id" class="badge-cell"
                  :class="{ locked: !b.unlocked }" :style="{ '--badge-color': b.color }"
                  :title="`${b.name} · ${b.desc}`"
                >
                  <span class="bc-icon">{{ b.unlocked ? b.icon : '🔒' }}</span>
                  <small>{{ b.name }}</small>
                </div>
              </div>
            </section>
          </aside>
        </div>
      </template>
    </main>

    <!-- ===== 装扮弹窗 ===== -->
    <Teleport to="body">
      <div v-if="dressOpen" class="nest-mask" @click.self="dressOpen = false">
        <div class="nest-modal" role="dialog" aria-modal="true">
          <header class="nm-head">
            <span class="nm-icon">🎀</span>
            <div><strong>宠物装扮</strong><small>点击穿戴，毛孩子身上会实时显示哦</small></div>
            <button type="button" class="nm-close" aria-label="关闭" @click="dressOpen = false">✕</button>
          </header>
          <div v-if="decorList.length" class="dress-grid">
            <button
              v-for="it in decorList" :key="it.id" type="button"
              class="dress-item" :class="{ on: home?.outfit === it.id }"
              @click="toggleOutfit(it.meta)"
            >
              <span class="di-art"><ItemArt :art="it.meta.art" /></span>
              <strong>{{ it.meta.name }}</strong>
              <small>持有 ×{{ it.count }}</small>
              <span class="di-tag">{{ home?.outfit === it.id ? '佩戴中' : '点击穿戴' }}</span>
            </button>
          </div>
          <CuteEmpty v-else compact title="还没有装饰道具" desc="去积分商城挑个小皇冠或领巾吧～">
            <button type="button" class="nest-btn primary" @click="goShop">去商城逛逛</button>
          </CuteEmpty>
        </div>
      </div>
    </Teleport>

    <!-- ===== 串门弹窗 ===== -->
    <Teleport to="body">
      <div v-if="visitOpen" class="nest-mask" @click.self="visitOpen = false">
        <div class="nest-modal" role="dialog" aria-modal="true">
          <header class="nm-head">
            <span class="nm-icon mint">🚪</span>
            <div><strong>{{ visiting ? `在「${visiting.owner}」家串门` : '去串门' }}</strong><small>{{ visiting ? '给邻居家的毛孩子投喂、互动吧' : '挑一位邻居，去 TA 家看看毛孩子～' }}</small></div>
            <button type="button" class="nm-close" aria-label="关闭" @click="visitOpen = false">✕</button>
          </header>

          <div v-if="!visiting" class="neighbor-list">
            <button v-for="n in NEIGHBORS" :key="n.id" type="button" class="neighbor-item" @click="enterNeighbor(n)">
              <img :src="n.pet.image" :alt="n.pet.name">
              <span class="ni-copy">
                <strong>{{ n.pet.name }} <em>· {{ n.owner }}</em></strong>
                <small>{{ n.line }}</small>
              </span>
              <span class="ni-go">串门 ›</span>
            </button>
          </div>

          <div v-else class="visit-room">
            <div class="vr-stage">
              <span class="vr-cushion" aria-hidden="true"></span>
              <img :src="visiting.pet.image" :alt="visiting.pet.name">
              <span v-if="visitHearts" class="vr-heart" aria-hidden="true">💗💖💕</span>
              <span v-if="bubble" class="stage-bubble">{{ bubble }}</span>
            </div>
            <p class="vr-name">{{ visiting.moodFace }} 我是{{ visiting.pet.name }}，{{ visiting.line }}</p>
            <div class="vr-actions">
              <button type="button" class="nest-btn primary" @click="feedNeighbor">🎁 投喂小零食</button>
              <button type="button" class="nest-btn mint" @click="playNeighbor">🎾 一起玩一会儿</button>
              <button type="button" class="nest-btn ghost" @click="visiting = null">‹ 换个邻居</button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <div class="nest-toast" :class="{ show: toast }">{{ toast }}</div>
  </div>
</template>

<style scoped>
:global(body.home-body) { display: block; align-items: initial; justify-content: initial; padding: 0; }

.nest-page { min-height: 100vh; font-family: var(--font-body); color: var(--text-1); }
.empty-actions { display: flex; gap: 12px; flex-wrap: wrap; justify-content: center; }
.empty-tip { margin: 12px 0 0; font-size: 10.5px; font-weight: 700; color: var(--text-3); text-align: center; }
.nest-main { max-width: var(--layout-max); margin: 0 auto; padding: var(--layout-pad-top) var(--layout-pad-x) var(--layout-pad-bottom); }

/* ===== 顶部 ===== */
.nest-head { display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; margin-bottom: 20px; }
.nh-title { display: flex; align-items: center; gap: 13px; }
.nh-icon { width: 50px; height: 50px; flex: 0 0 auto; display: grid; place-items: center; font-size: 25px; background: var(--yellow); border: var(--line); border-radius: 15px; box-shadow: var(--shadow-2); }
.nh-title h1 { margin: 0 0 3px; font-size: 30px; letter-spacing: 0.4px; }
.nh-title h1 span { color: var(--pink); }
.nh-title p { margin: 0; font-size: 12px; font-weight: 700; color: var(--text-2); }
.nh-actions { display: flex; gap: 9px; flex-wrap: wrap; }

/* ===== 通用按钮 ===== */
.nest-btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  padding: 9px 15px; font: inherit; font-size: 12.5px; font-weight: 900; color: var(--ink);
  background: #fff; border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-1);
  cursor: pointer; transition: transform 0.16s var(--ease-pop), box-shadow 0.16s ease, background-color 0.16s ease;
}
.nest-btn:hover:not(:disabled) { transform: translateY(-3px); box-shadow: var(--shadow-3); }
.nest-btn:active:not(:disabled) { transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }
.nest-btn:disabled { opacity: 0.45; cursor: not-allowed; box-shadow: 2px 2px 0 var(--ink); }
.nest-btn.primary { background: var(--yellow); }
.nest-btn.mint { background: var(--mint); }
.nest-btn.ghost { background: #fff; }
.nest-btn.lg { padding: 12px 22px; font-size: 14px; }
.nest-btn.sm { padding: 6px 11px; font-size: 11px; border-radius: 10px; }
.nest-btn em { display: inline-grid; place-items: center; min-width: 18px; height: 18px; padding: 0 4px; font-size: 9px; font-style: normal; background: var(--pink); border: 2px solid var(--ink); border-radius: 999px; }

/* ===== 切换 ===== */
.nest-switch { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px; }
.ns-chip {
  display: inline-flex; align-items: center; gap: 7px; padding: 4px 13px 4px 4px;
  font: inherit; font-size: 12px; font-weight: 900; color: var(--ink); background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.16); border-radius: 999px; cursor: pointer; transition: 0.16s;
}
.ns-chip img { width: 28px; height: 28px; object-fit: contain; }
.ns-chip:hover { border-color: var(--ink); transform: translateY(-2px); }
.ns-chip.active { background: var(--yellow); border-color: var(--ink); box-shadow: 2px 2px 0 var(--ink); }

/* ===== 布局 ===== */
.nest-grid { display: grid; grid-template-columns: minmax(0, 1.6fr) minmax(300px, 1fr); gap: 20px; align-items: start; }
.nest-left { display: grid; gap: 18px; min-width: 0; }
.nest-right { display: grid; gap: 16px; min-width: 0; }

.room-card, .stats-card, .diary-card, .side-card {
  background: #fffdf6; border: var(--line); border-radius: var(--r-lg);
  box-shadow: var(--shadow-2), inset 0 2px 0 rgba(255, 255, 255, 0.9);
}

/* ===== 房间舞台 ===== */
.room-card { position: relative; padding: 14px 16px 12px; }
.rc-stamp {
  position: absolute; right: -8px; top: -12px; z-index: 3;
  padding: 5px 13px; font-size: 11px; font-weight: 900; color: var(--ink);
  background: var(--pink-soft); border: var(--line); border-radius: 999px; box-shadow: var(--shadow-1); transform: rotate(4deg);
}
.room-stage {
  position: relative; height: 340px; overflow: hidden; cursor: pointer;
  background: linear-gradient(#fff7e6, #ffeacd); border: var(--line); border-radius: 14px; isolation: isolate;
}
.room-stage::before {
  content: ''; position: absolute; inset: 0 0 34% 0;
  background-image: radial-gradient(rgba(232, 190, 130, 0.6) 1.4px, transparent 1.4px); background-size: 18px 18px; opacity: 0.55;
}
.room-stage::after {
  content: ''; position: absolute; left: 0; right: 0; bottom: 0; height: 34%;
  background: repeating-linear-gradient(92deg, #f8ddb5 0 34px, #f3d2a5 34px 36px); border-top: 2px solid var(--ink);
}
.stage-sun { position: absolute; right: 26px; top: 22px; width: 42px; height: 42px; border-radius: 50%; background: var(--yellow); border: var(--line); box-shadow: 0 0 0 10px rgba(255, 216, 77, 0.25); }
.stage-window { position: absolute; left: 20px; top: 20px; width: 96px; height: 80px; background: linear-gradient(#d9f1ff, #eefaff); border: var(--line); border-radius: 12px; overflow: hidden; box-shadow: var(--shadow-1); z-index: 1; }
.stage-window i:first-child { position: absolute; left: 50%; top: 0; bottom: 0; width: 2px; background: var(--ink); }
.stage-window i:nth-child(2) { position: absolute; left: 0; right: 0; top: 50%; height: 2px; background: var(--ink); }
.stage-window b { position: absolute; left: 8px; top: 8px; font-size: 16px; }
.stage-plant { position: absolute; right: 22px; top: 84px; font-size: 30px; z-index: 1; }
.stage-frame { position: absolute; right: 96px; top: 26px; width: 46px; height: 46px; display: grid; place-items: center; font-size: 20px; background: #fffdf6; border: var(--line); border-radius: 9px; box-shadow: var(--shadow-1); transform: rotate(5deg); z-index: 1; }

/* 气泡 */
.stage-bubble {
  position: absolute; left: 50%; top: 22px; transform: translateX(-50%); z-index: 6;
  max-width: 74%; padding: 8px 14px; font-size: 12px; font-weight: 900; line-height: 1.5; text-align: center;
  background: #fff; border: var(--line); border-radius: 13px; box-shadow: var(--shadow-1);
  animation: bubble-in 0.28s var(--ease-pop);
}
.stage-bubble::after { content: ''; position: absolute; left: 50%; bottom: -8px; width: 11px; height: 11px; background: #fff; border-right: var(--line); border-bottom: var(--line); transform: translateX(-50%) rotate(45deg); }
@keyframes bubble-in { from { opacity: 0; transform: translateX(-50%) scale(0.85) translateY(6px); } to { opacity: 1; transform: translateX(-50%) scale(1); } }

/* 软垫 */
.pet-cushion {
  position: absolute; left: 50%; bottom: 30px; width: 270px; height: 62px; transform: translateX(-50%); z-index: 2;
  background: radial-gradient(ellipse at 50% 30%, #fff0f6 0%, #ffc9de 70%, #f7a9c6 100%);
  border: var(--line); border-radius: 50%; box-shadow: var(--shadow-1), inset 0 -6px 0 rgba(43, 43, 43, 0.08);
}
.pet-cushion::after { content: ''; position: absolute; inset: 8px 22px; border: 2px dashed rgba(43, 43, 43, 0.22); border-radius: 50%; }

/* 3D 毛绒宠物 */
.plush-wrap { position: absolute; left: 50%; bottom: 56px; width: 216px; height: 216px; transform: translateX(-50%); z-index: 3; display: grid; place-items: end center; }
.plush-glow { position: absolute; left: 50%; top: 42%; width: 190px; height: 190px; transform: translate(-50%, -50%); border-radius: 50%; background: radial-gradient(circle, rgba(255, 255, 255, 0.85), rgba(255, 235, 200, 0) 70%); z-index: -1; animation: glow 3.4s ease-in-out infinite; }
.plush-pet {
  width: 100%; height: 100%; object-fit: contain;
  filter: drop-shadow(0 10px 9px rgba(120, 88, 50, 0.28)) drop-shadow(0 2px 0 rgba(255, 255, 255, 0.9));
  animation: floaty 3.6s ease-in-out infinite; transition: scale 0.25s var(--ease-pop);
}
.room-stage:hover .plush-pet { scale: 1.04; }
@keyframes floaty { 0%, 100% { transform: translateY(0) rotate(-1deg); } 50% { transform: translateY(-9px) rotate(1deg); } }
@keyframes glow { 0%, 100% { opacity: 0.7; transform: translate(-50%, -50%) scale(1); } 50% { opacity: 1; transform: translate(-50%, -50%) scale(1.08); } }

/* 表情动作 */
.room-stage.blink .plush-pet { animation: blink 0.5s ease-in-out 2; }
@keyframes blink { 0%, 100% { transform: scaleY(1); } 50% { transform: scaleY(0.94) scaleX(1.03); } }
.room-stage.sad .plush-pet { filter: drop-shadow(0 8px 8px rgba(120, 88, 50, 0.25)) grayscale(0.25); animation: sad-drop 2.6s ease-in-out infinite; }
@keyframes sad-drop { 0%, 100% { transform: translateY(0) rotate(0); } 50% { transform: translateY(3px) rotate(-2deg); } }
.room-stage.stretch .plush-pet { animation: stretch 1.8s ease-in-out; }
@keyframes stretch { 0%, 100% { transform: scale(1) translateY(0); } 45% { transform: scale(1.08, 0.92) translateY(6px) rotate(-3deg); } }
.room-stage.petting .plush-pet { animation: pat 0.7s var(--ease-pop); }
@keyframes pat { 0% { transform: scale(1); } 35% { transform: scale(1.09, 0.91) translateY(6px); } 65% { transform: scale(0.96, 1.07) translateY(-8px); } 100% { transform: scale(1); } }

.plush-outfit { position: absolute; width: 46px; height: 46px; z-index: 4; filter: drop-shadow(0 2px 2px rgba(43, 43, 43, 0.25)); animation: outfit-pop 0.4s var(--ease-pop); }
.plush-outfit.head { top: 10px; left: 50%; transform: translateX(-50%); }
.plush-outfit.neck { bottom: 56px; left: calc(50% - 46px); width: 40px; height: 40px; }
.plush-outfit :deep(.item-art) { width: 100%; height: 100%; }
@keyframes outfit-pop { from { opacity: 0; transform: translateX(-50%) scale(0.4) rotate(-14deg); } to { opacity: 1; transform: translateX(-50%) scale(1); } }
.plush-face { position: absolute; right: 14px; top: 26px; font-size: 22px; z-index: 5; filter: drop-shadow(0 2px 2px rgba(43, 43, 43, 0.2)); animation: face-pop 0.35s var(--ease-pop); }
@keyframes face-pop { from { transform: scale(0.5) rotate(-16deg); } to { transform: scale(1) rotate(0); } }

.pet-nameplate {
  position: absolute; left: 14px; bottom: 12px; z-index: 4; display: grid; gap: 1px;
  padding: 6px 12px; background: #fff; border: var(--line); border-radius: 12px; box-shadow: var(--shadow-1); max-width: 66%;
}
.pet-nameplate strong { font-size: 13px; }
.pet-nameplate small { font-size: 9.5px; font-weight: 700; color: var(--text-2); }

/* 粒子 / 飘字 */
.heart-particle { position: absolute; bottom: 150px; font-size: 19px; pointer-events: none; z-index: 8; animation: heart-up 1.4s ease-out forwards; }
@keyframes heart-up { 0% { opacity: 0; transform: translate(-50%, 0) scale(0.6); } 20% { opacity: 1; } 100% { opacity: 0; transform: translate(calc(-50% + var(--dx)), -110px) scale(1.2) rotate(var(--rot)); } }
.stage-float { position: absolute; left: 50%; bottom: 190px; transform: translateX(-50%); z-index: 9; padding: 4px 11px; font-size: 11px; font-weight: 900; white-space: nowrap; background: #fff; border: var(--line); border-radius: 999px; box-shadow: var(--shadow-1); animation: float-up 1.3s ease-out forwards; }
.stage-float.pink { background: var(--pink-soft); } .stage-float.blue { background: var(--blue-soft); } .stage-float.mint { background: var(--mint-soft); } .stage-float.yellow { background: var(--yellow-soft); }
@keyframes float-up { 0% { opacity: 0; transform: translate(-50%, 10px); } 20% { opacity: 1; } 100% { opacity: 0; transform: translate(-50%, -44px); } }
.rc-hint { margin: 10px 0 0; font-size: 10.5px; font-weight: 700; color: var(--text-3); text-align: center; }

/* ===== 状态条 ===== */
.stats-card { padding: 16px 18px; }
.sc-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 12px; }
.sc-head h2 { margin: 0; font-size: 16px; }
.sc-note { font-size: 10px; font-weight: 800; color: var(--ok); }
.sc-note.low { color: var(--danger); }
.stat-list { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 18px; }
.stat-row { display: grid; grid-template-columns: 24px 52px minmax(0, 1fr) 30px; align-items: center; gap: 8px; padding: 8px 10px; background: #fff; border: 2px solid rgba(43, 43, 43, 0.12); border-radius: 12px; }
.stat-row.low { border-color: rgba(216, 56, 91, 0.4); background: var(--danger-soft); }
.sr-icon { font-size: 15px; }
.sr-label { font-size: 11.5px; font-weight: 900; }
.sr-track { height: 13px; background: #f4ead9; border: 2px solid var(--ink); border-radius: 999px; overflow: hidden; }
.sr-fill { display: block; height: 100%; border-radius: 999px; transition: width 0.55s cubic-bezier(0.2, 1, 0.3, 1); }
.stat-row.pink .sr-fill { background: linear-gradient(90deg, #ffd3e2, var(--pink)); }
.stat-row.yellow .sr-fill { background: linear-gradient(90deg, #ffe9a3, #ffb056); }
.stat-row.blue .sr-fill { background: linear-gradient(90deg, #d6ebff, #7fb8ef); }
.stat-row.mint .sr-fill { background: linear-gradient(90deg, #c9f2df, var(--mint)); }
.sr-num { font-size: 13px; text-align: right; }
.stat-actions { display: flex; gap: 9px; margin-top: 12px; }

/* ===== 日记 ===== */
.diary-card { padding: 16px 18px; }
.dc-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 11px; }
.dc-head h2 { margin: 0; font-size: 16px; }
.dc-count { padding: 2px 9px; font-size: 10px; font-weight: 900; background: var(--pink-soft); border: 2px solid var(--ink); border-radius: 999px; }
.diary-list { display: grid; gap: 7px; margin: 0; padding: 0; list-style: none; }
.diary-item { display: flex; align-items: center; gap: 10px; padding: 8px 11px; background: #fff; border: 2px solid rgba(43, 43, 43, 0.1); border-radius: 11px; }
.di-icon { width: 28px; height: 28px; flex: 0 0 auto; display: grid; place-items: center; font-size: 14px; background: #fff3c9; border: 2px solid rgba(43, 43, 43, 0.18); border-radius: 9px; }
.diary-item.pink .di-icon { background: #ffe0ec; } .diary-item.blue .di-icon { background: #dcefff; } .diary-item.mint .di-icon { background: #d3f3e7; }
.di-copy { flex: 1; min-width: 0; display: grid; gap: 1px; }
.di-copy strong { font-size: 11.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.di-copy small { font-size: 9.5px; font-weight: 700; color: var(--text-3); }
.diary-item time { font-size: 9px; font-weight: 900; color: var(--text-3); flex: 0 0 auto; }
.diary-empty { margin: 0; padding: 16px; font-size: 11px; font-weight: 700; color: var(--text-3); text-align: center; background: #fffdf6; border: 2px dashed #e2cda8; border-radius: 12px; }

/* ===== 右侧卡片 ===== */
.side-card { padding: 15px 16px; }
.side-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 11px; }
.side-head h2 { margin: 0; font-size: 15px; }
.side-chip { padding: 2px 9px; font-size: 10px; font-weight: 900; background: var(--yellow-soft); border: 2px solid var(--ink); border-radius: 999px; }
.side-link { font: inherit; font-size: 10.5px; font-weight: 900; color: var(--text-2); background: none; border: none; cursor: pointer; }
.side-link:hover { color: var(--ink); text-decoration: underline; }

.task-list { display: grid; gap: 8px; margin: 0; padding: 0; list-style: none; }
.task-item { display: flex; align-items: center; gap: 9px; padding: 8px 10px; background: #fff; border: 2px solid rgba(43, 43, 43, 0.1); border-radius: 11px; }
.task-item.done { background: #fffaea; border-color: rgba(43, 43, 43, 0.28); }
.ti-icon { width: 28px; height: 28px; flex: 0 0 auto; display: grid; place-items: center; font-size: 14px; background: #fff3c9; border: 2px solid rgba(43, 43, 43, 0.18); border-radius: 9px; }
.ti-copy { flex: 1; min-width: 0; display: grid; gap: 1px; }
.ti-copy strong { font-size: 11.5px; }
.ti-copy small { font-size: 9.5px; font-weight: 700; color: var(--text-3); }
.ti-btn { flex: 0 0 auto; padding: 5px 9px; font: inherit; font-size: 10px; font-weight: 900; color: var(--ink); background: #efe7da; border: 2px solid rgba(43, 43, 43, 0.22); border-radius: 9px; cursor: not-allowed; opacity: 0.62; }
.ti-btn.ready { background: var(--yellow); border-color: var(--ink); box-shadow: 2px 2px 0 var(--ink); cursor: pointer; opacity: 1; animation: ready-pulse 1.8s ease-in-out infinite; }
.ti-btn.ready:hover { transform: translateY(-2px); }
.ti-btn.claimed { background: var(--mint-soft); opacity: 0.85; }
@keyframes ready-pulse { 0%, 100% { box-shadow: 2px 2px 0 var(--ink); } 50% { box-shadow: 2px 2px 0 var(--ink), 0 0 0 4px rgba(255, 216, 77, 0.35); } }

.bag-list { display: grid; gap: 7px; max-height: 250px; overflow-y: auto; }
.bag-item { display: grid; grid-template-columns: 38px minmax(0, 1fr) auto; align-items: center; gap: 9px; padding: 6px 8px; font: inherit; color: var(--ink); text-align: left; background: #fff; border: 2px solid rgba(43, 43, 43, 0.12); border-radius: 11px; cursor: pointer; transition: 0.15s; }
.bag-item:hover:not(:disabled) { border-color: var(--ink); transform: translateY(-2px); box-shadow: var(--shadow-1); }
.bag-item:disabled { opacity: 0.5; cursor: not-allowed; }
.bi-art { width: 38px; height: 38px; display: grid; place-items: center; }
.bi-art :deep(.item-art) { width: 100%; height: 100%; }
.bi-copy { min-width: 0; display: grid; gap: 1px; }
.bi-copy strong { font-size: 11px; }
.bi-copy small { font-size: 9px; font-weight: 700; color: var(--text-3); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bi-count { padding: 1px 7px; font-size: 9px; font-weight: 900; background: var(--yellow); border: 2px solid var(--ink); border-radius: 999px; }
.bag-empty, .bag-empty span { display: grid; justify-items: center; gap: 9px; font-size: 10.5px; font-weight: 700; color: var(--text-3); text-align: center; padding: 8px 0; }

.badge-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.badge-cell { display: grid; justify-items: center; gap: 3px; padding: 9px 3px 7px; background: var(--badge-color, #fff3c9); border: 2px solid var(--ink); border-radius: 12px; box-shadow: var(--shadow-1); transition: transform 0.16s; animation: badge-bob 3.6s ease-in-out infinite; }
.badge-cell:hover { transform: translateY(-3px); }
.badge-cell:nth-child(2n) { animation-delay: 0.5s; }
.badge-cell.locked { background: #efe9df; border-style: dashed; box-shadow: none; filter: grayscale(1); opacity: 0.62; animation: none; }
.bc-icon { font-size: 21px; }
.badge-cell small { font-size: 8.5px; font-weight: 900; text-align: center; line-height: 1.2; }
@keyframes badge-bob { 0%, 100% { translate: 0 0; } 50% { translate: 0 -4px; } }

/* ===== 弹窗 ===== */
.nest-mask { position: fixed; inset: 0; z-index: 80; display: grid; place-items: center; padding: 20px; background: rgba(46, 34, 24, 0.42); backdrop-filter: blur(3px); }
.nest-modal { width: min(560px, 100%); max-height: 84vh; overflow: auto; padding: 20px 22px 22px; background: #fffdf6; border: var(--line); border-radius: var(--r-lg); box-shadow: var(--shadow-4); animation: modal-in 0.26s var(--ease-pop); }
@keyframes modal-in { from { opacity: 0; transform: translateY(16px) scale(0.96); } to { opacity: 1; transform: none; } }
.nm-head { display: flex; align-items: center; gap: 11px; margin-bottom: 16px; }
.nm-icon { width: 40px; height: 40px; flex: 0 0 auto; display: grid; place-items: center; font-size: 19px; background: var(--pink-soft); border: var(--line); border-radius: 12px; box-shadow: var(--shadow-1); }
.nm-icon.mint { background: var(--mint-soft); }
.nm-head > div { flex: 1; min-width: 0; display: grid; gap: 2px; }
.nm-head strong { font-size: 16px; }
.nm-head small { font-size: 10.5px; font-weight: 700; color: var(--text-3); }
.nm-close { width: 30px; height: 30px; flex: 0 0 auto; display: grid; place-items: center; font-size: 13px; color: var(--ink); background: #fff; border: var(--line); border-radius: 50%; cursor: pointer; }
.nm-close:hover { background: var(--pink-soft); transform: rotate(90deg); }

.dress-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.dress-item { display: grid; justify-items: center; gap: 3px; padding: 12px 7px 9px; font: inherit; color: var(--ink); background: #fff; border: 2px solid rgba(43, 43, 43, 0.14); border-radius: 12px; cursor: pointer; transition: 0.16s; }
.dress-item:hover { border-color: var(--ink); transform: translateY(-3px); box-shadow: var(--shadow-1); }
.dress-item.on { background: #fff6d9; border-color: var(--ink); box-shadow: var(--shadow-1); }
.di-art { width: 50px; height: 50px; display: grid; place-items: center; }
.di-art :deep(.item-art) { width: 100%; height: 100%; }
.dress-item strong { font-size: 11px; }
.dress-item small { font-size: 9px; font-weight: 700; color: var(--text-3); }
.di-tag { margin-top: 2px; padding: 1px 8px; font-size: 9px; font-weight: 900; background: #f0e5d2; border: 2px solid var(--ink); border-radius: 999px; }
.dress-item.on .di-tag { background: var(--yellow); }

.neighbor-list { display: grid; gap: 10px; }
.neighbor-item { display: flex; align-items: center; gap: 12px; padding: 11px 13px; font: inherit; color: var(--ink); text-align: left; background: #fff; border: var(--line); border-radius: 12px; box-shadow: var(--shadow-1); cursor: pointer; transition: 0.16s; }
.neighbor-item:hover { transform: translateY(-3px); box-shadow: var(--shadow-3); }
.neighbor-item img { width: 52px; height: 52px; object-fit: contain; }
.ni-copy { flex: 1; min-width: 0; display: grid; gap: 3px; }
.ni-copy strong { font-size: 13px; }
.ni-copy strong em { font-style: normal; font-size: 10px; font-weight: 700; color: var(--text-3); }
.ni-copy small { font-size: 10.5px; font-weight: 700; color: var(--text-2); }
.ni-go { font-size: 11px; font-weight: 900; }

.visit-room { display: grid; justify-items: center; gap: 12px; }
.vr-stage { position: relative; width: 100%; height: 220px; display: grid; place-items: center; background: linear-gradient(#fff7e6, #ffeacd); border: var(--line); border-radius: 14px; overflow: hidden; }
.vr-cushion { position: absolute; bottom: 18px; left: 50%; width: 200px; height: 44px; transform: translateX(-50%); background: radial-gradient(ellipse at 50% 30%, #fff0f6, #f7a9c6); border: var(--line); border-radius: 50%; }
.vr-stage img { position: relative; z-index: 2; width: 170px; height: 170px; object-fit: contain; filter: drop-shadow(0 8px 8px rgba(120, 88, 50, 0.25)); animation: floaty 3.4s ease-in-out infinite; }
.vr-heart { position: absolute; top: 20px; z-index: 5; font-size: 24px; letter-spacing: 3px; animation: float-up 1.5s ease-out; }
.vr-name { margin: 0; font-size: 12px; font-weight: 800; }
.vr-actions { display: flex; gap: 9px; flex-wrap: wrap; justify-content: center; }

/* toast */
.nest-toast { position: fixed; left: 50%; bottom: 34px; z-index: 95; transform: translate(-50%, 20px); padding: 11px 20px; font-size: 12.5px; font-weight: 900; color: var(--ink); background: #fffdf6; border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-3); opacity: 0; pointer-events: none; transition: 0.25s var(--ease-pop); }
.nest-toast.show { opacity: 1; transform: translate(-50%, 0); }

/* ===== 响应式 ===== */
@media (max-width: 1040px) {
  .nest-grid { grid-template-columns: minmax(0, 1fr); }
  .nest-right { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .badge-card { grid-column: 1 / -1; }
}
@media (max-width: 720px) {
  .nest-main { padding: 22px 14px 70px; }
  .nh-title h1 { font-size: 24px; }
  .nest-right { grid-template-columns: minmax(0, 1fr); }
  .badge-card { grid-column: auto; }
  .stat-list { grid-template-columns: minmax(0, 1fr); }
  .room-stage { height: 300px; }
  .plush-wrap { width: 186px; height: 186px; }
  .pet-cushion { width: 226px; }
  .dress-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 480px) {
  .room-stage { height: 268px; }
  .plush-wrap { width: 158px; height: 158px; }
  .stage-frame, .stage-plant { display: none; }
  .pet-nameplate small { display: none; }
}
</style>
