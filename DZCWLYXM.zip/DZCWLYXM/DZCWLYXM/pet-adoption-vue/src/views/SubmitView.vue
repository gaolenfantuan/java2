<script setup>
import { onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import '../page.css'

const notices = [
  { icon: '📋', title: '送养条件', text: '宠物需满 6 周龄、身体健康、无严重传染病；请如实告知性格与健康状况。' },
  { icon: '🔍', title: '审核规则', text: '我们会对每份送养申请进行资料审核与实地回访，审核通过后会发布到领养专区。' },
  { icon: '⚠️', title: '注意事项', text: '请勿用于商业繁殖或贩卖，送养后需配合定期回访，确保毛孩子 welfare。' }
]
const KEY = 'submissionRecords'
const records = ref([])
const form = reactive({ name: '', breed: '', age: '', gender: '妹妹', health: '', reason: '', contact: '', photo: '' })
const agreed = ref(false)
const showSuccess = ref(false)
const toastText = ref('')
let toastTimer = null

const emojis = ['🐱', '🐶', '🐰', '🐹', '🐾']

function load() {
  try {
    const r = JSON.parse(localStorage.getItem(KEY) || '[]')
    records.value = Array.isArray(r) ? r : []
  } catch { records.value = [] }
}

function submit() {
  if (!agreed.value) { showToast('请先阅读并勾选送养须知～'); return }
  if (!form.name.trim() || !form.breed.trim() || !form.reason.trim() || !form.contact.trim()) {
    showToast('请填写宠物名字、品种、送养原因和联系方式～'); return
  }
  records.value = [{ ...form, time: new Date().toLocaleString('zh-CN'), status: '审核中' }, ...records.value]
  localStorage.setItem(KEY, JSON.stringify(records.value))
  showSuccess.value = true
  Object.assign(form, { name: '', breed: '', age: '', gender: '妹妹', health: '', reason: '', contact: '', photo: '' })
  agreed.value = false
}

function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2400)
}

onMounted(() => { document.body.classList.add('home-body'); load() })
onBeforeUnmount(() => { document.body.classList.remove('home-body'); clearTimeout(toastTimer) })
</script>

<template>
  <div class="app-bg fun-page">
    <main class="fun-main">
      <div class="fun-head">
        <h1>送养投稿 <span>✍️</span></h1>
        <p>给毛孩子找一个温暖的家，从认真填写送养申请开始～</p>
      </div>

      <!-- 送养须知 -->
      <section class="notice-grid">
        <div v-for="n in notices" :key="n.title" class="notice-card fun-card">
          <span class="notice-icon">{{ n.icon }}</span>
          <h3>{{ n.title }}</h3>
          <p>{{ n.text }}</p>
        </div>
      </section>

      <!-- 送养表单 -->
      <section class="form-card fun-card">
        <h2>📝 送养申请表单</h2>
        <div class="fun-form">
          <div class="form-row">
            <label><span>宠物名字</span><input v-model="form.name" type="text" placeholder="如：小咪"></label>
            <label><span>品种</span><input v-model="form.breed" type="text" placeholder="如：中华田园猫"></label>
          </div>
          <div class="form-row">
            <label><span>年龄</span><input v-model="form.age" type="text" placeholder="如：6 个月"></label>
            <label><span>性别</span><select v-model="form.gender"><option>妹妹</option><option>弟弟</option></select></label>
          </div>
          <label><span>健康情况</span><input v-model="form.health" type="text" placeholder="是否绝育/疫苗/有无疾病"></label>
          <label><span>送养原因</span><textarea v-model="form.reason" rows="3" placeholder="请如实说明送养原因..."></textarea></label>
          <label><span>联系方式</span><input v-model="form.contact" type="text" placeholder="手机号 / 微信"></label>
          <label>
            <span>宠物照片（选择卡通图标作示意）</span>
            <div class="photo-pick">
              <button v-for="e in emojis" :key="e" type="button" class="emoji-opt" :class="{ active: form.photo === e }" @click="form.photo = e">{{ e }}</button>
              <span class="photo-tip">真实项目中可替换为文件上传</span>
            </div>
          </label>
          <label class="agree"><input v-model="agreed" type="checkbox"><span>我已阅读并同意上方送养须知</span></label>
        </div>
        <button type="button" class="fun-btn submit-btn" @click="submit">提交送养申请 ✓</button>
      </section>

      <!-- 投稿记录 -->
      <section v-if="records.length" class="record-section fun-card">
        <h2>📄 我的投稿记录 <span class="go-my" @click="$router.push('/my-pets')">去个人中心查看 →</span></h2>
        <div v-for="(r, i) in records" :key="i" class="record-item">
          <span class="record-pet">{{ r.photo || '🐾' }} {{ r.name }} · {{ r.breed }}</span>
          <span class="record-status">⏳ {{ r.status }}</span>
          <small>{{ r.time }}</small>
        </div>
      </section>
    </main>

    <!-- 成功提示 -->
    <div v-if="showSuccess" class="fun-mask" @click.self="showSuccess = false">
      <div class="fun-modal success-modal">
        <div class="success-emoji">🎉</div>
        <h2>提交成功！</h2>
        <p>你的送养申请已进入审核队列，志愿者会在 <strong>3-5 个工作日</strong> 内完成资料审核与联系。</p>
        <p class="sub">审核通过后，毛孩子就会出现在领养专区啦～ 请保持联系方式畅通！</p>
        <button type="button" class="fun-btn" @click="showSuccess = false">好的 🐾</button>
      </div>
    </div>

    <div class="fun-toast" :class="{ show: !!toastText }">🐾 {{ toastText }}</div>
  </div>
</template>

<style scoped>
.notice-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px; }
.notice-card { padding: 18px; }
.notice-icon { font-size: 30px; }
.notice-card h3 { margin: 8px 0 6px; font-size: 15px; }
.notice-card p { margin: 0; font-size: 11px; font-weight: 700; line-height: 1.7; color: var(--text-2); }
.form-card { padding: 24px; }
.form-card h2 { margin: 0 0 18px; font-size: 21px; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.photo-pick { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.emoji-opt { width: 42px; height: 42px; font-size: 22px; background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm); cursor: pointer; }
.emoji-opt.active { background: var(--yellow); box-shadow: 2px 2px 0 var(--ink); }
.photo-tip { font-size: 10px; color: var(--text-3); font-weight: 700; }
.agree { flex-direction: row !important; align-items: center; gap: 8px !important; margin-top: 4px; }
.agree input { width: 18px; height: 18px; accent-color: var(--pink); }
.submit-btn { margin-top: 20px; width: 100%; }
.record-section { padding: 22px; margin-top: 26px; }
.record-section h2 { margin: 0 0 14px; font-size: 20px; }
.go-my { font-size: 12px; color: var(--text-2); cursor: pointer; text-decoration: underline; }
.record-item { display: grid; grid-template-columns: 1fr auto auto; gap: 14px; align-items: center; padding: 10px 0; border-bottom: 2px dashed #e6d3b3; font-size: 13px; font-weight: 900; }
.record-status { padding: 3px 9px; font-size: 10px; background: var(--yellow); border: 2px solid var(--ink); border-radius: var(--r-sm); }
.record-item small { color: var(--text-3); font-weight: 700; }
.success-modal { text-align: center; }
.success-emoji { font-size: 64px; animation: pop 0.5s cubic-bezier(0.2, 1.6, 0.4, 1); }
@keyframes pop { from { transform: scale(0.3); } to { transform: scale(1); } }
.success-modal p { font-size: 13px; font-weight: 700; line-height: 1.8; }
.success-modal .fun-btn { margin-top: 12px; }
@media (max-width: 760px) { .notice-grid { grid-template-columns: 1fr; } .form-row { grid-template-columns: 1fr; } }
</style>
