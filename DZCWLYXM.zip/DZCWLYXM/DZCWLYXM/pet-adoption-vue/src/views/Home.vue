<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { homePets as pets, homeCategories as categories } from '../data/homePets'
import { pets as defaultPets } from '../data/pets'
import BadgeCelebration from '../components/BadgeCelebration.vue'
import CuteEmpty from '../components/CuteEmpty.vue'
import CoinIcon from '../components/CoinIcon.vue'
import HomeContentBoards from '../components/HomeContentBoards.vue'
import HomeContentPopup from '../components/HomeContentPopup.vue'
import { recordMatchComplete, syncAchievements } from '../utils/achievements'
import { store, ensureDailyFresh } from '../store'
import { badges } from '../utils/achievements'
import { highlightHtml } from '../utils/highlight'

const router = useRouter()
const activeCategory = ref('全部')
const favorites = ref([])
const showBackTop = ref(false)
const celebrateBadge = ref(null)
let celebrateTimer = null

// 今日明星毛孩子：后台可调整排序，第一只即为明星宠物
const starPet = computed(() => pets.value[0] || defaultPets[0])
const starIntro = '超粘人的小奶盖，最爱趴在窗边晒太阳，还会用小脑袋蹭你的手心～'

// 首屏问候语：早上 / 下午 / 晚上三段自动切换
const greeting = computed(() => {
  const hour = new Date().getHours()
  if (hour < 12) return { emoji: '🌤️', text: '早上好，毛孩子们醒啦' }
  if (hour < 18) return { emoji: '☀️', text: '下午好，来陪毛孩子玩吧' }
  return { emoji: '🌙', text: '晚上好，毛孩子们想你了' }
})

// 主页佩戴中的徽章（在「我的毛孩子 - 我的徽章」里佩戴）
const wornBadge = computed(() => badges.find(b => b.id === store.wornBadge) || null)

// 领养流程四步走（纯展示，不涉及业务流程）
const adoptSteps = [
  { emoji: '🐾', title: '挑选毛孩子', desc: '逛一逛，遇见心动的那一只' },
  { emoji: '📝', title: '提交申请', desc: '填写简单资料，讲讲你的心意' },
  { emoji: '☎️', title: '沟通家访', desc: '聊聊养宠计划，确认彼此合适' },
  { emoji: '🏡', title: '签协议回家', desc: '签领养协议，带 TA 回家啦' }
]

// 领养前置须知弹窗
const noticeModalShow = ref(false)
const noticeTarget = ref(null)

// 领养弹窗状态
const adoptModalShow = ref(false)
const submitting = ref(false)
const adoptTarget = ref(null)
const adoptForm = reactive({ name: '', contact: '', message: '' })
const adoptAgreed = ref(false)
const adoptError = ref(false)
const applyStatuses = ref({})

// 心情彩蛋气泡
const eggPetId = ref(null)
const eggText = ref('')
const moodEggs = {
  '开心到冒泡': '我今天超开心，尾巴都摇成小螺旋桨啦！',
  '有点困': '呼噜呼噜…再做五分钟的星星梦💤',
  '摇尾巴中': '你回来啦！我的尾巴已经控制不住啦～',
  '想要零食': '闻到了吗？是零食的味道！分我一口嘛🥺',
  '啃胡萝卜中': '咔嚓咔嚓…胡萝卜真的超甜！要一起吗？',
  '跑轮中': '等等我！我跑完这一圈就过来找你🐹'
}

// 云撸宠：摸一下（1.5s 内防连点）
const patPetId = ref(null)
let patTimer = null
let patLocked = false

// 3D 旋转：仅在图片区跟随鼠标，移动端不触发
const tiltState = reactive({})
const tiltTimers = {}
const hasFinePointer = () =>
  typeof window !== 'undefined' && window.matchMedia?.('(hover: hover) and (pointer: fine)').matches

function handleTiltMove(pet, event) {
  if (!hasFinePointer()) return
  const rect = event.currentTarget.getBoundingClientRect()
  if (!rect.width || !rect.height) return
  const px = (event.clientX - rect.left) / rect.width
  const py = (event.clientY - rect.top) / rect.height
  const state = tiltState[pet.id] || (tiltState[pet.id] = { x: 0, y: 0, resetting: false })
  clearTimeout(tiltTimers[pet.id])
  state.resetting = false
  // 左右移动 → Y 轴旋转；上下移动 → X 轴俯仰
  state.y = (px - 0.5) * 80
  state.x = (0.5 - py) * 52
}

function resetTilt(pet) {
  const state = tiltState[pet.id]
  if (!state) return
  clearTimeout(tiltTimers[pet.id])
  state.resetting = true
  state.x = 0
  state.y = 0
  tiltTimers[pet.id] = setTimeout(() => { state.resetting = false }, 650)
}

function resetAllTilt() {
  Object.keys(tiltState).forEach((id) => {
    const state = tiltState[id]
    if (state && (state.x || state.y)) {
      state.resetting = true
      state.x = 0
      state.y = 0
      clearTimeout(tiltTimers[id])
      tiltTimers[id] = setTimeout(() => { state.resetting = false }, 650)
    }
  })
}

// 轻提示
const toastText = ref('')
let eggTimer = null
let toastTimer = null

// 缘分毛孩子匹配测试
const matchModalShow = ref(false)
const currentQuestion = ref(0)
const matchAnswers = ref(Array(5).fill(null))
const matchResult = ref(null)

const matchQuestions = [
  {
    title: '周末最想怎么度过呀？',
    options: [
      { emoji: '🛋️', label: '窝在沙发上被毛孩子蹭蹭', tags: ['粘人', '温顺'] },
      { emoji: '🌳', label: '出门散步晒太阳', tags: ['阳光', '活泼'] },
      { emoji: '🧶', label: '在家拆一个新玩具', tags: ['好奇', '贪吃'] }
    ]
  },
  {
    title: '你心仪的毛孩子性格是？',
    options: [
      { emoji: '💕', label: '黏人小甜心', tags: ['粘人', '温顺'] },
      { emoji: '😼', label: '高冷小傲娇', tags: ['高冷', '安静'] },
      { emoji: '☀️', label: '活力小太阳', tags: ['阳光', '活泼'] }
    ]
  },
  {
    title: '最喜欢的互动方式是？',
    options: [
      { emoji: '🍿', label: '静静依偎在一起看剧', tags: ['安静', '粘人'] },
      { emoji: '🎾', label: '一起疯跑玩耍', tags: ['活泼', '阳光'] },
      { emoji: '🍪', label: '一起研究小零食', tags: ['贪吃', '好奇'] }
    ]
  },
  {
    title: '家里谁是撒娇小冠军？',
    options: [
      { emoji: '🥺', label: '软乎乎的贴贴怪', tags: ['粘人', '温顺'] },
      { emoji: '👀', label: '高冷但偷偷看着你', tags: ['高冷', '安静'] },
      { emoji: '🚀', label: '一刻不停的探险家', tags: ['好奇', '活泼'] }
    ]
  },
  {
    title: '如果它打翻了水杯，你会？',
    options: [
      { emoji: '🤗', label: '先抱起来耐心安慰', tags: ['温顺', '粘人'] },
      { emoji: '🧽', label: '笑着一起擦干净', tags: ['阳光', '活泼'] },
      { emoji: '🦴', label: '拿零食转移注意力', tags: ['贪吃', '好奇'] }
    ]
  }
]

const petTraits = {
  1: ['粘人', '温顺', '撒娇'],
  2: ['高冷', '安静', '慢热'],
  3: ['阳光', '活泼', '热情'],
  4: ['贪吃', '活泼', '好奇'],
  5: ['安静', '温顺', '慢热'],
  6: ['好奇', '活泼', '贪玩']
}

const matchComments = {
  1: '你和奶盖都是贴贴届冠军，注定要腻在一起啦～',
  2: '你懂芝麻的高冷，它也愿意只对你慢慢靠近🌙',
  3: '阳光发的快乐互相照亮，出门遛弯搭子就它了！',
  4: '一个爱吃一个爱玩，家里每天都会叮叮当当超热闹～',
  5: '安安静静的温柔最治愈，你们适合一起晒太阳发呆。',
  6: '好奇心满格组合！一起探索世界永远不会无聊🐹'
}

// ── 条件筛选：年龄区间 + 性格标签多选 ──
// 标签全部由现有 petTraits 派生、年龄由 age 文本解析，绝不动 pets.js 数据结构
const ageRanges = [
  { key: 'baby', label: '3 个月以内', min: 0, max: 3 },
  { key: 'child', label: '4 - 6 个月', min: 4, max: 6 },
  { key: 'teen', label: '7 - 12 个月', min: 7, max: 12 },
  { key: 'adult', label: '1 岁以上', min: 13, max: Infinity }
]
const traitOptions = ['粘人', '温顺', '活泼', '安静', '贪吃', '好奇']

const ageRange = ref('all')
const activeTraits = ref([])
const onlyFavorites = ref(false)

const activeAgeRange = computed(() => ageRanges.find(item => item.key === ageRange.value) || null)

const hasActiveFilter = computed(() =>
  ageRange.value !== 'all' || activeTraits.value.length > 0 || onlyFavorites.value
)

// 「3 个月」/「1 岁」→ 月龄；解析不出返回 null（不参与年龄筛选）
function petAgeInMonths(pet) {
  const matched = String(pet.age || '').match(/(\d+)\s*(个月|月|岁)/)
  if (!matched) return null
  const value = Number(matched[1])
  return matched[2] === '岁' ? value * 12 : value
}

function toggleTrait(tag) {
  activeTraits.value = activeTraits.value.includes(tag)
    ? activeTraits.value.filter(item => item !== tag)
    : [...activeTraits.value, tag]
}

function resetFilters() {
  ageRange.value = 'all'
  activeTraits.value = []
  onlyFavorites.value = false
}

function toggleFavoritesOnly() {
  onlyFavorites.value = !onlyFavorites.value
}

const filteredPets = computed(() => {
  const keyword = store.searchQuery.trim().toLowerCase()
  const range = activeAgeRange.value
  const traits = activeTraits.value
  return pets.value.filter(pet => {
    const matchCategory = activeCategory.value === '全部' || pet.category === activeCategory.value
    const matchKeyword = !keyword ||
      pet.name.toLowerCase().includes(keyword) ||
      pet.breed.toLowerCase().includes(keyword)
    if (!matchCategory || !matchKeyword) return false

    if (onlyFavorites.value && !isFavorite(pet.id)) return false

    if (range) {
      const months = petAgeInMonths(pet)
      if (months === null || months < range.min || months > range.max) return false
    }

    if (traits.length) {
      const petTags = petTraits[pet.id] || []
      if (!traits.some(tag => petTags.includes(tag))) return false
    }
    return true
  })
})

// 右侧悬浮侧栏：收藏数 / 领养申请进度（已提交「预约中」的数量）
const applyingCount = computed(() =>
  Object.values(applyStatuses.value).filter(status => status === '预约中').length
)

function goProgress() {
  router.push('/my-pets')
}

// 玩法入口：萌宠乐园 / 积分商城 / 我的背包
const bagCount = computed(() => store.backpack.reduce((sum, item) => sum + item.count, 0))
function goPlayground() {
  router.push('/playground')
}
function goShop() {
  router.push('/shop')
}
function goBackpack() {
  router.push('/backpack')
}

function goDetail(pet) {
  router.push(`/pet/${pet.id}`)
}

function isFavorite(id) {
  return favorites.value.includes(id)
}

function loadFavorites() {
  try {
    const saved = JSON.parse(localStorage.getItem('petFavorites') || '[]')
    favorites.value = Array.isArray(saved) ? saved : []
  } catch {
    favorites.value = []
  }
}

function toggleFavorite(id) {
  if (isFavorite(id)) {
    favorites.value = favorites.value.filter(item => item !== id)
  } else {
    favorites.value.push(id)
  }
  localStorage.setItem('petFavorites', JSON.stringify(favorites.value))
  refreshAchievements()
}

function handleScroll() {
  showBackTop.value = window.scrollY > window.innerHeight
}

function backToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

function refreshAchievements() {
  const result = syncAchievements()
  store.unlockedBadgeCount = result.state.unlocked.length
  if (result.newlyUnlocked.length) {
    celebrateBadge.value = result.newlyUnlocked[0]
    clearTimeout(celebrateTimer)
    celebrateTimer = setTimeout(() => { celebrateBadge.value = null }, 2600)
  }
}

function openMatchModal() {
  matchModalShow.value = true
  currentQuestion.value = 0
  matchAnswers.value = Array(matchQuestions.length).fill(null)
  matchResult.value = null
}

function closeMatchModal() {
  matchModalShow.value = false
}

function selectMatchOption(optionIndex) {
  matchAnswers.value[currentQuestion.value] = optionIndex
}

function nextMatchQuestion() {
  if (matchAnswers.value[currentQuestion.value] === null) return
  if (currentQuestion.value < matchQuestions.length - 1) {
    currentQuestion.value += 1
  }
}

function prevMatchQuestion() {
  if (currentQuestion.value > 0) currentQuestion.value -= 1
}

function finishMatch() {
  if (matchAnswers.value.some(answer => answer === null)) return

  const selectedTags = []
  matchAnswers.value.forEach((optionIndex, questionIndex) => {
    const option = matchQuestions[questionIndex].options[optionIndex]
    if (option) selectedTags.push(...option.tags)
  })

  let best = null
  pets.value.forEach(pet => {
    const traits = petTraits[pet.id] || []
    const hits = selectedTags.filter(tag => traits.includes(tag)).length
    const percent = Math.round((hits / selectedTags.length) * 100)
    if (!best || percent > best.percent) {
      best = { pet, percent, comment: matchComments[pet.id] || '你们看起来会很合拍哦～' }
    }
  })
  matchResult.value = best
  recordMatchComplete()
  refreshAchievements()
}

function resetMatch() {
  currentQuestion.value = 0
  matchAnswers.value = Array(matchQuestions.length).fill(null)
  matchResult.value = null
}

function goMatchPetDetail() {
  if (!matchResult.value) return
  const pet = matchResult.value.pet
  closeMatchModal()
  goDetail(pet)
}

function getPetStatus(id) {
  return applyStatuses.value[id] || '待领养'
}

function loadApplyStatuses() {
  try {
    const saved = JSON.parse(localStorage.getItem('petApplyStatuses') || '{}')
    applyStatuses.value = saved && typeof saved === 'object' ? saved : {}
  } catch {
    applyStatuses.value = {}
  }
}

function openNotice(pet) {
  noticeTarget.value = pet
  noticeModalShow.value = true
}

function closeNotice() {
  noticeModalShow.value = false
  noticeTarget.value = null
}

// 看完须知再进入正式表单
function confirmNotice() {
  const pet = noticeTarget.value
  noticeModalShow.value = false
  noticeTarget.value = null
  if (pet) openAdoptModal(pet)
}

function openAdoptModal(pet) {
  adoptTarget.value = pet
  adoptForm.name = ''
  adoptForm.contact = ''
  adoptForm.message = ''
  adoptAgreed.value = false
  adoptError.value = false
  adoptModalShow.value = true
}

function closeAdoptModal() {
  adoptModalShow.value = false
  adoptTarget.value = null
}

function submitAdopt() {
  if (!adoptAgreed.value) {
    adoptError.value = true
    return
  }
  if (!adoptForm.name.trim() || !adoptForm.contact.trim() || !adoptForm.message.trim()) {
    adoptError.value = true
    return
  }
  if (!adoptTarget.value) return

  if (submitting.value) return

  // 模拟提交请求：按钮进入 loading 态，避免重复点击
  submitting.value = true
  const target = adoptTarget.value
  setTimeout(() => {
    applyStatuses.value = {
      ...applyStatuses.value,
      [target.id]: '预约中'
    }
    localStorage.setItem('petApplyStatuses', JSON.stringify(applyStatuses.value))
    refreshAchievements()
    submitting.value = false
    closeAdoptModal()
    showToast('申请已提交啦，TA 正在等你哦～')
  }, 650)
}

// 角落小爪印彩蛋：点一下随机冒出一句撒娇台词
const eggPopped = ref(false)
let eggPopTimer = null
const eggLines = [
  '喵～被你发现啦！',
  '偷偷在你手心盖个章 🐾',
  '今天的幸运值 +1 ✨',
  '汪！带我去散步嘛',
  '这里有一只偷偷观察你的小家伙',
  '摸摸头，今天也要开心哦'
]

function patEgg() {
  eggPopped.value = true
  clearTimeout(eggPopTimer)
  eggPopTimer = setTimeout(() => { eggPopped.value = false }, 460)
  showToast(eggLines[Math.floor(Math.random() * eggLines.length)])
}

function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2400)
}

function showMoodEgg(pet) {
  eggText.value = moodEggs[pet.mood] || '我今天也很开心，带我回家好不好～'
  eggPetId.value = pet.id
  clearTimeout(eggTimer)
  eggTimer = setTimeout(() => { eggPetId.value = null }, 2000)
}

function patPet(pet) {
  if (patLocked) return
  patLocked = true
  patPetId.value = pet.id
  clearTimeout(patTimer)
  patTimer = setTimeout(() => {
    patPetId.value = null
    patLocked = false
  }, 1500)
}

// 登录页是居中的单屏布局，首页是滚动长页，进入时临时切换 body 布局
onMounted(() => document.body.classList.add('home-body'))
onBeforeUnmount(() => document.body.classList.remove('home-body'))

onMounted(() => {
  loadFavorites()
  ensureDailyFresh()
  window.addEventListener('scroll', handleScroll, { passive: true })
  window.addEventListener('mouseup', resetAllTilt)
})
onBeforeUnmount(() => {
  window.removeEventListener('scroll', handleScroll)
  window.removeEventListener('mouseup', resetAllTilt)
  Object.keys(tiltTimers).forEach((id) => clearTimeout(tiltTimers[id]))
})

onMounted(() => {
  loadApplyStatuses()
  refreshAchievements()
})
onBeforeUnmount(() => {
  clearTimeout(eggTimer)
  clearTimeout(toastTimer)
  clearTimeout(patTimer)
  clearTimeout(celebrateTimer)
  clearTimeout(eggPopTimer)
})
</script>

<template>
  <div class="home-page app-bg">
    <main class="home-main">
      <section class="hero">
        <div class="hero-copy">
          <span class="hero-tag">{{ greeting.emoji }} {{ greeting.text }}</span>
          <span v-if="wornBadge" class="hero-worn" :style="{ '--worn-color': wornBadge.color }">
            <span class="hw-medal" aria-hidden="true">{{ wornBadge.icon }}</span>
            佩戴中 · {{ wornBadge.name }}
          </span>
          <h1>挑一只毛孩子，带它回家吧！</h1>
          <p>每一个它，都在等一个你。先逛逛，喜欢就点进详情页认识一下～</p>
        </div>
        <div class="hero-sticker" aria-hidden="true">
          <span class="hero-dog">🐶</span>
          <span class="hero-cat">🐱</span>
          <span class="hero-recommend">🐾 今日推荐</span>
        </div>
      </section>

      <!-- 后台统一管理：首页轮播 + 首页公告 -->
      <HomeContentBoards placement="top" />

      <button type="button" class="match-entry" @click="openMatchModal">
        <span class="match-entry-spark" aria-hidden="true">✨</span>
        <span class="match-entry-copy">
          <strong>测测你的专属毛孩子</strong>
          <small>5 道萌系小题，找到命中注定的 TA 🐾</small>
        </span>
        <span class="match-entry-arrow" aria-hidden="true">→</span>
      </button>

      <!-- 每日赚币入口：测试卡片下方，通向萌宠乐园 -->
      <button type="button" class="game-entry" @click="goPlayground">
        <span class="game-entry-art" aria-hidden="true">
          <svg class="ge-pad" viewBox="0 0 48 32">
            <path
              d="M14 4h20c6 0 10 5 11 12l1 8c1 5-5 8-8 4l-4-5H14l-4 5c-3 4-9 1-8-4l1-8C4 9 8 4 14 4z"
              fill="#9fd3ff"
              stroke="#2b2b2b"
              stroke-width="2.6"
              stroke-linejoin="round"
            />
            <path d="M16 12v8M12 16h8" stroke="#2b2b2b" stroke-width="2.4" stroke-linecap="round" />
            <circle cx="32" cy="13" r="2.3" fill="#ff9ec4" stroke="#2b2b2b" stroke-width="1.8" />
            <circle cx="37" cy="18" r="2.3" fill="#ffd84d" stroke="#2b2b2b" stroke-width="1.8" />
          </svg>
          <span class="ge-coin"><CoinIcon :size="17" /></span>
          <span class="ge-spark">✨</span>
        </span>
        <span class="game-entry-copy">
          <span class="ge-title">
            萌宠乐园 · 每日赚币
            <em>NEW</em>
          </span>
          <small>玩 15 秒小游戏攒游戏币，去积分商城换零食和玩具</small>
          <span class="ge-tags">
            <em>今日已玩 {{ store.daily.games }} 局</em>
            <em>单局最高 +27 币</em>
            <em>每日任务再加 53 币</em>
          </span>
        </span>
        <span class="game-entry-side">
          <span class="ge-balance">
            <CoinIcon :size="17" />
            <strong>{{ store.coins }}</strong>
          </span>
          <span class="ge-go">去赚币 →</span>
        </span>
      </button>

      <section class="star-card" :style="{ '--star-color': starPet.color }">
        <div class="star-photo">
          <img v-if="starPet.image" :src="starPet.image" :alt="starPet.name">
          <span v-else class="star-emoji">{{ starPet.emoji }}</span>
        </div>
        <div class="star-copy">
          <span class="star-badge">✨ 今日明星毛孩子</span>
          <h2>{{ starPet.name }} <small>· {{ starPet.breed }}</small></h2>
          <p>{{ starIntro }}</p>
          <div class="star-tags">
            <span>{{ starPet.gender }}</span>
            <span>{{ starPet.age }}</span>
            <span>{{ starPet.personality }}</span>
          </div>
        </div>
        <button type="button" class="star-btn" @click="goDetail(starPet)">去看看 TA →</button>
      </section>

      <section class="step-bar" aria-label="领养流程">
        <div class="step-head">
          <h3>🐾 领养四步走</h3>
          <p>从心动到回家，每一步都有我们陪着</p>
        </div>
        <ol class="step-list">
          <li v-for="(step, index) in adoptSteps" :key="step.title" class="step-item">
            <span class="step-num" aria-hidden="true">{{ index + 1 }}</span>
            <span class="step-emoji" aria-hidden="true">{{ step.emoji }}</span>
            <strong>{{ step.title }}</strong>
            <small>{{ step.desc }}</small>
          </li>
        </ol>
      </section>

      <!-- 后台统一管理：推荐宠物 + 首页活动 + 首页小贴士 -->
      <HomeContentBoards placement="middle" />

      <section class="filter-bar" aria-label="宠物分类筛选">
        <button
          v-for="cat in categories"
          :key="cat"
          type="button"
          class="filter-btn"
          :class="{ active: activeCategory === cat }"
          @click="activeCategory = cat"
        >
          {{ cat }}
        </button>
      </section>

      <section class="pet-filter" aria-label="按年龄和性格筛选">
        <div class="pet-filter-head">
          <span class="pet-filter-title">🔍 帮你缩小一点范围</span>
          <button
            type="button"
            class="filter-clear"
            :disabled="!hasActiveFilter"
            @click="resetFilters"
          >↺ 重置筛选</button>
        </div>

        <div class="filter-row">
          <span class="filter-label">年龄</span>
          <div class="filter-chips">
            <button
              type="button"
              class="chip"
              :class="{ active: ageRange === 'all' }"
              @click="ageRange = 'all'"
            >不限</button>
            <button
              v-for="range in ageRanges"
              :key="range.key"
              type="button"
              class="chip"
              :class="{ active: ageRange === range.key }"
              @click="ageRange = range.key"
            >{{ range.label }}</button>
          </div>
        </div>

        <div class="filter-row">
          <span class="filter-label">性格<small>可多选</small></span>
          <div class="filter-chips">
            <button
              v-for="tag in traitOptions"
              :key="tag"
              type="button"
              class="chip"
              :class="{ active: activeTraits.includes(tag) }"
              @click="toggleTrait(tag)"
            >{{ tag }}</button>
          </div>
        </div>
      </section>

      <p class="result-hint">
        共 {{ filteredPets.length }} 位毛孩子等你认识 🐾
        <span v-if="onlyFavorites" class="hint-tag">只看收藏</span>
        <span v-else-if="hasActiveFilter" class="hint-tag">已按条件筛选</span>
      </p>

      <section class="pet-grid">
        <article
          v-for="pet in filteredPets"
          :key="pet.id"
          class="pet-card"
          :class="{ 'is-pat': patPetId === pet.id }"
          tabindex="0"
          role="button"
          :aria-label="`查看 ${pet.name} 的详情`"
          @click="goDetail(pet)"
          @keydown.enter="goDetail(pet)"
        >
          <div
            class="pet-photo"
            :style="{ '--pet-color': pet.color }"
            @mousemove="handleTiltMove(pet, $event)"
            @mouseleave="resetTilt(pet)"
          >
            <img
              v-if="pet.image"
              :src="pet.image"
              :alt="pet.name"
              :style="{
                '--tilt-x': (tiltState[pet.id]?.x || 0) + 'deg',
                '--tilt-y': (tiltState[pet.id]?.y || 0) + 'deg',
                transitionDuration: tiltState[pet.id]?.resetting ? '0.65s' : '0.12s'
              }"
            >
            <div v-else class="photo-placeholder">
              <span>{{ pet.emoji }}</span>
            </div>
            <button
              type="button"
              class="heart-btn"
              :class="{ active: isFavorite(pet.id) }"
              :aria-label="isFavorite(pet.id) ? `取消收藏 ${pet.name}` : `收藏 ${pet.name}`"
              @click.stop="toggleFavorite(pet.id)"
            >{{ isFavorite(pet.id) ? '♥' : '♡' }}</button>
            <span class="status-badge" :class="{ applied: getPetStatus(pet.id) === '预约中' }">{{ getPetStatus(pet.id) }}</span>
            <span
              class="mood-badge mood-egg-trigger"
              role="button"
              :aria-label="`看看 ${pet.name} 的心情`"
              @click.stop="showMoodEgg(pet)"
            >{{ pet.moodEmoji }} {{ pet.mood }}</span>
            <div v-if="eggPetId === pet.id" class="mood-egg">{{ eggText }}</div>

            <button
              type="button"
              class="pat-btn"
              :aria-label="`摸摸 ${pet.name} 的头`"
              @click.stop="patPet(pet)"
            >🤚 摸一下</button>

            <template v-if="patPetId === pet.id">
              <div class="pat-hearts" aria-hidden="true">
                <span>❤</span><span>💕</span><span>❤</span>
              </div>
              <div class="pat-paws" aria-hidden="true">
                <span>🐾</span><span>🐾</span><span>🐾</span>
              </div>
              <div class="pat-bubble">💖 蹭蹭你～</div>
            </template>
          </div>

          <div class="pet-body">
            <div class="pet-title">
              <h2 v-html="highlightHtml(pet.name, store.searchQuery)"></h2>
              <span class="pet-breed" v-html="highlightHtml(pet.breed, store.searchQuery)"></span>
            </div>
            <div class="pet-tags">
              <span class="pet-tag">{{ pet.gender }}</span>
              <span class="pet-tag">{{ pet.age }}</span>
              <span class="pet-tag">{{ pet.personality }}</span>
            </div>
            <div class="card-foot">
              <span class="category-chip">{{ pet.category }}</span>
              <button type="button" class="detail-btn" @click.stop="goDetail(pet)">查看详情 →</button>
              <button
                type="button"
                class="apply-btn"
                :disabled="getPetStatus(pet.id) === '预约中'"
                @click.stop="openNotice(pet)"
              >{{ getPetStatus(pet.id) === '预约中' ? '已申请 ✓' : '申请领养' }}</button>
            </div>
          </div>
        </article>
      </section>

      <CuteEmpty
        v-if="!filteredPets.length"
        variant="search"
        title="没有找到匹配的毛孩子 🐾"
        :desc="hasActiveFilter ? '试试放宽年龄或性格条件，说不定 TA 就在下一页' : '换个关键词试试，或者去领养专区逛逛吧'"
      >
        <button type="button" class="empty-reset" @click="resetFilters">重置筛选</button>
      </CuteEmpty>

      <!-- 后台统一管理：管理员自定义板块 -->
      <HomeContentBoards placement="extra" />
    </main>

    <aside class="side-dock" aria-label="快捷面板">
      <button
        type="button"
        class="dock-item"
        :class="{ active: onlyFavorites }"
        :aria-pressed="onlyFavorites"
        :aria-label="onlyFavorites ? '显示全部毛孩子' : '只看我收藏的毛孩子'"
        @click="toggleFavoritesOnly"
      >
        <span class="dock-icon" aria-hidden="true">{{ favorites.length ? '♥' : '♡' }}</span>
        <strong>{{ favorites.length }}</strong>
        <small>收藏</small>
      </button>

      <span class="dock-line" aria-hidden="true"></span>

      <button type="button" class="dock-item dock-progress" aria-label="查看领养申请进度" @click="goProgress">
        <span class="dock-icon paw" aria-hidden="true">🐾</span>
        <strong>{{ applyingCount }}</strong>
        <small>申请中</small>
      </button>

      <span class="dock-line" aria-hidden="true"></span>

      <!-- 游戏币余额：点一下去积分商城 -->
      <button type="button" class="dock-item dock-coins" aria-label="我的游戏币，去积分商城" @click="goShop">
        <span class="dock-coin">
          <CoinIcon :size="17" />
          <strong>{{ store.coins }}</strong>
        </span>
        <small>游戏币</small>
      </button>

      <!-- 背包快捷入口 -->
      <button type="button" class="dock-item" aria-label="打开我的背包" @click="goBackpack">
        <span class="dock-icon bag" aria-hidden="true">🎒</span>
        <strong>{{ bagCount }}</strong>
        <small>背包</small>
      </button>
    </aside>

    <!-- 角落小爪印彩蛋 -->
    <button
      type="button"
      class="paw-egg"
      :class="{ popped: eggPopped }"
      aria-label="偷偷点一下小爪印"
      @click="patEgg"
    >🐾</button>

    <button
      type="button"
      class="back-top"
      :class="{ show: showBackTop }"
      aria-label="回到顶部"
      @click="backToTop"
    >
      <span class="paw-toe toe-1"></span>
      <span class="paw-toe toe-2"></span>
      <span class="paw-toe toe-3"></span>
      <span class="paw-toe toe-4"></span>
      <span class="paw-pad">顶</span>
    </button>

    <div class="adopt-mask" :class="{ show: adoptModalShow }" @click.self="closeAdoptModal">
      <div v-if="adoptTarget" class="adopt-modal">
        <div class="adopt-icon">🐾</div>
        <h2>申请领养 {{ adoptTarget.name }}</h2>
        <p class="adopt-sub">填好小资料，让 TA 更快找到家～</p>

        <form @submit.prevent="submitAdopt">
          <label class="form-field">
            <span>姓名</span>
            <input v-model="adoptForm.name" type="text" placeholder="怎么称呼你呀？">
          </label>
          <label class="form-field">
            <span>联系方式</span>
            <input v-model="adoptForm.contact" type="text" placeholder="手机号或微信号">
          </label>
          <label class="form-field">
            <span>领养寄语</span>
            <textarea v-model="adoptForm.message" rows="3" placeholder="想对 TA 说点什么～"></textarea>
          </label>

          <div class="notice-box">
            <strong>领养须知</strong>
            <p>领养前请确认有稳定住所与陪伴时间；同意接受后续回访；请科学喂养、不离不弃。</p>
            <label class="notice-check">
              <input v-model="adoptAgreed" type="checkbox" @change="adoptError = false">
              我已阅读并同意以上领养须知
            </label>
          </div>

          <p v-if="adoptError" class="form-error">请先填好资料并勾选领养须知哦～</p>

          <div class="modal-actions">
            <button type="button" class="cancel-btn" @click="closeAdoptModal">再想想</button>
            <button type="submit" class="submit-btn" :disabled="!adoptAgreed || submitting">
              {{ submitting ? '提交中…' : '提交申请 →' }}
            </button>
          </div>
        </form>
      </div>
    </div>

    <div class="adopt-mask" :class="{ show: noticeModalShow }" @click.self="closeNotice">
      <div v-if="noticeTarget" class="notice-modal">
        <div class="notice-icon" aria-hidden="true">💡</div>
        <h2>领养 {{ noticeTarget.name }} 前，先说三件小事</h2>
        <ul class="notice-list">
          <li>
            <span aria-hidden="true">🏠</span>
            <div><strong>稳定住所</strong><small>租房需征得房东同意，避免中途二次转手</small></div>
          </li>
          <li>
            <span aria-hidden="true">⏰</span>
            <div><strong>每天陪伴</strong><small>毛孩子需要固定时间的陪伴、喂食与遛弯</small></div>
          </li>
          <li>
            <span aria-hidden="true">📞</span>
            <div><strong>接受回访</strong><small>我们会不定期问候 TA 的近况，一起把它养好</small></div>
          </li>
        </ul>
        <div class="modal-actions">
          <button type="button" class="cancel-btn" @click="closeNotice">再想想</button>
          <button type="button" class="submit-btn" @click="confirmNotice">我已了解，继续填表 →</button>
        </div>
      </div>
    </div>

    <div class="match-mask" :class="{ show: matchModalShow }" @click.self="closeMatchModal">
      <div class="match-modal">
        <button type="button" class="match-close" aria-label="关闭匹配测试" @click="closeMatchModal">×</button>

        <template v-if="!matchResult">
          <div class="match-head" aria-hidden="true">🐾💘🐾</div>
          <h2>缘分毛孩子匹配</h2>
          <p class="match-sub">回答 5 道小题，看看哪只 TA 和你最合拍～</p>

          <div class="match-progress" aria-hidden="true">
            <span
              v-for="(answer, index) in matchAnswers"
              :key="index"
              :class="{ done: answer !== null, current: index === currentQuestion }"
            ></span>
          </div>
          <p class="match-step">第 {{ currentQuestion + 1 }} / {{ matchQuestions.length }} 题</p>

          <div class="question-card" :key="currentQuestion">
            <p class="question-title">{{ matchQuestions[currentQuestion].title }}</p>
            <div class="option-list">
              <button
                v-for="(option, index) in matchQuestions[currentQuestion].options"
                :key="index"
                type="button"
                class="option-btn"
                :class="{ selected: matchAnswers[currentQuestion] === index }"
                @click="selectMatchOption(index)"
              >
                <span class="option-emoji" aria-hidden="true">{{ option.emoji }}</span>
                <span>{{ option.label }}</span>
              </button>
            </div>
          </div>

          <div class="match-actions">
            <button v-if="currentQuestion > 0" type="button" class="match-prev" @click="prevMatchQuestion">← 上一题</button>
            <button
              v-if="currentQuestion < matchQuestions.length - 1"
              type="button"
              class="match-next"
              :disabled="matchAnswers[currentQuestion] === null"
              @click="nextMatchQuestion"
            >下一题 →</button>
            <button
              v-else
              type="button"
              class="match-next"
              :disabled="matchAnswers[currentQuestion] === null"
              @click="finishMatch"
            >看看结果 →</button>
          </div>
        </template>

        <template v-else>
          <div class="result-card" :style="{ '--result-color': matchResult.pet.color }">
            <span class="result-badge">💘 命中注定的 TA</span>
            <div class="result-photo">
              <img v-if="matchResult.pet.image" :src="matchResult.pet.image" :alt="matchResult.pet.name">
              <span v-else aria-hidden="true">{{ matchResult.pet.emoji }}</span>
            </div>
            <h2>{{ matchResult.pet.name }}</h2>
            <p class="result-breed">{{ matchResult.pet.breed }} · {{ matchResult.pet.personality }}</p>
            <div class="result-score">
              <strong>{{ matchResult.percent }}%</strong>
              <span>契合度</span>
            </div>
            <p class="result-comment">{{ matchResult.comment }}</p>
            <div class="result-actions">
              <button type="button" class="result-again" @click="resetMatch">再测一次</button>
              <button type="button" class="result-go" @click="goMatchPetDetail">去看看它 →</button>
            </div>
          </div>
        </template>
      </div>
    </div>

    <BadgeCelebration
      v-if="celebrateBadge"
      :badge="celebrateBadge"
      @close="celebrateBadge = null"
    />

    <div class="cute-toast" :class="{ show: !!toastText }">🐾 {{ toastText }}</div>

    <!-- 后台统一管理：首页弹窗 -->
    <HomeContentPopup />
  </div>
</template>

<style scoped>
:global(body.home-body) {
  display: block;
  align-items: initial;
  justify-content: initial;
  padding: 0;
}

.home-page {
  min-height: 100vh;
  color: var(--text-1);
  font-family: var(--font-body);
}

.topbar {
  position: sticky;
  top: 0;
  z-index: 10;
  background: #fffdf6;
  border-bottom: 2px solid var(--ink);
  box-shadow: 0 5px 0 rgba(43, 43, 43, 0.08);
}

.topbar-inner {
  max-width: 1180px;
  margin: 0 auto;
  padding: 14px 22px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

.brand {
  display: flex;
  align-items: center;
  gap: 11px;
  font-size: 21px;
  font-weight: 900;
  letter-spacing: 0.5px;
}

.brand-badge {
  width: 42px;
  height: 42px;
  display: grid;
  place-items: center;
  background: var(--pink);
  border: var(--line);
  border-radius: var(--r-sm);
  font-size: 23px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-6deg);
}

.nav-actions {
  display: flex;
  gap: 12px;
}

.nav-btn {
  padding: 10px 18px;
  font: inherit;
  font-size: 14px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.nav-btn:hover {
  transform: translate(-2px, -2px);
  box-shadow: 6px 6px 0 var(--ink);
}

.nav-btn:active {
  transform: translate(4px, 4px);
  box-shadow: 1px 1px 0 var(--ink);
}

.nav-btn.mine { background: var(--mint); }
.nav-btn.logout { background: #ffc9cf; }

.home-main {
  width: 100%;
  max-width: var(--layout-max);
  margin: 0 auto;
  padding: var(--layout-pad-top) var(--layout-pad-x) var(--layout-pad-bottom);
}

.hero {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  padding: 30px 34px;
  margin-bottom: 30px;
  background: linear-gradient(125deg, #fff7dc 0%, #fff0bb 46%, #ffe6a8 100%);
  border: var(--line);
  border-radius: 26px;
  box-shadow: 5px 7px 0 var(--ink), 0 16px 34px rgba(222, 164, 90, 0.22);
  overflow: hidden;
  transition: transform 0.24s ease, box-shadow 0.24s ease;
}
.hero:hover {
  transform: translateY(-4px);
  box-shadow: 5px 11px 0 var(--ink), 0 22px 42px rgba(222, 164, 90, 0.28);
}

/* 淡波点 + 云朵肌理：只做背景层次，不参与点击 */
.hero::before,
.hero::after {
  content: "";
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.hero::before {
  background-image: radial-gradient(rgba(255, 255, 255, 0.85) 1.6px, transparent 1.7px);
  background-size: 22px 22px;
  opacity: 0.6;
}
.hero::after {
  background:
    radial-gradient(ellipse 86px 26px at 16% 82%, rgba(255, 255, 255, 0.62), transparent 72%),
    radial-gradient(ellipse 110px 32px at 62% 16%, rgba(255, 255, 255, 0.5), transparent 70%),
    radial-gradient(ellipse 70px 22px at 88% 74%, rgba(255, 255, 255, 0.46), transparent 72%);
}

.hero-copy { position: relative; z-index: 1; min-width: 0; }

/* 问候气泡：粉色卡通对话气泡 + 小尾巴，缓慢上浮轻晃 */
.hero-tag {
  position: relative;
  display: inline-block;
  padding: 7px 15px;
  margin-bottom: 14px;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: 18px 18px 18px 5px;
  box-shadow: 3px 4px 0 var(--ink);
  animation: hero-bubble-float 3.2s ease-in-out infinite;
}
.hero-tag::after {
  content: "";
  position: absolute;
  left: 12px;
  bottom: -8px;
  width: 12px;
  height: 12px;
  background: var(--pink);
  border-right: 2px solid var(--ink);
  border-bottom: 2px solid var(--ink);
  transform: rotate(45deg);
}
@keyframes hero-bubble-float {
  0%, 100% { transform: translate(0, 0) rotate(-2deg); }
  50% { transform: translate(7px, -5px) rotate(2deg); }
}

/* 佩戴中的徽章小标：跟在问候语后面，轻轻摇摆 */
.hero-worn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px 4px 5px;
  margin: 0 0 12px 8px;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 3px 3px 0 var(--ink);
  animation: worn-sway 3.4s ease-in-out infinite;
}
.hw-medal {
  width: 20px;
  height: 20px;
  display: grid;
  place-items: center;
  font-size: 11px;
  background: var(--worn-color, var(--yellow));
  border: 2px solid var(--ink);
  border-radius: 50%;
}
@keyframes worn-sway {
  0%, 100% { rotate: 2deg; }
  50% { rotate: -2deg; }
}

.hero h1 {
  margin: 0 0 8px;
  font-size: 38px;
  font-weight: 900;
  line-height: 1.24;
  letter-spacing: 1px;
  font-family: var(--font-display, var(--font-body));
  text-shadow: 2px 3px 0 rgba(255, 255, 255, 0.75);
  animation: hero-title-breathe 4.2s ease-in-out infinite;
}
@keyframes hero-title-breathe {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.022); }
}

.hero p {
  margin: 0;
  max-width: 560px;
  font-size: 13px;
  font-weight: 700;
  line-height: 1.85;
  letter-spacing: 0.3px;
  color: var(--text-2);
  opacity: 0.9;
}

.hero-sticker {
  position: relative;
  z-index: 1;
  flex-shrink: 0;
  width: 150px;
  height: 120px;
}

.hero-sticker .hero-dog,
.hero-sticker .hero-cat {
  position: absolute;
  font-size: 60px;
  filter: drop-shadow(5px 6px 0 rgba(43, 43, 43, 0.22));
  animation: bob 3s ease-in-out infinite;
}
.hero-sticker .hero-dog { left: 4px; top: 16px; transform: rotate(-12deg); }
.hero-sticker .hero-cat {
  right: 4px;
  top: 6px;
  font-size: 52px;
  animation-delay: 0.8s;
  transform: rotate(10deg);
}

/* 右上角爪印标签：圆角纸片 + 轻微放大反馈 */
.hero-recommend {
  position: absolute;
  right: -6px;
  top: 0;
  display: inline-flex;
  align-items: center;
  gap: 3px;
  padding: 5px 11px;
  font-size: 11px;
  font-weight: 900;
  white-space: nowrap;
  color: var(--ink);
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: 6px 16px 6px 16px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(6deg);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.hero-sticker .hero-recommend { animation: none; filter: none; }
.hero:hover .hero-recommend { transform: rotate(6deg) scale(1.08); box-shadow: 4px 5px 0 var(--ink); }

@keyframes bob {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -12px; }
}

.filter-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 18px;
}

.filter-btn {
  min-width: 92px;
  padding: 11px 20px;
  font: inherit;
  font-size: 15px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.filter-btn:hover { background: #fff6d9; transform: translate(-2px, -2px); box-shadow: 6px 6px 0 var(--ink); }

.filter-btn.active {
  background: var(--yellow);
  transform: translate(2px, 2px);
  box-shadow: 1px 1px 0 var(--ink);
}

.result-hint {
  margin: 0 0 18px;
  font-size: 13px;
  font-weight: 900;
  color: var(--text-2);
}

.pet-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(268px, 1fr));
  gap: 26px;
}

.pet-card {
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-2);
  overflow: hidden;
  cursor: pointer;
  outline: none;
  transition: transform 0.18s ease, box-shadow 0.18s ease;
  animation: card-in 0.45s cubic-bezier(0.2, 1.4, 0.4, 1) backwards;
}

.pet-card:hover,
.pet-card:focus-visible {
  transform: translate(-2px, -6px);
  box-shadow: 8px 11px 0 var(--ink);
}

.pet-card:active {
  transform: translate(0, -1px);
  box-shadow: 2px 3px 0 var(--ink);
}

@keyframes card-in {
  from { opacity: 0; transform: translateY(18px) scale(0.96); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}

.pet-photo {
  position: relative;
  height: 176px;
  display: grid;
  place-items: center;
  background: var(--pet-color);
  border-bottom: 2px solid var(--ink);
  overflow: hidden;
}

.pet-photo img {
  width: 70%;
  height: 70%;
  object-fit: contain;
}

.photo-placeholder {
  width: 100%;
  height: 100%;
  display: grid;
  place-items: center;
  background:
    radial-gradient(circle at 50% 120%, rgba(255, 255, 255, 0.65), transparent 60%),
    repeating-linear-gradient(45deg, rgba(255, 255, 255, 0.18) 0 12px, transparent 12px 24px);
}

.photo-placeholder span {
  font-size: 86px;
  line-height: 1;
  filter: drop-shadow(6px 8px 0 rgba(43, 43, 43, 0.2));
  transition: transform 0.2s;
}

.pet-card:hover .photo-placeholder span { transform: scale(1.08) rotate(-5deg); }

.mood-badge {
  position: absolute;
  left: 12px;
  top: 12px;
  padding: 6px 11px;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-5deg);
}

.pet-body { padding: 16px 18px 18px; }

.pet-title {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 12px;
}

.pet-title h2 {
  margin: 0;
  font-size: 22px;
  letter-spacing: 1px;
}

.pet-breed {
  font-size: 12px;
  font-weight: 900;
  color: var(--text-2);
}

.pet-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  margin-bottom: 18px;
}

.pet-tag {
  padding: 5px 10px;
  font-size: 11px;
  font-weight: 900;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
}

.pet-tag:nth-child(2) { background: var(--blue); }
.pet-tag:nth-child(3) { background: var(--pink); }

.card-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.category-chip {
  padding: 5px 12px;
  font-size: 11px;
  font-weight: 900;
  background: var(--mint);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
}

.detail-btn {
  padding: 8px 14px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.detail-btn:hover { background: #ffe27a; transform: translate(-1px, -1px); box-shadow: 4px 4px 0 var(--ink); }

@media (max-width: 760px) {
  .topbar-inner { flex-wrap: wrap; }
  .home-main { padding: 22px 16px 48px; }
  .hero { padding: 22px 20px 26px; border-radius: 22px; }
  .hero-sticker { width: auto; height: auto; }
  .hero-sticker .hero-dog,
  .hero-sticker .hero-cat { display: none; }
  .hero-sticker .hero-recommend { position: static; transform: rotate(3deg); }
  .hero:hover .hero-recommend { transform: rotate(3deg) scale(1.06); }
  .hero h1 { font-size: 27px; }
  .pet-grid { grid-template-columns: 1fr; }
}

/* ===== 增量功能：搜索 / 收藏 / 状态角标 / 图标浮动 / 回到顶部 ===== */

/* 1. 导航栏搜索框 */
.search-box {
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 6px 15px;
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  transition: 0.12s;
}

.search-box:focus-within {
  transform: translate(-2px, -2px);
  box-shadow: 6px 6px 0 var(--ink);
}

.search-icon { font-size: 15px; }

.search-box input {
  width: 168px;
  border: 0;
  outline: 0;
  background: transparent;
  font: inherit;
  font-size: 13px;
  font-weight: 800;
  color: var(--ink);
}

.search-box input::placeholder { color: #b7a999; font-weight: 700; }
.search-box input::-webkit-search-cancel-button { cursor: pointer; }

/* 2. 爱心收藏按钮 */
.heart-btn {
  position: absolute;
  left: 12px;
  top: 12px;
  z-index: 4;
  width: 34px;
  height: 34px;
  padding: 0;
  display: grid;
  place-items: center;
  font-size: 26px;
  line-height: 1;
  color: #fff;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.15s;
  text-shadow:
    -1px -1px 0 var(--ink), 1px -1px 0 var(--ink),
    -1px 1px 0 var(--ink), 1px 1px 0 var(--ink);
}

.heart-btn:hover { transform: translate(-1px, -2px) scale(1.08); box-shadow: 4px 5px 0 var(--ink); }
.heart-btn.active {
  color: #ff4d7d;
  background: #fff0f4;
  animation: heart-pop 0.5s cubic-bezier(0.2, 1.6, 0.4, 1);
  transition: background 0.2s ease, color 0.2s ease, transform 0.15s;
}

@keyframes heart-pop {
  0% { transform: scale(0.55) rotate(-16deg); }
  45% { transform: scale(1.32) rotate(7deg); }
  70% { transform: scale(0.92) rotate(-3deg); }
  100% { transform: scale(1) rotate(0); }
}

/* 心情徽章为爱心让位，保持原有样式不变 */
.pet-photo .mood-badge { left: 54px; }

/* 3. 待领养状态角标 */
.status-badge {
  position: absolute;
  right: 12px;
  top: 12px;
  z-index: 4;
  padding: 6px 11px;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(5deg);
}

/* 4. 悬停时宠物图标小幅上下浮动，强化 3D 感 */
@keyframes icon-float {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -9px; }
}

.pet-card:hover .photo-placeholder span,
.pet-card:hover .pet-photo img {
  animation: icon-float 1.1s ease-in-out infinite;
}

/* 5. 爪印形状的回到顶部按钮 */
.back-top {
  position: fixed;
  right: 26px;
  bottom: 26px;
  z-index: 30;
  width: 62px;
  height: 62px;
  padding: 0;
  border: 0;
  background: transparent;
  cursor: pointer;
  opacity: 0;
  pointer-events: none;
  transform: translateY(18px) scale(0.9);
  transition: opacity 0.2s, transform 0.2s;
}

.back-top.show {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0) scale(1);
}

.back-top:hover { animation: bob 0.9s ease-in-out infinite; }

.paw-toe,
.paw-pad {
  position: absolute;
  display: grid;
  place-items: center;
  background: var(--yellow);
  border: 2px solid var(--ink);
  box-shadow: 2px 2px 0 var(--ink);
}

.paw-toe { width: 17px; height: 20px; border-radius: 50%; }
.toe-1 { left: 5px; top: 5px; transform: rotate(-22deg); }
.toe-2 { left: 22px; top: 0; }
.toe-3 { left: 39px; top: 0; }
.toe-4 { right: 4px; top: 7px; transform: rotate(22deg); }

.paw-pad {
  left: 12px;
  bottom: 2px;
  width: 38px;
  height: 30px;
  border-radius: 50% 50% 45% 45%;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
}

@media (max-width: 900px) {
  .search-box input { width: 120px; }
}

@media (max-width: 760px) {
  .nav-actions { flex-wrap: wrap; justify-content: flex-end; }
  .search-box { order: 3; width: 100%; }
  .search-box input { width: 100%; }
}

/* ===== 领养闭环增量样式 ===== */

/* 1. 今日明星毛孩子 */
.star-card {
  position: relative;
  display: grid;
  grid-template-columns: 150px 1fr auto;
  align-items: center;
  gap: 22px;
  padding: 18px 24px;
  margin-bottom: 30px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-3);
  overflow: hidden;
  animation: star-breathe 4s ease-in-out infinite;
}

.star-card::after {
  content: "";
  position: absolute;
  right: -40px;
  top: -60px;
  width: 220px;
  height: 220px;
  border-radius: 50%;
  background: repeating-conic-gradient(from 0deg, rgba(255, 216, 77, 0.28) 0 14deg, transparent 14deg 28deg);
  pointer-events: none;
}

@keyframes star-breathe {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -4px; }
}

.star-photo {
  position: relative;
  z-index: 1;
  width: 150px;
  height: 120px;
  display: grid;
  place-items: center;
  background: var(--star-color);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-1);
  overflow: hidden;
}

.star-photo img { width: 100%; height: 100%; object-fit: contain; padding: 2px; }
.star-emoji {
  font-size: 78px;
  line-height: 1;
  filter: drop-shadow(5px 7px 0 rgba(43, 43, 43, 0.2));
  animation: bob 2.8s ease-in-out infinite;
}

.star-copy { position: relative; z-index: 1; }

.star-badge {
  display: inline-block;
  padding: 5px 12px;
  margin-bottom: 8px;
  font-size: 12px;
  font-weight: 900;
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-3deg);
}

.star-copy h2 { margin: 0 0 6px; font-size: 27px; }
.star-copy h2 small { font-size: 14px; color: var(--text-2); }
.star-copy p { margin: 0 0 12px; font-size: 13px; font-weight: 700; line-height: 1.6; color: var(--text-2); }
.star-tags { display: flex; flex-wrap: wrap; gap: 7px; }
.star-tags span {
  padding: 5px 10px;
  font-size: 11px;
  font-weight: 900;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
}

.star-btn {
  position: relative;
  z-index: 1;
  padding: 11px 18px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.star-btn:hover { transform: translate(-2px, -2px); box-shadow: 6px 6px 0 var(--ink); }
.star-btn:active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

/* 2. 申请领养按钮 */
.card-foot { flex-wrap: wrap; }
.card-foot .detail-btn { padding: 8px 11px; font-size: 11px; }

.apply-btn {
  padding: 8px 11px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.apply-btn:hover:not(:disabled) { background: #ffb6d3; transform: translate(-1px, -1px); box-shadow: 4px 4px 0 var(--ink); }
.apply-btn:disabled { background: #dcd4c8; cursor: default; }

.status-badge.applied { background: var(--mint); }

/* 3. 心情徽章彩蛋气泡 */
.pet-photo .mood-egg-trigger { cursor: pointer; }
.mood-egg-trigger:hover { filter: brightness(1.04); }

.mood-egg {
  position: absolute;
  left: 54px;
  top: 50px;
  z-index: 6;
  max-width: 190px;
  padding: 10px 13px;
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  font-size: 12px;
  font-weight: 900;
  line-height: 1.5;
  animation: egg-pop 0.25s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}

.mood-egg::after {
  content: "";
  position: absolute;
  left: 22px;
  top: -13px;
  width: 18px;
  height: 18px;
  background: #fff;
  border-left: var(--line);
  border-top: var(--line);
  transform: rotate(45deg);
}

@keyframes egg-pop {
  from { opacity: 0; transform: scale(0.8) translateY(6px); }
  to { opacity: 1; transform: scale(1) translateY(0); }
}

/* 5. 领养弹窗 */
.adopt-mask {
  position: fixed;
  inset: 0;
  z-index: 50;
  display: none;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: rgba(43, 43, 43, 0.45);
}
.adopt-mask.show { display: flex; }

.adopt-modal {
  width: min(440px, 100%);
  max-height: 90vh;
  overflow: auto;
  padding: 26px 26px 24px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 9px 10px 0 var(--ink);
  animation: modal-pop 0.3s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}

@keyframes modal-pop {
  from { opacity: 0; transform: scale(0.82) rotate(-4deg); }
  to { opacity: 1; transform: scale(1) rotate(0); }
}

.adopt-icon { font-size: 42px; text-align: center; }
.adopt-modal h2 { margin: 6px 0 2px; text-align: center; font-size: 24px; }
.adopt-sub { margin: 0 0 18px; text-align: center; font-size: 12px; font-weight: 700; color: var(--text-2); }

.form-field { display: block; margin-bottom: 13px; }
.form-field span { display: block; margin-bottom: 6px; font-size: 12px; font-weight: 900; }
.form-field input,
.form-field textarea {
  width: 100%;
  padding: 10px 12px;
  font: inherit;
  font-size: 13px;
  font-weight: 700;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  outline: none;
  resize: vertical;
  transition: 0.12s;
}
.form-field input:focus,
.form-field textarea:focus { box-shadow: 4px 4px 0 var(--ink); transform: translate(-2px, -2px); }
.form-field input::placeholder,
.form-field textarea::placeholder { color: #b7a999; font-weight: 600; }

.notice-box {
  margin: 16px 0;
  padding: 12px 14px;
  background: #fff6d9;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
}
.notice-box strong { font-size: 13px; }
.notice-box p { margin: 6px 0 10px; font-size: 11px; font-weight: 700; line-height: 1.6; color: var(--text-2); }
.notice-check { display: flex; align-items: center; gap: 8px; font-size: 12px; font-weight: 900; cursor: pointer; }
.notice-check input {
  appearance: none;
  width: 18px;
  height: 18px;
  margin: 0;
  border: 2px solid var(--ink);
  border-radius: 5px;
  background: #fff;
  cursor: pointer;
  position: relative;
}
.notice-check input:checked { background: var(--yellow); }
.notice-check input:checked::after {
  content: "✓";
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  font-size: 13px;
  font-weight: 900;
}

.form-error { margin: 0 0 10px; font-size: 11px; font-weight: 900; color: #d8385b; }

.modal-actions { display: flex; gap: 12px; }
.cancel-btn,
.submit-btn {
  flex: 1;
  padding: 11px 0;
  font: inherit;
  font-size: 14px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
}
.cancel-btn { background: #fff; }
.submit-btn { background: var(--yellow); }
.submit-btn:disabled { background: #e6ded2; cursor: not-allowed; }
.cancel-btn:active,
.submit-btn:not(:disabled):active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

/* 提交成功轻提示 */
.cute-toast {
  position: fixed;
  left: 50%;
  bottom: 34px;
  z-index: 60;
  translate: -50% 20px;
  opacity: 0;
  pointer-events: none;
  padding: 12px 20px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 5px 5px 0 var(--ink);
  font-size: 13px;
  font-weight: 900;
  white-space: nowrap;
  transition: opacity 0.25s, translate 0.25s;
}
.cute-toast.show { opacity: 1; translate: -50% 0; }

@media (max-width: 900px) {
  .star-card { grid-template-columns: 110px 1fr; }
  .star-photo { width: 110px; height: 100px; }
  .star-emoji { font-size: 60px; }
  .star-btn { grid-column: 1 / -1; width: 100%; }
}

@media (max-width: 760px) {
  .star-card { grid-template-columns: 1fr; padding: 18px; }
  .star-photo { width: 132px; height: 112px; margin: 0 auto; }
  .star-btn { grid-column: auto; }
  .mood-egg { left: 12px; top: 52px; }
}

/* ===== 缘分毛孩子匹配（增量） ===== */

/* banner 下方入口按钮 */
.match-entry {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 16px;
  margin: -10px 0 30px;
  padding: 16px 24px;
  font: inherit;
  text-align: left;
  color: var(--ink);
  background: linear-gradient(100deg, #fff2c9, #ffe0ec);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 7px 8px 0 var(--ink);
  cursor: pointer;
  transition: 0.15s;
  animation: match-breathe 4s ease-in-out infinite;
}

.match-entry:hover { transform: translate(-3px, -4px); box-shadow: 10px 12px 0 var(--ink); }
.match-entry:active { transform: translate(4px, 4px); box-shadow: 3px 4px 0 var(--ink); }

@keyframes match-breathe {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -3px; }
}

.match-entry-spark {
  font-size: 34px;
  line-height: 1;
  filter: drop-shadow(3px 4px 0 rgba(43, 43, 43, 0.18));
  animation: bob 2.6s ease-in-out infinite;
}

.match-entry-copy { flex: 1; display: flex; flex-direction: column; gap: 3px; }
.match-entry-copy strong { font-size: 19px; letter-spacing: 0.5px; }
.match-entry-copy small { font-size: 12px; font-weight: 700; color: var(--text-2); }

.match-entry-arrow {
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: 3px 3px 0 var(--ink);
  font-size: 20px;
  font-weight: 900;
}

/* ===== 每日赚币游戏入口卡片 ===== */
.game-entry {
  position: relative;
  width: 100%;
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: center;
  gap: 16px;
  margin: 0 0 30px;
  padding: 14px 20px 14px 16px;
  font: inherit;
  text-align: left;
  color: var(--ink);
  background: linear-gradient(100deg, #d9f5ea, #ddeaff);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 7px 8px 0 var(--ink);
  cursor: pointer;
  overflow: hidden;
  transition: 0.15s;
}
.game-entry::after {
  content: "";
  position: absolute;
  inset: 0;
  pointer-events: none;
  background: radial-gradient(rgba(43, 43, 43, 0.07) 1.2px, transparent 1.2px);
  background-size: 14px 14px;
  opacity: 0.55;
}
.game-entry:hover { transform: translate(-3px, -4px); box-shadow: 10px 12px 0 var(--ink); }
.game-entry:active { transform: translate(4px, 4px); box-shadow: 3px 4px 0 var(--ink); }

.game-entry-art {
  position: relative;
  z-index: 1;
  width: 62px;
  height: 62px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  background: #fffdf6;
  border: var(--line);
  border-radius: 18px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-4deg);
}
.ge-pad {
  width: 40px;
  height: auto;
  animation: bob 3s ease-in-out infinite;
}
.ge-coin {
  position: absolute;
  right: -8px;
  bottom: -8px;
  width: 27px;
  height: 27px;
  display: grid;
  place-items: center;
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 50%;
}
.ge-spark { position: absolute; left: -9px; top: -7px; font-size: 13px; }

.game-entry-copy {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
}
.ge-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 19px;
  font-weight: 900;
  letter-spacing: 0.5px;
}
.ge-title em {
  padding: 2px 6px;
  font-style: normal;
  font-size: 9px;
  font-weight: 900;
  color: #fffdf6;
  background: #e2603f;
  border: 2px solid var(--ink);
  border-radius: 6px;
  transform: rotate(-4deg);
}
.game-entry-copy small { font-size: 12px; font-weight: 700; color: var(--text-2); }
.ge-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 2px; }
.ge-tags em {
  padding: 3px 8px;
  font-style: normal;
  font-size: 10px;
  font-weight: 900;
  color: var(--text-2);
  background: #fffdf6;
  border: 2px solid rgba(43, 43, 43, 0.2);
  border-radius: 99px;
}
.game-entry-side {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 7px;
}
.ge-balance {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  font-size: 13px;
  font-weight: 900;
  background: #fffdf6;
  border: 2px solid var(--ink);
  border-radius: 99px;
  box-shadow: 2px 2px 0 var(--ink);
}
.ge-go {
  padding: 8px 14px;
  font-size: 12px;
  font-weight: 900;
  white-space: nowrap;
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
}
.game-entry:hover .ge-go { background: #ffe27a; }

/* 匹配弹窗 */
.match-mask {
  position: fixed;
  inset: 0;
  z-index: 55;
  display: none;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: rgba(43, 43, 43, 0.45);
}
.match-mask.show { display: flex; }

.match-modal {
  position: relative;
  width: min(480px, 100%);
  max-height: 90vh;
  overflow: auto;
  padding: 28px 28px 26px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 9px 10px 0 var(--ink);
  animation: modal-pop 0.3s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}

.match-close {
  position: absolute;
  right: 14px;
  top: 14px;
  z-index: 2;
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  font: inherit;
  font-size: 24px;
  font-weight: 900;
  line-height: 1;
  color: var(--ink);
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: transform 0.2s;
}
.match-close:hover { transform: rotate(90deg); }

.match-head { text-align: center; font-size: 30px; letter-spacing: 4px; }
.match-modal h2 { margin: 6px 0 2px; text-align: center; font-size: 25px; }
.match-sub { margin: 0 0 16px; text-align: center; font-size: 12px; font-weight: 700; color: var(--text-2); }

.match-progress { display: flex; justify-content: center; gap: 8px; margin-bottom: 6px; }
.match-progress span {
  width: 24px;
  height: 8px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  transition: 0.2s;
}
.match-progress span.done { background: var(--mint); }
.match-progress span.current { background: var(--yellow); transform: scaleY(1.35); }
.match-step { margin: 0 0 14px; text-align: center; font-size: 11px; font-weight: 900; color: var(--text-2); }

/* 卡通气泡题卡 */
.question-card {
  position: relative;
  padding: 20px 18px 18px;
  background: #fff6d9;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 5px 6px 0 var(--ink);
  animation: egg-pop 0.3s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
.question-card::after {
  content: "";
  position: absolute;
  left: 34px;
  bottom: -14px;
  width: 20px;
  height: 20px;
  background: #fff6d9;
  border-right: var(--line);
  border-bottom: var(--line);
  transform: rotate(45deg) skew(-8deg, -8deg);
}
.question-title { margin: 0 0 14px; font-size: 16px; font-weight: 900; }
.option-list { display: grid; gap: 10px; }

.option-btn {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 11px 13px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  text-align: left;
  color: var(--ink);
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}
.option-btn:hover { transform: translate(-2px, -2px); box-shadow: 5px 5px 0 var(--ink); }
.option-btn.selected { background: var(--yellow); transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }
.option-emoji { font-size: 20px; }

.match-actions { display: flex; gap: 12px; margin-top: 22px; }
.match-prev,
.match-next {
  flex: 1;
  padding: 12px 0;
  font: inherit;
  font-size: 14px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
}
.match-prev { background: #fff; }
.match-next { background: var(--yellow); }
.match-next:disabled { background: #e6ded2; cursor: not-allowed; }
.match-prev:active,
.match-next:not(:disabled):active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

/* 匹配结果卡 */
.result-card { text-align: center; padding: 6px 4px 2px; animation: modal-pop 0.45s cubic-bezier(0.2, 1.5, 0.4, 1) both; }
.result-badge {
  display: inline-block;
  padding: 6px 14px;
  font-size: 12px;
  font-weight: 900;
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-3deg);
}
.result-photo {
  width: 140px;
  height: 130px;
  margin: 18px auto 10px;
  display: grid;
  place-items: center;
  background: var(--result-color);
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 5px 5px 0 var(--ink);
  overflow: hidden;
}
.result-photo img { width: 100%; height: 100%; object-fit: cover; }
.result-photo span {
  font-size: 76px;
  line-height: 1;
  filter: drop-shadow(4px 6px 0 rgba(43, 43, 43, 0.2));
  animation: bob 2.6s ease-in-out infinite;
}
.result-card h2 { margin: 0 0 2px; font-size: 26px; }
.result-breed { margin: 0 0 12px; font-size: 12px; font-weight: 700; color: var(--text-2); }
.result-score {
  display: inline-flex;
  align-items: baseline;
  gap: 6px;
  padding: 8px 16px;
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
}
.result-score strong { font-size: 26px; }
.result-score span { font-size: 12px; font-weight: 900; }
.result-comment { margin: 16px auto 4px; max-width: 330px; font-size: 13px; font-weight: 800; line-height: 1.7; color: var(--text-2); }
.result-actions { display: flex; gap: 12px; margin-top: 20px; }
.result-again,
.result-go {
  flex: 1;
  padding: 12px 0;
  font: inherit;
  font-size: 14px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
}
.result-again { background: #fff; }
.result-go { background: var(--mint); }
.result-again:active,
.result-go:active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

@media (max-width: 760px) {
  .match-entry { padding: 14px 16px; gap: 10px; }
  .match-entry-copy strong { font-size: 16px; }
  .match-entry-spark { font-size: 26px; }
  .match-modal { padding: 24px 18px; }
  .result-photo { width: 120px; height: 110px; }
}

/* ===== 云撸宠：摸脑袋（增量） ===== */
.pat-btn {
  position: absolute;
  left: 12px;
  bottom: 10px;
  z-index: 5;
  padding: 6px 11px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}
.pat-btn:hover { background: var(--pink); transform: translate(-1px, -1px); box-shadow: 4px 4px 0 var(--ink); }
.pat-btn:active { transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }

/* 选择器权重需高于原 hover 动画，故保留 .pet-card 前缀 */
.pet-card.is-pat .photo-placeholder span,
.pet-card.is-pat .pet-photo img { animation: pat-shake 0.45s ease-in-out 2; }

@keyframes pat-shake {
  0%, 100% { rotate: 0deg; translate: 0 0; }
  25% { rotate: -9deg; translate: -5px 0; }
  50% { rotate: 8deg; translate: 4px -4px; }
  75% { rotate: -5deg; translate: -3px 0; }
}

.pat-hearts { position: absolute; inset: 0; z-index: 6; pointer-events: none; }
.pat-hearts span {
  position: absolute;
  left: 50%;
  top: 42%;
  font-size: 20px;
  animation: heart-float 0.9s ease-out forwards;
}
.pat-hearts span:nth-child(1) { margin-left: -34px; animation-delay: 0s; }
.pat-hearts span:nth-child(2) { margin-left: 0; font-size: 24px; animation-delay: 0.12s; }
.pat-hearts span:nth-child(3) { margin-left: 30px; animation-delay: 0.22s; }

@keyframes heart-float {
  0% { opacity: 0; transform: translateY(10px) scale(0.6); }
  25% { opacity: 1; }
  100% { opacity: 0; transform: translateY(-60px) scale(1.15); }
}

.pat-bubble {
  position: absolute;
  left: 12px;
  bottom: 48px;
  z-index: 7;
  padding: 8px 12px;
  background: #fff;
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: 4px 4px 0 var(--ink);
  font-size: 12px;
  font-weight: 900;
  animation: egg-pop 0.25s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}
.pat-bubble::after {
  content: "";
  position: absolute;
  left: 20px;
  bottom: -12px;
  width: 16px;
  height: 16px;
  background: #fff;
  border-right: var(--line);
  border-bottom: var(--line);
  transform: rotate(45deg);
}

/* ===== 导航栏头像 + 徽章数量角标（增量） ===== */
.user-avatar {
  position: relative;
  width: 44px;
  height: 44px;
  padding: 0;
  display: grid;
  place-items: center;
  background: #fff0f4;
  border: var(--line);
  border-radius: 50%;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}
.user-avatar:hover { transform: translate(-2px, -2px); box-shadow: 5px 5px 0 var(--ink); }
.avatar-face { font-size: 24px; line-height: 1; }
.avatar-badge-count {
  position: absolute;
  right: -8px;
  top: -8px;
  min-width: 20px;
  height: 20px;
  padding: 0 4px;
  display: grid;
  place-items: center;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
  animation: badge-count-pop 0.4s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}
@keyframes badge-count-pop {
  from { transform: scale(0.5); }
  to { transform: scale(1); }
}

/* ===== 宠物形象完整展示：仅调整装饰元素位置，其余一律不动 ===== */
/* 图片区不再溢出隐藏（圆角仍由卡片父级 overflow 保证），图片不裁切 */
.pet-card .pet-photo { overflow: visible; }

/* 宠物图片完整 contain + 居中留白，不拉伸不裁切 */
.pet-card .pet-photo img {
  width: 86%;
  height: 86%;
  object-fit: contain;
}

/* 顶部留白带：心情徽章(左) / 待领养角标(右) / 爱心收藏(最右上角)，均不压宠物 */
.pet-card .pet-photo .mood-badge { left: 10px; top: 10px; }
.pet-card .pet-photo .status-badge { right: 54px; top: 12px; }
.pet-card .pet-photo .heart-btn { left: auto; right: 10px; top: 10px; }

/* 心情彩蛋气泡跟随心情徽章 */
.pet-card .pet-photo .mood-egg { left: 10px; top: 46px; }

/* 摸一下按钮：只改定位——右侧靠右对齐、垂直居中于宠物形象；尺寸/圆角/描边/投影/文字/交互全部沿用原样式 */
.pet-card .pet-photo .pat-btn {
  left: auto;
  right: 10px;
  top: 50%;
  bottom: auto;
  transform: translateY(-50%);
}
.pet-card .pet-photo .pat-btn:hover { transform: translateY(-50%) translate(-1px, -1px); }
.pet-card .pet-photo .pat-btn:active { transform: translateY(-50%) translate(2px, 2px); }

/* 摸头互动气泡跟随按钮居中（用 margin 居中，避免被 egg-pop 的 transform 覆盖） */
.pet-card .pet-photo .pat-bubble { left: 50%; bottom: 44px; margin-left: -50px; }
.pet-card .pet-photo .pat-bubble::after { left: 50%; margin-left: -8px; }

/* ===== 图片区背景 + 宠物 3D 质感增强（只改背景与质感，不动布局） ===== */
/* 干净平整的柔和斜纹底色（去掉棋盘格/网格感），沿用每只宠物的专属底色 */
.pet-card .pet-photo {
  background-color: var(--pet-color);
  /* 浅淡细腻肌理底纹：柔光晕 + 极细密点，替代原斜纹 */
  background-image:
    radial-gradient(circle at 50% 22%, rgba(255, 255, 255, 0.55), rgba(255, 255, 255, 0) 62%),
    radial-gradient(rgba(255, 255, 255, 0.34) 0.7px, rgba(255, 255, 255, 0) 0.8px),
    radial-gradient(rgba(255, 255, 255, 0.20) 0.7px, rgba(255, 255, 255, 0) 0.8px);
  background-size: 100% 100%, 6px 6px, 6px 6px;
  background-position: 0 0, 0 0, 3px 3px;
}

/* 宠物图：透明显色 + 多层柔和投影强化立体感（圆润高光/细腻阴影/接触投影） */
.pet-card .pet-photo img {
  filter:
    drop-shadow(0 2px 1px rgba(43, 43, 43, 0.16))
    drop-shadow(0 7px 6px rgba(43, 43, 43, 0.18))
    drop-shadow(0 14px 12px rgba(90, 60, 30, 0.12))
    saturate(1.06) contrast(1.03) brightness(1.01);
}

/* 无图占位符也沿用干净斜纹，避免网格 */
.pet-card .pet-photo .photo-placeholder {
  background:
    radial-gradient(circle at 50% 118%, rgba(255, 255, 255, 0.7), transparent 62%),
    repeating-linear-gradient(135deg, rgba(255, 255, 255, 0.32) 0 10px, rgba(255, 255, 255, 0) 10px 20px);
}

/* ===== 宠物形象底部居中：只改摆放位置，尺寸/滤镜/其余元素一律不动 ===== */
/* 锁定图片区网格轨道高度=容器高度，避免 img 按宽度把自动轨道撑大、导致图片越出图片区 */
.pet-card .pet-photo { grid-template-rows: 100%; }

/* 图片框底边贴到图片区下沿（水平方向仍由 place-items:center 保持居中）；
   PNG 自身底部有透明留白，用 transform 向下补偿，让可见的宠物脚底真正贴边。
   transform 与 hover 的 icon-float / 摸头的 pat-shake（用 translate/rotate 独立属性）叠加互不覆盖。 */
.pet-card .pet-photo img {
  align-self: end;
  --pet-ground-shift: 8%;
  --tilt-x: 0deg;
  --tilt-y: 0deg;
  /* 贴底位移 + 鼠标控制的 X/Y 轴旋转；perspective 放在 transform 内，不影响徽章/按钮 */
  transform:
    perspective(700px)
    translateY(var(--pet-ground-shift))
    rotateX(var(--tilt-x))
    rotateY(var(--tilt-y));
  transform-style: preserve-3d;
  transition: transform 0.12s ease-out, scale 0.22s ease;
  will-change: transform;
}
/* 按各图底部透明留白百分比补偿，6 只脚底对齐同一水平线（百分比相对图片自身高度，卡片高度变化也自适应） */
.pet-card .pet-photo img[src*="naigai.png"]      { --pet-ground-shift: 8%; }
.pet-card .pet-photo img[src*="zhima.png"]       { --pet-ground-shift: 8%; }
.pet-card .pet-photo img[src*="buding.png"]      { --pet-ground-shift: 8%; }
.pet-card .pet-photo img[src*="kele.png"]        { --pet-ground-shift: 8%; }
.pet-card .pet-photo img[src*="mianhuatang.png"] { --pet-ground-shift: 8%; }
.pet-card .pet-photo img[src*="doudou.png"]      { --pet-ground-shift: 8%; }

/* ===== 领养流程步骤条 ===== */
.step-bar {
  margin: 0 0 30px;
  padding: 20px 24px 22px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 7px 7px 0 var(--ink);
}

.step-head {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 16px;
}

.step-head h3 {
  margin: 0;
  font-size: 18px;
  letter-spacing: 0.5px;
}

.step-head p {
  margin: 0;
  font-size: 12px;
  font-weight: 800;
  color: var(--text-2);
}

.step-list {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.step-item {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  padding: 18px 12px 14px;
  text-align: center;
  background: #fff8e9;
  border: 2px solid var(--ink);
  border-radius: var(--r-lg);
  box-shadow: 3px 3px 0 rgba(43, 43, 43, 0.14);
  transition: transform 0.18s ease, box-shadow 0.18s ease, background 0.18s ease;
}

.step-item:hover {
  background: #fff2c9;
  transform: translateY(-5px) rotate(-1deg);
  box-shadow: 4px 8px 0 rgba(43, 43, 43, 0.2);
}

/* 步骤之间的箭头连接 */
.step-item::after {
  content: "→";
  position: absolute;
  right: -16px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 16px;
  font-weight: 900;
  color: var(--text-3);
  transition: transform 0.18s ease, color 0.18s ease;
}

.step-item:last-child::after { display: none; }

.step-item:hover::after { color: var(--orange); transform: translate(2px, -50%); }

.step-num {
  position: absolute;
  left: 10px;
  top: 10px;
  width: 22px;
  height: 22px;
  display: grid;
  place-items: center;
  font-size: 11px;
  font-weight: 900;
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: 50%;
}

.step-emoji {
  font-size: 26px;
  line-height: 1.25;
  transition: transform 0.2s ease;
}

.step-item:hover .step-emoji { transform: scale(1.14) rotate(-6deg); }

.step-item strong { font-size: 14px; }

.step-item small {
  font-size: 11px;
  font-weight: 700;
  line-height: 1.55;
  color: var(--text-2);
}

/* ===== 条件筛选区 ===== */
.pet-filter {
  display: grid;
  gap: 12px;
  margin-bottom: 16px;
  padding: 18px 22px 20px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 6px 6px 0 var(--ink);
}

.pet-filter-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.pet-filter-title {
  font-size: 14px;
  font-weight: 900;
}

.filter-clear {
  padding: 5px 12px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: #ffe9ef;
  border: 2px solid var(--ink);
  border-radius: var(--r-sm);
  box-shadow: 2px 2px 0 var(--ink);
  cursor: pointer;
  transition: 0.15s;
}

.filter-clear:hover {
  background: #ffd6e2;
  transform: translate(-1px, -1px);
  box-shadow: 3px 3px 0 var(--ink);
}

.filter-clear:active {
  transform: translate(2px, 2px);
  box-shadow: 0 0 0 var(--ink);
}

.filter-row {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  gap: 10px 14px;
}

.filter-label {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 5px;
  padding-top: 7px;
  font-size: 13px;
  font-weight: 900;
  color: var(--text-2);
}

.filter-label small {
  padding: 1px 6px;
  font-size: 10px;
  font-weight: 800;
  color: var(--text-2);
  background: #f3e6c9;
  border-radius: var(--r-sm);
}

.filter-chips {
  flex: 1 1 320px;
  display: flex;
  flex-wrap: wrap;
  gap: 9px;
}

.chip {
  padding: 7px 14px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: 2px solid rgba(43, 43, 43, 0.18);
  border-radius: var(--r-sm);
  box-shadow: 0 2px 0 rgba(43, 43, 43, 0.1);
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease, border-color 0.15s ease;
}

.chip:hover {
  background: #fff8e9;
  border-color: var(--ink);
  transform: translateY(-2px);
  box-shadow: 0 4px 0 rgba(43, 43, 43, 0.16);
}

.chip.active {
  background: var(--mint);
  border-color: var(--ink);
  box-shadow: 2px 2px 0 var(--ink);
  transform: translateY(-1px);
}

.hint-tag {
  display: inline-block;
  margin-left: 6px;
  padding: 2px 9px;
  font-size: 11px;
  font-weight: 900;
  color: var(--text-2);
  background: #f3e6c9;
  border: 2px solid rgba(43, 43, 43, 0.14);
  border-radius: var(--r-sm);
  animation: hint-pop 0.24s ease both;
}

@keyframes hint-pop {
  from { opacity: 0; transform: scale(0.85); }
  to { opacity: 1; transform: scale(1); }
}

/* ===== 右侧固定悬浮侧栏 ===== */
.side-dock {
  position: fixed;
  right: 14px;
  top: 50%;
  z-index: 22;
  width: 68px;
  padding: 10px 6px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: 5px 6px 0 var(--ink);
  transform: translateY(-50%);
  animation: dock-in 0.5s cubic-bezier(0.2, 1.3, 0.4, 1) both;
}

@keyframes dock-in {
  from { opacity: 0; transform: translate(26px, -50%); }
  to { opacity: 1; transform: translate(0, -50%); }
}

.dock-item {
  width: 100%;
  display: grid;
  place-items: center;
  gap: 1px;
  padding: 9px 4px;
  font: inherit;
  color: var(--ink);
  background: transparent;
  border: 0;
  border-radius: var(--r-sm);
  cursor: pointer;
  transition: background 0.18s ease, transform 0.18s ease;
}

.dock-item:hover {
  background: #fff2c9;
  transform: translateY(-2px);
}

.dock-item:active { transform: translateY(1px) scale(0.96); }

.dock-item.active { background: #ffe9ef; }

.dock-icon {
  font-size: 18px;
  line-height: 1;
  color: #ff5f86;
  transition: transform 0.18s ease;
}

.dock-item:hover .dock-icon { transform: scale(1.15); }

.dock-icon.paw { font-size: 17px; }
.dock-icon.bag { font-size: 16px; }

/* 悬浮栏游戏币：小金币 + 数字，点进商城 */
.dock-coins .dock-coin {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  line-height: 1;
}
.dock-coins .dock-coin strong {
  font-size: 12px;
  letter-spacing: -0.3px;
}

.dock-item strong {
  font-size: 15px;
  line-height: 1.05;
}

.dock-item small {
  font-size: 10px;
  font-weight: 900;
  color: var(--text-2);
}

.dock-line {
  width: 34px;
  height: 2px;
  margin: 3px 0;
  background: rgba(43, 43, 43, 0.14);
  border-radius: 2px;
}

/* 「摸一下」点击时的缩放反馈 */
.pet-card.is-pat .pet-photo { animation: pat-pop 0.42s cubic-bezier(0.2, 1.4, 0.4, 1); }

@keyframes pat-pop {
  0% { transform: scale(1); }
  40% { transform: scale(0.955); }
  100% { transform: scale(1); }
}

.pet-card.is-pat .pat-btn { animation: pat-tap 0.42s cubic-bezier(0.2, 1.5, 0.4, 1); }

@keyframes pat-tap {
  0% { transform: scale(1); }
  35% { transform: scale(0.86); }
  70% { transform: scale(1.1); }
  100% { transform: scale(1); }
}

/* 桌面端窄屏：侧栏收起，避免压住内容 */
@media (max-width: 1359px) {
  .side-dock { display: none; }
}

@media (max-width: 900px) {
  .step-list { grid-template-columns: repeat(2, 1fr); }
  .step-item::after { display: none; }
  .game-entry { grid-template-columns: auto minmax(0, 1fr); }
  .game-entry-side {
    grid-column: 1 / -1;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    width: 100%;
  }
}

@media (max-width: 620px) {
  .step-list { grid-template-columns: 1fr; }
  .filter-label { padding-top: 0; }
  .ge-title { font-size: 16px; }
  .game-entry { padding: 12px 14px; gap: 12px; }
}

/* ===== 空状态操作按钮 ===== */
.empty-reset {
  padding: 10px 22px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-1);
  cursor: pointer;
}
.empty-reset:hover { background: #ffe27a; transform: translate(-1px, -3px); box-shadow: 4px 5px 0 var(--ink); }
.empty-reset:active { transform: translate(1px, 1px); box-shadow: 1px 1px 0 var(--ink); }

/* ===== 搜索关键词高亮（v-html 内容需 :deep 才能命中） ===== */
:deep(.kw) {
  padding: 0 2px;
  color: var(--ink);
  background: var(--yellow);
  border-radius: 4px;
  box-shadow: 0 2px 0 rgba(43, 43, 43, 0.18);
}

/* ===== 重置筛选按钮（无筛选时禁用） ===== */
.filter-clear:disabled {
  opacity: 0.45;
  cursor: not-allowed;
  background: #f3ece0;
  box-shadow: 1px 1px 0 rgba(43, 43, 43, 0.25);
  transform: none;
}

/* ===== 摸一下：爱心 + 爪印粒子 ===== */
.pat-paws { position: absolute; inset: 0; z-index: 6; pointer-events: none; }
.pat-paws span {
  position: absolute;
  left: 50%;
  bottom: 24%;
  font-size: 15px;
  opacity: 0;
  animation: paw-float 1s ease-out forwards;
}
.pat-paws span:nth-child(1) { margin-left: -48px; animation-delay: 0.02s; }
.pat-paws span:nth-child(2) { margin-left: -6px; animation-delay: 0.1s; font-size: 13px; }
.pat-paws span:nth-child(3) { margin-left: 34px; animation-delay: 0.18s; font-size: 16px; }

@keyframes paw-float {
  0% { opacity: 0; transform: translate(0, 8px) rotate(-12deg) scale(0.7); }
  30% { opacity: 1; }
  100% { opacity: 0; transform: translate(0, -56px) rotate(14deg) scale(1.1); }
}

/* ===== 领养前置须知弹窗 ===== */
.notice-modal {
  width: min(430px, 100%);
  padding: 22px 24px 20px;
  text-align: center;
  background: #fffdf6;
  border: var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-3);
  animation: pop-in 0.3s cubic-bezier(0.2, 1.5, 0.4, 1);
}
@keyframes pop-in {
  from { opacity: 0; transform: scale(0.9) translateY(12px); }
  to { opacity: 1; transform: none; }
}
.notice-icon { font-size: 38px; line-height: 1; }
.notice-modal h2 { margin: 8px 0 14px; font-size: 18px; line-height: 1.4; }
.notice-list {
  display: grid;
  gap: 9px;
  margin: 0 0 18px;
  padding: 0;
  list-style: none;
  text-align: left;
}
.notice-list li {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 12px;
  background: #fff8e9;
  border: 2px solid rgba(43, 43, 43, 0.12);
  border-radius: var(--r-sm);
  transition: border-color 0.18s ease, background 0.18s ease;
}
.notice-list li:hover { border-color: var(--ink); background: #fff2c9; }
.notice-list li > span { font-size: 17px; line-height: 1.3; }
.notice-list strong { display: block; font-size: 13px; }
.notice-list small {
  display: block;
  margin-top: 2px;
  font-size: 11px;
  font-weight: 700;
  line-height: 1.55;
  color: var(--text-2);
}

/* ===== 角落爪印彩蛋 ===== */
.paw-egg {
  position: fixed;
  left: 20px;
  bottom: 22px;
  z-index: 30;
  width: 46px;
  height: 46px;
  display: grid;
  place-items: center;
  padding: 0;
  font-size: 20px;
  background: #fffdf6;
  border: var(--line);
  border-radius: 50%;
  box-shadow: var(--shadow-1);
  cursor: pointer;
  transform: rotate(-8deg);
  opacity: 0.85;
  transition: transform 0.2s cubic-bezier(0.2, 1.4, 0.4, 1), opacity 0.2s ease, box-shadow 0.2s ease;
}
.paw-egg:hover {
  opacity: 1;
  transform: rotate(6deg) scale(1.12);
  box-shadow: var(--shadow-2);
}
.paw-egg.popped { animation: paw-pop 0.46s cubic-bezier(0.2, 1.6, 0.4, 1); }
@keyframes paw-pop {
  0% { transform: rotate(-8deg) scale(1); }
  40% { transform: rotate(5deg) scale(1.3); }
  100% { transform: rotate(-8deg) scale(1); }
}

/* ===== 宠物图片浅底衬边：内圈柔光 + 内描边，像嵌在浅色衬板上 ===== */
.pet-card .pet-photo {
  box-shadow:
    inset 0 0 0 2px rgba(255, 255, 255, 0.6),
    inset 0 -30px 34px -30px rgba(120, 92, 60, 0.22);
}

/* 卡片 hover 时图片轻微放大（scale 独立属性，不与 3D 倾斜的 transform 冲突） */
.pet-card:hover .pet-photo img { scale: 1.045; }

/* 移动端/粗指针：始终正面显示，不触发旋转 */
@media (hover: none), (pointer: coarse) {
  .pet-card .pet-photo img {
    --tilt-x: 0deg !important;
    --tilt-y: 0deg !important;
  }
}
</style>
