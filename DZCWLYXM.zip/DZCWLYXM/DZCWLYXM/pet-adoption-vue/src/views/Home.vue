<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { categories, pets } from '../data/pets'
import BadgeCelebration from '../components/BadgeCelebration.vue'
import { recordMatchComplete, syncAchievements } from '../utils/achievements'
import { store } from '../store'

const router = useRouter()
const activeCategory = ref('全部')
const favorites = ref([])
const showBackTop = ref(false)
const celebrateBadge = ref(null)
let celebrateTimer = null

// 今日明星毛孩子
const starPet = pets[0]
const starIntro = '超粘人的小奶盖，最爱趴在窗边晒太阳，还会用小脑袋蹭你的手心～'

// 领养弹窗状态
const adoptModalShow = ref(false)
const adoptTarget = ref(null)
const adoptForm = reactive({ name: '', contact: '', message: '' })
const adoptAgreed = ref(false)
const adoptError = ref(false)
const applyStatuses = ref({})

// 心情彩蛋气泡
const eggPetId = ref(null)
const eggText = ref('')
const moodEggs = {
  '开心到冒泡': '我今天超开心，尾巴都摇成小螺旋桨啦！',
  '有点困': '呼噜呼噜…再做五分钟的星星梦💤',
  '摇尾巴中': '你回来啦！我的尾巴已经控制不住啦～',
  '想要零食': '闻到了吗？是零食的味道！分我一口嘛🥺',
  '啃胡萝卜中': '咔嚓咔嚓…胡萝卜真的超甜！要一起吗？',
  '跑轮中': '等等我！我跑完这一圈就过来找你🐹'
}

// 云撸宠：摸一下（1.5s 内防连点）
const patPetId = ref(null)
let patTimer = null
let patLocked = false

// 3D 旋转：仅在图片区跟随鼠标，移动端不触发
const tiltState = reactive({})
const tiltTimers = {}
const hasFinePointer = () =>
  typeof window !== 'undefined' && window.matchMedia?.('(hover: hover) and (pointer: fine)').matches

function handleTiltMove(pet, event) {
  if (!hasFinePointer()) return
  const rect = event.currentTarget.getBoundingClientRect()
  if (!rect.width || !rect.height) return
  const px = (event.clientX - rect.left) / rect.width
  const py = (event.clientY - rect.top) / rect.height
  const state = tiltState[pet.id] || (tiltState[pet.id] = { x: 0, y: 0, resetting: false })
  clearTimeout(tiltTimers[pet.id])
  state.resetting = false
  // 左右移动 → Y 轴旋转；上下移动 → X 轴俯仰
  state.y = (px - 0.5) * 80
  state.x = (0.5 - py) * 52
}

function resetTilt(pet) {
  const state = tiltState[pet.id]
  if (!state) return
  clearTimeout(tiltTimers[pet.id])
  state.resetting = true
  state.x = 0
  state.y = 0
  tiltTimers[pet.id] = setTimeout(() => { state.resetting = false }, 650)
}

function resetAllTilt() {
  Object.keys(tiltState).forEach((id) => {
    const state = tiltState[id]
    if (state && (state.x || state.y)) {
      state.resetting = true
      state.x = 0
      state.y = 0
      clearTimeout(tiltTimers[id])
      tiltTimers[id] = setTimeout(() => { state.resetting = false }, 650)
    }
  })
}

// 轻提示
const toastText = ref('')
let eggTimer = null
let toastTimer = null

// 缘分毛孩子匹配测试
const matchModalShow = ref(false)
const currentQuestion = ref(0)
const matchAnswers = ref(Array(5).fill(null))
const matchResult = ref(null)

const matchQuestions = [
  {
    title: '周末最想怎么度过呀？',
    options: [
      { emoji: '🛋️', label: '窝在沙发上被毛孩子蹭蹭', tags: ['粘人', '温顺'] },
      { emoji: '🌳', label: '出门散步晒太阳', tags: ['阳光', '活泼'] },
      { emoji: '🧶', label: '在家拆一个新玩具', tags: ['好奇', '贪吃'] }
    ]
  },
  {
    title: '你心仪的毛孩子性格是？',
    options: [
      { emoji: '💕', label: '黏人小甜心', tags: ['粘人', '温顺'] },
      { emoji: '😼', label: '高冷小傲娇', tags: ['高冷', '安静'] },
      { emoji: '☀️', label: '活力小太阳', tags: ['阳光', '活泼'] }
    ]
  },
  {
    title: '最喜欢的互动方式是？',
    options: [
      { emoji: '🍿', label: '静静依偎在一起看剧', tags: ['安静', '粘人'] },
      { emoji: '🎾', label: '一起疯跑玩耍', tags: ['活泼', '阳光'] },
      { emoji: '🍪', label: '一起研究小零食', tags: ['贪吃', '好奇'] }
    ]
  },
  {
    title: '家里谁是撒娇小冠军？',
    options: [
      { emoji: '🥺', label: '软乎乎的贴贴怪', tags: ['粘人', '温顺'] },
      { emoji: '👀', label: '高冷但偷偷看着你', tags: ['高冷', '安静'] },
      { emoji: '🚀', label: '一刻不停的探险家', tags: ['好奇', '活泼'] }
    ]
  },
  {
    title: '如果它打翻了水杯，你会？',
    options: [
      { emoji: '🤗', label: '先抱起来耐心安慰', tags: ['温顺', '粘人'] },
      { emoji: '🧽', label: '笑着一起擦干净', tags: ['阳光', '活泼'] },
      { emoji: '🦴', label: '拿零食转移注意力', tags: ['贪吃', '好奇'] }
    ]
  }
]

const petTraits = {
  1: ['粘人', '温顺', '撒娇'],
  2: ['高冷', '安静', '慢热'],
  3: ['阳光', '活泼', '热情'],
  4: ['贪吃', '活泼', '好奇'],
  5: ['安静', '温顺', '慢热'],
  6: ['好奇', '活泼', '贪玩']
}

const matchComments = {
  1: '你和奶盖都是贴贴届冠军，注定要腻在一起啦～',
  2: '你懂芝麻的高冷，它也愿意只对你慢慢靠近🌙',
  3: '阳光发的快乐互相照亮，出门遛弯搭子就它了！',
  4: '一个爱吃一个爱玩，家里每天都会叮叮当当超热闹～',
  5: '安安静静的温柔最治愈，你们适合一起晒太阳发呆。',
  6: '好奇心满格组合！一起探索世界永远不会无聊🐹'
}

const filteredPets = computed(() => {
  const keyword = store.searchQuery.trim().toLowerCase()
  return pets.filter(pet => {
    const matchCategory = activeCategory.value === '全部' || pet.category === activeCategory.value
    const matchKeyword = !keyword ||
      pet.name.toLowerCase().includes(keyword) ||
      pet.breed.toLowerCase().includes(keyword)
    return matchCategory && matchKeyword
  })
})

function goDetail(pet) {
  router.push(`/pet/${pet.id}`)
}

function isFavorite(id) {
  return favorites.value.includes(id)
}

function loadFavorites() {
  try {
    const saved = JSON.parse(localStorage.getItem('petFavorites') || '[]')
    favorites.value = Array.isArray(saved) ? saved : []
  } catch {
    favorites.value = []
  }
}

function toggleFavorite(id) {
  if (isFavorite(id)) {
    favorites.value = favorites.value.filter(item => item !== id)
  } else {
    favorites.value.push(id)
  }
  localStorage.setItem('petFavorites', JSON.stringify(favorites.value))
  refreshAchievements()
}

function handleScroll() {
  showBackTop.value = window.scrollY > window.innerHeight
}

function backToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

function refreshAchievements() {
  const result = syncAchievements()
  store.unlockedBadgeCount = result.state.unlocked.length
  if (result.newlyUnlocked.length) {
    celebrateBadge.value = result.newlyUnlocked[0]
    clearTimeout(celebrateTimer)
    celebrateTimer = setTimeout(() => { celebrateBadge.value = null }, 2600)
  }
}

function openMatchModal() {
  matchModalShow.value = true
  currentQuestion.value = 0
  matchAnswers.value = Array(matchQuestions.length).fill(null)
  matchResult.value = null
}

function closeMatchModal() {
  matchModalShow.value = false
}

function selectMatchOption(optionIndex) {
  matchAnswers.value[currentQuestion.value] = optionIndex
}

function nextMatchQuestion() {
  if (matchAnswers.value[currentQuestion.value] === null) return
  if (currentQuestion.value < matchQuestions.length - 1) {
    currentQuestion.value += 1
  }
}

function prevMatchQuestion() {
  if (currentQuestion.value > 0) currentQuestion.value -= 1
}

function finishMatch() {
  if (matchAnswers.value.some(answer => answer === null)) return

  const selectedTags = []
  matchAnswers.value.forEach((optionIndex, questionIndex) => {
    const option = matchQuestions[questionIndex].options[optionIndex]
    if (option) selectedTags.push(...option.tags)
  })

  let best = null
  pets.forEach(pet => {
    const traits = petTraits[pet.id] || []
    const hits = selectedTags.filter(tag => traits.includes(tag)).length
    const percent = Math.round((hits / selectedTags.length) * 100)
    if (!best || percent > best.percent) {
      best = { pet, percent, comment: matchComments[pet.id] || '你们看起来会很合拍哦～' }
    }
  })
  matchResult.value = best
  recordMatchComplete()
  refreshAchievements()
}

function resetMatch() {
  currentQuestion.value = 0
  matchAnswers.value = Array(matchQuestions.length).fill(null)
  matchResult.value = null
}

function goMatchPetDetail() {
  if (!matchResult.value) return
  const pet = matchResult.value.pet
  closeMatchModal()
  goDetail(pet)
}

function getPetStatus(id) {
  return applyStatuses.value[id] || '待领养'
}

function loadApplyStatuses() {
  try {
    const saved = JSON.parse(localStorage.getItem('petApplyStatuses') || '{}')
    applyStatuses.value = saved && typeof saved === 'object' ? saved : {}
  } catch {
    applyStatuses.value = {}
  }
}

function openAdoptModal(pet) {
  adoptTarget.value = pet
  adoptForm.name = ''
  adoptForm.contact = ''
  adoptForm.message = ''
  adoptAgreed.value = false
  adoptError.value = false
  adoptModalShow.value = true
}

function closeAdoptModal() {
  adoptModalShow.value = false
  adoptTarget.value = null
}

function submitAdopt() {
  if (!adoptAgreed.value) {
    adoptError.value = true
    return
  }
  if (!adoptForm.name.trim() || !adoptForm.contact.trim() || !adoptForm.message.trim()) {
    adoptError.value = true
    return
  }
  if (!adoptTarget.value) return

  applyStatuses.value = {
    ...applyStatuses.value,
    [adoptTarget.value.id]: '预约中'
  }
  localStorage.setItem('petApplyStatuses', JSON.stringify(applyStatuses.value))
  refreshAchievements()
  closeAdoptModal()
  showToast('申请已提交啦，TA 正在等你哦～')
}

function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2400)
}

function showMoodEgg(pet) {
  eggText.value = moodEggs[pet.mood] || '我今天也很开心，带我回家好不好～'
  eggPetId.value = pet.id
  clearTimeout(eggTimer)
  eggTimer = setTimeout(() => { eggPetId.value = null }, 2000)
}

function patPet(pet) {
  if (patLocked) return
  patLocked = true
  patPetId.value = pet.id
  clearTimeout(patTimer)
  patTimer = setTimeout(() => {
    patPetId.value = null
    patLocked = false
  }, 1500)
}

// 登录页是居中的单屏布局，首页是滚动长页，进入时临时切换 body 布局
onMounted(() => document.body.classList.add('home-body'))
onBeforeUnmount(() => document.body.classList.remove('home-body'))

onMounted(() => {
  loadFavorites()
  window.addEventListener('scroll', handleScroll, { passive: true })
  window.addEventListener('mouseup', resetAllTilt)
})
onBeforeUnmount(() => {
  window.removeEventListener('scroll', handleScroll)
  window.removeEventListener('mouseup', resetAllTilt)
  Object.keys(tiltTimers).forEach((id) => clearTimeout(tiltTimers[id]))
})

onMounted(() => {
  loadApplyStatuses()
  refreshAchievements()
})
onBeforeUnmount(() => {
  clearTimeout(eggTimer)
  clearTimeout(toastTimer)
  clearTimeout(patTimer)
  clearTimeout(celebrateTimer)
})
</script>

<template>
  <div class="home-page">
    <main class="home-main">
      <section class="hero">
        <div class="hero-copy">
          <span class="hero-tag">今日份可爱已上线 ✨</span>
          <h1>挑一只毛孩子，带它回家吧！</h1>
          <p>每一个它，都在等一个你。先逛逛，喜欢就点进详情页认识一下～</p>
        </div>
        <div class="hero-sticker" aria-hidden="true">
          <span>🐶</span>
          <span>🐱</span>
        </div>
      </section>

      <button type="button" class="match-entry" @click="openMatchModal">
        <span class="match-entry-spark" aria-hidden="true">✨</span>
        <span class="match-entry-copy">
          <strong>测测你的专属毛孩子</strong>
          <small>5 道萌系小题，找到命中注定的 TA 🐾</small>
        </span>
        <span class="match-entry-arrow" aria-hidden="true">→</span>
      </button>

      <section class="star-card" :style="{ '--star-color': starPet.color }">
        <div class="star-photo">
          <img v-if="starPet.image" :src="starPet.image" :alt="starPet.name">
          <span v-else class="star-emoji">{{ starPet.emoji }}</span>
        </div>
        <div class="star-copy">
          <span class="star-badge">✨ 今日明星毛孩子</span>
          <h2>{{ starPet.name }} <small>· {{ starPet.breed }}</small></h2>
          <p>{{ starIntro }}</p>
          <div class="star-tags">
            <span>{{ starPet.gender }}</span>
            <span>{{ starPet.age }}</span>
            <span>{{ starPet.personality }}</span>
          </div>
        </div>
        <button type="button" class="star-btn" @click="goDetail(starPet)">去看看 TA →</button>
      </section>

      <section class="filter-bar" aria-label="宠物分类筛选">
        <button
          v-for="cat in categories"
          :key="cat"
          type="button"
          class="filter-btn"
          :class="{ active: activeCategory === cat }"
          @click="activeCategory = cat"
        >
          {{ cat }}
        </button>
      </section>

      <p class="result-hint">共 {{ filteredPets.length }} 位毛孩子等你认识 🐾</p>

      <section class="pet-grid">
        <article
          v-for="pet in filteredPets"
          :key="pet.id"
          class="pet-card"
          :class="{ 'is-pat': patPetId === pet.id }"
          tabindex="0"
          role="button"
          :aria-label="`查看 ${pet.name} 的详情`"
          @click="goDetail(pet)"
          @keydown.enter="goDetail(pet)"
        >
          <div
            class="pet-photo"
            :style="{ '--pet-color': pet.color }"
            @mousemove="handleTiltMove(pet, $event)"
            @mouseleave="resetTilt(pet)"
          >
            <img
              v-if="pet.image"
              :src="pet.image"
              :alt="pet.name"
              :style="{
                '--tilt-x': (tiltState[pet.id]?.x || 0) + 'deg',
                '--tilt-y': (tiltState[pet.id]?.y || 0) + 'deg',
                transitionDuration: tiltState[pet.id]?.resetting ? '0.65s' : '0.12s'
              }"
            >
            <div v-else class="photo-placeholder">
              <span>{{ pet.emoji }}</span>
            </div>
            <button
              type="button"
              class="heart-btn"
              :class="{ active: isFavorite(pet.id) }"
              :aria-label="isFavorite(pet.id) ? `取消收藏 ${pet.name}` : `收藏 ${pet.name}`"
              @click.stop="toggleFavorite(pet.id)"
            >{{ isFavorite(pet.id) ? '♥' : '♡' }}</button>
            <span class="status-badge" :class="{ applied: getPetStatus(pet.id) === '预约中' }">{{ getPetStatus(pet.id) }}</span>
            <span
              class="mood-badge mood-egg-trigger"
              role="button"
              :aria-label="`看看 ${pet.name} 的心情`"
              @click.stop="showMoodEgg(pet)"
            >{{ pet.moodEmoji }} {{ pet.mood }}</span>
            <div v-if="eggPetId === pet.id" class="mood-egg">{{ eggText }}</div>

            <button
              type="button"
              class="pat-btn"
              :aria-label="`摸摸 ${pet.name} 的头`"
              @click.stop="patPet(pet)"
            >🤚 摸一下</button>

            <template v-if="patPetId === pet.id">
              <div class="pat-hearts" aria-hidden="true">
                <span>❤</span><span>💕</span><span>❤</span>
              </div>
              <div class="pat-bubble">💖 蹭蹭你～</div>
            </template>
          </div>

          <div class="pet-body">
            <div class="pet-title">
              <h2>{{ pet.name }}</h2>
              <span class="pet-breed">{{ pet.breed }}</span>
            </div>
            <div class="pet-tags">
              <span class="pet-tag">{{ pet.gender }}</span>
              <span class="pet-tag">{{ pet.age }}</span>
              <span class="pet-tag">{{ pet.personality }}</span>
            </div>
            <div class="card-foot">
              <span class="category-chip">{{ pet.category }}</span>
              <button type="button" class="detail-btn" @click.stop="goDetail(pet)">查看详情 →</button>
              <button
                type="button"
                class="apply-btn"
                :disabled="getPetStatus(pet.id) === '预约中'"
                @click.stop="openAdoptModal(pet)"
              >{{ getPetStatus(pet.id) === '预约中' ? '已预约' : '申请领养' }}</button>
            </div>
          </div>
        </article>
      </section>

      <div v-if="!filteredPets.length" class="empty-state">
        <svg viewBox="0 0 180 140" role="img" aria-label="找不到宠物的可爱空状态插画">
          <ellipse cx="88" cy="124" rx="58" ry="9" fill="#f1d6a2" stroke="#2b2b2b" stroke-width="3"/>
          <g stroke="#2b2b2b" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">
            <path d="M46 104q0-46 43-46t43 46z" fill="#fff"/>
            <path d="M56 70 52 40l24 16z" fill="#fff"/>
            <path d="M122 70 126 40l-24 16z" fill="#fff"/>
            <path d="M59 62 57 48l11 7z" fill="#ff9ec4" stroke="none"/>
            <path d="M119 62 121 48l-11 7z" fill="#ff9ec4" stroke="none"/>
            <ellipse cx="74" cy="88" rx="5" ry="7" fill="#2b2b2b" stroke="none"/>
            <ellipse cx="104" cy="88" rx="5" ry="7" fill="#2b2b2b" stroke="none"/>
            <path d="M89 96l-4 4h8z" fill="#ff8fa8"/>
            <path d="M89 100q-7 8-13 1m13-1q7 8 13 1" fill="none"/>
            <path d="M66 102h-14m14 7h-11m62-7h14m-14 7h11" fill="none" stroke="#c9a87f" stroke-width="2"/>
            <circle cx="139" cy="76" r="19" fill="#fff8e9"/>
            <path d="m152 90 14 14" fill="none" stroke-width="5"/>
          </g>
          <text x="139" y="84" text-anchor="middle" font-size="22" font-weight="900" fill="#ff9b54" stroke="none">?</text>
          <g fill="#ffd84d" stroke="#2b2b2b" stroke-width="2">
            <path d="M24 34l3 7 7 3-7 3-3 7-3-7-7-3 7-3z"/>
            <path d="M160 34l2 5 5 2-5 2-2 5-2-5-5-2 5-2z"/>
          </g>
        </svg>
        <p class="no-result">没有找到匹配的毛孩子，换个关键词试试吧 🐾</p>
      </div>
    </main>

    <button
      type="button"
      class="back-top"
      :class="{ show: showBackTop }"
      aria-label="回到顶部"
      @click="backToTop"
    >
      <span class="paw-toe toe-1"></span>
      <span class="paw-toe toe-2"></span>
      <span class="paw-toe toe-3"></span>
      <span class="paw-toe toe-4"></span>
      <span class="paw-pad">顶</span>
    </button>

    <div class="adopt-mask" :class="{ show: adoptModalShow }" @click.self="closeAdoptModal">
      <div v-if="adoptTarget" class="adopt-modal">
        <div class="adopt-icon">🐾</div>
        <h2>申请领养 {{ adoptTarget.name }}</h2>
        <p class="adopt-sub">填好小资料，让 TA 更快找到家～</p>

        <form @submit.prevent="submitAdopt">
          <label class="form-field">
            <span>姓名</span>
            <input v-model="adoptForm.name" type="text" placeholder="怎么称呼你呀？">
          </label>
          <label class="form-field">
            <span>联系方式</span>
            <input v-model="adoptForm.contact" type="text" placeholder="手机号或微信号">
          </label>
          <label class="form-field">
            <span>领养寄语</span>
            <textarea v-model="adoptForm.message" rows="3" placeholder="想对 TA 说点什么～"></textarea>
          </label>

          <div class="notice-box">
            <strong>领养须知</strong>
            <p>领养前请确认有稳定住所与陪伴时间；同意接受后续回访；请科学喂养、不离不弃。</p>
            <label class="notice-check">
              <input v-model="adoptAgreed" type="checkbox" @change="adoptError = false">
              我已阅读并同意以上领养须知
            </label>
          </div>

          <p v-if="adoptError" class="form-error">请先填好资料并勾选领养须知哦～</p>

          <div class="modal-actions">
            <button type="button" class="cancel-btn" @click="closeAdoptModal">再想想</button>
            <button type="submit" class="submit-btn" :disabled="!adoptAgreed">提交申请 →</button>
          </div>
        </form>
      </div>
    </div>

    <div class="match-mask" :class="{ show: matchModalShow }" @click.self="closeMatchModal">
      <div class="match-modal">
        <button type="button" class="match-close" aria-label="关闭匹配测试" @click="closeMatchModal">×</button>

        <template v-if="!matchResult">
          <div class="match-head" aria-hidden="true">🐾💘🐾</div>
          <h2>缘分毛孩子匹配</h2>
          <p class="match-sub">回答 5 道小题，看看哪只 TA 和你最合拍～</p>

          <div class="match-progress" aria-hidden="true">
            <span
              v-for="(answer, index) in matchAnswers"
              :key="index"
              :class="{ done: answer !== null, current: index === currentQuestion }"
            ></span>
          </div>
          <p class="match-step">第 {{ currentQuestion + 1 }} / {{ matchQuestions.length }} 题</p>

          <div class="question-card" :key="currentQuestion">
            <p class="question-title">{{ matchQuestions[currentQuestion].title }}</p>
            <div class="option-list">
              <button
                v-for="(option, index) in matchQuestions[currentQuestion].options"
                :key="index"
                type="button"
                class="option-btn"
                :class="{ selected: matchAnswers[currentQuestion] === index }"
                @click="selectMatchOption(index)"
              >
                <span class="option-emoji" aria-hidden="true">{{ option.emoji }}</span>
                <span>{{ option.label }}</span>
              </button>
            </div>
          </div>

          <div class="match-actions">
            <button v-if="currentQuestion > 0" type="button" class="match-prev" @click="prevMatchQuestion">← 上一题</button>
            <button
              v-if="currentQuestion < matchQuestions.length - 1"
              type="button"
              class="match-next"
              :disabled="matchAnswers[currentQuestion] === null"
              @click="nextMatchQuestion"
            >下一题 →</button>
            <button
              v-else
              type="button"
              class="match-next"
              :disabled="matchAnswers[currentQuestion] === null"
              @click="finishMatch"
            >看看结果 →</button>
          </div>
        </template>

        <template v-else>
          <div class="result-card" :style="{ '--result-color': matchResult.pet.color }">
            <span class="result-badge">💘 命中注定的 TA</span>
            <div class="result-photo">
              <img v-if="matchResult.pet.image" :src="matchResult.pet.image" :alt="matchResult.pet.name">
              <span v-else aria-hidden="true">{{ matchResult.pet.emoji }}</span>
            </div>
            <h2>{{ matchResult.pet.name }}</h2>
            <p class="result-breed">{{ matchResult.pet.breed }} · {{ matchResult.pet.personality }}</p>
            <div class="result-score">
              <strong>{{ matchResult.percent }}%</strong>
              <span>契合度</span>
            </div>
            <p class="result-comment">{{ matchResult.comment }}</p>
            <div class="result-actions">
              <button type="button" class="result-again" @click="resetMatch">再测一次</button>
              <button type="button" class="result-go" @click="goMatchPetDetail">去看看它 →</button>
            </div>
          </div>
        </template>
      </div>
    </div>

    <BadgeCelebration
      v-if="celebrateBadge"
      :badge="celebrateBadge"
      @close="celebrateBadge = null"
    />

    <div class="cute-toast" :class="{ show: !!toastText }">🐾 {{ toastText }}</div>
  </div>
</template>

<style scoped>
:global(body.home-body) {
  display: block;
  align-items: initial;
  justify-content: initial;
  padding: 0;
}

.home-page {
  min-height: 100vh;
  color: var(--ink);
  font-family: "Comic Sans MS", "YouYuan", "幼圆", "Microsoft YaHei", sans-serif;
  background-color: #fff8e9;
  background-image:
    radial-gradient(#f0c98a 1.4px, transparent 1.4px),
    radial-gradient(#f0c98a 1.4px, transparent 1.4px);
  background-size: 26px 26px, 26px 26px;
  background-position: 0 0, 13px 13px;
}

.topbar {
  position: sticky;
  top: 0;
  z-index: 10;
  background: #fffdf6;
  border-bottom: 3px solid var(--ink);
  box-shadow: 0 5px 0 rgba(43, 43, 43, 0.08);
}

.topbar-inner {
  max-width: 1180px;
  margin: 0 auto;
  padding: 14px 22px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

.brand {
  display: flex;
  align-items: center;
  gap: 11px;
  font-size: 21px;
  font-weight: 900;
  letter-spacing: 0.5px;
}

.brand-badge {
  width: 42px;
  height: 42px;
  display: grid;
  place-items: center;
  background: var(--pink);
  border: var(--line);
  border-radius: 13px;
  font-size: 23px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-6deg);
}

.nav-actions {
  display: flex;
  gap: 12px;
}

.nav-btn {
  padding: 10px 18px;
  font: inherit;
  font-size: 14px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: 12px;
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.nav-btn:hover {
  transform: translate(-2px, -2px);
  box-shadow: 6px 6px 0 var(--ink);
}

.nav-btn:active {
  transform: translate(4px, 4px);
  box-shadow: 1px 1px 0 var(--ink);
}

.nav-btn.mine { background: var(--mint); }
.nav-btn.logout { background: #ffc9cf; }

.home-main {
  max-width: 1180px;
  margin: 0 auto;
  padding: 32px 22px 64px;
}

.hero {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  padding: 30px 34px;
  margin-bottom: 30px;
  background: #fff2c9;
  border: var(--line);
  border-radius: 26px;
  box-shadow: 8px 8px 0 var(--ink);
  overflow: hidden;
}

.hero::after {
  content: "";
  position: absolute;
  inset: 0;
  background: repeating-conic-gradient(from 0deg at 88% 20%, rgba(255, 255, 255, 0.5) 0 15deg, transparent 15deg 30deg);
  pointer-events: none;
}

.hero-copy { position: relative; z-index: 1; }

.hero-tag {
  display: inline-block;
  padding: 5px 12px;
  margin-bottom: 12px;
  font-size: 12px;
  font-weight: 900;
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: 999px;
  transform: rotate(-3deg);
}

.hero h1 {
  margin: 0 0 8px;
  font-size: 30px;
  letter-spacing: 1px;
}

.hero p {
  margin: 0;
  font-size: 14px;
  font-weight: 700;
  color: #8a6a4f;
}

.hero-sticker {
  position: relative;
  z-index: 1;
  flex-shrink: 0;
  width: 130px;
  height: 110px;
}

.hero-sticker span {
  position: absolute;
  font-size: 60px;
  filter: drop-shadow(5px 6px 0 rgba(43, 43, 43, 0.22));
  animation: bob 3s ease-in-out infinite;
}

.hero-sticker span:first-child { left: 0; top: 12px; transform: rotate(-12deg); }
.hero-sticker span:last-child { right: 0; top: 0; font-size: 52px; animation-delay: 0.8s; transform: rotate(10deg); }

@keyframes bob {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -12px; }
}

.filter-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 18px;
}

.filter-btn {
  min-width: 92px;
  padding: 11px 20px;
  font: inherit;
  font-size: 15px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: 13px;
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.filter-btn:hover { background: #fff6d9; transform: translate(-2px, -2px); box-shadow: 6px 6px 0 var(--ink); }

.filter-btn.active {
  background: var(--yellow);
  transform: translate(2px, 2px);
  box-shadow: 1px 1px 0 var(--ink);
}

.result-hint {
  margin: 0 0 18px;
  font-size: 13px;
  font-weight: 900;
  color: #8a6a4f;
}

.pet-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(268px, 1fr));
  gap: 26px;
}

.pet-card {
  background: #fffdf6;
  border: var(--line);
  border-radius: 24px;
  box-shadow: 8px 9px 0 var(--ink);
  overflow: hidden;
  cursor: pointer;
  outline: none;
  transition: transform 0.18s ease, box-shadow 0.18s ease;
  animation: card-in 0.45s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}

.pet-card:hover,
.pet-card:focus-visible {
  transform: translate(-4px, -7px);
  box-shadow: 12px 16px 0 var(--ink);
}

.pet-card:active {
  transform: translate(4px, 4px);
  box-shadow: 3px 4px 0 var(--ink);
}

@keyframes card-in {
  from { opacity: 0; transform: translateY(18px) scale(0.96); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}

.pet-photo {
  position: relative;
  height: 176px;
  display: grid;
  place-items: center;
  background: var(--pet-color);
  border-bottom: 3px solid var(--ink);
  overflow: hidden;
}

.pet-photo img {
  width: 70%;
  height: 70%;
  object-fit: contain;
}

.photo-placeholder {
  width: 100%;
  height: 100%;
  display: grid;
  place-items: center;
  background:
    radial-gradient(circle at 50% 120%, rgba(255, 255, 255, 0.65), transparent 60%),
    repeating-linear-gradient(45deg, rgba(255, 255, 255, 0.18) 0 12px, transparent 12px 24px);
}

.photo-placeholder span {
  font-size: 86px;
  line-height: 1;
  filter: drop-shadow(6px 8px 0 rgba(43, 43, 43, 0.2));
  transition: transform 0.2s;
}

.pet-card:hover .photo-placeholder span { transform: scale(1.08) rotate(-5deg); }

.mood-badge {
  position: absolute;
  left: 12px;
  top: 12px;
  padding: 6px 11px;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-5deg);
}

.pet-body { padding: 16px 18px 18px; }

.pet-title {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 12px;
}

.pet-title h2 {
  margin: 0;
  font-size: 22px;
  letter-spacing: 1px;
}

.pet-breed {
  font-size: 12px;
  font-weight: 900;
  color: #8a6a4f;
}

.pet-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  margin-bottom: 18px;
}

.pet-tag {
  padding: 5px 10px;
  font-size: 11px;
  font-weight: 900;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
}

.pet-tag:nth-child(2) { background: var(--blue); }
.pet-tag:nth-child(3) { background: var(--pink); }

.card-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.category-chip {
  padding: 5px 12px;
  font-size: 11px;
  font-weight: 900;
  background: var(--mint);
  border: 2px solid var(--ink);
  border-radius: 999px;
}

.detail-btn {
  padding: 8px 14px;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 10px;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.detail-btn:hover { background: #ffe27a; transform: translate(-1px, -1px); box-shadow: 4px 4px 0 var(--ink); }

@media (max-width: 760px) {
  .topbar-inner { flex-wrap: wrap; }
  .home-main { padding: 22px 16px 48px; }
  .hero { padding: 24px 22px; }
  .hero-sticker { display: none; }
  .hero h1 { font-size: 24px; }
  .pet-grid { grid-template-columns: 1fr; }
}

/* ===== 增量功能：搜索 / 收藏 / 状态角标 / 图标浮动 / 回到顶部 ===== */

/* 1. 导航栏搜索框 */
.search-box {
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 6px 15px;
  background: #fff;
  border: var(--line);
  border-radius: 999px;
  box-shadow: 4px 4px 0 var(--ink);
  transition: 0.12s;
}

.search-box:focus-within {
  transform: translate(-2px, -2px);
  box-shadow: 6px 6px 0 var(--ink);
}

.search-icon { font-size: 15px; }

.search-box input {
  width: 168px;
  border: 0;
  outline: 0;
  background: transparent;
  font: inherit;
  font-size: 13px;
  font-weight: 800;
  color: var(--ink);
}

.search-box input::placeholder { color: #b7a999; font-weight: 700; }
.search-box input::-webkit-search-cancel-button { cursor: pointer; }

/* 2. 爱心收藏按钮 */
.heart-btn {
  position: absolute;
  left: 12px;
  top: 12px;
  z-index: 4;
  width: 34px;
  height: 34px;
  padding: 0;
  display: grid;
  place-items: center;
  font-size: 26px;
  line-height: 1;
  color: #fff;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.15s;
  text-shadow:
    -1px -1px 0 var(--ink), 1px -1px 0 var(--ink),
    -1px 1px 0 var(--ink), 1px 1px 0 var(--ink);
}

.heart-btn:hover { transform: translate(-1px, -2px) scale(1.08); box-shadow: 4px 5px 0 var(--ink); }
.heart-btn.active {
  color: #ff4d7d;
  background: #fff0f4;
  animation: heart-pop 0.3s cubic-bezier(0.2, 1.6, 0.4, 1);
}

@keyframes heart-pop {
  from { transform: scale(0.7) rotate(-12deg); }
  to { transform: scale(1) rotate(0); }
}

/* 心情徽章为爱心让位，保持原有样式不变 */
.pet-photo .mood-badge { left: 54px; }

/* 3. 待领养状态角标 */
.status-badge {
  position: absolute;
  right: 12px;
  top: 12px;
  z-index: 4;
  padding: 6px 11px;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 10px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(5deg);
}

/* 4. 悬停时宠物图标小幅上下浮动，强化 3D 感 */
@keyframes icon-float {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -9px; }
}

.pet-card:hover .photo-placeholder span,
.pet-card:hover .pet-photo img {
  animation: icon-float 1.1s ease-in-out infinite;
}

.no-result {
  padding: 40px 20px;
  text-align: center;
  font-size: 14px;
  font-weight: 900;
  color: #8a6a4f;
}

/* 5. 爪印形状的回到顶部按钮 */
.back-top {
  position: fixed;
  right: 26px;
  bottom: 26px;
  z-index: 30;
  width: 62px;
  height: 62px;
  padding: 0;
  border: 0;
  background: transparent;
  cursor: pointer;
  opacity: 0;
  pointer-events: none;
  transform: translateY(18px) scale(0.9);
  transition: opacity 0.2s, transform 0.2s;
}

.back-top.show {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0) scale(1);
}

.back-top:hover { animation: bob 0.9s ease-in-out infinite; }

.paw-toe,
.paw-pad {
  position: absolute;
  display: grid;
  place-items: center;
  background: var(--yellow);
  border: 2px solid var(--ink);
  box-shadow: 2px 2px 0 var(--ink);
}

.paw-toe { width: 17px; height: 20px; border-radius: 50%; }
.toe-1 { left: 5px; top: 5px; transform: rotate(-22deg); }
.toe-2 { left: 22px; top: 0; }
.toe-3 { left: 39px; top: 0; }
.toe-4 { right: 4px; top: 7px; transform: rotate(22deg); }

.paw-pad {
  left: 12px;
  bottom: 2px;
  width: 38px;
  height: 30px;
  border-radius: 50% 50% 45% 45%;
  font: inherit;
  font-size: 12px;
  font-weight: 900;
  color: var(--ink);
}

@media (max-width: 900px) {
  .search-box input { width: 120px; }
}

@media (max-width: 760px) {
  .nav-actions { flex-wrap: wrap; justify-content: flex-end; }
  .search-box { order: 3; width: 100%; }
  .search-box input { width: 100%; }
}

/* ===== 领养闭环增量样式 ===== */

/* 1. 今日明星毛孩子 */
.star-card {
  position: relative;
  display: grid;
  grid-template-columns: 150px 1fr auto;
  align-items: center;
  gap: 22px;
  padding: 18px 24px;
  margin-bottom: 30px;
  background: #fffdf6;
  border: var(--line);
  border-radius: 26px;
  box-shadow: 8px 9px 0 var(--ink);
  overflow: hidden;
  animation: star-breathe 4s ease-in-out infinite;
}

.star-card::after {
  content: "";
  position: absolute;
  right: -40px;
  top: -60px;
  width: 220px;
  height: 220px;
  border-radius: 50%;
  background: repeating-conic-gradient(from 0deg, rgba(255, 216, 77, 0.28) 0 14deg, transparent 14deg 28deg);
  pointer-events: none;
}

@keyframes star-breathe {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -4px; }
}

.star-photo {
  position: relative;
  z-index: 1;
  width: 150px;
  height: 120px;
  display: grid;
  place-items: center;
  background: var(--star-color);
  border: 3px solid var(--ink);
  border-radius: 20px;
  box-shadow: 5px 5px 0 var(--ink);
  overflow: hidden;
}

.star-photo img { width: 100%; height: 100%; object-fit: cover; }
.star-emoji {
  font-size: 78px;
  line-height: 1;
  filter: drop-shadow(5px 7px 0 rgba(43, 43, 43, 0.2));
  animation: bob 2.8s ease-in-out infinite;
}

.star-copy { position: relative; z-index: 1; }

.star-badge {
  display: inline-block;
  padding: 5px 12px;
  margin-bottom: 8px;
  font-size: 12px;
  font-weight: 900;
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-3deg);
}

.star-copy h2 { margin: 0 0 6px; font-size: 27px; }
.star-copy h2 small { font-size: 14px; color: #8a6a4f; }
.star-copy p { margin: 0 0 12px; font-size: 13px; font-weight: 700; line-height: 1.6; color: #8a6a4f; }
.star-tags { display: flex; flex-wrap: wrap; gap: 7px; }
.star-tags span {
  padding: 5px 10px;
  font-size: 11px;
  font-weight: 900;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
}

.star-btn {
  position: relative;
  z-index: 1;
  padding: 11px 18px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: var(--line);
  border-radius: 13px;
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.star-btn:hover { transform: translate(-2px, -2px); box-shadow: 6px 6px 0 var(--ink); }
.star-btn:active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

/* 2. 申请领养按钮 */
.card-foot { flex-wrap: wrap; }
.card-foot .detail-btn { padding: 8px 11px; font-size: 11px; }

.apply-btn {
  padding: 8px 11px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: 10px;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}

.apply-btn:hover:not(:disabled) { background: #ffb6d3; transform: translate(-1px, -1px); box-shadow: 4px 4px 0 var(--ink); }
.apply-btn:disabled { background: #dcd4c8; cursor: default; }

.status-badge.applied { background: var(--mint); }

/* 3. 心情徽章彩蛋气泡 */
.pet-photo .mood-egg-trigger { cursor: pointer; }
.mood-egg-trigger:hover { filter: brightness(1.04); }

.mood-egg {
  position: absolute;
  left: 54px;
  top: 50px;
  z-index: 6;
  max-width: 190px;
  padding: 10px 13px;
  background: #fff;
  border: var(--line);
  border-radius: 14px;
  box-shadow: 4px 4px 0 var(--ink);
  font-size: 12px;
  font-weight: 900;
  line-height: 1.5;
  animation: egg-pop 0.25s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}

.mood-egg::after {
  content: "";
  position: absolute;
  left: 22px;
  top: -13px;
  width: 18px;
  height: 18px;
  background: #fff;
  border-left: var(--line);
  border-top: var(--line);
  transform: rotate(45deg);
}

@keyframes egg-pop {
  from { opacity: 0; transform: scale(0.8) translateY(6px); }
  to { opacity: 1; transform: scale(1) translateY(0); }
}

/* 4. Q 版空状态插画 */
.empty-state { padding: 46px 20px 30px; text-align: center; }
.empty-state svg {
  width: 180px;
  max-width: 100%;
  height: auto;
  animation: bob 3s ease-in-out infinite;
}
.empty-state .no-result { margin-top: 6px; }

/* 5. 领养弹窗 */
.adopt-mask {
  position: fixed;
  inset: 0;
  z-index: 50;
  display: none;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: rgba(43, 43, 43, 0.45);
}
.adopt-mask.show { display: flex; }

.adopt-modal {
  width: min(440px, 100%);
  max-height: 90vh;
  overflow: auto;
  padding: 26px 26px 24px;
  background: #fffdf6;
  border: var(--line);
  border-radius: 24px;
  box-shadow: 9px 10px 0 var(--ink);
  animation: modal-pop 0.3s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}

@keyframes modal-pop {
  from { opacity: 0; transform: scale(0.82) rotate(-4deg); }
  to { opacity: 1; transform: scale(1) rotate(0); }
}

.adopt-icon { font-size: 42px; text-align: center; }
.adopt-modal h2 { margin: 6px 0 2px; text-align: center; font-size: 24px; }
.adopt-sub { margin: 0 0 18px; text-align: center; font-size: 12px; font-weight: 700; color: #8a6a4f; }

.form-field { display: block; margin-bottom: 13px; }
.form-field span { display: block; margin-bottom: 6px; font-size: 12px; font-weight: 900; }
.form-field input,
.form-field textarea {
  width: 100%;
  padding: 10px 12px;
  font: inherit;
  font-size: 13px;
  font-weight: 700;
  color: var(--ink);
  background: #fff;
  border: var(--line);
  border-radius: 12px;
  outline: none;
  resize: vertical;
  transition: 0.12s;
}
.form-field input:focus,
.form-field textarea:focus { box-shadow: 4px 4px 0 var(--ink); transform: translate(-2px, -2px); }
.form-field input::placeholder,
.form-field textarea::placeholder { color: #b7a999; font-weight: 600; }

.notice-box {
  margin: 16px 0;
  padding: 12px 14px;
  background: #fff6d9;
  border: 2px solid var(--ink);
  border-radius: 14px;
}
.notice-box strong { font-size: 13px; }
.notice-box p { margin: 6px 0 10px; font-size: 11px; font-weight: 700; line-height: 1.6; color: #8a6a4f; }
.notice-check { display: flex; align-items: center; gap: 8px; font-size: 12px; font-weight: 900; cursor: pointer; }
.notice-check input {
  appearance: none;
  width: 18px;
  height: 18px;
  margin: 0;
  border: 2px solid var(--ink);
  border-radius: 5px;
  background: #fff;
  cursor: pointer;
  position: relative;
}
.notice-check input:checked { background: var(--yellow); }
.notice-check input:checked::after {
  content: "✓";
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  font-size: 13px;
  font-weight: 900;
}

.form-error { margin: 0 0 10px; font-size: 11px; font-weight: 900; color: #d8385b; }

.modal-actions { display: flex; gap: 12px; }
.cancel-btn,
.submit-btn {
  flex: 1;
  padding: 11px 0;
  font: inherit;
  font-size: 14px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: 12px;
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
}
.cancel-btn { background: #fff; }
.submit-btn { background: var(--yellow); }
.submit-btn:disabled { background: #e6ded2; cursor: not-allowed; }
.cancel-btn:active,
.submit-btn:not(:disabled):active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

/* 提交成功轻提示 */
.cute-toast {
  position: fixed;
  left: 50%;
  bottom: 34px;
  z-index: 60;
  translate: -50% 20px;
  opacity: 0;
  pointer-events: none;
  padding: 12px 20px;
  background: #fffdf6;
  border: var(--line);
  border-radius: 999px;
  box-shadow: 5px 5px 0 var(--ink);
  font-size: 13px;
  font-weight: 900;
  white-space: nowrap;
  transition: opacity 0.25s, translate 0.25s;
}
.cute-toast.show { opacity: 1; translate: -50% 0; }

@media (max-width: 900px) {
  .star-card { grid-template-columns: 110px 1fr; }
  .star-photo { width: 110px; height: 100px; }
  .star-emoji { font-size: 60px; }
  .star-btn { grid-column: 1 / -1; width: 100%; }
}

@media (max-width: 760px) {
  .star-card { grid-template-columns: 1fr; padding: 18px; }
  .star-photo { width: 100%; height: 140px; }
  .star-btn { grid-column: auto; }
  .mood-egg { left: 12px; top: 52px; }
}

/* ===== 缘分毛孩子匹配（增量） ===== */

/* banner 下方入口按钮 */
.match-entry {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 16px;
  margin: -10px 0 30px;
  padding: 16px 24px;
  font: inherit;
  text-align: left;
  color: var(--ink);
  background: linear-gradient(100deg, #fff2c9, #ffe0ec);
  border: var(--line);
  border-radius: 22px;
  box-shadow: 7px 8px 0 var(--ink);
  cursor: pointer;
  transition: 0.15s;
  animation: match-breathe 4s ease-in-out infinite;
}

.match-entry:hover { transform: translate(-3px, -4px); box-shadow: 10px 12px 0 var(--ink); }
.match-entry:active { transform: translate(4px, 4px); box-shadow: 3px 4px 0 var(--ink); }

@keyframes match-breathe {
  0%, 100% { translate: 0 0; }
  50% { translate: 0 -3px; }
}

.match-entry-spark {
  font-size: 34px;
  line-height: 1;
  filter: drop-shadow(3px 4px 0 rgba(43, 43, 43, 0.18));
  animation: bob 2.6s ease-in-out infinite;
}

.match-entry-copy { flex: 1; display: flex; flex-direction: column; gap: 3px; }
.match-entry-copy strong { font-size: 19px; letter-spacing: 0.5px; }
.match-entry-copy small { font-size: 12px; font-weight: 700; color: #8a6a4f; }

.match-entry-arrow {
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: 3px 3px 0 var(--ink);
  font-size: 20px;
  font-weight: 900;
}

/* 匹配弹窗 */
.match-mask {
  position: fixed;
  inset: 0;
  z-index: 55;
  display: none;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: rgba(43, 43, 43, 0.45);
}
.match-mask.show { display: flex; }

.match-modal {
  position: relative;
  width: min(480px, 100%);
  max-height: 90vh;
  overflow: auto;
  padding: 28px 28px 26px;
  background: #fffdf6;
  border: var(--line);
  border-radius: 26px;
  box-shadow: 9px 10px 0 var(--ink);
  animation: modal-pop 0.3s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}

.match-close {
  position: absolute;
  right: 14px;
  top: 14px;
  z-index: 2;
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  font: inherit;
  font-size: 24px;
  font-weight: 900;
  line-height: 1;
  color: var(--ink);
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: 50%;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: transform 0.2s;
}
.match-close:hover { transform: rotate(90deg); }

.match-head { text-align: center; font-size: 30px; letter-spacing: 4px; }
.match-modal h2 { margin: 6px 0 2px; text-align: center; font-size: 25px; }
.match-sub { margin: 0 0 16px; text-align: center; font-size: 12px; font-weight: 700; color: #8a6a4f; }

.match-progress { display: flex; justify-content: center; gap: 8px; margin-bottom: 6px; }
.match-progress span {
  width: 24px;
  height: 8px;
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
  transition: 0.2s;
}
.match-progress span.done { background: var(--mint); }
.match-progress span.current { background: var(--yellow); transform: scaleY(1.35); }
.match-step { margin: 0 0 14px; text-align: center; font-size: 11px; font-weight: 900; color: #8a6a4f; }

/* 卡通气泡题卡 */
.question-card {
  position: relative;
  padding: 20px 18px 18px;
  background: #fff6d9;
  border: var(--line);
  border-radius: 20px;
  box-shadow: 5px 6px 0 var(--ink);
  animation: egg-pop 0.3s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
.question-card::after {
  content: "";
  position: absolute;
  left: 34px;
  bottom: -14px;
  width: 20px;
  height: 20px;
  background: #fff6d9;
  border-right: var(--line);
  border-bottom: var(--line);
  transform: rotate(45deg) skew(-8deg, -8deg);
}
.question-title { margin: 0 0 14px; font-size: 16px; font-weight: 900; }
.option-list { display: grid; gap: 10px; }

.option-btn {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 11px 13px;
  font: inherit;
  font-size: 13px;
  font-weight: 900;
  text-align: left;
  color: var(--ink);
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 13px;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}
.option-btn:hover { transform: translate(-2px, -2px); box-shadow: 5px 5px 0 var(--ink); }
.option-btn.selected { background: var(--yellow); transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }
.option-emoji { font-size: 20px; }

.match-actions { display: flex; gap: 12px; margin-top: 22px; }
.match-prev,
.match-next {
  flex: 1;
  padding: 12px 0;
  font: inherit;
  font-size: 14px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: 13px;
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
}
.match-prev { background: #fff; }
.match-next { background: var(--yellow); }
.match-next:disabled { background: #e6ded2; cursor: not-allowed; }
.match-prev:active,
.match-next:not(:disabled):active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

/* 匹配结果卡 */
.result-card { text-align: center; padding: 6px 4px 2px; animation: modal-pop 0.45s cubic-bezier(0.2, 1.5, 0.4, 1) both; }
.result-badge {
  display: inline-block;
  padding: 6px 14px;
  font-size: 12px;
  font-weight: 900;
  background: var(--pink);
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 3px 3px 0 var(--ink);
  transform: rotate(-3deg);
}
.result-photo {
  width: 140px;
  height: 130px;
  margin: 18px auto 10px;
  display: grid;
  place-items: center;
  background: var(--result-color);
  border: 3px solid var(--ink);
  border-radius: 20px;
  box-shadow: 5px 5px 0 var(--ink);
  overflow: hidden;
}
.result-photo img { width: 100%; height: 100%; object-fit: cover; }
.result-photo span {
  font-size: 76px;
  line-height: 1;
  filter: drop-shadow(4px 6px 0 rgba(43, 43, 43, 0.2));
  animation: bob 2.6s ease-in-out infinite;
}
.result-card h2 { margin: 0 0 2px; font-size: 26px; }
.result-breed { margin: 0 0 12px; font-size: 12px; font-weight: 700; color: #8a6a4f; }
.result-score {
  display: inline-flex;
  align-items: baseline;
  gap: 6px;
  padding: 8px 16px;
  background: var(--yellow);
  border: var(--line);
  border-radius: 999px;
  box-shadow: 4px 4px 0 var(--ink);
}
.result-score strong { font-size: 26px; }
.result-score span { font-size: 12px; font-weight: 900; }
.result-comment { margin: 16px auto 4px; max-width: 330px; font-size: 13px; font-weight: 800; line-height: 1.7; color: #8a6a4f; }
.result-actions { display: flex; gap: 12px; margin-top: 20px; }
.result-again,
.result-go {
  flex: 1;
  padding: 12px 0;
  font: inherit;
  font-size: 14px;
  font-weight: 900;
  color: var(--ink);
  border: var(--line);
  border-radius: 13px;
  box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer;
}
.result-again { background: #fff; }
.result-go { background: var(--mint); }
.result-again:active,
.result-go:active { transform: translate(4px, 4px); box-shadow: 1px 1px 0 var(--ink); }

@media (max-width: 760px) {
  .match-entry { padding: 14px 16px; gap: 10px; }
  .match-entry-copy strong { font-size: 16px; }
  .match-entry-spark { font-size: 26px; }
  .match-modal { padding: 24px 18px; }
  .result-photo { width: 120px; height: 110px; }
}

/* ===== 云撸宠：摸脑袋（增量） ===== */
.pat-btn {
  position: absolute;
  left: 12px;
  bottom: 10px;
  z-index: 5;
  padding: 6px 11px;
  font: inherit;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: #fff;
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}
.pat-btn:hover { background: var(--pink); transform: translate(-1px, -1px); box-shadow: 4px 4px 0 var(--ink); }
.pat-btn:active { transform: translate(2px, 2px); box-shadow: 1px 1px 0 var(--ink); }

/* 选择器权重需高于原 hover 动画，故保留 .pet-card 前缀 */
.pet-card.is-pat .photo-placeholder span,
.pet-card.is-pat .pet-photo img { animation: pat-shake 0.45s ease-in-out 2; }

@keyframes pat-shake {
  0%, 100% { rotate: 0deg; translate: 0 0; }
  25% { rotate: -9deg; translate: -5px 0; }
  50% { rotate: 8deg; translate: 4px -4px; }
  75% { rotate: -5deg; translate: -3px 0; }
}

.pat-hearts { position: absolute; inset: 0; z-index: 6; pointer-events: none; }
.pat-hearts span {
  position: absolute;
  left: 50%;
  top: 42%;
  font-size: 20px;
  animation: heart-float 0.9s ease-out forwards;
}
.pat-hearts span:nth-child(1) { margin-left: -34px; animation-delay: 0s; }
.pat-hearts span:nth-child(2) { margin-left: 0; font-size: 24px; animation-delay: 0.12s; }
.pat-hearts span:nth-child(3) { margin-left: 30px; animation-delay: 0.22s; }

@keyframes heart-float {
  0% { opacity: 0; transform: translateY(10px) scale(0.6); }
  25% { opacity: 1; }
  100% { opacity: 0; transform: translateY(-60px) scale(1.15); }
}

.pat-bubble {
  position: absolute;
  left: 12px;
  bottom: 48px;
  z-index: 7;
  padding: 8px 12px;
  background: #fff;
  border: var(--line);
  border-radius: 14px;
  box-shadow: 4px 4px 0 var(--ink);
  font-size: 12px;
  font-weight: 900;
  animation: egg-pop 0.25s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}
.pat-bubble::after {
  content: "";
  position: absolute;
  left: 20px;
  bottom: -12px;
  width: 16px;
  height: 16px;
  background: #fff;
  border-right: var(--line);
  border-bottom: var(--line);
  transform: rotate(45deg);
}

/* ===== 导航栏头像 + 徽章数量角标（增量） ===== */
.user-avatar {
  position: relative;
  width: 44px;
  height: 44px;
  padding: 0;
  display: grid;
  place-items: center;
  background: #fff0f4;
  border: var(--line);
  border-radius: 50%;
  box-shadow: 3px 3px 0 var(--ink);
  cursor: pointer;
  transition: 0.12s;
}
.user-avatar:hover { transform: translate(-2px, -2px); box-shadow: 5px 5px 0 var(--ink); }
.avatar-face { font-size: 24px; line-height: 1; }
.avatar-badge-count {
  position: absolute;
  right: -8px;
  top: -8px;
  min-width: 20px;
  height: 20px;
  padding: 0 4px;
  display: grid;
  place-items: center;
  font-size: 11px;
  font-weight: 900;
  color: var(--ink);
  background: var(--yellow);
  border: 2px solid var(--ink);
  border-radius: 999px;
  box-shadow: 2px 2px 0 var(--ink);
  animation: badge-count-pop 0.4s cubic-bezier(0.2, 1.5, 0.4, 1) both;
}
@keyframes badge-count-pop {
  from { transform: scale(0.5); }
  to { transform: scale(1); }
}

/* ===== 宠物形象完整展示：仅调整装饰元素位置，其余一律不动 ===== */
/* 图片区不再溢出隐藏（圆角仍由卡片父级 overflow 保证），图片不裁切 */
.pet-card .pet-photo { overflow: visible; }

/* 宠物图片完整 contain + 居中留白，不拉伸不裁切 */
.pet-card .pet-photo img {
  width: 72%;
  height: 72%;
  object-fit: contain;
}

/* 顶部留白带：心情徽章(左) / 待领养角标(右) / 爱心收藏(最右上角)，均不压宠物 */
.pet-card .pet-photo .mood-badge { left: 10px; top: 10px; }
.pet-card .pet-photo .status-badge { right: 54px; top: 12px; }
.pet-card .pet-photo .heart-btn { left: auto; right: 10px; top: 10px; }

/* 心情彩蛋气泡跟随心情徽章 */
.pet-card .pet-photo .mood-egg { left: 10px; top: 46px; }

/* 摸一下按钮：只改定位——右侧靠右对齐、垂直居中于宠物形象；尺寸/圆角/描边/投影/文字/交互全部沿用原样式 */
.pet-card .pet-photo .pat-btn {
  left: auto;
  right: 10px;
  top: 50%;
  bottom: auto;
  transform: translateY(-50%);
}
.pet-card .pet-photo .pat-btn:hover { transform: translateY(-50%) translate(-1px, -1px); }
.pet-card .pet-photo .pat-btn:active { transform: translateY(-50%) translate(2px, 2px); }

/* 摸头互动气泡跟随按钮居中（用 margin 居中，避免被 egg-pop 的 transform 覆盖） */
.pet-card .pet-photo .pat-bubble { left: 50%; bottom: 44px; margin-left: -50px; }
.pet-card .pet-photo .pat-bubble::after { left: 50%; margin-left: -8px; }

/* ===== 图片区背景 + 宠物 3D 质感增强（只改背景与质感，不动布局） ===== */
/* 干净平整的柔和斜纹底色（去掉棋盘格/网格感），沿用每只宠物的专属底色 */
.pet-card .pet-photo {
  background-color: var(--pet-color);
  background-image:
    repeating-linear-gradient(135deg, rgba(255, 255, 255, 0.32) 0 10px, rgba(255, 255, 255, 0) 10px 20px);
}

/* 宠物图：透明显色 + 多层柔和投影强化立体感（圆润高光/细腻阴影/接触投影） */
.pet-card .pet-photo img {
  filter:
    drop-shadow(0 2px 1px rgba(43, 43, 43, 0.16))
    drop-shadow(0 7px 6px rgba(43, 43, 43, 0.18))
    drop-shadow(0 14px 12px rgba(90, 60, 30, 0.12))
    saturate(1.06) contrast(1.03) brightness(1.01);
}

/* 无图占位符也沿用干净斜纹，避免网格 */
.pet-card .pet-photo .photo-placeholder {
  background:
    radial-gradient(circle at 50% 118%, rgba(255, 255, 255, 0.7), transparent 62%),
    repeating-linear-gradient(135deg, rgba(255, 255, 255, 0.32) 0 10px, rgba(255, 255, 255, 0) 10px 20px);
}

/* ===== 宠物形象底部居中：只改摆放位置，尺寸/滤镜/其余元素一律不动 ===== */
/* 锁定图片区网格轨道高度=容器高度，避免 img 按宽度把自动轨道撑大、导致图片越出图片区 */
.pet-card .pet-photo { grid-template-rows: 100%; }

/* 图片框底边贴到图片区下沿（水平方向仍由 place-items:center 保持居中）；
   PNG 自身底部有透明留白，用 transform 向下补偿，让可见的宠物脚底真正贴边。
   transform 与 hover 的 icon-float / 摸头的 pat-shake（用 translate/rotate 独立属性）叠加互不覆盖。 */
.pet-card .pet-photo img {
  align-self: end;
  --pet-ground-shift: 11.3%;
  --tilt-x: 0deg;
  --tilt-y: 0deg;
  /* 贴底位移 + 鼠标控制的 X/Y 轴旋转；perspective 放在 transform 内，不影响徽章/按钮 */
  transform:
    perspective(700px)
    translateY(var(--pet-ground-shift))
    rotateX(var(--tilt-x))
    rotateY(var(--tilt-y));
  transform-style: preserve-3d;
  transition: transform 0.12s ease-out;
  will-change: transform;
}
/* 按各图底部透明留白百分比补偿，6 只脚底对齐同一水平线（百分比相对图片自身高度，卡片高度变化也自适应） */
.pet-card .pet-photo img[src*="naigai.png"]      { --pet-ground-shift: 11.3%; }
.pet-card .pet-photo img[src*="zhima.png"]       { --pet-ground-shift: 17.9%; }
.pet-card .pet-photo img[src*="buding.png"]      { --pet-ground-shift: 13.7%; }
.pet-card .pet-photo img[src*="kele.png"]        { --pet-ground-shift: 9.3%; }
.pet-card .pet-photo img[src*="mianhuatang.png"] { --pet-ground-shift: 20.2%; }
.pet-card .pet-photo img[src*="doudou.png"]      { --pet-ground-shift: 13.3%; }

/* 移动端/粗指针：始终正面显示，不触发旋转 */
@media (hover: none), (pointer: coarse) {
  .pet-card .pet-photo img {
    --tilt-x: 0deg !important;
    --tilt-y: 0deg !important;
  }
}
</style>
