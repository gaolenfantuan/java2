<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { adoptPets, filterConfig, sortOptions } from '../data/adoptPets'
import { getRescuedAdoptPets } from '../data/rescuePets'
import CuteEmpty from '../components/CuteEmpty.vue'

const router = useRouter()

// 页面内关键词搜索（名字 / 品种 / 城市 / 性格），与全局导航搜索相互独立
const keyword = ref('')

// ===== 状态分类 Tab =====
const statusTabs = [
  { label: '全部', value: 'all', icon: '🐾' },
  { label: '待领养', value: 'available', icon: '💛' },
  { label: '预约中', value: 'reserved', icon: '⏳' },
  { label: '已领养', value: 'adopted', icon: '🏠' }
]
const activeStatus = ref('all')

// ===== localStorage 状态 =====
const applyStatuses = ref({})   // { [petId]: '预约中' }
const adoptedIds = ref([])      // 已领养宠物 id
const applications = ref([])    // 申请记录
const allPets = ref([...adoptPets])  // 领养池：原有宠物 + 救助完成转入的宠物

function loadStorage() {
  // 合并「流浪救助」完成的宠物（状态为待领养），按 id 去重
  const rescued = getRescuedAdoptPets()
  const merged = [...adoptPets]
  rescued.forEach(p => { if (!merged.some(x => x.id === p.id)) merged.push(p) })
  allPets.value = merged
  try {
    const s = JSON.parse(localStorage.getItem('petApplyStatuses') || '{}')
    applyStatuses.value = s && typeof s === 'object' ? s : {}
  } catch { applyStatuses.value = {} }
  try {
    const a = JSON.parse(localStorage.getItem('petAdopted') || '[]')
    adoptedIds.value = Array.isArray(a) ? a : []
  } catch { adoptedIds.value = [] }
  try {
    const r = JSON.parse(localStorage.getItem('petAdoptApplications') || '[]')
    applications.value = Array.isArray(r) ? r : []
  } catch { applications.value = [] }
  loadFavorites()
}

// 宠物状态：adopted > reserved > available
function petStatus(pet) {
  if (adoptedIds.value.includes(pet.id)) return 'adopted'
  if (applyStatuses.value[pet.id] === '预约中') return 'reserved'
  return 'available'
}
const STATUS_META = {
  available: { text: '待领养', icon: '💛' },
  reserved: { text: '预约中', icon: '⏳' },
  adopted: { text: '已回家', icon: '🏠' }
}

// ===== 收藏（与首页共用 petFavorites，跨页同步） =====
const favorites = ref([])
const favPopId = ref(null)
let favTimer = null

function loadFavorites() {
  try {
    const saved = JSON.parse(localStorage.getItem('petFavorites') || '[]')
    favorites.value = Array.isArray(saved) ? saved : []
  } catch { favorites.value = [] }
}
function isFavorite(id) { return favorites.value.includes(id) }
function toggleFavorite(pet) {
  if (isFavorite(pet.id)) favorites.value = favorites.value.filter(x => x !== pet.id)
  else favorites.value = [...favorites.value, pet.id]
  try { localStorage.setItem('petFavorites', JSON.stringify(favorites.value)) } catch { /* ignore */ }
  // 弹跳反馈：标记当前卡片，动画结束后自动摘除
  favPopId.value = pet.id
  clearTimeout(favTimer)
  favTimer = setTimeout(() => { favPopId.value = null }, 540)
}

// ===== 高级筛选（多选） =====
const selectedFilters = reactive({
  city: [], breed: [], gender: [], ageGroup: [], sterilized: [], vaccinated: [], traits: []
})

// 进阶项默认收起，选中后保持展开避免「隐藏的已选项」造成困惑
const ADVANCED_KEYS = ['sterilized', 'vaccinated', 'traits']
const advancedOpen = ref(false)
const basicFilterEntries = computed(() =>
  Object.entries(filterConfig).filter(([key]) => !ADVANCED_KEYS.includes(key))
)
const advancedFilterEntries = computed(() =>
  Object.entries(filterConfig).filter(([key]) => ADVANCED_KEYS.includes(key))
)
const hiddenFilterCount = computed(() =>
  ADVANCED_KEYS.reduce((sum, key) => sum + selectedFilters[key].length, 0)
)

function toggleFilter(key, option) {
  const list = selectedFilters[key]
  const idx = list.indexOf(option)
  if (idx === -1) list.push(option)
  else list.splice(idx, 1)
}
function isFilterActive(key, option) {
  return selectedFilters[key].includes(option)
}
function clearFilters() {
  Object.keys(selectedFilters).forEach(key => { selectedFilters[key] = [] })
}
const hasFilters = computed(() => Object.values(selectedFilters).some(list => list.length > 0))

// 已选条件回显标签：按「维度 + 值」拍平，支持单个删除
const FILTER_ICONS = {
  city: '📍', breed: '🐾', gender: '💕', ageGroup: '🎂',
  sterilized: '✂️', vaccinated: '💉', traits: '✨'
}
const activeFilterTags = computed(() => {
  const tags = []
  Object.keys(selectedFilters).forEach(key => {
    selectedFilters[key].forEach(value => {
      tags.push({ key, value, icon: FILTER_ICONS[key] || '•' })
    })
  })
  return tags
})
function removeFilterTag(tag) {
  const list = selectedFilters[tag.key]
  const idx = list.indexOf(tag.value)
  if (idx > -1) list.splice(idx, 1)
}
function resetAll() {
  clearFilters()
  keyword.value = ''
  activeStatus.value = 'all'
}

// ===== 排序 & 视图 =====
const sortBy = ref('latest')
const viewMode = ref('grid') // grid | list

// ===== 列表计算 =====
function matchFilters(pet) {
  const f = selectedFilters
  if (f.city.length && !f.city.some(c => pet.city.startsWith(c))) return false
  if (f.breed.length && !f.breed.includes(pet.breed)) return false
  if (f.gender.length && !f.gender.includes(pet.gender)) return false
  if (f.ageGroup.length && !f.ageGroup.includes(pet.ageGroup)) return false
  if (f.sterilized.length) {
    const val = pet.sterilized ? '已绝育' : '未绝育'
    if (!f.sterilized.includes(val)) return false
  }
  if (f.vaccinated.length) {
    const val = pet.vaccinated ? '已接种' : '未接种'
    if (!f.vaccinated.includes(val)) return false
  }
  if (f.traits.length && !f.traits.some(t => pet.traits.includes(t))) return false
  return true
}

// 年龄转月数，用于「年龄最小 / 最大」排序
function ageMonths(pet) {
  const num = parseInt(String(pet.age).replace(/[^0-9]/g, ''), 10) || 0
  return String(pet.age).includes('岁') ? num * 12 : num
}

const filteredPets = computed(() => {
  const kw = keyword.value.trim().toLowerCase()
  let list = allPets.value.filter(pet => {
    const status = petStatus(pet)
    if (activeStatus.value !== 'all' && status !== activeStatus.value) return false
    if (!matchFilters(pet)) return false
    if (!kw) return true
    // 关键词模糊匹配：名字 / 品种 / 城市 / 性格 / 标签
    return [pet.name, pet.breed, pet.city, pet.personality, ...(pet.traits || [])]
      .some(v => String(v || '').toLowerCase().includes(kw))
  })
  list = [...list]
  switch (sortBy.value) {
    case 'popular': list.sort((a, b) => b.popularity - a.popularity); break
    case 'youngest': list.sort((a, b) => ageMonths(a) - ageMonths(b)); break
    case 'oldest': list.sort((a, b) => ageMonths(b) - ageMonths(a)); break
    case 'name': list.sort((a, b) => String(a.name).localeCompare(String(b.name), 'zh-CN')); break
    default: list.sort((a, b) => String(b.listedAt).localeCompare(String(a.listedAt)))
  }
  return list
})

const statusCount = value => value === 'all'
  ? allPets.value.length
  : allPets.value.filter(p => petStatus(p) === value).length

// ===== 分页 =====
const page = ref(1)
const pageSize = ref(6)
const totalPages = computed(() => Math.max(1, Math.ceil(filteredPets.value.length / pageSize.value)))
const pagedPets = computed(() => {
  const start = (page.value - 1) * pageSize.value
  return filteredPets.value.slice(start, start + pageSize.value)
})
// 页码窗口：总数多时只显示当前页附近的 5 个
const pageNumbers = computed(() => {
  const total = totalPages.value
  if (total <= 6) return Array.from({ length: total }, (_, i) => i + 1)
  const start = Math.min(Math.max(1, page.value - 2), total - 4)
  return Array.from({ length: 5 }, (_, i) => start + i)
})
const listTop = ref(null)
function goPage(target) {
  const next = Math.min(Math.max(1, target), totalPages.value)
  if (next === page.value) return
  page.value = next
  const el = listTop.value
  if (el && el.getBoundingClientRect().top < 0) {
    window.scrollTo({ top: window.scrollY + el.getBoundingClientRect().top - 90, behavior: 'smooth' })
  }
}

// ===== 筛选骨架屏：条件变化时给一段短暂的加载反馈 =====
const filtering = ref(true)
let filterTimer = null
function runSkeleton(delay = 420) {
  filtering.value = true
  clearTimeout(filterTimer)
  filterTimer = setTimeout(() => { filtering.value = false }, delay)
}

// 任一筛选 / 搜索 / 排序条件变化：回到第一页并播一次骨架屏
const filterSignature = computed(() => JSON.stringify({
  status: activeStatus.value,
  keyword: keyword.value.trim(),
  sort: sortBy.value,
  filters: selectedFilters
}))
watch(filterSignature, () => {
  page.value = 1
  runSkeleton()
})
watch(pageSize, () => {
  page.value = 1
})
// 结果变少后页码可能越界，自动回退到最后一页
watch(totalPages, total => {
  if (page.value > total) page.value = total
})

// ===== 最多 3 只宠物对比 =====
const compareIds = ref([])
const compareShow = ref(false)
const comparePets = computed(() =>
  compareIds.value.map(id => allPets.value.find(p => p.id === id)).filter(Boolean)
)
const canCompare = computed(() => comparePets.value.length >= 2)

function inCompare(id) { return compareIds.value.includes(id) }
function toggleCompare(pet) {
  if (inCompare(pet.id)) {
    compareIds.value = compareIds.value.filter(x => x !== pet.id)
    return
  }
  if (compareIds.value.length >= 3) {
    showToast('最多同时对比 3 只毛孩子哦～')
    return
  }
  compareIds.value = [...compareIds.value, pet.id]
}
function removeCompare(id) {
  compareIds.value = compareIds.value.filter(x => x !== id)
  if (compareIds.value.length < 2) compareShow.value = false
}
function clearCompare() {
  compareIds.value = []
  compareShow.value = false
}

// 对比表内容：按维度逐行对齐
const compareRows = computed(() => {
  const list = comparePets.value
  const map = fn => list.map(p => fn(p) ?? '—')
  return [
    { label: '品种', values: map(p => p.breed) },
    { label: '性别', values: map(p => p.gender) },
    { label: '年龄', values: map(p => p.age) },
    { label: '城市', values: map(p => p.city) },
    { label: '性格', values: map(p => p.personality) },
    { label: '健康状况', values: map(p => p.health) },
    { label: '绝育情况', values: map(p => p.sterilized ? '已绝育' : '未绝育') },
    { label: '疫苗接种', values: map(p => p.vaccinated ? '已接种' : '未接种') },
    { label: '人气值', values: map(p => `${p.popularity || 0} ❤`) },
    { label: '当前状态', values: map(p => STATUS_META[petStatus(p)].text) }
  ]
})

// ===== 申请闭环：须知 → 表单 → 提交 =====
const applyModalShow = ref(false)
const applyStep = ref('notice') // notice | form
const applyTarget = ref(null)
const noticeAgreed = ref(false)
const applyForm = reactive({ name: '', contact: '', experience: '', housing: '', message: '' })
const formError = ref(false)
const submitting = ref(false)
const toastText = ref('')
let toastTimer = null

function openApply(pet) {
  if (petStatus(pet) !== 'available') return
  applyTarget.value = pet
  applyStep.value = 'notice'
  noticeAgreed.value = false
  formError.value = false
  submitting.value = false
  Object.assign(applyForm, { name: '', contact: '', experience: '', housing: '', message: '' })
  applyModalShow.value = true
}
function closeApply() {
  applyModalShow.value = false
  applyTarget.value = null
  submitting.value = false
}
function nextToForm() {
  if (noticeAgreed.value) applyStep.value = 'form'
}
function submitApply() {
  if (submitting.value) return
  if (!applyForm.name.trim() || !applyForm.contact.trim() || !applyForm.message.trim()) {
    formError.value = true
    return
  }
  if (!applyTarget.value || petStatus(applyTarget.value) !== 'available') return
  submitting.value = true
  const target = applyTarget.value
  // 模拟异步提交：按钮进入 loading，避免重复点击
  setTimeout(() => {
    applyStatuses.value = { ...applyStatuses.value, [target.id]: '预约中' }
    applications.value = [{
      petId: target.id,
      petName: target.name,
      name: applyForm.name.trim(),
      contact: applyForm.contact.trim(),
      experience: applyForm.experience.trim(),
      housing: applyForm.housing.trim(),
      message: applyForm.message.trim(),
      time: new Date().toLocaleString('zh-CN')
    }, ...applications.value]
    try {
      localStorage.setItem('petApplyStatuses', JSON.stringify(applyStatuses.value))
      localStorage.setItem('petAdoptApplications', JSON.stringify(applications.value))
    } catch { /* ignore */ }
    submitting.value = false
    closeApply()
    showToast('申请提交成功，TA 正在等你哦～ 🐾')
  }, 620)
}
function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2400)
}

function goDetail(pet) {
  router.push(`/pet/${pet.id}`)
}
function goRecords() {
  router.push({ path: '/my-pets', query: { tab: 'applications' } })
}

// 跨页面/跨标签页实时同步：其它页面改动救助、收藏或领养状态后，本页自动刷新
const SYNC_KEYS = [
  'petRescueDone', 'petRescueSync', 'petAdopted',
  'petApplyStatuses', 'petAdoptApplications', 'petFavorites'
]
function onStorage(e) {
  if (e.key && SYNC_KEYS.includes(e.key)) loadStorage()
}

onMounted(() => {
  document.body.classList.add('home-body')
  loadStorage()
  runSkeleton(520)
  window.addEventListener('storage', onStorage)
})
onBeforeUnmount(() => {
  document.body.classList.remove('home-body')
  window.removeEventListener('storage', onStorage)
  clearTimeout(toastTimer)
  clearTimeout(favTimer)
  clearTimeout(filterTimer)
})
</script>

<template>
  <div class="adopt-page app-bg">
    <main class="adopt-main" :class="{ 'with-compare': compareIds.length > 0 }">
      <div class="page-head">
        <div>
          <h1>领养专区 <span>🐾</span></h1>
          <p>每一个它都在等一个你，找到属于你的那份缘分吧～</p>
        </div>
        <button type="button" class="records-btn" @click="goRecords">
          📝 我的申请记录
          <span v-if="applications.length" class="records-count">{{ applications.length }}</span>
        </button>
      </div>

      <!-- 状态分类 Tab -->
      <div class="status-tabs" role="tablist" aria-label="领养状态分类">
        <button
          v-for="tab in statusTabs"
          :key="tab.value"
          type="button"
          class="status-tab"
          :class="{ active: activeStatus === tab.value }"
          role="tab"
          :aria-selected="activeStatus === tab.value"
          @click="activeStatus = tab.value"
        >
          <span aria-hidden="true">{{ tab.icon }}</span>{{ tab.label }}
          <span class="tab-count">{{ statusCount(tab.value) }}</span>
        </button>
      </div>

      <!-- 筛选面板 -->
      <section class="filter-panel" aria-label="宠物筛选">
        <div class="filter-grid">
          <div v-for="[key, cfg] in basicFilterEntries" :key="key" class="filter-group">
            <span class="filter-label">{{ cfg.icon }} {{ cfg.label }}</span>
            <div class="filter-options">
              <button
                v-for="opt in cfg.options"
                :key="opt"
                type="button"
                class="filter-chip"
                :class="{ active: isFilterActive(key, opt) }"
                :aria-pressed="isFilterActive(key, opt)"
                @click="toggleFilter(key, opt)"
              >{{ opt }}</button>
            </div>
          </div>
        </div>

        <!-- 高级筛选：默认收起 -->
        <div class="filter-advanced" :class="{ open: advancedOpen }">
          <div class="filter-grid">
            <div
              v-for="[key, cfg] in advancedFilterEntries"
              :key="key"
              class="filter-group"
              :class="{ wide: key === 'traits' }"
            >
              <span class="filter-label">{{ cfg.icon }} {{ cfg.label }}</span>
              <div class="filter-options">
                <button
                  v-for="opt in cfg.options"
                  :key="opt"
                  type="button"
                  class="filter-chip"
                  :class="{ active: isFilterActive(key, opt) }"
                  :aria-pressed="isFilterActive(key, opt)"
                  @click="toggleFilter(key, opt)"
                >{{ opt }}</button>
              </div>
            </div>
          </div>
        </div>

        <!-- 已选条件回显 + 高级筛选开关 -->
        <div class="active-bar">
          <div v-if="activeFilterTags.length" class="active-tags">
            <span class="at-label">已选</span>
            <button
              v-for="tag in activeFilterTags"
              :key="tag.key + tag.value"
              type="button"
              class="active-tag"
              :title="`移除「${tag.value}」`"
              @click="removeFilterTag(tag)"
            >
              <span aria-hidden="true">{{ tag.icon }}</span>{{ tag.value }}
              <span class="at-x" aria-hidden="true">✕</span>
            </button>
            <button type="button" class="active-clear" @click="clearFilters">全部清空</button>
          </div>
          <p v-else class="active-empty">还没有选条件，随便逛逛也很治愈～</p>

          <button type="button" class="more-toggle" :aria-expanded="advancedOpen" @click="advancedOpen = !advancedOpen">
            {{ advancedOpen ? '收起高级筛选' : '展开高级筛选' }}
            <span v-if="!advancedOpen && hiddenFilterCount" class="more-count">{{ hiddenFilterCount }}</span>
            <span class="chev" :class="{ open: advancedOpen }" aria-hidden="true">▾</span>
          </button>
        </div>

        <!-- 底部工具条：清空 / 搜索 / 排序 / 视图，全部底边对齐 -->
        <div class="filter-toolbar">
          <div class="toolbar-left">
            <button type="button" class="clear-btn" :disabled="!hasFilters && !keyword" @click="resetAll">🧹 清空筛选</button>
            <label class="keyword-search">
              <span class="kw-icon" aria-hidden="true">🔍</span>
              <input v-model="keyword" type="search" placeholder="搜名字 / 品种 / 城市..." aria-label="关键词搜索宠物">
              <button v-if="keyword" type="button" class="kw-clear" aria-label="清除搜索" @click="keyword = ''">✕</button>
            </label>
          </div>
          <div class="toolbar-right">
            <label class="sort-select">
              <span>排序</span>
              <select v-model="sortBy" aria-label="排序方式">
                <option v-for="opt in sortOptions" :key="opt.value" :value="opt.value">{{ opt.icon }} {{ opt.label }}</option>
              </select>
            </label>
            <div class="view-switch" role="group" aria-label="视图切换">
              <button type="button" :class="{ active: viewMode === 'grid' }" title="大卡片模式" aria-label="大卡片模式" @click="viewMode = 'grid'">▦</button>
              <button type="button" :class="{ active: viewMode === 'list' }" title="紧凑列表模式" aria-label="紧凑列表模式" @click="viewMode = 'list'">☰</button>
            </div>
          </div>
        </div>
      </section>

      <div ref="listTop" class="list-anchor">
        <p class="result-hint">
          共 <strong>{{ filteredPets.length }}</strong> 位毛孩子符合条件
          <span v-if="activeFilterTags.length" class="hint-chip">已筛 {{ activeFilterTags.length }} 项</span>
          <span v-if="!compareIds.length" class="hint-tip">点卡片右下角 ⇄ 可对比最多 3 只</span>
          <span v-if="filteredPets.length" class="hint-page">第 {{ page }} / {{ totalPages }} 页</span>
        </p>
      </div>

      <!-- 骨架屏：条件变化时短暂占位 -->
      <div v-if="filtering" class="pet-list skeleton-list" :class="viewMode" aria-hidden="true">
        <div v-for="n in 6" :key="n" class="skeleton-card">
          <div class="sk-photo"><span class="sk-shine"></span></div>
          <div class="sk-body">
            <span class="sk-line w55"></span>
            <div class="sk-chips"><i></i><i></i><i></i></div>
            <span class="sk-line w80"></span>
            <span class="sk-btn"></span>
          </div>
        </div>
      </div>

      <!-- 宠物列表 -->
      <div v-else-if="pagedPets.length" class="pet-list" :class="viewMode">
        <article
          v-for="pet in pagedPets"
          :key="pet.id"
          class="adopt-card"
          :class="[
            'is-' + petStatus(pet),
            { 'in-compare': inCompare(pet.id) }
          ]"
          @click="goDetail(pet)"
        >
          <div class="card-photo" :style="{ '--pet-color': pet.color }">
            <img v-if="pet.image" :src="pet.image" :alt="pet.name" loading="lazy">
            <span v-else class="card-emoji">{{ pet.emoji }}</span>

            <!-- 左上：收藏 -->
            <button
              type="button"
              class="fav-btn"
              :class="{ on: isFavorite(pet.id), pop: favPopId === pet.id }"
              :aria-pressed="isFavorite(pet.id)"
              :aria-label="isFavorite(pet.id) ? `取消收藏${pet.name}` : `收藏${pet.name}`"
              @click.stop="toggleFavorite(pet)"
            >
              <span aria-hidden="true">♥</span>
            </button>

            <!-- 右上：固定状态角标 -->
            <span class="corner-badge" :class="petStatus(pet)">
              <span aria-hidden="true">{{ STATUS_META[petStatus(pet)].icon }}</span>
              {{ STATUS_META[petStatus(pet)].text }}
            </span>

            <span class="city-tag">📍 {{ pet.city }}</span>

            <!-- 右下：加入对比 -->
            <button
              type="button"
              class="compare-btn"
              :class="{ on: inCompare(pet.id) }"
              :aria-pressed="inCompare(pet.id)"
              :title="inCompare(pet.id) ? '移出对比' : '加入对比'"
              @click.stop="toggleCompare(pet)"
            >⇄</button>

            <!-- 已领养：灰度蒙版 -->
            <div v-if="petStatus(pet) === 'adopted'" class="adopted-veil" aria-hidden="true">
              <span class="veil-stamp">🏠 已回家</span>
            </div>
          </div>

          <div class="card-info">
            <!-- 第一层：名字 + 品种 -->
            <div class="card-title">
              <h2>{{ pet.name }}</h2>
              <span class="breed">{{ pet.breed }}</span>
            </div>

            <!-- 第二层：属性标签，按属性分色 -->
            <div class="card-tags">
              <span class="tag gender" :class="pet.gender === '弟弟' ? 'male' : 'female'">💕 {{ pet.gender }}</span>
              <span class="tag age">🎂 {{ pet.age }}</span>
              <span class="tag trait">✨ {{ pet.personality }}</span>
            </div>

            <!-- 第三层：健康与保障 -->
            <div class="card-health">
              <span class="health-tag">💚 {{ pet.health }}</span>
              <span class="mini-tag" :class="pet.sterilized ? 'yes' : 'no'">{{ pet.sterilized ? '已绝育' : '未绝育' }}</span>
              <span class="mini-tag" :class="pet.vaccinated ? 'yes' : 'no'">{{ pet.vaccinated ? '已接种' : '未接种' }}</span>
            </div>

            <!-- 底部双按钮 -->
            <div class="card-actions">
              <button
                type="button"
                class="detail-btn"
                :disabled="petStatus(pet) === 'adopted'"
                @click.stop="goDetail(pet)"
              >查看详情</button>
              <button
                type="button"
                class="apply-btn"
                :disabled="petStatus(pet) !== 'available'"
                @click.stop="openApply(pet)"
              >
                {{ petStatus(pet) === 'available' ? '💌 申请领养' : petStatus(pet) === 'reserved' ? '⏳ 已预约' : '🏠 已回家' }}
              </button>
            </div>
          </div>
        </article>
      </div>

      <!-- 空状态：套一层卡片，与页面其它模块保持一致 -->
      <div v-else class="empty-wrap">
        <CuteEmpty
          variant="search"
        title="没有符合条件的毛孩子"
          :desc="hasFilters || keyword ? '试着减少几个筛选条件，或者换个关键词，缘分也许就在下一页～' : '这个分类下暂时还没有毛孩子，去别的分类看看吧 🐾'"
        >
          <button type="button" class="reset-btn" @click="resetAll">重置全部条件</button>
        </CuteEmpty>
      </div>

      <!-- 分页器 -->
      <nav v-if="!filtering && filteredPets.length" class="pager" aria-label="分页">
        <button type="button" class="pg-btn pg-step" :disabled="page === 1" @click="goPage(page - 1)">‹ 上一页</button>
        <button
          v-for="n in pageNumbers"
          :key="n"
          type="button"
          class="pg-btn"
          :class="{ active: n === page }"
          :aria-current="n === page ? 'page' : undefined"
          @click="goPage(n)"
        >{{ n }}</button>
        <button type="button" class="pg-btn pg-step" :disabled="page === totalPages" @click="goPage(page + 1)">下一页 ›</button>
        <span class="pg-total">共 {{ filteredPets.length }} 只</span>
        <label class="pg-size">
          每页
          <select v-model.number="pageSize" aria-label="每页显示数量">
            <option :value="3">3</option>
            <option :value="6">6</option>
            <option :value="9">9</option>
          </select>
          只
        </label>
      </nav>
    </main>

    <!-- 对比悬浮栏 -->
    <transition name="cmp-slide">
      <div v-if="compareIds.length" class="compare-bar">
        <div class="cb-head">
          <span class="cb-title">⇄ 对比栏</span>
          <span class="cb-count">{{ compareIds.length }} / 3</span>
        </div>
        <div class="cb-items">
          <div v-for="pet in comparePets" :key="pet.id" class="cb-item">
            <img :src="pet.image" :alt="pet.name">
            <span>{{ pet.name }}</span>
            <button type="button" class="cb-x" :aria-label="`移出${pet.name}`" @click="removeCompare(pet.id)">✕</button>
          </div>
          <div v-for="n in (3 - comparePets.length)" :key="'ph' + n" class="cb-item empty" aria-hidden="true">
            <span class="cb-plus">＋</span>
          </div>
        </div>
        <div class="cb-actions">
          <button type="button" class="cb-clear" @click="clearCompare">清空</button>
          <button type="button" class="cb-go" :disabled="!canCompare" @click="compareShow = true">
            {{ canCompare ? '开始对比' : '再选一只' }}
          </button>
        </div>
      </div>
    </transition>

    <!-- 对比结果弹窗 -->
    <div v-if="compareShow" class="modal-mask" @click.self="compareShow = false">
      <div class="compare-modal" role="dialog" aria-modal="true" aria-label="宠物对比">
        <button type="button" class="modal-close" aria-label="关闭" @click="compareShow = false">✕</button>
        <h2>⇄ 毛孩子对比</h2>
        <p class="modal-sub">把犹豫的点摆开看，答案会清楚很多～</p>

        <div class="compare-table">
          <div class="cm-row cm-head">
            <span class="cm-label">对比项</span>
            <div v-for="pet in comparePets" :key="pet.id" class="cm-pet">
              <img :src="pet.image" :alt="pet.name">
              <strong>{{ pet.name }}</strong>
            </div>
          </div>
          <div v-for="row in compareRows" :key="row.label" class="cm-row">
            <span class="cm-label">{{ row.label }}</span>
            <span v-for="(val, i) in row.values" :key="i" class="cm-cell">{{ val }}</span>
          </div>
        </div>

        <div class="modal-actions">
          <button type="button" class="modal-ghost" @click="clearCompare">清空对比</button>
          <button type="button" class="modal-primary" @click="compareShow = false">继续挑选</button>
        </div>
      </div>
    </div>

    <!-- 申请弹窗 -->
    <div v-if="applyModalShow" class="modal-mask" @click.self="closeApply">
      <div class="apply-modal" role="dialog" aria-modal="true">
        <button type="button" class="modal-close" aria-label="关闭" @click="closeApply">✕</button>

        <template v-if="applyStep === 'notice'">
          <h2>📋 领养须知</h2>
          <p class="modal-sub">在领养 {{ applyTarget?.name }} 之前，请认真阅读以下内容～</p>
          <ul class="notice-list">
            <li><strong>领养责任</strong>：领养后请长期负责喂养、照顾，不离不弃，不得随意转送或弃养。</li>
            <li><strong>回访要求</strong>：我们会定期回访了解毛孩子的生活状况，请配合提供近况。</li>
            <li><strong>领养条件</strong>：需年满 18 周岁，有稳定住所与经济能力，家人同意共同饲养。</li>
          </ul>
          <label class="agree-line">
            <input v-model="noticeAgreed" type="checkbox">
            <span>我已阅读并同意以上领养须知</span>
          </label>
          <button type="button" class="modal-primary" :disabled="!noticeAgreed" @click="nextToForm">下一步 →</button>
        </template>

        <template v-else>
          <h2>💌 领养申请</h2>
          <p class="modal-sub">介绍一下你自己，让 {{ applyTarget?.name }} 更快认识你～</p>
          <div class="form-grid">
            <label><span>姓名</span><input v-model="applyForm.name" type="text" placeholder="你的姓名"></label>
            <label><span>联系方式</span><input v-model="applyForm.contact" type="text" placeholder="手机号 / 微信"></label>
            <label><span>养宠经验</span><input v-model="applyForm.experience" type="text" placeholder="如：养过猫 3 年"></label>
            <label><span>居住环境</span><input v-model="applyForm.housing" type="text" placeholder="如：自有住房 / 合租"></label>
            <label class="full"><span>领养寄语</span><textarea v-model="applyForm.message" rows="3" placeholder="想对 TA 说的话..."></textarea></label>
          </div>
          <p v-if="formError" class="form-error">⚠️ 请填写姓名、联系方式和领养寄语哦～</p>
          <div class="modal-actions">
            <button type="button" class="modal-ghost" :disabled="submitting" @click="applyStep = 'notice'">← 上一步</button>
            <button type="button" class="modal-primary" :disabled="submitting" @click="submitApply">
              {{ submitting ? '提交中…' : '提交申请 ✓' }}
            </button>
          </div>
        </template>
      </div>
    </div>

    <div class="cute-toast" :class="{ show: !!toastText, lifted: compareIds.length > 0 }">🐾 {{ toastText }}</div>
  </div>
</template>

<style scoped>
.adopt-page {
  min-height: 100vh;
  color: var(--text-1);
  font-family: var(--font-body);
}
:global(body.home-body) { display: block; align-items: initial; justify-content: initial; padding: 0; }

.records-btn { padding: 9px 16px; display: inline-flex; align-items: center; gap: 7px; font: inherit; font-size: 13px; font-weight: 900; color: var(--ink); background: var(--yellow); border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-2); cursor: pointer; transition: 0.15s; }
.records-btn:hover { transform: translate(-1px, -3px); box-shadow: 4px 7px 0 var(--ink); }
.records-count { min-width: 20px; height: 20px; display: grid; place-items: center; padding: 0 5px; font-size: 11px; background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm); }

.adopt-main { max-width: var(--layout-max); margin: 0 auto; padding: var(--layout-pad-top) var(--layout-pad-x) var(--layout-pad-bottom); transition: padding-bottom 0.2s ease; }
.adopt-main.with-compare { padding-bottom: 150px; }
.page-head { margin-bottom: 22px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
.page-head h1 { margin: 0 0 6px; font-size: 32px; }
.page-head h1 span { color: var(--pink); }
.page-head p { margin: 0; font-size: 14px; font-weight: 700; color: var(--text-2); }

/* ===== 状态 Tab ===== */
.status-tabs { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 18px; }
.status-tab {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 9px 16px; font: inherit; font-size: 14px; font-weight: 900;
  color: var(--ink); background: var(--paper); border: var(--line);
  border-radius: var(--r-sm); box-shadow: var(--shadow-2);
  cursor: pointer; transition: 0.15s;
}
.status-tab:hover { transform: translate(-1px, -3px); box-shadow: 4px 7px 0 var(--ink); }
.status-tab.active { background: var(--yellow); box-shadow: 4px 6px 0 var(--ink); }
.tab-count { padding: 1px 7px; font-size: 11px; background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm); }

/* ===== 筛选面板 ===== */
.filter-panel { padding: 18px 20px 16px; background: var(--paper); border: var(--line); border-radius: var(--r-lg); box-shadow: 7px 8px 0 var(--ink); margin-bottom: 18px; }
.filter-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px 24px; }
.filter-group { display: flex; flex-direction: column; gap: 8px; min-width: 0; }
.filter-group.wide { grid-column: 1 / -1; }
.filter-label { font-size: 13px; font-weight: 900; }
.filter-options { display: flex; flex-wrap: wrap; gap: 7px; }

.filter-chip {
  padding: 5px 11px; font: inherit; font-size: 11px; font-weight: 900;
  color: var(--ink); background: #fff; border: 2px solid var(--ink);
  border-radius: var(--r-sm); cursor: pointer; transition: 0.15s;
}
.filter-chip:hover { transform: translateY(-2px); background: #fff3cf; }
/* 选中态：主色黄填充 + 白字（加深一档保证可读性） */
.filter-chip.active {
  color: #fff;
  background: #ffc61a;
  text-shadow: 0 1px 0 rgba(150, 96, 0, 0.85), 0 0 2px rgba(150, 96, 0, 0.55);
  box-shadow: 2px 2px 0 var(--ink);
}
.filter-chip.active:hover { background: #ffcf3d; }

/* 高级筛选折叠 */
.filter-advanced {
  max-height: 0;
  overflow: hidden;
  opacity: 0;
  transition: max-height 0.34s ease, opacity 0.24s ease, margin-top 0.24s ease;
}
.filter-advanced.open { max-height: 520px; opacity: 1; margin-top: 14px; }

/* 已选条件回显条 */
.active-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  margin-top: 16px;
  padding: 9px 12px;
  background: #fffaeb;
  border: 2px dashed #e6d3b3;
  border-radius: var(--r-sm);
}
.active-tags { display: flex; align-items: center; flex-wrap: wrap; gap: 7px; min-width: 0; }
.at-label { font-size: 11px; font-weight: 900; color: var(--text-3); }
.active-tag {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 3px 6px 3px 8px; font: inherit; font-size: 11px; font-weight: 900;
  color: var(--ink); background: #fff; border: 2px solid var(--ink);
  border-radius: var(--r-sm); cursor: pointer; transition: 0.15s;
}
.active-tag:hover { background: #ffe0e3; transform: translateY(-2px); }
.at-x { font-size: 9px; opacity: 0.55; }
.active-tag:hover .at-x { opacity: 1; }
.active-clear {
  padding: 3px 9px; font: inherit; font-size: 11px; font-weight: 900;
  color: #b23a53; background: #ffeef1; border: 2px solid #b23a53;
  border-radius: var(--r-sm); cursor: pointer; transition: 0.15s;
}
.active-clear:hover { background: #ffdde3; transform: translateY(-2px); }
.active-empty { margin: 0; font-size: 11px; font-weight: 700; color: var(--text-3); }

.more-toggle {
  display: inline-flex; align-items: center; gap: 5px;
  padding: 5px 11px; font: inherit; font-size: 11px; font-weight: 900;
  color: var(--ink); background: #fff; border: 2px solid var(--ink);
  border-radius: var(--r-sm); cursor: pointer; transition: 0.15s;
}
.more-toggle:hover { background: var(--blue); transform: translateY(-2px); }
.more-count { min-width: 17px; height: 17px; display: grid; place-items: center; padding: 0 4px; font-size: 10px; color: #fff; background: var(--orange); border: 2px solid var(--ink); border-radius: 50%; }
.chev { display: inline-block; transition: transform 0.2s ease; }
.chev.open { transform: rotate(180deg); }

/* 底部工具条：所有控件同高 + 底边对齐 */
.filter-toolbar {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  margin-top: 14px;
  padding-top: 14px;
  border-top: 2px dashed #e6d3b3;
}
.toolbar-left, .toolbar-right { display: flex; align-items: flex-end; gap: 10px; flex-wrap: wrap; }

.clear-btn {
  height: 38px; padding: 0 14px; font: inherit; font-size: 12px; font-weight: 900;
  color: var(--ink); background: #ffc9cf; border: var(--line);
  border-radius: var(--r-sm); box-shadow: var(--shadow-2); cursor: pointer;
}
.clear-btn:hover:not(:disabled) { background: #ffb3bc; transform: translate(-1px, -3px); box-shadow: 4px 7px 0 var(--ink); }
.clear-btn:disabled { opacity: 0.45; cursor: not-allowed; box-shadow: 2px 2px 0 var(--ink); }

.keyword-search { display: flex; align-items: center; gap: 6px; height: 38px; padding: 0 11px; background: #fff; border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-2); transition: box-shadow 0.15s ease, border-color 0.15s ease; }
.keyword-search:focus-within { box-shadow: 4px 4px 0 var(--blue); }
.keyword-search .kw-icon { font-size: 12px; }
.keyword-search input { width: 180px; padding: 0; font: inherit; font-size: 12px; color: var(--ink); background: transparent; border: none; outline: none; }
.keyword-search input::placeholder { color: var(--text-3); }
.keyword-search input::-webkit-search-cancel-button { display: none; }
.kw-clear { width: 19px; height: 19px; display: grid; place-items: center; padding: 0; font: inherit; font-size: 10px; font-weight: 900; color: var(--ink); background: #ffe0e3; border: 2px solid var(--ink); border-radius: 50%; cursor: pointer; }

.sort-select { display: flex; align-items: center; gap: 7px; height: 38px; font-size: 12px; font-weight: 900; }
.sort-select select { height: 38px; padding: 0 10px; font: inherit; font-size: 12px; font-weight: 900; color: var(--ink); background: #fff; border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-2); cursor: pointer; }
.sort-select select:hover { background: #fff8e9; }

.view-switch { display: flex; height: 38px; border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-2); overflow: hidden; }
.view-switch button { width: 38px; height: 100%; font-size: 15px; font-weight: 900; color: var(--ink); background: #fff; border: none; cursor: pointer; transition: background 0.15s ease; }
.view-switch button + button { border-left: 2px solid var(--ink); }
.view-switch button:hover { background: #fff3cf; }
.view-switch button.active { background: var(--yellow); }

/* ===== 结果提示 ===== */
.list-anchor { scroll-margin-top: 90px; }
.result-hint { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; font-size: 13px; font-weight: 900; color: var(--text-2); margin: 4px 0 14px; }
.result-hint strong { font-size: 15px; color: var(--ink); }
.hint-chip { padding: 2px 8px; font-size: 10px; color: var(--ink); background: var(--yellow); border: 2px solid var(--ink); border-radius: var(--r-sm); }
.hint-tip { font-size: 10px; font-weight: 700; color: var(--text-3); }
.hint-page { margin-left: auto; font-size: 11px; font-weight: 800; color: var(--text-3); }

/* ===== 宠物列表 ===== */
.pet-list { display: grid; gap: 20px; }
.pet-list.grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.pet-list.list { grid-template-columns: 1fr; }

.adopt-card {
  position: relative;
  display: flex;
  flex-direction: column;
  background: var(--paper); border: var(--line); border-radius: var(--r-lg);
  box-shadow: var(--shadow-2); overflow: hidden; cursor: pointer;
  transition: transform 0.18s ease, box-shadow 0.18s ease;
  /* 不加 fill-mode：动画未执行时保持 opacity:1，避免极端情况下卡片不可见 */
  animation: card-in 0.4s cubic-bezier(0.2, 1.4, 0.4, 1);
}
.adopt-card:hover { transform: translate(-2px, -6px); box-shadow: 8px 11px 0 var(--ink); }
@keyframes card-in { from { opacity: 0; transform: translateY(16px) scale(0.97); } to { opacity: 1; transform: none; } }
.adopt-card.in-compare { outline: 3px solid var(--blue); outline-offset: 2px; }

.card-photo {
  position: relative;
  height: 178px;
  display: grid;
  place-items: center;
  grid-template-rows: 100%;
  background-color: var(--pet-color);
  border-bottom: var(--line);
  background-image:
    radial-gradient(circle at 50% 22%, rgba(255, 255, 255, 0.55), rgba(255, 255, 255, 0) 62%),
    radial-gradient(rgba(255, 255, 255, 0.34) 0.7px, rgba(255, 255, 255, 0) 0.8px),
    radial-gradient(rgba(255, 255, 255, 0.2) 0.7px, rgba(255, 255, 255, 0) 0.8px);
  background-size: 100% 100%, 6px 6px, 6px 6px;
  background-position: 0 0, 0 0, 3px 3px;
  /* 浅底衬边：内圈柔光 + 底部接触阴影 */
  box-shadow:
    inset 0 0 0 2px rgba(255, 255, 255, 0.6),
    inset 0 -30px 34px -30px rgba(120, 92, 60, 0.22);
}

/* contain 完整显示 + 底边对齐；按各 PNG 底部透明留白做百分比补偿，6 只脚底齐平 */
.card-photo img {
  width: 86%;
  height: 86%;
  object-fit: contain;
  align-self: end;
  --pet-ground-shift: 8%;
  transform: translateY(var(--pet-ground-shift));
  filter:
    drop-shadow(0 2px 1px rgba(43, 43, 43, 0.16))
    drop-shadow(0 7px 6px rgba(43, 43, 43, 0.18))
    drop-shadow(0 14px 12px rgba(90, 60, 30, 0.12))
    saturate(1.06) contrast(1.03) brightness(1.01);
  transition: scale 0.24s ease, filter 0.24s ease;
}
.adopt-card:hover .card-photo img { scale: 1.05; }
.card-emoji { font-size: 82px; filter: drop-shadow(6px 8px 0 rgba(43, 43, 43, 0.2)); transition: 0.2s; }
.adopt-card:hover .card-emoji { transform: scale(1.08) rotate(-5deg); }

/* 左上：收藏 */
.fav-btn {
  position: absolute; left: 10px; top: 10px; z-index: 4;
  width: 34px; height: 34px; display: grid; place-items: center; padding: 0;
  font-size: 17px; line-height: 1; color: #c3ae9a;
  background: rgba(255, 255, 255, 0.94); border: var(--line); border-radius: 50%;
  box-shadow: var(--shadow-1); cursor: pointer;
  transition: color 0.18s ease, background 0.18s ease;
}
.fav-btn:hover { color: #ff8fae; background: #fff; transform: translateY(-2px); }
.fav-btn.on { color: #ff5c8a; background: #fff0f4; }
.fav-btn.on:hover { color: #ff366f; }
/* 弹跳填充动画：只在切换瞬间触发 */
.fav-btn.pop { animation: fav-pop 0.52s cubic-bezier(0.2, 1.6, 0.4, 1); }
.fav-btn.pop span { display: inline-block; animation: heart-bounce 0.52s cubic-bezier(0.2, 1.6, 0.4, 1); }
@keyframes fav-pop {
  0% { transform: scale(1); }
  35% { transform: scale(1.24); }
  62% { transform: scale(0.94); }
  100% { transform: scale(1); }
}
@keyframes heart-bounce {
  0% { transform: scale(0.5) rotate(-14deg); }
  45% { transform: scale(1.3) rotate(8deg); }
  72% { transform: scale(0.92) rotate(-3deg); }
  100% { transform: scale(1) rotate(0); }
}

/* 右上：固定状态角标 */
.corner-badge {
  position: absolute; right: -2px; top: 12px; z-index: 3;
  display: inline-flex; align-items: center; gap: 4px;
  padding: 5px 10px; font-size: 11px; font-weight: 900;
  border: var(--line); border-right: none;
  border-radius: var(--r-sm) 0 0 var(--r-sm);
  box-shadow: -2px 2px 0 rgba(43, 43, 43, 0.22);
}
.corner-badge.available { background: var(--yellow); }
.corner-badge.reserved { background: var(--mint); }
.corner-badge.adopted { background: #cfcac3; color: #5d5a55; }

.city-tag {
  position: absolute; left: 10px; bottom: 10px; z-index: 3;
  padding: 4px 9px; font-size: 10px; font-weight: 900;
  background: rgba(255, 255, 255, 0.94); border: 2px solid var(--ink);
  border-radius: var(--r-sm);
}

/* 右下：加入对比 */
.compare-btn {
  position: absolute; right: 10px; bottom: 10px; z-index: 4;
  width: 30px; height: 30px; display: grid; place-items: center; padding: 0;
  font: inherit; font-size: 14px; font-weight: 900; color: var(--ink);
  background: rgba(255, 255, 255, 0.94); border: 2px solid var(--ink);
  border-radius: 50%; box-shadow: 2px 2px 0 var(--ink); cursor: pointer;
  transition: 0.15s;
}
.compare-btn:hover { background: var(--blue); transform: translateY(-2px); }
.compare-btn.on { background: var(--blue); box-shadow: 2px 2px 0 var(--ink), inset 0 0 0 2px #fff; }

/* 已领养：灰度蒙版 */
.adopt-card.is-adopted .card-photo img,
.adopt-card.is-adopted .card-emoji { filter: grayscale(1) contrast(0.92) brightness(1.04); }
.adopt-card.is-adopted:hover .card-photo img { scale: 1; }
.adopted-veil {
  position: absolute; inset: 0; z-index: 2; display: grid; place-items: center;
  background: linear-gradient(180deg, rgba(255, 253, 246, 0.5), rgba(240, 236, 228, 0.62));
  backdrop-filter: blur(0.4px);
  pointer-events: none;
}
.veil-stamp {
  padding: 7px 16px; font-size: 15px; font-weight: 900; letter-spacing: 2px; color: #6d675f;
  background: rgba(255, 255, 255, 0.9); border: 3px double #9c948a; border-radius: var(--r-sm);
  transform: rotate(-7deg);
}
.adopt-card.is-adopted .card-title h2,
.adopt-card.is-adopted .breed { color: #7c766e; }

/* ===== 卡片信息：三层排布 ===== */
.card-info { display: flex; flex-direction: column; flex: 1; padding: 14px 16px 16px; gap: 9px; }
/* 第一层：名字 + 品种 */
.card-title { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; }
.card-title h2 { margin: 0; font-size: 21px; line-height: 1.2; }
.breed {
  flex: 0 0 auto; padding: 2px 8px; font-size: 10px; font-weight: 900; color: var(--text-2);
  background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm);
}

/* 第二层：属性标签，按属性分色 */
.card-tags { display: flex; flex-wrap: wrap; gap: 6px; }
.tag {
  display: inline-flex; align-items: center; gap: 3px;
  padding: 3px 8px; font-size: 10px; font-weight: 900;
  color: var(--ink); border: 2px solid var(--ink); border-radius: var(--r-sm);
}
.tag.gender.male { background: #d9ecff; }
.tag.gender.female { background: #ffdcea; }
.tag.age { background: #ffe9b8; }
.tag.trait { background: #e3dcfb; }

/* 第三层：健康与保障 */
.card-health { display: flex; flex-wrap: wrap; gap: 6px; }
.health-tag, .mini-tag { padding: 3px 8px; font-size: 10px; font-weight: 900; border-radius: var(--r-sm); }
.health-tag { color: #1f6b4a; background: #dcf5e8; border: 2px solid #1f6b4a; }
.mini-tag { color: var(--text-2); border: 2px solid #cfc0ab; }
.mini-tag.yes { color: #1f6b4a; background: #eafaf1; border-color: #8ed3b2; }
.mini-tag.no { color: #8b6a4a; background: #f6efe3; }

/* 底部双按钮 */
.card-actions { display: flex; gap: 8px; margin-top: auto; padding-top: 4px; }
.detail-btn, .apply-btn {
  flex: 1; height: 36px; padding: 0 10px; font: inherit; font-size: 12px; font-weight: 900;
  border: var(--line); border-radius: var(--r-sm); cursor: pointer; transition: 0.15s;
}
.detail-btn { color: var(--ink); background: #fff; box-shadow: 2px 2px 0 var(--ink); }
.detail-btn:hover:not(:disabled) { background: var(--blue); transform: translateY(-2px); box-shadow: 2px 5px 0 var(--ink); }
.apply-btn { color: var(--ink); background: var(--yellow); box-shadow: var(--shadow-2); }
.apply-btn:hover:not(:disabled) { background: #ffe07a; transform: translateY(-2px); box-shadow: 2px 6px 0 var(--ink); }
.detail-btn:disabled, .apply-btn:disabled { color: #9a9288; background: #eae4d9; border-color: #b6ada0; box-shadow: 2px 2px 0 #c3b9ab; cursor: not-allowed; }

/* ===== 紧凑列表模式 ===== */
.pet-list.list .adopt-card { display: grid; grid-template-columns: 220px minmax(0, 1fr); }
.pet-list.list .card-photo { height: 100%; min-height: 172px; border-bottom: none; border-right: var(--line); }
.pet-list.list .card-photo img { width: 82%; height: 82%; }
/* 列表视图：文字信息在左，操作按钮竖排贴右，整体垂直居中 */
.pet-list.list .card-info {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  align-content: center;
  align-items: center;
  column-gap: 18px;
  row-gap: 8px;
  padding: 16px 20px;
}
.pet-list.list .card-title { justify-content: flex-start; gap: 10px; }
.pet-list.list .card-title,
.pet-list.list .card-tags,
.pet-list.list .card-health { grid-column: 1; }
.pet-list.list .card-actions {
  grid-column: 2;
  grid-row: 1 / 4;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
}
.pet-list.list .card-actions > button { width: 124px; flex: 0 0 auto; }
.pet-list.list .detail-btn, .pet-list.list .apply-btn { flex: 0 0 auto; min-width: 108px; }

/* ===== 骨架屏 ===== */
.skeleton-card { background: var(--paper); border: var(--line); border-radius: var(--r-lg); box-shadow: var(--shadow-1); overflow: hidden; }
.sk-photo { position: relative; height: 178px; background: #f2ece0; overflow: hidden; border-bottom: 2px solid #e6dccb; }
.sk-body { display: flex; flex-direction: column; gap: 10px; padding: 16px; }
.sk-line { height: 13px; border-radius: 6px; background: #f2ece0; overflow: hidden; position: relative; }
.sk-line.w55 { width: 55%; height: 17px; }
.sk-line.w80 { width: 80%; }
.sk-chips { display: flex; gap: 6px; }
.sk-chips i { width: 52px; height: 18px; border-radius: 6px; background: #f2ece0; position: relative; overflow: hidden; }
.sk-btn { height: 36px; border-radius: var(--r-sm); background: #f2ece0; position: relative; overflow: hidden; margin-top: 2px; }
.sk-shine, .sk-line::after, .sk-chips i::after, .sk-btn::after {
  content: ""; position: absolute; inset: 0;
  background: linear-gradient(100deg, transparent 20%, rgba(255, 255, 255, 0.85) 50%, transparent 80%);
  transform: translateX(-100%);
  animation: sk-sweep 1.25s ease-in-out infinite;
}
@keyframes sk-sweep { to { transform: translateX(100%); } }
.pet-list.list .skeleton-card { display: grid; grid-template-columns: 220px minmax(0, 1fr); }
.pet-list.list .sk-photo { height: 100%; min-height: 172px; border-bottom: none; border-right: 2px solid #e6dccb; }

/* ===== 分页器 ===== */
.pager { display: flex; align-items: center; justify-content: center; flex-wrap: wrap; gap: 8px; margin-top: 28px; }
.pg-btn {
  min-width: 38px; height: 38px; padding: 0 12px; font: inherit; font-size: 13px; font-weight: 900;
  color: var(--ink); background: #fff; border: var(--line); border-radius: var(--r-sm);
  box-shadow: var(--shadow-1); cursor: pointer; transition: 0.15s;
}
.pg-btn:hover:not(:disabled):not(.active) { background: #fff3cf; transform: translateY(-2px); box-shadow: 2px 4px 0 var(--ink); }
.pg-btn.active { background: var(--yellow); box-shadow: 2px 2px 0 var(--ink); }
.pg-btn:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: 1px 1px 0 var(--ink); }
.pg-step { padding: 0 14px; }
.pg-total { margin-left: 6px; font-size: 11px; font-weight: 800; color: var(--text-3); }
.pg-size { display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: 800; color: var(--text-3); }
.pg-size select {
  height: 30px; padding: 0 4px; font: inherit; font-size: 11px; font-weight: 900; color: var(--ink);
  background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm); cursor: pointer;
}

/* ===== 对比悬浮栏 ===== */
.compare-bar {
  position: fixed; left: 50%; bottom: 18px; z-index: 45;
  transform: translateX(-50%);
  display: flex; align-items: center; gap: 16px;
  width: min(860px, calc(100% - 40px));
  padding: 11px 16px;
  background: var(--paper); border: var(--line); border-radius: var(--r-lg);
  box-shadow: var(--shadow-3);
}
.cb-head { display: flex; flex-direction: column; gap: 2px; flex: 0 0 auto; }
.cb-title { font-size: 13px; font-weight: 900; }
.cb-count { font-size: 10px; font-weight: 800; color: var(--text-3); }
.cb-items { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
.cb-item {
  position: relative; display: flex; align-items: center; gap: 6px;
  padding: 4px 8px 4px 4px; min-width: 0;
  background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm);
}
.cb-item img { width: 30px; height: 30px; object-fit: contain; background: #fff; border-radius: 6px; }
.cb-item span { font-size: 11px; font-weight: 900; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cb-x {
  width: 17px; height: 17px; display: grid; place-items: center; padding: 0;
  font: inherit; font-size: 9px; font-weight: 900; color: var(--ink);
  background: #ffe0e3; border: 1.5px solid var(--ink); border-radius: 50%; cursor: pointer;
}
.cb-item.empty { width: 60px; height: 42px; justify-content: center; border-style: dashed; border-color: #cbbfa9; background: #fffdf6; }
.cb-plus { color: #c2b49e; font-size: 15px; }
.cb-actions { display: flex; gap: 8px; flex: 0 0 auto; }
.cb-clear { height: 36px; padding: 0 14px; font: inherit; font-size: 12px; font-weight: 900; color: var(--ink); background: #fff; border: var(--line); border-radius: var(--r-sm); cursor: pointer; }
.cb-clear:hover { background: #ffeef1; }
.cb-go { height: 36px; padding: 0 18px; font: inherit; font-size: 12px; font-weight: 900; color: var(--ink); background: var(--yellow); border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-1); cursor: pointer; }
.cb-go:hover:not(:disabled) { background: #ffe07a; transform: translateY(-2px); }
.cb-go:disabled { opacity: 0.5; cursor: not-allowed; }

.cmp-slide-enter-active, .cmp-slide-leave-active { transition: opacity 0.24s ease, transform 0.24s cubic-bezier(0.2, 1.3, 0.4, 1); }
.cmp-slide-enter-from, .cmp-slide-leave-to { opacity: 0; transform: translate(-50%, 24px); }

/* ===== 对比弹窗 ===== */
.compare-modal {
  position: relative; width: min(920px, 100%); max-height: 88vh; overflow-y: auto;
  padding: 26px; background: var(--paper); border: var(--line); border-radius: var(--r-lg);
  box-shadow: 10px 12px 0 var(--ink);
  animation: modal-pop 0.3s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
.compare-modal h2 { margin: 0 0 6px; font-size: 23px; }
.compare-table { margin-top: 16px; border: var(--line); border-radius: var(--r-sm); overflow: hidden; }
.cm-row { display: grid; grid-template-columns: 104px repeat(3, minmax(0, 1fr)); align-items: center; }
.cm-row:nth-child(even) { background: #fffaeb; }
.cm-row + .cm-row { border-top: 2px solid #ece0cb; }
.cm-head { background: #fff3cf; border-bottom: var(--line); }
.cm-label { padding: 10px 12px; font-size: 11px; font-weight: 900; color: var(--text-2); border-right: 2px solid #ece0cb; }
.cm-pet { display: flex; flex-direction: column; align-items: center; gap: 5px; padding: 12px 8px; text-align: center; }
.cm-pet img { width: 76px; height: 76px; object-fit: contain; background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm); }
.cm-pet strong { font-size: 13px; }
.cm-cell { padding: 12px; font-size: 12px; font-weight: 800; text-align: center; color: var(--text-1); border-left: 2px solid #ece0cb; }

/* ===== 空状态 ===== */
.empty-wrap { background: var(--paper); border: var(--line); border-radius: var(--r-lg); box-shadow: var(--shadow-2); }
.reset-btn { padding: 9px 20px; font: inherit; font-size: 13px; font-weight: 900; color: var(--ink); background: var(--yellow); border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-1); cursor: pointer; }
.reset-btn:hover { background: #ffe27a; transform: translate(-1px, -3px); box-shadow: 4px 6px 0 var(--ink); }

/* ===== 弹窗 ===== */
.modal-mask { position: fixed; inset: 0; z-index: 60; display: grid; place-items: center; padding: 20px; background: rgba(43, 43, 43, 0.45); }
.apply-modal { position: relative; width: min(520px, 100%); max-height: 90vh; overflow-y: auto; padding: 28px; background: var(--paper); border: var(--line); border-radius: var(--r-lg); box-shadow: 10px 12px 0 var(--ink); animation: modal-pop 0.3s cubic-bezier(0.2, 1.4, 0.4, 1) both; }
@keyframes modal-pop { from { opacity: 0; transform: scale(0.85) translateY(20px); } to { opacity: 1; transform: none; } }
.modal-close { position: absolute; right: 16px; top: 16px; width: 32px; height: 32px; font: inherit; font-weight: 900; background: #ffc9cf; border: 2px solid var(--ink); border-radius: 50%; cursor: pointer; }
.apply-modal h2 { margin: 0 0 6px; font-size: 23px; }
.modal-sub { margin: 0 0 16px; font-size: 13px; font-weight: 700; color: var(--text-2); }
.notice-list { margin: 0 0 18px; padding-left: 20px; }
.notice-list li { margin-bottom: 10px; font-size: 13px; font-weight: 700; line-height: 1.7; }
.notice-list strong { color: #d2691e; }
.agree-line { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 900; margin-bottom: 18px; cursor: pointer; }
.agree-line input { width: 18px; height: 18px; accent-color: var(--pink); }
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.form-grid label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; font-weight: 900; }
.form-grid label.full { grid-column: 1 / -1; }
.form-grid input, .form-grid textarea { padding: 9px 11px; font: inherit; font-size: 13px; color: var(--ink); background: #fff; border: 2px solid var(--ink); border-radius: var(--r-sm); outline: none; resize: vertical; }
.form-grid input:focus, .form-grid textarea:focus { box-shadow: 3px 3px 0 var(--pink); }
.form-error { color: #d2691e; font-size: 12px; font-weight: 900; margin: 12px 0 0; }
.modal-primary { padding: 11px 22px; font: inherit; font-size: 14px; font-weight: 900; color: var(--ink); background: var(--yellow); border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-2); cursor: pointer; }
.modal-primary:hover:not(:disabled) { background: #ffe07a; transform: translateY(-2px); }
.modal-primary:disabled { opacity: 0.5; cursor: default; }
.modal-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }
.modal-ghost { padding: 11px 18px; font: inherit; font-size: 13px; font-weight: 900; color: var(--ink); background: #fff; border: var(--line); border-radius: var(--r-sm); cursor: pointer; }

.cute-toast { position: fixed; left: 50%; bottom: 40px; z-index: 70; transform: translate(-50%, 20px); padding: 11px 20px; font-size: 13px; font-weight: 900; background: #fff; border: var(--line); border-radius: var(--r-sm); box-shadow: var(--shadow-3); opacity: 0; pointer-events: none; transition: 0.25s; }
.cute-toast.show { opacity: 1; transform: translate(-50%, 0); }
.cute-toast.show.lifted { bottom: 104px; }

/* ===== 响应式 ===== */
@media (max-width: 1080px) {
  .pet-list.grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 900px) {
  .filter-grid { grid-template-columns: 1fr; }
  .compare-bar { flex-wrap: wrap; gap: 10px; }
  .cb-items { order: 3; width: 100%; flex-basis: 100%; }
}
@media (max-width: 760px) {
  .pet-list.list .adopt-card,
  .pet-list.list .skeleton-card { grid-template-columns: 150px minmax(0, 1fr); }
  .pet-list.list .card-photo { min-height: 156px; }
  .pet-list.list .card-actions { justify-content: flex-start; }
  .cm-row { grid-template-columns: 84px repeat(3, minmax(0, 1fr)); }
  .cm-cell, .cm-label { padding: 8px 6px; font-size: 11px; }
  .cm-pet img { width: 54px; height: 54px; }
}
@media (max-width: 620px) {
  .pet-list.grid { grid-template-columns: 1fr; }
  .form-grid { grid-template-columns: 1fr; }
  .toolbar-left, .toolbar-right { width: 100%; }
  .keyword-search { flex: 1; }
  .keyword-search input { width: 100%; }
  .hint-page { margin-left: 0; }
  .pager .pg-total { width: 100%; text-align: center; margin: 4px 0 0; }
}
</style>
