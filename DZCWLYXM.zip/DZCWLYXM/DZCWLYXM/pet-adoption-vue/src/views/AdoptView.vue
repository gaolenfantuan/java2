<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { adoptPets, filterConfig, sortOptions } from '../data/adoptPets'
import { getRescuedAdoptPets } from '../data/rescuePets'

const router = useRouter()

// 页面内关键词搜索（名字 / 品种 / 城市 / 性格），与全局导航搜索相互独立
const keyword = ref('')

// ===== 状态分类 Tab =====
const statusTabs = [
  { label: '全部', value: 'all', icon: '🐾' },
  { label: '待领养', value: 'available', icon: '💛' },
  { label: '预约中', value: 'reserved', icon: '⏳' },
  { label: '已领养', value: 'adopted', icon: '🏠' }
]
const activeStatus = ref('all')

// ===== localStorage 状态 =====
const applyStatuses = ref({})   // { [petId]: '预约中' }
const adoptedIds = ref([])      // 已领养宠物 id
const applications = ref([])    // 申请记录
const allPets = ref([...adoptPets])  // 领养池：原有宠物 + 救助完成转入的宠物

function loadStorage() {
  // 合并「流浪救助」完成的宠物（状态为待领养），按 id 去重
  const rescued = getRescuedAdoptPets()
  const merged = [...adoptPets]
  rescued.forEach(p => { if (!merged.some(x => x.id === p.id)) merged.push(p) })
  allPets.value = merged
  try {
    const s = JSON.parse(localStorage.getItem('petApplyStatuses') || '{}')
    applyStatuses.value = s && typeof s === 'object' ? s : {}
  } catch { applyStatuses.value = {} }
  try {
    const a = JSON.parse(localStorage.getItem('petAdopted') || '[]')
    adoptedIds.value = Array.isArray(a) ? a : []
  } catch { adoptedIds.value = [] }
  try {
    const r = JSON.parse(localStorage.getItem('petAdoptApplications') || '[]')
    applications.value = Array.isArray(r) ? r : []
  } catch { applications.value = [] }
}

// 宠物状态：adopted > reserved > available
function petStatus(pet) {
  if (adoptedIds.value.includes(pet.id)) return 'adopted'
  if (applyStatuses.value[pet.id] === '预约中') return 'reserved'
  return 'available'
}

// ===== 高级筛选（多选） =====
const selectedFilters = reactive({
  city: [], breed: [], gender: [], ageGroup: [], sterilized: [], vaccinated: [], traits: []
})

function toggleFilter(key, option) {
  const list = selectedFilters[key]
  const idx = list.indexOf(option)
  if (idx === -1) list.push(option)
  else list.splice(idx, 1)
}
function isFilterActive(key, option) {
  return selectedFilters[key].includes(option)
}
function clearFilters() {
  Object.keys(selectedFilters).forEach(key => { selectedFilters[key] = [] })
}
const hasFilters = computed(() => Object.values(selectedFilters).some(list => list.length > 0))

// ===== 排序 & 视图 =====
const sortBy = ref('latest')
const viewMode = ref('grid') // grid | list

// ===== 列表计算 =====
function matchFilters(pet) {
  const f = selectedFilters
  if (f.city.length && !f.city.some(c => pet.city.startsWith(c))) return false
  if (f.breed.length && !f.breed.includes(pet.breed)) return false
  if (f.gender.length && !f.gender.includes(pet.gender)) return false
  if (f.ageGroup.length && !f.ageGroup.includes(pet.ageGroup)) return false
  if (f.sterilized.length) {
    const val = pet.sterilized ? '已绝育' : '未绝育'
    if (!f.sterilized.includes(val)) return false
  }
  if (f.vaccinated.length) {
    const val = pet.vaccinated ? '已接种' : '未接种'
    if (!f.vaccinated.includes(val)) return false
  }
  if (f.traits.length && !f.traits.some(t => pet.traits.includes(t))) return false
  return true
}

const visiblePets = computed(() => {
  const kw = keyword.value.trim().toLowerCase()
  let list = allPets.value.filter(pet => {
    const status = petStatus(pet)
    const statusMatch = activeStatus.value === 'all' || status === activeStatus.value
    if (!statusMatch || !matchFilters(pet)) return false
    if (!kw) return true
    // 关键词模糊匹配：名字 / 品种 / 城市 / 性格 / 标签
    return [pet.name, pet.breed, pet.city, pet.personality, ...(pet.traits || [])]
      .some(v => String(v || '').toLowerCase().includes(kw))
  })
  list = [...list]
  if (sortBy.value === 'popular') list.sort((a, b) => b.popularity - a.popularity)
  else if (sortBy.value === 'youngest') {
    const ageVal = p => (String(p.age).includes('岁') ? 24 : 0) + (parseInt(String(p.age).replace(/[^0-9]/g, ''), 10) || 0)
    list.sort((a, b) => ageVal(a) - ageVal(b))
  } else list.sort((a, b) => String(b.listedAt).localeCompare(String(a.listedAt)))
  return list
})

const statusCount = value => value === 'all'
  ? allPets.value.length
  : allPets.value.filter(p => petStatus(p) === value).length

// ===== 申请闭环：须知 → 表单 → 提交 =====
const applyModalShow = ref(false)
const applyStep = ref('notice') // notice | form
const applyTarget = ref(null)
const noticeAgreed = ref(false)
const applyForm = reactive({ name: '', contact: '', experience: '', housing: '', message: '' })
const formError = ref(false)
const toastText = ref('')
let toastTimer = null

function openApply(pet) {
  if (petStatus(pet) !== 'available') return
  applyTarget.value = pet
  applyStep.value = 'notice'
  noticeAgreed.value = false
  formError.value = false
  Object.assign(applyForm, { name: '', contact: '', experience: '', housing: '', message: '' })
  applyModalShow.value = true
}
function closeApply() {
  applyModalShow.value = false
  applyTarget.value = null
}
function nextToForm() {
  if (noticeAgreed.value) applyStep.value = 'form'
}
function submitApply() {
  if (!applyForm.name.trim() || !applyForm.contact.trim() || !applyForm.message.trim()) {
    formError.value = true
    return
  }
  if (!applyTarget.value || petStatus(applyTarget.value) !== 'available') return
  const id = applyTarget.value.id
  applyStatuses.value = { ...applyStatuses.value, [id]: '预约中' }
  applications.value = [{
    petId: id,
    petName: applyTarget.value.name,
    name: applyForm.name.trim(),
    contact: applyForm.contact.trim(),
    experience: applyForm.experience.trim(),
    housing: applyForm.housing.trim(),
    message: applyForm.message.trim(),
    time: new Date().toLocaleString('zh-CN')
  }, ...applications.value]
  localStorage.setItem('petApplyStatuses', JSON.stringify(applyStatuses.value))
  localStorage.setItem('petAdoptApplications', JSON.stringify(applications.value))
  closeApply()
  showToast('申请提交成功，TA 正在等你哦～ 🐾')
}
function showToast(text) {
  toastText.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastText.value = '' }, 2400)
}

function goDetail(pet) {
  router.push(`/pet/${pet.id}`)
}
function goRecords() {
  router.push({ path: '/my-pets', query: { tab: 'applications' } })
}

// 跨页面/跨标签页实时同步：其它页面改动救助或领养状态后，本页自动刷新
const SYNC_KEYS = ['petRescueDone', 'petRescueSync', 'petAdopted', 'petApplyStatuses', 'petAdoptApplications']
function onStorage(e) {
  if (e.key && SYNC_KEYS.includes(e.key)) loadStorage()
}

onMounted(() => {
  document.body.classList.add('home-body')
  loadStorage()
  window.addEventListener('storage', onStorage)
})
onBeforeUnmount(() => {
  document.body.classList.remove('home-body')
  window.removeEventListener('storage', onStorage)
  clearTimeout(toastTimer)
})
</script>

<template>
  <div class="adopt-page">
    <main class="adopt-main">
      <div class="page-head">
        <div>
          <h1>领养专区 <span>🐾</span></h1>
          <p>每一个它都在等一个你，找到属于你的那份缘分吧～</p>
        </div>
        <button type="button" class="records-btn" @click="goRecords">📝 我的申请记录</button>
      </div>

      <!-- 状态分类 Tab -->
      <div class="status-tabs" role="tablist" aria-label="领养状态分类">
        <button
          v-for="tab in statusTabs"
          :key="tab.value"
          type="button"
          class="status-tab"
          :class="{ active: activeStatus === tab.value }"
          role="tab"
          :aria-selected="activeStatus === tab.value"
          @click="activeStatus = tab.value"
        >
          <span>{{ tab.icon }}</span>{{ tab.label }}
          <span class="tab-count">{{ statusCount(tab.value) }}</span>
        </button>
      </div>

      <!-- 高级筛选栏 -->
      <section class="filter-panel" aria-label="高级筛选">
        <div class="filter-grid">
          <div v-for="(cfg, key) in filterConfig" :key="key" class="filter-group">
            <span class="filter-label">{{ cfg.icon }} {{ cfg.label }}</span>
            <div class="filter-options">
              <button
                v-for="opt in cfg.options"
                :key="opt"
                type="button"
                class="filter-chip"
                :class="{ active: isFilterActive(key, opt) }"
                @click="toggleFilter(key, opt)"
              >{{ opt }}</button>
            </div>
          </div>
        </div>
        <div class="filter-toolbar">
          <div class="toolbar-left">
            <button type="button" class="clear-btn" :disabled="!hasFilters" @click="clearFilters">🧹 清空筛选</button>
            <label class="keyword-search">
              <span class="kw-icon" aria-hidden="true">🔍</span>
              <input v-model="keyword" type="search" placeholder="搜名字 / 品种 / 城市..." aria-label="关键词搜索宠物">
              <button v-if="keyword" type="button" class="kw-clear" aria-label="清除搜索" @click="keyword = ''">✕</button>
            </label>
          </div>
          <div class="toolbar-right">
            <label class="sort-select">
              <span>排序</span>
              <select v-model="sortBy" aria-label="排序方式">
                <option v-for="opt in sortOptions" :key="opt.value" :value="opt.value">{{ opt.icon }} {{ opt.label }}</option>
              </select>
            </label>
            <div class="view-switch" aria-label="视图切换">
              <button type="button" :class="{ active: viewMode === 'grid' }" title="大卡片模式" @click="viewMode = 'grid'">▦</button>
              <button type="button" :class="{ active: viewMode === 'list' }" title="紧凑列表模式" @click="viewMode = 'list'">☰</button>
            </div>
          </div>
        </div>
      </section>

      <p class="result-hint">共 {{ visiblePets.length }} 位毛孩子符合条件 🐾</p>

      <!-- 宠物列表 -->
      <div v-if="visiblePets.length" class="pet-list" :class="viewMode">
        <article
          v-for="pet in visiblePets"
          :key="pet.id"
          class="adopt-card"
          :class="{ 'is-adopted': petStatus(pet) === 'adopted', 'is-reserved': petStatus(pet) === 'reserved' }"
          @click="goDetail(pet)"
        >
          <div class="card-photo" :style="{ '--pet-color': pet.color }">
            <img v-if="pet.image" :src="pet.image" :alt="pet.name">
            <span v-else class="card-emoji">{{ pet.emoji }}</span>
            <span class="city-tag">📍 {{ pet.city }}</span>
            <span v-if="petStatus(pet) === 'adopted'" class="corner-badge home">🏠 已回家</span>
            <span v-else-if="petStatus(pet) === 'reserved'" class="corner-badge reserved">⏳ 预约中</span>
            <span v-else class="corner-badge available">💛 待领养</span>
          </div>

          <div class="card-info">
            <div class="card-title">
              <h2>{{ pet.name }}</h2>
              <span class="breed">{{ pet.breed }}</span>
            </div>
            <div class="card-tags">
              <span>{{ pet.gender }}</span>
              <span>{{ pet.age }}</span>
              <span>{{ pet.personality }}</span>
            </div>
            <div class="card-extra">
              <span class="health-tag">💚 {{ pet.health }}</span>
              <span class="mini-tag" :class="pet.sterilized ? 'yes' : 'no'">{{ pet.sterilized ? '已绝育' : '未绝育' }}</span>
              <span class="mini-tag" :class="pet.vaccinated ? 'yes' : 'no'">{{ pet.vaccinated ? '已接种疫苗' : '未接种疫苗' }}</span>
            </div>
            <button
              type="button"
              class="apply-btn"
              :disabled="petStatus(pet) !== 'available'"
              @click.stop="openApply(pet)"
            >
              {{ petStatus(pet) === 'available' ? '💌 申请领养' : petStatus(pet) === 'reserved' ? '⏳ 已预约' : '🏠 已回家' }}
            </button>
          </div>
        </article>
      </div>

      <!-- 空状态 -->
      <div v-else class="empty-state">
        <svg class="empty-illustration" viewBox="0 0 200 160" aria-hidden="true">
          <ellipse cx="100" cy="140" rx="62" ry="10" fill="#f0dcbf" />
          <path d="M62 118c0-26 17-44 38-44s38 18 38 44z" fill="#ffd84d" stroke="#2b2b2b" stroke-width="4" stroke-linejoin="round" />
          <circle cx="100" cy="66" r="34" fill="#fff3cf" stroke="#2b2b2b" stroke-width="4" />
          <path d="M76 42l6-20 16 14M124 42l-6-20-16 14" fill="#fff3cf" stroke="#2b2b2b" stroke-width="4" stroke-linejoin="round" />
          <circle cx="88" cy="64" r="3.5" fill="#2b2b2b" />
          <circle cx="112" cy="64" r="3.5" fill="#2b2b2b" />
          <path d="M94 76q6 6 12 0" fill="none" stroke="#2b2b2b" stroke-width="3" stroke-linecap="round" />
          <circle cx="146" cy="52" r="20" fill="#9fd3ff" stroke="#2b2b2b" stroke-width="4" />
          <path d="M160 66l16 16" stroke="#2b2b2b" stroke-width="6" stroke-linecap="round" />
        </svg>
        <p>没有找到符合条件的毛孩子～</p>
        <small>换个筛选条件，缘分也许就在下一页 🐾</small>
        <button type="button" class="reset-btn" @click="clearFilters">重置筛选</button>
      </div>
    </main>

    <!-- 申请弹窗 -->
    <div v-if="applyModalShow" class="modal-mask" @click.self="closeApply">
      <div class="apply-modal" role="dialog" aria-modal="true">
        <button type="button" class="modal-close" aria-label="关闭" @click="closeApply">✕</button>

        <template v-if="applyStep === 'notice'">
          <h2>📋 领养须知</h2>
          <p class="modal-sub">在领养 {{ applyTarget?.name }} 之前，请认真阅读以下内容～</p>
          <ul class="notice-list">
            <li><strong>领养责任</strong>：领养后请长期负责喂养、照顾，不离不弃，不得随意转送或弃养。</li>
            <li><strong>回访要求</strong>：我们会定期回访了解毛孩子的生活状况，请配合提供近况。</li>
            <li><strong>领养条件</strong>：需年满 18 周岁，有稳定住所与经济能力，家人同意共同饲养。</li>
          </ul>
          <label class="agree-line">
            <input v-model="noticeAgreed" type="checkbox">
            <span>我已阅读并同意以上领养须知</span>
          </label>
          <button type="button" class="modal-primary" :disabled="!noticeAgreed" @click="nextToForm">下一步 →</button>
        </template>

        <template v-else>
          <h2>💌 领养申请</h2>
          <p class="modal-sub">介绍一下你自己，让 {{ applyTarget?.name }} 更快认识你～</p>
          <div class="form-grid">
            <label><span>姓名</span><input v-model="applyForm.name" type="text" placeholder="你的姓名"></label>
            <label><span>联系方式</span><input v-model="applyForm.contact" type="text" placeholder="手机号 / 微信"></label>
            <label><span>养宠经验</span><input v-model="applyForm.experience" type="text" placeholder="如：养过猫 3 年"></label>
            <label><span>居住环境</span><input v-model="applyForm.housing" type="text" placeholder="如：自有住房 / 合租"></label>
            <label class="full"><span>领养寄语</span><textarea v-model="applyForm.message" rows="3" placeholder="想对 TA 说的话..."></textarea></label>
          </div>
          <p v-if="formError" class="form-error">⚠️ 请填写姓名、联系方式和领养寄语哦～</p>
          <div class="modal-actions">
            <button type="button" class="modal-ghost" @click="applyStep = 'notice'">← 上一步</button>
            <button type="button" class="modal-primary" @click="submitApply">提交申请 ✓</button>
          </div>
        </template>
      </div>
    </div>

    <div class="cute-toast" :class="{ show: !!toastText }">🐾 {{ toastText }}</div>
  </div>
</template>

<style scoped>
.adopt-page {
  min-height: 100vh;
  color: var(--ink);
  font-family: "Comic Sans MS", "YouYuan", "幼圆", "Microsoft YaHei", sans-serif;
  background-color: #fff8e9;
  background-image:
    radial-gradient(#f0c98a 1.4px, transparent 1.4px),
    radial-gradient(#f0c98a 1.4px, transparent 1.4px);
  background-size: 26px 26px, 26px 26px;
  background-position: 0 0, 13px 13px;
}
:global(body.home-body) { display: block; align-items: initial; justify-content: initial; padding: 0; }

.topbar { position: sticky; top: 0; z-index: 10; background: #fffdf6; border-bottom: 3px solid var(--ink); }
.topbar-inner { max-width: 1180px; margin: 0 auto; padding: 12px 22px; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
.brand { display: flex; align-items: center; gap: 11px; font-size: 21px; font-weight: 900; background: none; border: none; cursor: pointer; font-family: inherit; color: var(--ink); }
.brand-badge { width: 42px; height: 42px; display: grid; place-items: center; background: var(--pink); border: var(--line); border-radius: 13px; font-size: 23px; box-shadow: 3px 3px 0 var(--ink); transform: rotate(-6deg); }
.records-btn { padding: 9px 16px; font: inherit; font-size: 13px; font-weight: 900; color: var(--ink); background: var(--yellow); border: var(--line); border-radius: 12px; box-shadow: 4px 4px 0 var(--ink); cursor: pointer; transition: 0.15s; }
.records-btn:hover { transform: translateY(-3px); box-shadow: 4px 7px 0 var(--ink); }

.adopt-main { max-width: 1180px; margin: 0 auto; padding: 30px 22px 70px; }
.page-head { margin-bottom: 22px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
.page-head h1 { margin: 0 0 6px; font-size: 32px; }
.page-head h1 span { color: var(--pink); }
.page-head p { margin: 0; font-size: 14px; font-weight: 700; color: #8a6a4f; }

/* 状态 Tab */
.status-tabs { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 18px; }
.status-tab {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 9px 16px; font: inherit; font-size: 14px; font-weight: 900;
  color: var(--ink); background: #fffdf6; border: var(--line);
  border-radius: 14px; box-shadow: 4px 4px 0 var(--ink);
  cursor: pointer; transition: 0.15s;
}
.status-tab:hover { transform: translateY(-3px); box-shadow: 4px 7px 0 var(--ink); }
.status-tab.active { background: var(--yellow); box-shadow: 4px 6px 0 var(--ink); }
.tab-count { padding: 1px 7px; font-size: 11px; background: #fff; border: 2px solid var(--ink); border-radius: 999px; }

/* 筛选面板 */
.filter-panel { padding: 18px 20px; background: #fffdf6; border: var(--line); border-radius: 22px; box-shadow: 7px 8px 0 var(--ink); margin-bottom: 18px; }
.filter-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px 24px; }
.filter-group { display: flex; flex-direction: column; gap: 8px; }
.filter-label { font-size: 13px; font-weight: 900; }
.filter-options { display: flex; flex-wrap: wrap; gap: 7px; }
.filter-chip {
  padding: 5px 11px; font: inherit; font-size: 11px; font-weight: 900;
  color: var(--ink); background: #fff; border: 2px solid var(--ink);
  border-radius: 999px; cursor: pointer; transition: 0.15s;
}
.filter-chip:hover { transform: translateY(-2px); background: #fff3cf; }
.filter-chip.active { background: var(--mint); box-shadow: 2px 2px 0 var(--ink); }

.filter-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-top: 18px; padding-top: 14px; border-top: 2px dashed #e6d3b3; }
.toolbar-left { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.clear-btn { padding: 7px 13px; font: inherit; font-size: 12px; font-weight: 900; color: var(--ink); background: #ffc9cf; border: 2px solid var(--ink); border-radius: 10px; cursor: pointer; }
.clear-btn:disabled { opacity: 0.5; cursor: default; }
.keyword-search { display: flex; align-items: center; gap: 5px; padding: 5px 10px; background: #fff; border: 2px solid var(--ink); border-radius: 999px; box-shadow: 3px 3px 0 var(--ink); }
.keyword-search .kw-icon { font-size: 12px; }
.keyword-search input { width: 168px; padding: 2px 0; font: inherit; font-size: 12px; color: var(--ink); background: transparent; border: none; outline: none; }
.keyword-search input::placeholder { color: #b49a7d; }
.keyword-search input::-webkit-search-cancel-button { display: none; }
.kw-clear { width: 18px; height: 18px; display: grid; place-items: center; padding: 0; font: inherit; font-size: 11px; font-weight: 900; color: var(--ink); background: #ffe0e3; border: 1.5px solid var(--ink); border-radius: 50%; cursor: pointer; }
.toolbar-right { display: flex; align-items: center; gap: 12px; }
.sort-select { display: flex; align-items: center; gap: 7px; font-size: 12px; font-weight: 900; }
.sort-select select { padding: 6px 10px; font: inherit; font-size: 12px; font-weight: 900; color: var(--ink); background: #fff; border: 2px solid var(--ink); border-radius: 10px; cursor: pointer; }
.view-switch { display: flex; border: 2px solid var(--ink); border-radius: 10px; overflow: hidden; }
.view-switch button { width: 34px; height: 30px; font-size: 15px; font-weight: 900; color: var(--ink); background: #fff; border: none; cursor: pointer; }
.view-switch button + button { border-left: 2px solid var(--ink); }
.view-switch button.active { background: var(--yellow); }

.result-hint { font-size: 13px; font-weight: 900; color: #8a6a4f; margin: 4px 0 14px; }

/* 宠物列表 */
.pet-list { display: grid; gap: 20px; }
.pet-list.grid { grid-template-columns: repeat(3, 1fr); }
.pet-list.list { grid-template-columns: 1fr; }

.adopt-card {
  background: #fffdf6; border: var(--line); border-radius: 22px;
  box-shadow: 8px 9px 0 var(--ink); overflow: hidden; cursor: pointer;
  transition: transform 0.18s ease, box-shadow 0.18s ease;
  animation: card-in 0.4s cubic-bezier(0.2, 1.4, 0.4, 1) both;
}
.adopt-card:hover { transform: translate(-4px, -7px); box-shadow: 12px 16px 0 var(--ink); }
@keyframes card-in { from { opacity: 0; transform: translateY(16px) scale(0.97); } to { opacity: 1; transform: none; } }
.adopt-card.is-adopted { filter: grayscale(0.9); opacity: 0.72; }
.adopt-card.is-reserved { opacity: 0.92; }

.card-photo { position: relative; height: 168px; display: grid; place-items: center; background: var(--pet-color); border-bottom: 3px solid var(--ink); }
.card-photo img { width: 100%; height: 100%; object-fit: cover; }
.card-emoji { font-size: 82px; filter: drop-shadow(6px 8px 0 rgba(43,43,43,0.2)); transition: 0.2s; }
.adopt-card:hover .card-emoji { transform: scale(1.08) rotate(-5deg); }
.city-tag { position: absolute; left: 10px; bottom: 10px; padding: 4px 9px; font-size: 10px; font-weight: 900; background: #fff; border: 2px solid var(--ink); border-radius: 999px; }
.corner-badge { position: absolute; right: -2px; top: 12px; padding: 5px 10px; font-size: 11px; font-weight: 900; border: 2px solid var(--ink); border-radius: 10px 0 0 10px; box-shadow: 3px 3px 0 var(--ink); }
.corner-badge.available { background: var(--yellow); }
.corner-badge.reserved { background: var(--mint); }
.corner-badge.home { background: #d3d3d3; }

.card-info { padding: 15px 17px 17px; }
.card-title { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; margin-bottom: 10px; }
.card-title h2 { margin: 0; font-size: 21px; }
.breed { font-size: 11px; font-weight: 900; color: #8a6a4f; }
.card-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }
.card-tags span { padding: 4px 9px; font-size: 10px; font-weight: 900; background: #fff; border: 2px solid var(--ink); border-radius: 999px; }
.card-tags span:nth-child(2) { background: var(--blue); }
.card-tags span:nth-child(3) { background: var(--pink); }
.card-extra { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 14px; }
.health-tag, .mini-tag { padding: 3px 8px; font-size: 10px; font-weight: 900; border-radius: 8px; }
.health-tag { background: #dcf5e8; border: 2px solid var(--ink); }
.mini-tag { border: 1.5px solid var(--ink); }
.mini-tag.yes { background: var(--mint); }
.mini-tag.no { background: #f0e6d8; }
.apply-btn {
  width: 100%; padding: 10px; font: inherit; font-size: 13px; font-weight: 900;
  color: var(--ink); background: var(--yellow); border: var(--line);
  border-radius: 12px; box-shadow: 4px 4px 0 var(--ink); cursor: pointer; transition: 0.15s;
}
.apply-btn:hover:not(:disabled) { transform: translateY(-3px); box-shadow: 4px 7px 0 var(--ink); }
.apply-btn:disabled { background: #e6ded2; color: #888; cursor: default; box-shadow: 2px 2px 0 var(--ink); }

/* 紧凑列表模式 */
.pet-list.list .adopt-card { display: flex; align-items: stretch; }
.pet-list.list .card-photo { flex: 0 0 180px; height: auto; min-height: 150px; border-bottom: none; border-right: 3px solid var(--ink); }
.pet-list.list .card-info { flex: 1; display: flex; flex-direction: column; justify-content: center; }
.pet-list.list .apply-btn { width: auto; align-self: flex-start; padding: 8px 20px; }

/* 空状态 */
.empty-state { text-align: center; padding: 40px 20px; background: #fffdf6; border: var(--line); border-radius: 24px; box-shadow: 8px 9px 0 var(--ink); }
.empty-illustration { width: 180px; height: 145px; }
.empty-state p { font-size: 18px; font-weight: 900; margin: 12px 0 4px; }
.empty-state small { color: #8a6a4f; font-weight: 700; }
.reset-btn { display: block; margin: 16px auto 0; padding: 9px 18px; font: inherit; font-size: 13px; font-weight: 900; background: var(--yellow); border: var(--line); border-radius: 12px; box-shadow: 4px 4px 0 var(--ink); cursor: pointer; }

/* 弹窗 */
.modal-mask { position: fixed; inset: 0; z-index: 60; display: grid; place-items: center; padding: 20px; background: rgba(43,43,43,0.45); }
.apply-modal { position: relative; width: min(520px, 100%); max-height: 90vh; overflow-y: auto; padding: 28px; background: #fffdf6; border: var(--line); border-radius: 24px; box-shadow: 10px 12px 0 var(--ink); animation: modal-pop 0.3s cubic-bezier(0.2, 1.4, 0.4, 1) both; }
@keyframes modal-pop { from { opacity: 0; transform: scale(0.85) translateY(20px); } to { opacity: 1; transform: none; } }
.modal-close { position: absolute; right: 16px; top: 16px; width: 32px; height: 32px; font: inherit; font-weight: 900; background: #ffc9cf; border: 2px solid var(--ink); border-radius: 50%; cursor: pointer; }
.apply-modal h2 { margin: 0 0 6px; font-size: 23px; }
.modal-sub { margin: 0 0 16px; font-size: 13px; font-weight: 700; color: #8a6a4f; }
.notice-list { margin: 0 0 18px; padding-left: 20px; }
.notice-list li { margin-bottom: 10px; font-size: 13px; font-weight: 700; line-height: 1.7; }
.notice-list strong { color: #d2691e; }
.agree-line { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 900; margin-bottom: 18px; cursor: pointer; }
.agree-line input { width: 18px; height: 18px; accent-color: var(--pink); }
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.form-grid label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; font-weight: 900; }
.form-grid label.full { grid-column: 1 / -1; }
.form-grid input, .form-grid textarea { padding: 9px 11px; font: inherit; font-size: 13px; color: var(--ink); background: #fff; border: 2px solid var(--ink); border-radius: 10px; outline: none; resize: vertical; }
.form-grid input:focus, .form-grid textarea:focus { box-shadow: 3px 3px 0 var(--pink); }
.form-error { color: #d2691e; font-size: 12px; font-weight: 900; margin: 12px 0 0; }
.modal-primary { padding: 11px 22px; font: inherit; font-size: 14px; font-weight: 900; color: var(--ink); background: var(--yellow); border: var(--line); border-radius: 12px; box-shadow: 4px 4px 0 var(--ink); cursor: pointer; }
.modal-primary:disabled { opacity: 0.5; cursor: default; }
.modal-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }
.modal-ghost { padding: 11px 18px; font: inherit; font-size: 13px; font-weight: 900; color: var(--ink); background: #fff; border: var(--line); border-radius: 12px; cursor: pointer; }

.cute-toast { position: fixed; left: 50%; bottom: 40px; z-index: 70; transform: translate(-50%, 20px); padding: 11px 20px; font-size: 13px; font-weight: 900; background: #fff; border: var(--line); border-radius: 999px; box-shadow: 5px 5px 0 var(--ink); opacity: 0; pointer-events: none; transition: 0.25s; }
.cute-toast.show { opacity: 1; transform: translate(-50%, 0); }

@media (max-width: 980px) {
  .pet-list.grid { grid-template-columns: repeat(2, 1fr); }
  .filter-grid { grid-template-columns: 1fr; }
}
@media (max-width: 620px) {
  .pet-list.grid { grid-template-columns: 1fr; }
  .pet-list.list .card-photo { flex-basis: 120px; }
  .form-grid { grid-template-columns: 1fr; }
  .toolbar-left { width: 100%; }
  .keyword-search input { width: 100%; }
}

/* ===== 宠物形象底部居中：与首页一致，只改摆放，尺寸/滤镜/其余元素不动 ===== */
/* 锁定图片区网格轨道高度，避免 img 按宽度把自动轨道撑大后越出图片区 */
.card-photo { grid-template-rows: 100%; }
/* contain 完整显示 + 底边对齐；按各 PNG 底部透明留白做百分比补偿，6 只脚底齐平 */
.card-photo img {
  width: 72%;
  height: 72%;
  object-fit: contain;
  align-self: end;
  --pet-ground-shift: 11.3%;
  transform: translateY(var(--pet-ground-shift));
  filter:
    drop-shadow(0 2px 1px rgba(43, 43, 43, 0.16))
    drop-shadow(0 7px 6px rgba(43, 43, 43, 0.18))
    drop-shadow(0 14px 12px rgba(90, 60, 30, 0.12))
    saturate(1.06) contrast(1.03) brightness(1.01);
}
.card-photo img[src*="naigai.png"]      { --pet-ground-shift: 11.3%; }
.card-photo img[src*="zhima.png"]       { --pet-ground-shift: 17.9%; }
.card-photo img[src*="buding.png"]      { --pet-ground-shift: 13.7%; }
.card-photo img[src*="kele.png"]        { --pet-ground-shift: 9.3%; }
.card-photo img[src*="mianhuatang.png"] { --pet-ground-shift: 20.2%; }
.card-photo img[src*="doudou.png"]      { --pet-ground-shift: 13.3%; }
</style>
