import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

// 样式分层：令牌 → 基础层 → 公共组件层（顺序不可调换）
import './styles/tokens.css'
import './styles/base.css'
import './styles/components.css'

const app = createApp(App).use(router)

// 等首个路由解析完成再挂载：首屏直接渲染真实页面，
// 不会先空一帧再触发入场过渡，避免闪白。
router.isReady().then(() => app.mount('#app'))
