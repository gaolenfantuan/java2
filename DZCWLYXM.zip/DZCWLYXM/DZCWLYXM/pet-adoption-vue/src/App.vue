<script setup>
// 全局外壳：固定导航（准入页除外）+ 统一路由过渡 + 背景装饰
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import MainNav from './components/MainNav.vue'

const route = useRoute()
// 准入门页与后台管理页不显示前台导航（后台有自己的侧边栏）
const showNav = computed(() => route.meta.public !== true && route.meta.hideNav !== true)
</script>

<template>
  <div class="bg-deco" aria-hidden="true">
    <div class="burst one"></div>
    <div class="burst two"></div>
    <div class="float a">🐾</div>
    <div class="float b">💛</div>
    <div class="float c">🦴</div>
    <div class="float d">🐾</div>
  </div>

  <!-- 全局固定导航：除准入页外所有页面共用，切换时导航常驻不消失 -->
  <MainNav v-if="showNav" />

  <RouterView v-slot="{ Component }">
    <Transition name="page" mode="out-in">
      <component :is="Component" />
    </Transition>
  </RouterView>
</template>
