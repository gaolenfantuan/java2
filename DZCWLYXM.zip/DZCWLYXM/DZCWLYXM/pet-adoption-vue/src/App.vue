<script setup>
// 全局固定导航常驻（登录页除外），页面结构交给 router-view
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import MainNav from './components/MainNav.vue'

const route = useRoute()
const showNav = computed(() => route.path !== '/login')
</script>

<template>
  <div class="bg-deco" aria-hidden="true">
    <div class="burst one"></div>
    <div class="burst two"></div>
    <div class="float a">🐾</div>
    <div class="float b">💛</div>
    <div class="float c">🦴</div>
    <div class="float d">🐾</div>
  </div>

  <!-- 全局固定导航：除登录页外所有页面共用，切换时导航常驻不消失 -->
  <MainNav v-if="showNav" />

  <router-view />
</template>
