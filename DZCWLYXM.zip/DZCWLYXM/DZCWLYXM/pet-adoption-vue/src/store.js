// 全局共享状态（纯 Vue reactive，无第三方库）
// 用于跨页面共享：搜索词（首页筛选）、徽章数（导航角标）、浏览历史（个人中心）
import { reactive } from 'vue'

const HISTORY_KEY = 'petHistory'

function loadHistory() {
  try {
    const arr = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]')
    return Array.isArray(arr) ? arr : []
  } catch {
    return []
  }
}

export const store = reactive({
  searchQuery: '',
  unlockedBadgeCount: 0,
  history: loadHistory()
})

// 浏览历史：记录看过的宠物 id（置顶去重，最多 12 条），持久化
export function recordHistory(id) {
  if (id == null) return
  const num = Number(id)
  const next = [num, ...store.history.filter(x => Number(x) !== num)].slice(0, 12)
  store.history = next
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(next))
  } catch { /* ignore */ }
}

export function clearHistory() {
  store.history = []
  try {
    localStorage.setItem(HISTORY_KEY, '[]')
  } catch { /* ignore */ }
}
