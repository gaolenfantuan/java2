// 全局共享状态（纯 Vue reactive，无第三方库）
// 用于跨页面共享：搜索词（首页筛选）、徽章数（导航角标）、浏览历史、游戏币钱包、背包
import { reactive } from 'vue'

const HISTORY_KEY = 'petHistory'
const HISTORY_LOG_KEY = 'petHistoryLog'
const COIN_KEY = 'petCoins'
const BAG_KEY = 'petBackpack'
const DAILY_KEY = 'petDailyState'
const WORN_KEY = 'petWornBadge'
const GAME_TOTAL_KEY = 'petGameTotal'
const PURCHASE_TOTAL_KEY = 'petTotalPurchases'
const DIARY_KEY = 'petDiary'

// 新用户初始游戏币：够在商城买几件小物，避免空钱包逛商城
const DEFAULT_COINS = 268

function readArr(key) {
  try {
    const arr = JSON.parse(localStorage.getItem(key) || '[]')
    return Array.isArray(arr) ? arr : []
  } catch {
    return []
  }
}

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return fallback
    const val = JSON.parse(raw)
    return val == null ? fallback : val
  } catch {
    return fallback
  }
}

function todayKey() {
  const d = new Date()
  const p = n => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

function loadCoins() {
  const raw = localStorage.getItem(COIN_KEY)
  // 首次访问（没有记录 / 空串）给一份初始游戏币，避免新用户空钱包逛商城
  if (raw == null || raw === '') return DEFAULT_COINS
  const n = Number(raw)
  return Number.isFinite(n) && n >= 0 ? n : DEFAULT_COINS
}

function loadBackpack() {
  const arr = readJSON(BAG_KEY, [])
  if (!Array.isArray(arr)) return []
  return arr
    .filter(it => it && it.id && Number(it.count) > 0)
    .map(it => ({ id: it.id, count: Number(it.count) }))
}

function emptyDaily() {
  return { date: todayKey(), games: 0, bestScore: 0, purchases: 0, signed: false, earned: 0, claimed: [] }
}

function loadDaily() {
  const saved = readJSON(DAILY_KEY, null)
  // 跨天自动重置每日任务进度
  if (!saved || saved.date !== todayKey()) return emptyDaily()
  return {
    ...emptyDaily(),
    ...saved,
    claimed: Array.isArray(saved.claimed) ? saved.claimed : []
  }
}

export const store = reactive({
  searchQuery: '',
  unlockedBadgeCount: 0,
  history: readArr(HISTORY_KEY),
  // 浏览时间戳：{ [petId]: 毫秒数 }，用于「浏览历史」按时间分组
  historyLog: readJSON(HISTORY_LOG_KEY, {}),
  // 当前佩戴到主页的徽章 id（空串表示未佩戴）
  wornBadge: localStorage.getItem(WORN_KEY) || '',
  // 游戏币钱包
  coins: loadCoins(),
  // 背包：[{ id, count }]
  backpack: loadBackpack(),
  // 每日任务与战绩（跨天重置）
  daily: loadDaily(),
  // 累计数据（用于徽章解锁，不随每日重置）
  totalGames: Number(localStorage.getItem(GAME_TOTAL_KEY) || 0) || 0,
  totalPurchases: Number(localStorage.getItem(PURCHASE_TOTAL_KEY) || 0) || 0,
  // 成长日记：[{ id, petId, petName, text, mood, time }]
  diary: readArr(DIARY_KEY)
})

function persistDaily() {
  try {
    localStorage.setItem(DAILY_KEY, JSON.stringify(store.daily))
  } catch { /* ignore */ }
}

function persistCoins() {
  try {
    localStorage.setItem(COIN_KEY, String(store.coins))
  } catch { /* ignore */ }
}

function persistBackpack() {
  try {
    localStorage.setItem(BAG_KEY, JSON.stringify(store.backpack))
  } catch { /* ignore */ }
}

// 跨天时在页面初始化调用，确保日期切换后任务进度归零
export function ensureDailyFresh() {
  if (store.daily.date !== todayKey()) {
    store.daily = emptyDaily()
    persistDaily()
  }
}

// ===== 游戏币 =====
export function addCoins(amount) {
  const n = Math.max(0, Math.round(Number(amount) || 0))
  if (!n) return 0
  store.coins += n
  persistCoins()
  return n
}

export function spendCoins(amount) {
  const n = Math.max(0, Math.round(Number(amount) || 0))
  if (store.coins < n) return false
  store.coins -= n
  persistCoins()
  return true
}

// ===== 背包 =====
export function itemCount(id) {
  const found = store.backpack.find(it => it.id === id)
  return found ? found.count : 0
}

export function addItem(id, count = 1) {
  if (!id) return
  const n = Math.max(1, Math.round(Number(count) || 1))
  const found = store.backpack.find(it => it.id === id)
  if (found) found.count += n
  else store.backpack.push({ id, count: n })
  persistBackpack()
}

export function removeItem(id, count = 1) {
  const n = Math.max(1, Math.round(Number(count) || 1))
  const index = store.backpack.findIndex(it => it.id === id)
  if (index === -1) return false
  const item = store.backpack[index]
  if (item.count < n) return false
  item.count -= n
  if (item.count <= 0) store.backpack.splice(index, 1)
  persistBackpack()
  return true
}

export function bagTotalCount() {
  return store.backpack.reduce((sum, it) => sum + it.count, 0)
}

// ===== 每日任务 =====
export function isTaskClaimed(taskId) {
  return store.daily.claimed.includes(taskId)
}

export function claimTask(taskId, reward) {
  if (isTaskClaimed(taskId)) return false
  store.daily.claimed.push(taskId)
  persistDaily()
  addCoins(reward)
  return true
}

// 一局游戏结束：累计局数、最高分、今日赚币
export function recordGameRound(score, coins) {
  store.daily.games += 1
  store.daily.bestScore = Math.max(store.daily.bestScore, Math.round(Number(score) || 0))
  const earned = addCoins(coins)
  store.daily.earned += earned
  persistDaily()
  // 累计局数用于「游戏高手」徽章
  store.totalGames += 1
  try { localStorage.setItem(GAME_TOTAL_KEY, String(store.totalGames)) } catch { /* ignore */ }
  return earned
}

// 商城购买：计入每日「购买 1 件」任务进度 + 累计兑换数
export function recordPurchase() {
  store.daily.purchases += 1
  persistDaily()
  store.totalPurchases += 1
  try { localStorage.setItem(PURCHASE_TOTAL_KEY, String(store.totalPurchases)) } catch { /* ignore */ }
}

// ===== 佩戴徽章 =====
export function setWornBadge(id) {
  store.wornBadge = id || ''
  try {
    if (store.wornBadge) localStorage.setItem(WORN_KEY, store.wornBadge)
    else localStorage.removeItem(WORN_KEY)
  } catch { /* ignore */ }
}

// ===== 成长日记 =====
function persistDiary() {
  try { localStorage.setItem(DIARY_KEY, JSON.stringify(store.diary)) } catch { /* ignore */ }
}

export function addDiary({ petId = 0, petName = '', text = '', mood = '🥰' }) {
  const body = String(text || '').trim()
  if (!body) return null
  const now = new Date()
  const p = n => String(n).padStart(2, '0')
  const entry = {
    id: `${now.getTime()}-${Math.random().toString(36).slice(2, 6)}`,
    petId: Number(petId) || 0,
    petName,
    text: body.slice(0, 120),
    mood,
    time: `${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())} ${p(now.getHours())}:${p(now.getMinutes())}`
  }
  store.diary = [entry, ...store.diary].slice(0, 60)
  persistDiary()
  return entry
}

export function removeDiary(id) {
  store.diary = store.diary.filter(it => it.id !== id)
  persistDiary()
}

// ===== 浏览历史 =====
function persistHistoryLog() {
  try { localStorage.setItem(HISTORY_LOG_KEY, JSON.stringify(store.historyLog)) } catch { /* ignore */ }
}

export function recordHistory(id) {
  if (id == null) return
  const num = Number(id)
  const next = [num, ...store.history.filter(x => Number(x) !== num)].slice(0, 24)
  store.history = next
  // 记录浏览时间，供「浏览历史」按今天 / 昨天 / 更早分组
  store.historyLog = { ...store.historyLog, [num]: Date.now() }
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(next))
  } catch { /* ignore */ }
  persistHistoryLog()
}

// 删除单条浏览记录
export function removeHistory(id) {
  const num = Number(id)
  store.history = store.history.filter(x => Number(x) !== num)
  const next = { ...store.historyLog }
  delete next[num]
  store.historyLog = next
  try { localStorage.setItem(HISTORY_KEY, JSON.stringify(store.history)) } catch { /* ignore */ }
  persistHistoryLog()
}

export function clearHistory() {
  store.history = []
  store.historyLog = {}
  try {
    localStorage.setItem(HISTORY_KEY, '[]')
  } catch { /* ignore */ }
  persistHistoryLog()
}

// ===== 毛孩子的家：状态条 / 装扮 / 相册 / 照料记录 =====
const HOME_KEY = 'petHomeState'

// 按宠物 id 存放：{ [petId]: { hunger, mood, health, outfit, photos, events, adoptedAt } }
export const petHomes = reactive(readJSON(HOME_KEY, {}))

// 兼容旧数据：早期小屋只有饱腹/心情/健康三条，这里补齐「清洁值」
Object.keys(petHomes).forEach(k => {
  const h = petHomes[k]
  if (h && typeof h === 'object' && h.clean == null) {
    const seed = Math.abs(Number(k) || 1)
    h.clean = 62 + (seed * 11) % 20
  }
})

function persistHomes() {
  try { localStorage.setItem(HOME_KEY, JSON.stringify(petHomes)) } catch { /* ignore */ }
}

function clamp100(v) {
  const n = Math.round(Number(v) || 0)
  return n < 0 ? 0 : n > 100 ? 100 : n
}

// 首次进入毛孩子的家：给一份略有差异的初始状态，让每只毛孩子都不太一样
export function petHomeOf(petId) {
  const key = String(Number(petId) || 0)
  if (!petHomes[key]) {
    const seed = Math.abs(Number(petId) || 1)
    petHomes[key] = {
      hunger: 58 + (seed * 7) % 24,
      mood: 66 + (seed * 5) % 22,
      health: 74 + (seed * 3) % 18,
      // 清洁值：也会随时间缓慢下降，洗澡/打扫道具可以补回来
      clean: 62 + (seed * 11) % 20,
      outfit: '',
      photos: [],
      events: [],
      // 领养日：默认取一个过去的日子，让成长时间线先有内容可看
      adoptedAt: Date.now() - (12 + seed * 6) * 86400000,
      updatedAt: Date.now(),
      cares: 0
    }
  }
  return petHomes[key]
}

// 离线期间缓慢掉状态（回来喂一顿就能补上），最多掉 26 点
export function decayPetHome(petId) {
  const home = petHomeOf(petId)
  const now = Date.now()
  const hours = (now - (Number(home.updatedAt) || now)) / 3600000
  if (hours < 1) return home
  const lost = Math.min(26, Math.min(hours, 20) * 1.5)
  home.hunger = clamp100(home.hunger - lost)
  home.mood = clamp100(home.mood - lost * 0.7)
  home.health = clamp100(home.health - lost * 0.3)
  if (home.clean == null) home.clean = 70
  home.clean = clamp100(home.clean - lost * 0.5)
  home.updatedAt = now
  persistHomes()
  return home
}

// 一次照料行为：加数值 + 记一条时间线事件
export function carePet(petId, plan = {}) {
  const home = petHomeOf(petId)
  home.hunger = clamp100(home.hunger + (plan.hunger || 0))
  home.mood = clamp100(home.mood + (plan.mood || 0))
  home.health = clamp100(home.health + (plan.health || 0))
  if (home.clean == null) home.clean = 70
  home.clean = clamp100(home.clean + (plan.clean || 0))
  home.cares = (Number(home.cares) || 0) + 1
  home.updatedAt = Date.now()
  if (plan.event) {
    const event = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      icon: plan.event.icon || '🐾',
      title: plan.event.title || '陪毛孩子待了一会儿',
      note: plan.event.note || '',
      tone: plan.event.tone || 'yellow',
      at: Date.now()
    }
    home.events = [event, ...(Array.isArray(home.events) ? home.events : [])].slice(0, 24)
  }
  persistHomes()
  return home
}

export function setPetOutfit(petId, outfitId) {
  const home = petHomeOf(petId)
  home.outfit = outfitId || ''
  persistHomes()
  return home
}

export function addPetPhoto(petId, photo = {}) {
  const home = petHomeOf(petId)
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    mood: photo.mood || '🥰',
    note: photo.note || '',
    at: Date.now()
  }
  home.photos = [entry, ...(Array.isArray(home.photos) ? home.photos : [])].slice(0, 18)
  persistHomes()
  return entry
}

export function removePetPhoto(petId, photoId) {
  const home = petHomeOf(petId)
  home.photos = (Array.isArray(home.photos) ? home.photos : []).filter(p => p.id !== photoId)
  persistHomes()
  return home
}
