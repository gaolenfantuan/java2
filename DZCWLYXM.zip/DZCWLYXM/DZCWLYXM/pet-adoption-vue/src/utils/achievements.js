// 爱心成就徽章：纯前端 localStorage 存储，不依赖后端
import { hasAnyRescueDone } from '../data/rescuePets'

export const badges = [
  {
    id: 'first-visit',
    name: '初来乍到',
    desc: '第一次来到毛茸茸领养站',
    icon: '🐾',
    color: '#ffd84d'
  },
  {
    id: 'collector',
    name: '爱心收藏家',
    desc: '收藏满 5 只毛孩子',
    icon: '💖',
    color: '#ff9ec4'
  },
  {
    id: 'match-master',
    name: '缘分达人',
    desc: '完成 3 次缘分匹配测试',
    icon: '💘',
    color: '#9fd3ff'
  },
  {
    id: 'adopt-ready',
    name: '领养预备役',
    desc: '提交 1 次领养申请',
    icon: '🏠',
    color: '#8fd9c4'
  },
  {
    id: 'rescue-hero',
    name: '救助萌新',
    desc: '完成第一只流浪宠物的救助',
    icon: '🚑',
    color: '#ffb3b3'
  }
]

const STORAGE_KEY = 'petAchievements'

function readJSON(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || 'null')
    return value ?? fallback
  } catch {
    return fallback
  }
}

function getState() {
  const saved = readJSON(STORAGE_KEY, {})
  return {
    visited: !!saved.visited,
    matchCount: Number(saved.matchCount) || 0,
    unlocked: Array.isArray(saved.unlocked) ? saved.unlocked : []
  }
}

function getFavoritesCount() {
  const favorites = readJSON('petFavorites', [])
  return Array.isArray(favorites) ? favorites.length : 0
}

function getApplyCount() {
  const statuses = readJSON('petApplyStatuses', {})
  return statuses && typeof statuses === 'object' ? Object.keys(statuses).length : 0
}

function getMatchCount() {
  const count = Number(localStorage.getItem('petMatchCount') || 0)
  return Number.isFinite(count) ? count : 0
}

// 每次调用都会重新计算条件，并把新解锁的徽章返回给调用方做庆祝动画
export function syncAchievements() {
  const state = getState()
  if (!state.visited) state.visited = true

  const favoritesCount = getFavoritesCount()
  const applyCount = getApplyCount()
  const matchCount = getMatchCount()

  const reached = {
    'first-visit': true,
    collector: favoritesCount >= 5,
    'match-master': matchCount >= 3,
    'adopt-ready': applyCount >= 1,
    'rescue-hero': hasAnyRescueDone()
  }

  const newlyUnlocked = []
  badges.forEach(badge => {
    if (reached[badge.id] && !state.unlocked.includes(badge.id)) {
      state.unlocked.push(badge.id)
      newlyUnlocked.push(badge)
    }
  })

  state.matchCount = matchCount
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  return { state, newlyUnlocked }
}

// 完成一次缘分匹配后调用
export function recordMatchComplete() {
  const next = getMatchCount() + 1
  localStorage.setItem('petMatchCount', String(next))
  return next
}

// 徽章进度文案，用于「我的徽章」页面
export function getBadgeProgress(badgeId) {
  switch (badgeId) {
    case 'collector':
      return `${Math.min(getFavoritesCount(), 5)} / 5`
    case 'match-master':
      return `${Math.min(getMatchCount(), 3)} / 3`
    case 'adopt-ready':
      return `${Math.min(getApplyCount(), 1)} / 1`
    case 'rescue-hero':
      return hasAnyRescueDone() ? '已解锁' : '0 / 1'
    default:
      return '已开启'
  }
}
