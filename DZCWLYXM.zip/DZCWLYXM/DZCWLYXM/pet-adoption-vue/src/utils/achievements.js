// 爱心成就徽章：纯前端 localStorage 存储，不依赖后端
import { hasAnyRescueDone, getDoneIds } from '../data/rescuePets'

// 徽章分类：用于「我的徽章」分类切换
export const badgeCategories = [
  { value: 'all', label: '全部', icon: '✨' },
  { value: 'growth', label: '成长', icon: '🌱' },
  { value: 'love', label: '爱心', icon: '💖' },
  { value: 'fun', label: '趣味', icon: '🎈' },
  { value: 'rescue', label: '救助', icon: '🚑' }
]

export const badges = [
  {
    id: 'first-visit',
    name: '初来乍到',
    desc: '第一次来到毛茸茸领养站',
    tip: '只要在站内逛一逛，这枚徽章就是你的啦～',
    icon: '🐾',
    color: '#ffd84d',
    category: 'growth',
    cta: { label: '回首页逛逛', path: '/' }
  },
  {
    id: 'adopt-ready',
    name: '领养预备役',
    desc: '提交 1 次领养申请',
    tip: '挑一只喜欢的毛孩子，认真填写申请就能解锁。',
    icon: '🏠',
    color: '#8fd9c4',
    category: 'growth',
    cta: { label: '去提交申请', path: '/adopt' }
  },
  {
    id: 'diary-keeper',
    name: '日记小作家',
    desc: '写下 3 篇成长日记',
    tip: '把和毛孩子的小事记下来，写满 3 篇就点亮它。',
    icon: '📔',
    color: '#9fd3ff',
    category: 'growth',
    target: 3,
    cta: { label: '写第一篇日记', path: '/my-pets?diary=1' }
  },
  {
    id: 'collector',
    name: '爱心收藏家',
    desc: '收藏满 5 只毛孩子',
    tip: '在首页卡片右上角点小爱心，攒满 5 只就解锁。',
    icon: '💖',
    color: '#ff9ec4',
    category: 'love',
    target: 5,
    cta: { label: '去收藏毛孩子', path: '/adopt' }
  },
  {
    id: 'badge-legend',
    name: '徽章收藏家',
    desc: '累计解锁 6 枚徽章',
    tip: '你已经离得很近啦，把其它徽章都点亮吧！',
    icon: '👑',
    color: '#ffd84d',
    category: 'love',
    target: 6,
    cta: { label: '继续收集徽章', path: '/my-pets' }
  },
  {
    id: 'match-master',
    name: '缘分达人',
    desc: '完成 3 次缘分匹配测试',
    tip: '首页那张「测测你的专属毛孩子」卡片，做 3 次就好。',
    icon: '💘',
    color: '#ffc9b8',
    category: 'fun',
    target: 3,
    cta: { label: '去做缘分测试', path: '/' }
  },
  {
    id: 'game-lover',
    name: '游戏高手',
    desc: '累计在萌宠乐园玩满 10 局',
    tip: '每局只要 15 秒，顺手还能赚游戏币换零食。',
    icon: '🎮',
    color: '#c9b8ff',
    category: 'fun',
    target: 10,
    cta: { label: '去萌宠乐园', path: '/playground' }
  },
  {
    id: 'shop-spirit',
    name: '商城常客',
    desc: '累计在积分商城兑换 5 件物品',
    tip: '玩小游戏攒币，再去商城换点小零食试试。',
    icon: '🛍️',
    color: '#ffb3b3',
    category: 'fun',
    target: 5,
    cta: { label: '去积分商城', path: '/shop' }
  },
  {
    id: 'rescue-hero',
    name: '救助萌新',
    desc: '完成第一只流浪宠物的救助',
    tip: '去流浪救助页帮一只小可怜，它会有新家的。',
    icon: '🚑',
    color: '#8fd9c4',
    category: 'rescue',
    cta: { label: '去救助一只', path: '/rescue' }
  }
]

const STORAGE_KEY = 'petAchievements'

function readJSON(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || 'null')
    return value ?? fallback
  } catch {
    return fallback
  }
}

function readNumber(key) {
  const n = Number(localStorage.getItem(key) || 0)
  return Number.isFinite(n) ? n : 0
}

function getState() {
  const saved = readJSON(STORAGE_KEY, {})
  return {
    visited: !!saved.visited,
    matchCount: Number(saved.matchCount) || 0,
    unlocked: Array.isArray(saved.unlocked) ? saved.unlocked : [],
    times: saved.times && typeof saved.times === 'object' ? saved.times : {}
  }
}

function getFavoritesCount() {
  const favorites = readJSON('petFavorites', [])
  return Array.isArray(favorites) ? favorites.length : 0
}

function getApplyCount() {
  const statuses = readJSON('petApplyStatuses', {})
  return statuses && typeof statuses === 'object' ? Object.keys(statuses).length : 0
}

function getMatchCount() {
  return readNumber('petMatchCount')
}

// 各徽章的当前进度（数值），用于进度条与「还差 X」文案
export function getBadgeProgressValue(badgeId) {
  switch (badgeId) {
    case 'collector':
      return { cur: Math.min(getFavoritesCount(), 5), target: 5 }
    case 'match-master':
      return { cur: Math.min(getMatchCount(), 3), target: 3 }
    case 'adopt-ready':
      return { cur: Math.min(getApplyCount(), 1), target: 1 }
    case 'diary-keeper':
      return { cur: Math.min(readJSON('petDiary', []).length, 3), target: 3 }
    case 'game-lover':
      return { cur: Math.min(readNumber('petGameTotal'), 10), target: 10 }
    case 'shop-spirit':
      return { cur: Math.min(readNumber('petTotalPurchases'), 5), target: 5 }
    case 'badge-legend': {
      const unlocked = getState().unlocked.filter(id => id !== 'badge-legend').length
      return { cur: Math.min(unlocked, 6), target: 6 }
    }
    case 'rescue-hero':
      return { cur: Math.min(getDoneIds().length, 1), target: 1 }
    default:
      return { cur: 1, target: 1 }
  }
}

// 每次调用都会重新计算条件，并把新解锁的徽章返回给调用方做庆祝动画
export function syncAchievements() {
  const state = getState()
  if (!state.visited) state.visited = true

  const favoritesCount = getFavoritesCount()
  const applyCount = getApplyCount()
  const matchCount = getMatchCount()

  const reached = {
    'first-visit': true,
    collector: favoritesCount >= 5,
    'match-master': matchCount >= 3,
    'adopt-ready': applyCount >= 1,
    'rescue-hero': hasAnyRescueDone(),
    'game-lover': readNumber('petGameTotal') >= 10,
    'shop-spirit': readNumber('petTotalPurchases') >= 5,
    'diary-keeper': readJSON('petDiary', []).length >= 3
  }

  const newlyUnlocked = []
  badges.forEach(badge => {
    // 「徽章收藏家」依赖其它徽章的解锁数量，放在最后判定
    const ok = badge.id === 'badge-legend'
      ? state.unlocked.filter(id => id !== 'badge-legend').length >= 6
      : reached[badge.id]
    if (ok && !state.unlocked.includes(badge.id)) {
      state.unlocked.push(badge.id)
      state.times[badge.id] = Date.now()
      newlyUnlocked.push(badge)
    }
  })

  state.matchCount = matchCount
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  return { state, newlyUnlocked }
}

// 完成一次缘分匹配后调用
export function recordMatchComplete() {
  const next = getMatchCount() + 1
  localStorage.setItem('petMatchCount', String(next))
  return next
}

// 徽章文字进度，用于「我的徽章」页面
export function getBadgeProgress(badgeId) {
  const { cur, target } = getBadgeProgressValue(badgeId)
  if (badgeId === 'first-visit') return '已开启'
  return `${cur} / ${target}`
}
