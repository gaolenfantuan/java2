// 关键词高亮的公共工具：首页卡片与导航搜索联想共用同一套逻辑。
// 先转义 HTML 再包裹 <mark>，避免任何注入风险。

const ESCAPE_MAP = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;'
}

export function escapeHtml(text) {
  return String(text ?? '').replace(/[&<>"']/g, ch => ESCAPE_MAP[ch])
}

export function highlightHtml(text, keyword) {
  const safe = escapeHtml(text)
  const kw = String(keyword ?? '').trim()
  if (!kw) return safe
  const pattern = escapeHtml(kw).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  return safe.replace(new RegExp(pattern, 'gi'), matched => `<mark class="kw">${matched}</mark>`)
}
