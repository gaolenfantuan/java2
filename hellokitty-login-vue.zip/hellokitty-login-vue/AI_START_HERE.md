# AI_START_HERE —— 前端项目速查（给 AI 自己看的）

完整说明见后端项目根目录：`D:\workSpace\springBootTest\AI_START_HERE.md`

## 关键信息

- 路径：`C:\Users\彭彭\Desktop\hellokitty-login-vue`，Vue 3 + Vite 6，端口 5173
- 启动：双击 `scripts\启动前端.bat`（会自动检测 node、缺依赖自动还原缓存/npm ci）
- 停止：双击 `scripts\停止前端.bat`
- `node_modules` 每次开机被删 → 脚本已处理，别手动跑去 `npm install` 浪费时间
- Node：`C:\Program Files\nodejs\node.exe`
- 后端接口经 Vite 代理 `/api` → `http://localhost:8080`，配置在 `vite.config.js`
- 接口封装：`src/api/auth.js`（login / register / checkUsername）、`src/api/home.js`（分类/搜索/热门/详情/统计）

## 路由（已上 vue-router 4.6）

| 路径 | 组件 | 说明 |
|------|------|------|
| `/` | — | 重定向到 `/login` |
| `/login` | `components/KittyLogin.vue` | 登录页 |
| `/register` | `components/KittyRegister.vue` | 注册页 |
| `/home` | `views/Home.vue` | 首页，`meta.requiresAuth: true` |
| `/admin/login` | `views/admin/AdminLogin.vue` | 后台登录页（**只有登录，没有注册**） |
| `/admin` | `views/admin/AdminLayout.vue` | 后台布局（侧边栏 + 内容区），`redirect: /admin/dashboard`，`meta.requiresAdmin: true` |
| `/admin/dashboard` | `views/admin/AdminDashboard.vue` | 数据概览 |
| `/admin/items` | `views/admin/AdminItems.vue` | 内容管理（搜索/分页/新增/编辑/上下架/删除） |
| `/admin/categories` | `views/admin/AdminCategories.vue` | 分类管理（分级增删改查） |
| 其他 | — | 兜底重定向到 `/login` |

- 路由表：`src/router/index.js`；守卫逻辑单独在 `src/router/guard.js`（不 import .vue，可用 Node 直接测）
- 守卫规则：
  - `to.meta.requiresAuth && !isLoggedIn()` → 跳 `/login?redirect=<原地址>`（前台普通用户）
  - `to.meta.requiresAdmin && !isAdminLoggedIn()` → 跳 `/admin/login?redirect=<原地址>`（后台管理员，token 互相独立）
- 登录成功后 `router.replace(route.query.redirect || '/home')`
- 登录态工具：
  - `src/utils/auth.js`（`saveUser/getUser/getToken/isLoggedIn/clearUser`）
  - `src/utils/adminAuth.js`（`saveAdmin/getAdmin/isAdminLoggedIn/clearAdmin`）—— 后台专用，key 是 `kitty_admin`
- 存储约定：勾"记住我"→ `localStorage.kitty_user`，否则 `sessionStorage.kitty_user`；管理员 token 始终存 `localStorage.kitty_admin`
- 接口封装：`src/api/auth.js`（login/register/checkUsername）、`src/api/home.js`（分类/搜索/热门/详情/统计）、`src/api/admin.js`（后台登录/登出/概览/内容 CRUD/分类 CRUD）
- `App.vue` 现在只有 `<router-view />`，页面切换全部走路由（原来的 `view` ref 已删除）
- 首页导航栏「后台管理」按钮在 `components/home/HomeNav.vue`，点击 `router.push('/admin/login')`；已登录管理员访问登录页会自动跳后台（`AdminLogin.vue` 的 `onMounted`）

## 首页（views/Home.vue）—— 已接后端

- 数据全部来自 `/api/home/*`（Spring Boot + H2），**前端不再有假数据**
- `onMounted` 并行请求三个接口：分类树 / 统计 / 首屏列表（`Promise.all`）
- 状态：`keyword`（300ms 防抖）、`primaryId`（一级分类 0=全部）、`subId`（二级分类 0=本类全部）、`sort`（default/hot/new）
- 点一级分类 → 第二排 chips 出现它的 `children`；搜索 + 分类 + 排序三个条件在**后端**一起生效
- 分页：`PAGE_SIZE=12`，`hasNext` 为真时显示「看看更多」，追加到列表
- 点卡片会调 `/api/home/items/{id}`（后端浏览量 +1），把真实分类/浏览量用 toast 显示；详情页本身没做
- 卡片封面是 emoji + 渐变（`cover_bg` 字段），**故意不用外部图片**，避免离线裂图
- 统计条显示 内容总数 / 分类数 / 累计点赞，均来自 `/api/home/stats`
- 出错时显示「连不上服务器…」+ 重新加载按钮，不是前端 bug

## 视觉验证技巧（没有浏览器自动化时用这个）

本机有 Edge：`C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`，可以无头截图。

```bash
# 1) 先在 public/ 放一个临时页注入登录态，再跳 /home（否则守卫会把截图弹回登录页）
#    sessionStorage.setItem('kitty_user', JSON.stringify({...token...})); location.replace('/home')
msedge --headless=new --disable-gpu --hide-scrollbars --force-device-scale-factor=1 \
       --window-size=1280,780 --virtual-time-budget=7000 --screenshot=d3.png http://localhost:5173/__shot.html
```

- **Windows 无头窗口有最小宽度约 500px**，`--window-size=375` 不会真的变 375，会裁切造成"横向溢出"的假象
  → 验证手机布局要套一层 `<iframe src="/home" style="width:375px">`，量尺寸用 `iframe.contentDocument.documentElement.scrollWidth`
- 截图/量宽度都必须在**同一条 bash 命令**里完成（dev server 会被回收），用完删掉 `public/__*.html` 再 build

## 坑

- **npm 官方源在本机不通**（`curl registry.npmjs.org` 返回 000，`npm install` 会卡住几分钟）
  → 项目根有 `.npmrc` 固定 `registry=https://registry.npmmirror.com`，装包用它，实测 50 秒装完
- 改了 `package.json` 必须重建 `.deps-cache\node_modules.zip`（`deps-cache.ps1 save`），否则下次开机缓存被判过期会重装
- 后端没起时页面提示"连不上服务器"，不是前端 bug
- 本机 curl 测试要先 `unset HTTP_PROXY HTTPS_PROXY`
- 脚本是 GBK + CRLF 编码，别用 UTF-8 保存
- 路由用 `createWebHistory`，直接访问 `/home` 依赖 dev server 的 SPA 回退（Vite 默认支持）；若以后部署到 Nginx 要配 `try_files`
